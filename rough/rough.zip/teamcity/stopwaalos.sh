#!/bin/bash
ps -ef | grep "[j]ava -jar" |  awk '{print $2}' | xargs -r kill -9