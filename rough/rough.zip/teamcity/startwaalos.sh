#!/bin/bash

nohup java -jar /home/waalos/services/wms-*.jar --spring.config.location=file:/home/waalos/config/wms.yml> /opt/home/waalos/deployment/wms.log 2 &
sleep 5

nohup java -jar /home/waalos/services/fileprocessing-*.jar --spring.config.location=file:/home/waalos/config/fileprocessing.yml>  /opt/home/waalos/deployment/fileprocesing.log 2 &
sleep 5

nohup java -jar /home/waalos/services/slotting-*.jar --spring.config.location=file:/home/waalos/config/slotting.yml> /opt/home/waalos/deployment/slotting.log 2 &
sleep 5

nohup java -jar /home/waalos/services/waalosreports-*.jar --spring.config.location=file:/home/waalos/config/waalosreports.yml> /opt/home/waalos/deployment/waalosreports.log 2 &
sleep 5

nohup java -jar /home/waalos/services/prewavereport-*.jar --spring.config.location=file:/home/waalos/config/prewavereport.yml>  /opt/home/waalos/deployment/prewavereport.log 2 &
sleep 5

nohup java -jar /home/waalos/services/customertool-*.jar --spring.config.location=file:/home/waalos/config/customertool.yml>  /opt/home/waalos/deployment/customertool.log 2 &
sleep 5

nohup java -jar /home/waalos/services/waalosadmin-*.jar >  /opt/home/waalos/deployment/waalosadmin.log 2 &
