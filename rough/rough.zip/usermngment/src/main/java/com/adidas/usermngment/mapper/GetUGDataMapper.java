package com.adidas.usermngment.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.TreeMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.RowMapper;

@SuppressWarnings("rawtypes")
public class GetUGDataMapper implements RowMapper {
	private static final Logger LOGGER = LoggerFactory.getLogger(UGDashboardDataMapper.class);
	
	@SuppressWarnings("unchecked")
	@Override
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		List<String> funsList = null;
		TreeMap<String, List<String>> dcTemp = null;
		Map<String, TreeMap<String, List<String>>> ugFinal = null;
		Object returnObj = null;
			try {
				if(rs==null) {
					returnObj = null;
				}else {
					ugFinal = new HashMap <String, TreeMap<String, List<String>>>();
					do {
						 if(!(ugFinal.containsKey(rs.getString("role_nm")))) {
		            		 dcTemp = new TreeMap<String, List<String>>();
		            	 }
						 
		            	 if(dcTemp.containsKey(rs.getString("dc_nm"))) {
		            		funsList = dcTemp.get(rs.getString("dc_nm"));
		            	 }else {
		            		 funsList = new ArrayList<String>();
		            	 }
		            	 funsList.add(rs.getString("functnal_nm"));
		            	 dcTemp.put(rs.getString("dc_nm"), funsList);
		            	 ugFinal.put(rs.getString("role_nm"), dcTemp);
	            	}while(rs.next());
					returnObj = ugFinal;
				}
			}catch(Exception ex) {
				LOGGER.info("Exception while preparing the JSON at Row Mapper");
				LOGGER.error("Exception caught at Row Mapper...... ",ex.getMessage());
			}finally {
				funsList = null;
				dcTemp = null;
				ugFinal=null;
			}
			return returnObj;
	}
}
