package com.adidas.usermngment.util;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.security.jwt.JwtHelper;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestOperations;
import org.springframework.web.client.RestTemplate;

import com.adidas.usermngment.config.ApplicationConfiguration;
import com.adidas.usermngment.service.UserMngmentService;
import com.adidas.waaloscommon.dto.usermngmntdto.OAuthTokenResponse;
import com.adidas.waaloscommon.dto.usermngmntdto.UserResponseDto;
import com.adidas.waaloscommon.exception.WaalosErrorResponse;
import com.adidas.waaloscommon.exception.WaalosException;

@Component
public class AdfsTokenGeneration {

	private static final Logger LOGGER = LoggerFactory.getLogger(AdfsTokenGeneration.class);

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private ApplicationConfiguration config;

	@Autowired
	RestOperations restOperations;
	
	@Autowired
	private UserMngmentService userMngmntService;

	/*
	 * This method was used to generate ADFS token for the specific user details, now commented after AzureAD.
	
	 * @param username
	 * @param password
	 * @return the Userdetails
     
	@SuppressWarnings("unused")
	public Object generateAdfsAccessToken(String userName, String password,String ugName, String fName, String lName, 
			String defaultPrinterIp, String defaultPrinterName, int defaultPrinterId, String port) {
		LOGGER.info("Entering into generateAdfsAccessToken ", System.currentTimeMillis());
		UserResponseDto userResponseDto = null;
		OAuthTokenResponse oauthTokenResponse = null;
		try {
			LOGGER.info("userName...................{} ", userName);
			final MultiValueMap<String, String> parameters = getAdfsQueryParameters(userName, password);
			final MultiValueMap<String, String> headers = new LinkedMultiValueMap<String, String>();
			final List<String> headerlst = new ArrayList<String>();
			headerlst.add("application/x-www-form-urlencoded");
			headers.put("Content-Type", headerlst);
			final HttpEntity<MultiValueMap<String, String>> entity = new HttpEntity<MultiValueMap<String, String>>(
					parameters, headers);
			String masheryKey = userMngmntService.getMasheryKey();
			LOGGER.info("masheryKey...................{}", masheryKey);
			oauthTokenResponse = restTemplate.postForObject(config.getTokenUri(), entity, OAuthTokenResponse.class);

			if (oauthTokenResponse != null) {
				userResponseDto = decodeJwtToken(oauthTokenResponse,ugName,fName,lName,masheryKey,defaultPrinterIp,defaultPrinterName,defaultPrinterId, port);
			}
			LOGGER.error("userResponseDto...................{}", userResponseDto);

		} catch (HttpClientErrorException hex) {
			hex.printStackTrace();
			return new WaalosErrorResponse(UserMngmtConstants.USR8072_CODE, UserMngmtConstants.USR8072_MSG);
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new WaalosException(UserMngmtConstants.ERR99102_CODE, UserMngmtConstants.ERR99102_MSG);
		} finally {
			LOGGER.info("Exiting into generateAdfsAccessToken ", System.currentTimeMillis());
		}
		return userResponseDto;
	}
  */
  
  	/*
	 * This method is used to generate AzureAD token for the specific user details .
	 * 
     * @author AkhilAduvala(Infosys)
	 * @param username
	 * @param password
	 * @return the Userdetails
	 */
	@SuppressWarnings("unused")
	public Object generateAzureadAccessToken(String userName, String password,String ugName, String uEmail, String fName, String lName, 
			String defaultPrinterIp, String defaultPrinterName, int defaultPrinterId, String port) {
		LOGGER.info("Entering into generateAzureadAccessToken ", System.currentTimeMillis());
		UserResponseDto userResponseDto = null;
		OAuthTokenResponse oauthTokenResponse = null;
		try {
			LOGGER.info("userName...................{} ", userName);
			final MultiValueMap<String, String> parameters = getAzureadQueryParameters(uEmail, password);
			final HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
			final HttpEntity<MultiValueMap<String, String>> entity = new HttpEntity<MultiValueMap<String, String>>(
					parameters, headers);
			String masheryKey = userMngmntService.getMasheryKey();
			LOGGER.info("masheryKey...................{}", masheryKey);
			LOGGER.info("Inside generateAzureadAccessToken for AzureAD Condition config.getAzureAccessTokenUri() : ", config.getAzureAccessTokenUri());
			oauthTokenResponse = restTemplate.postForObject(config.getAzureAccessTokenUri(), entity, OAuthTokenResponse.class);
			if (oauthTokenResponse != null) {
				userResponseDto = decodeJwtTokenAzureAD(oauthTokenResponse,userName,ugName,uEmail,fName,lName,masheryKey,defaultPrinterIp,defaultPrinterName,defaultPrinterId, port);
			}
			LOGGER.error("userResponseDto...................{}", userResponseDto);

		} catch (HttpClientErrorException hex) {
			LOGGER.error("HttpClientErrorException HEX...................{}", hex);
			return new WaalosErrorResponse(UserMngmtConstants.USR8072_CODE, UserMngmtConstants.USR8072_MSG);
		} catch (Exception ex) {
			LOGGER.error("HttpClientErrorException EX...................{}", ex);
			throw new WaalosException(UserMngmtConstants.ERR99102_CODE, UserMngmtConstants.ERR99102_MSG);
		} finally {
			LOGGER.info("Exiting into generateAzureadAccessToken ", System.currentTimeMillis());
		}
		return userResponseDto;
	}
  
    /* This was used to dynamically pass parameter in ADFS, commented after AzureAD.
	 * @param code
	 * @param state
	 * @return
	 
	
    public MultiValueMap<String, String> getAdfsQueryParameters(final String userName, final String password) {
		final MultiValueMap<String, String> adfParameters = new LinkedMultiValueMap<String, String>();
		adfParameters.add("grant_type", "password");
		adfParameters.add("client_id", config.getClientId());
		adfParameters.add("client_secret", config.getClientsecret());
		adfParameters.add("username", userName);
		adfParameters.add("resource", config.getResourceUri());
		adfParameters.add("password", password);
		return adfParameters;
	}
  */
  
   /*
	 * This method is used to dynamically pass parameter for azureAD
     *
     * @author AkhilAduvala(Infosys)
	 * @param code
	 * @param state
	 * @return azureAdParameters
	 */
	public MultiValueMap<String, String> getAzureadQueryParameters(final String uEmail, final String password) {
		final MultiValueMap<String, String> azureAdParameters = new LinkedMultiValueMap<String, String>();
      	LOGGER.info("Inside getAdfsQueryParameters for AzureAD Condition userName: ", uEmail);
      	azureAdParameters.add("grant_type", config.getAzureGrantType());
      	azureAdParameters.add("client_id", config.getAzureClientId());
      	LOGGER.info("Inside getAdfsQueryParameters for AzureAD Condition config.getAzureClientId() : ", config.getAzureClientId());
      	azureAdParameters.add("client_secret", config.getAzureClientSecret());
      	LOGGER.error("Inside getAdfsQueryParameters for AzureAD Condition config.getAzureClientsecret() : ", config.getAzureClientSecret());
      	azureAdParameters.add("userName", uEmail);
      	azureAdParameters.add("password", password);
      	azureAdParameters.add("scope", config.getAzureScope());
		LOGGER.info("Inside getAdfsQueryParameters for AzureAD Condition ", System.currentTimeMillis());
		return azureAdParameters;
	}

	/**
    
     * This was used to set Response DTO in ADFS, commeneted after AzureAD
     
	 * @param tokenDetails
	 * @return UserResponseDto
	 
	public UserResponseDto decodeJwtToken(final OAuthTokenResponse tokenDetails,String ugName,String fName, String lName, String masheryKey, 
			String defaultPrinterIp, String defaultPrinterName, int defaultPrinterId, String port) {
		UserResponseDto finalUserResponseDto = new UserResponseDto();
		try {
			String jwtSTring = JwtHelper.decode(tokenDetails.getId_token()).getClaims();
			JSONObject jsonObject = new JSONObject(jwtSTring);
			finalUserResponseDto.setAccessToken(tokenDetails.getAccess_token());
			finalUserResponseDto.setExpiratinoTime(tokenDetails.getExpires_in());
			finalUserResponseDto.setUserId(jsonObject.getString("unique_name").toLowerCase());
			finalUserResponseDto.setUserEmail(jsonObject.getString("upn"));
			finalUserResponseDto.setUgName(ugName);
			finalUserResponseDto.setFName(fName);
			finalUserResponseDto.setLName(lName);	
			finalUserResponseDto.setApiKey(masheryKey);
			finalUserResponseDto.setDefaultPrinter(defaultPrinterIp);
			finalUserResponseDto.setDefaultPrinterName(defaultPrinterName);
			finalUserResponseDto.setDefaultPrinterId(defaultPrinterId);
			 finalUserResponseDto.setDefaultPrinterPort(port);
			 
		} catch (JSONException jse) {
			jse.printStackTrace();
			throw new WaalosException(UserMngmtConstants.ERR99103_CODE, UserMngmtConstants.ERR99103_MSG);
		}
		return finalUserResponseDto;
	}
    */
  
  	/**
	 * This method is used to set response DTO for azureAD
     *
     * @author AkhilAduvala(Infosys)
	 * @param tokenDetails
	 * @return UserResponseDto
	 */
	public UserResponseDto decodeJwtTokenAzureAD(final OAuthTokenResponse tokenDetails,String userName,String ugName,String uEmail,String fName, String lName, String masheryKey, 
			String defaultPrinterIp, String defaultPrinterName, int defaultPrinterId, String port) {
		UserResponseDto finalUserResponseDto = new UserResponseDto();
		try {
			String jwtSTring = JwtHelper.decode(tokenDetails.getId_token()).getClaims();
			JSONObject jsonObject = new JSONObject(jwtSTring);
			finalUserResponseDto.setAccessToken(tokenDetails.getAccess_token());
			finalUserResponseDto.setExpiratinoTime(tokenDetails.getExpires_in());
			finalUserResponseDto.setUserId(userName);
			finalUserResponseDto.setUserEmail(uEmail);
			finalUserResponseDto.setUgName(ugName);
			finalUserResponseDto.setFName(fName);
			finalUserResponseDto.setLName(lName);	
			finalUserResponseDto.setApiKey(masheryKey);
			finalUserResponseDto.setDefaultPrinter(defaultPrinterIp);
			finalUserResponseDto.setDefaultPrinterName(defaultPrinterName);
			finalUserResponseDto.setDefaultPrinterId(defaultPrinterId);
			finalUserResponseDto.setDefaultPrinterPort(port);
			
			LOGGER.info("finalUserResponseDto in decodeJwtToken",finalUserResponseDto.toString());
			 
		} catch (JSONException jse) {
			LOGGER.error("JSONException jse in decodeJwtToken...................{}", jse);
			throw new WaalosException(UserMngmtConstants.ERR99103_CODE, UserMngmtConstants.ERR99103_MSG);
		}
		return finalUserResponseDto;
	}
}
