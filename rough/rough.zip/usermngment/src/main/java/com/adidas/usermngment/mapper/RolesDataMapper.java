package com.adidas.usermngment.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.RowMapper;

public class RolesDataMapper implements RowMapper {
	private static final Logger LOGGER = LoggerFactory.getLogger(RolesDataMapper.class);

	Map<String, Integer> rolesMap = new HashMap<String, Integer>();
	
	@Override
	public Map<String, Integer> mapRow(ResultSet rs, int rowNum) throws SQLException {
		LOGGER.info("Entering mapRow RolesDataMapper {} ", System.currentTimeMillis());
		
		try {
			rolesMap.put(rs.getString("role_nm").toString(), Integer.parseInt(rs.getString("role_id").toString()));
		} finally {
			LOGGER.info("Exiting mapRow RolesDataMapper{} ", System.currentTimeMillis());
		}
		return rolesMap;
	}
}
