package com.adidas.usermngment.helper;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.adidas.usermngment.config.UserMngmntQueries;
import com.adidas.usermngment.util.UserMngmtConstants;
import com.adidas.waaloscommon.dto.usermngmntdto.UserDto;
import com.adidas.waaloscommon.exception.WaalosErrorResponse;
import com.adidas.waaloscommon.util.WaalosCommonUtil;

@Component
public class UserMngmntHelper {

	@Autowired
	private UserMngmntQueries queries;

	/**
	 * Validates the input parameter
	 * 
	 * @param usrDto
	 * @return boolean
	 */
	public boolean isValidUsrFltrCriteria(UserDto usrDto) {
		final WaalosCommonUtil waalosUtil = new WaalosCommonUtil();
		if (waalosUtil.isNullorEmpty(usrDto.getUsrId()) && waalosUtil.isNullorEmpty(usrDto.getUsrFirstName())
				&& waalosUtil.isNullorEmpty(usrDto.getUsrLastName())) {
			return false;
		}
		return true;
	}

	/**
	 * Method to for form the search query based on input parameters
	 * 
	 * @param usrDto
	 * @return String (query)
	 */
	public String createUserSearchQry(UserDto usrDto, String qryType) {
		String finalQry;
		final String space = " ";
		 StringBuilder query = new StringBuilder();
		final WaalosCommonUtil waalosUtil = new WaalosCommonUtil();
		if (qryType.equalsIgnoreCase(UserMngmtConstants.USRM_USR_QRY_ALL)) {
			query.append(queries.getQueries().get(UserMngmtConstants.USRM_SRCHUSR_QRY));
		} else {
			query.append(queries.getQueries().get(UserMngmtConstants.USRM_SRCHUSR_COUNT_QRY));
		}

		if (!waalosUtil.isNullorEmpty(usrDto.getUsrId())) {
			query.append(space).append(queries.getQueries().get(UserMngmtConstants.USRM_SRCHUSR_LIKE_ID));
		}
		if (!waalosUtil.isNullorEmpty(usrDto.getUsrFirstName())) {
			query.append(space).append(queries.getQueries().get(UserMngmtConstants.USRM_SRCHUSR_LIKE_FRSTNM));
		}
		if (!waalosUtil.isNullorEmpty(usrDto.getUsrLastName())) {
			query.append(space).append(queries.getQueries().get(UserMngmtConstants.USRM_SRCHUSR_LIKE_LSTNM));
		}
		finalQry = query.toString();
		finalQry = (finalQry.substring(0, finalQry.lastIndexOf("and")));
		return finalQry;
	}

	/**
	 * Forms the query parameter
	 * 
	 * @param usrDto
	 * @return Object array
	 */
	public Object[] usrSearchQryParam(UserDto usrDto) {
		final WaalosCommonUtil waalosUtil = new WaalosCommonUtil();
		final List<String> srchCriteria = new ArrayList<>();
		StringBuilder usrId;
		StringBuilder usrFrstName;
		StringBuilder userLstName;
		try{
		if (!waalosUtil.isNullorEmpty(usrDto.getUsrId())) {
			usrId = new StringBuilder(StringUtils.trimWhitespace(usrDto.getUsrId()).toLowerCase(Locale.getDefault()));
			srchCriteria.add((usrId).append("%").toString());
		}
		if (!waalosUtil.isNullorEmpty(usrDto.getUsrFirstName())) {
			usrFrstName = new StringBuilder(
					StringUtils.trimWhitespace(usrDto.getUsrFirstName()).toLowerCase(Locale.getDefault()));
			srchCriteria.add(usrFrstName.append("%").toString());
		}
		if (!waalosUtil.isNullorEmpty(usrDto.getUsrLastName())) {
			userLstName = new StringBuilder(
					StringUtils.trimWhitespace(usrDto.getUsrLastName()).toLowerCase(Locale.getDefault()));
			srchCriteria.add(userLstName.append("%").toString());
		}
		}finally {
			 usrId = null;
			 usrFrstName = null;
			 userLstName =  null;
		}
		return srchCriteria.toArray();
	}

	/**
	 * Forms the query parameter for adding a user
	 * 
	 * @param usrDto
	 * @return Object array
	 */
	public Object[] addUsrQryParam(UserDto usrDto) {
		final List<Object> paramList = new ArrayList<>();
		paramList.add(usrDto.getUsrId().toLowerCase(Locale.getDefault()));
		paramList.add(usrDto.getUsrFirstName());
		paramList.add(usrDto.getUsrMiddleName());
		paramList.add(usrDto.getUsrLastName());
		paramList.add(usrDto.getEmailId());		
		paramList.add(usrDto.getCity());
		paramList.add(usrDto.getState());
		paramList.add(usrDto.getCountry());
		paramList.add(usrDto.getUserGroup());
		paramList.add(usrDto.getUserName());
		paramList.add(usrDto.getDomainUserId());
		return paramList.toArray();

	}

	/**
	 * Validates the input parameter
	 * 
	 * @param usrDto
	 * @return boolean
	 */
	public WaalosErrorResponse validateAddUsrInpt(UserDto usrDto) {
		final WaalosCommonUtil waalosUtil = new WaalosCommonUtil();
		WaalosErrorResponse response = null;
		if (waalosUtil.isNullorEmpty(usrDto.getUsrId())) {
			response = new WaalosErrorResponse(UserMngmtConstants.USR8021_CODE, UserMngmtConstants.USR8021_MSG);
		} else if (waalosUtil.isNullorEmpty(usrDto.getUserGroup())) {
			response = new WaalosErrorResponse(UserMngmtConstants.USR8022_CODE, UserMngmtConstants.USR8022_MSG);
		}
		return response;
	}

}
