package com.adidas.usermngment.dao;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;

@Configuration
@ComponentScan("com.adidas.usermngment")

public class UserMngmntDBConfig {
 
	@Bean(name = "waalosOrclDb")
	@ConfigurationProperties(prefix = "spring.datasource.waalosdb")
	public DataSource wmsOracleDataSource() {
		return DataSourceBuilder.create().build();
	}

	@Bean(name = "waalosOrclTemplate")
	public JdbcTemplate jdbcPrimaryTemplate(@Qualifier(value = "waalosOrclDb") DataSource waalosOrclDb) {
		return new JdbcTemplate(waalosOrclDb);
	}
	
	@Bean
	@Qualifier(value = "waalosTransMngr")
    public PlatformTransactionManager transactionManager(@Qualifier("waalosOrclDb")
    					DataSource waalosOrclDb) {
        return new DataSourceTransactionManager(waalosOrclDb);
    }
	
}