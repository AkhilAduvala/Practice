package com.adidas.usermngment.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.RowMapper;

public class FunsDataMapper implements RowMapper {
	private static final Logger LOGGER = LoggerFactory.getLogger(FunsDataMapper.class);

	Map<String, Integer> funsMap = new HashMap<String, Integer>();
	
	@Override
	public Map<String, Integer> mapRow(ResultSet rs, int rowNum) throws SQLException {
		LOGGER.info("Entering mapRow FunsDataMapper {} ", System.currentTimeMillis());
		try {
			funsMap.put(rs.getString("functnal_nm").toString(), Integer.parseInt(rs.getString("functnal_id").toString()));
		} finally {
			LOGGER.info("Exiting mapRow FunsDataMapper{} ", System.currentTimeMillis());
		}
		return funsMap;
	}
}
