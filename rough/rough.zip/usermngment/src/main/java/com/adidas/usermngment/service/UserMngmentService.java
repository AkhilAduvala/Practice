package com.adidas.usermngment.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adidas.usermngment.dao.UserMngmntDao;
import com.adidas.waaloscommon.dto.usermngmntdto.DcDto;
import com.adidas.waaloscommon.dto.usermngmntdto.DefaultPrinterDto;
import com.adidas.waaloscommon.dto.usermngmntdto.FunctionDto;
import com.adidas.waaloscommon.dto.usermngmntdto.UserDto;
import com.adidas.waaloscommon.dto.usermngmntdto.UserMngmntDto;
import com.adidas.waaloscommon.dto.usermngmntdto.UserRolesDto;
import com.adidas.waaloscommon.dto.wmsdto.PrinterDto;
import com.adidas.waaloscommon.exception.WaalosResponse;
import com.adidas.waaloscommon.pagination.Page;

@Service
public class UserMngmentService {

	private static final Logger LOGGER = LoggerFactory.getLogger(UserMngmentService.class);

	@Autowired
	private UserMngmntDao userMngmentDao;

	public List<DcDto> getDcDetails() throws Exception {
		List<DcDto> dcLst = userMngmentDao.getDcDetails();
		return dcLst;
	}

	public Page<FunctionDto> getFunctionDtls(int pageNumber, int pageSize) throws Exception {
		Page<FunctionDto> functionLst = userMngmentDao.getFunctionDtls(pageNumber, pageSize);
		return functionLst;
	}

	public Object getHomePageData(final String username) throws Exception {
		return userMngmentDao.getHomePageData(username);
	}

	/**
	 * Fetches all users data
	 * 
	 * @param pgNum
	 * @param pgSize
	 * @return UserMngmntDto (containing all user data and user roles data)
	 */

	public UserMngmntDto searchAllUserDetails(int pgNum, int pgSize) {
		LOGGER.info("Inside searchAllUserDetails() in Service class at {}", System.currentTimeMillis());
		Page<UserDto> userDtoLst = null;
		List<UserRolesDto> usrRolesLst = null;
		UserMngmntDto usrMngmntDto = null;
		final int pageNum = pgNum;
		final int pageSize = pgSize;
		int finalPgNum = 0;
		int finalPgSize = 0;
		if (pageNum == 0) {
			finalPgNum = 1;
		} else {
			finalPgNum = pageNum;
		}
		if (pageSize == 0) {
			finalPgSize = 15;
		} else {
			finalPgSize = pageSize;
		}
		userDtoLst = userMngmentDao.searchAllUserDetails(finalPgNum, finalPgSize);
		usrRolesLst = fetchUserRoles();
		usrMngmntDto = new UserMngmntDto();
		usrMngmntDto.setPage(userDtoLst);
		usrMngmntDto.setUserRoles(usrRolesLst);
		return usrMngmntDto;
	}

	/**
	 * Method to fetch user data based on the input search criteria
	 * 
	 * @param userDto
	 * @return List<UserDto>
	 */
	public Page<UserDto> searchUserByFilter(UserDto userDto) {

		LOGGER.info("Inside searchUserByFilter() in Service class, Search Criteria passed : " + "UserId :"
				+ userDto.getUsrId() + " UserFirstName :" + userDto.getUsrFirstName() + " UserLastName :"
				+ userDto.getUsrLastName());

		return userMngmentDao.searchUserByFilter(userDto);

	}

	/**
	 * Method to update user data
	 * 
	 * @param userDto
	 * @return int (count of records modified)
	 */
	public int modifyUser(UserDto userDto) {
		LOGGER.info(
				"Data passed to update User, UsernFrstNm : {}, UsernFrstNm : {}, UserId: {} , eMailId: {} , UserGroup: {} , UserActiveFlg: {}",
				userDto.getUsrFirstName(), userDto.getUsrLastName(), userDto.getUsrId(), userDto.getEmailId(),
				userDto.getUserGroup(), userDto.getUsrActInd());

		return userMngmentDao.modifyUser(userDto);

	}

	/**
	 * Method to (soft) delete users from db
	 * 
	 * @param userDtoLst
	 *            (list of users)
	 * @return int (count of users deleted)
	 */
	public int deactivateUser(List<UserDto> userDtoLst) {
		return userMngmentDao.deactivateUser(userDtoLst);
	}

	/**
	 * Method to add a new user
	 * 
	 * @param userDto
	 * @return WaalosResponse
	 */
	public WaalosResponse addUser(UserDto userDto) {
		return userMngmentDao.addUser(userDto);
	}

	/**
	 * Method to fetch all user roles
	 * 
	 * @return list of UserRolesDto
	 */
	public List<UserRolesDto> fetchUserRoles() {
		return userMngmentDao.fetchUserRoles();
	}

	public Object fetchUserCount(String userId) throws Exception {
		return userMngmentDao.fetchUserCount(userId);
	}

	public String getMasheryKey() throws Exception {
		return userMngmentDao.getMasheryKey();
	}

	/**
	 * Get the list of existing PrinterDto with the data in request.
	 * 
	 * @param dcName
	 *            is the DC Name
	 * @return List of PrinterDto objects
	 */
	public Object getPrinterDtls(String dcName) throws Exception {
		@SuppressWarnings("unchecked")
		final List<PrinterDto> printerLst = (List<PrinterDto>) userMngmentDao.getPrinterDtls(dcName);
		return printerLst;
	}

	public Object getPrinterAllDtls(String userName) throws Exception {
		@SuppressWarnings("unchecked")
		final List<PrinterDto> printerLst = (List<PrinterDto>) userMngmentDao.getPrinterAllDtls(userName);
		return printerLst;
	}

	public int updateDefPrinterDtls(DefaultPrinterDto defaultPrinterDto) throws Exception {
		int printerUpdCnt = userMngmentDao.updateDefPrinterDtls(defaultPrinterDto);
		return printerUpdCnt;
	}

	public Object getDCPrinterDtls(String dcName,String userName) throws Exception {
		@SuppressWarnings("unchecked")
		final List<PrinterDto> printerLst = (List<PrinterDto>) userMngmentDao.getDCPrinterDtls(dcName,userName);
		return printerLst;
	}
}
