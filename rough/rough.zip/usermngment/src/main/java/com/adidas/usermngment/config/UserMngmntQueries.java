package com.adidas.usermngment.config;

import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@PropertySource(value = "classpath:queries.properties")
@Configuration
@ConfigurationProperties
public class UserMngmntQueries {

	private Map<String, String> queries;

	public UserMngmntQueries() {
		super();
	}

	public UserMngmntQueries(Map<String, String> queries) {
		super();
		this.queries = queries;
	}

	public Map<String, String> getQueries() {
		return queries;
	}

	public void setQueries(Map<String, String> queries) {
		this.queries = queries;
	}

}