package com.adidas.usermngment.dao;

import org.springframework.stereotype.Component;

import com.adidas.waaloscommon.dto.usermngmntdto.GetUGDataDto;
import com.adidas.waaloscommon.dto.usermngmntdto.ManageFavoritesDto;
import com.adidas.waaloscommon.dto.usermngmntdto.UserGroupMappingsDto;

@Component
public interface PermissionMngmentDao {
	public Object getUGDashboard(String username) throws Exception;
	public Object deleteUserGroup(String ugName) throws Exception;
	public Object getUserGroupData(GetUGDataDto ugDto) throws Exception;
	public Object addNewUG(UserGroupMappingsDto mappingsDto) throws Exception;
	public Object updateUG(UserGroupMappingsDto mappingsDto) throws Exception;
	public Object searchUGS(String ugName) throws Exception;	
	public Object addFavorite(ManageFavoritesDto favoritesDto) throws Exception;
	public Object deleteFavorite(ManageFavoritesDto favoritesDto) throws Exception;
	public Object getFavorites(String username) throws Exception;
}