package com.adidas.usermngment.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.TreeMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.RowMapper;

import com.adidas.waaloscommon.dto.usermngmntdto.UGDashboardDto;




@SuppressWarnings("rawtypes")
public class UGDashboardDataMapper implements RowMapper {
	private static final Logger LOGGER = LoggerFactory.getLogger(UGDashboardDataMapper.class);
	
	@SuppressWarnings("unchecked")
	@Override
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		List funsList = null;
		Map<String, List<String>> dcTemp = null;
		Object returnObj = null;
			try {
				if(rs==null) {
					return null;
				}else {
					dcTemp = new TreeMap<String, List<String>>();
					do {
		            	 if(dcTemp.containsKey(rs.getString("dc_nm"))) {
		            		funsList = dcTemp.get(rs.getString("dc_nm"));
		            	 }else {
		            		 funsList = new ArrayList();
		            	 }
		            	 funsList.add(rs.getString("functnal_nm"));
		            	 dcTemp.put(rs.getString("dc_nm"), funsList);

	            	}while(rs.next());
					returnObj = dcTemp;
				}
			}catch(Exception ex) {
				LOGGER.info("Exception while preparing the JSON at Row Mapper");
				LOGGER.error("Exception caught at Row Mapper...... ",ex.getMessage());
				returnObj = null;
			}finally {
				funsList = null;
				dcTemp = null;
			}
			return returnObj;
	}
}
