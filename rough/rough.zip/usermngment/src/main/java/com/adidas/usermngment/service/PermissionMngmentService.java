package com.adidas.usermngment.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adidas.usermngment.dao.impl.PermissionMngmntDaoImpl;
import com.adidas.waaloscommon.dto.usermngmntdto.GetUGDataDto;
import com.adidas.waaloscommon.dto.usermngmntdto.ManageFavoritesDto;
import com.adidas.waaloscommon.dto.usermngmntdto.UserGroupMappingsDto;


@Service
public class PermissionMngmentService {
	
	@Autowired
	private PermissionMngmntDaoImpl permsnMngmentDao;
	
		
	public Object getUGDashboard(String username) throws Exception {
		return permsnMngmentDao.getUGDashboard(username);
	}
	
	public Object deleteUserGroup(String ugName) throws Exception {
		return permsnMngmentDao.deleteUserGroup(ugName);
	}
	
	
	public Object getUserGroupData(final GetUGDataDto ugDto) throws Exception {
		return permsnMngmentDao.getUserGroupData(ugDto);
	}
		
	public Object addNewUG(final UserGroupMappingsDto mappingsDto) throws Exception {
		return permsnMngmentDao.addNewUG(mappingsDto);
	}

	public Object updateUG(final UserGroupMappingsDto mappingsDto) throws Exception {
		return permsnMngmentDao.updateUG(mappingsDto);
	}

	public Object searchUGS(String ugname) throws Exception {
		return permsnMngmentDao.searchUGS(ugname);
	}
	
	public Object addFavorite(final ManageFavoritesDto favDto) throws Exception {
		return permsnMngmentDao.addFavorite(favDto);
	}
	
	public Object deleteFavorite(final ManageFavoritesDto favDto) throws Exception {
		return permsnMngmentDao.deleteFavorite(favDto);
	}
	
	public Object getFavorites(String username) throws Exception {
		return permsnMngmentDao.getFavorites(username);
	}
}
