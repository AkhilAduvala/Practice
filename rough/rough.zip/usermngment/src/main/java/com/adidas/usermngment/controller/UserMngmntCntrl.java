package com.adidas.usermngment.controller;

import java.util.List;

import javax.xml.bind.DatatypeConverter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.adidas.usermngment.helper.UserMngmntHelper;
import com.adidas.usermngment.service.UserMngmentService;
import com.adidas.usermngment.util.AdfsTokenGeneration;
import com.adidas.usermngment.util.UserMngmtConstants;
import com.adidas.waaloscommon.constants.WaalosConstants;
import com.adidas.waaloscommon.dto.usermngmntdto.DcDto;
import com.adidas.waaloscommon.dto.usermngmntdto.DefaultPrinterDto;
import com.adidas.waaloscommon.dto.usermngmntdto.FunctionDto;
import com.adidas.waaloscommon.dto.usermngmntdto.HomePageUserDto;
import com.adidas.waaloscommon.dto.usermngmntdto.LoginDto;
import com.adidas.waaloscommon.dto.usermngmntdto.UserDto;
import com.adidas.waaloscommon.dto.usermngmntdto.UserMngmntDto;
import com.adidas.waaloscommon.dto.usermngmntdto.UserRolesDto;
import com.adidas.waaloscommon.dto.usermngmntdto.WaalosUserDto;
import com.adidas.waaloscommon.dto.wmsdto.PrinterDto;
import com.adidas.waaloscommon.exception.WaalosErrorResponse;
import com.adidas.waaloscommon.exception.WaalosException;
import com.adidas.waaloscommon.exception.WaalosResponse;
import com.adidas.waaloscommon.pagination.Page;
import com.adidas.waaloscommon.util.WaalosCommonUtil;
import com.google.gson.Gson;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/usrcntrl")
@SuppressWarnings("squid:S1200")
public class UserMngmntCntrl {

	private static final Logger LOGGER = LoggerFactory.getLogger(UserMngmntCntrl.class);

	@Autowired
	private UserMngmentService userMngmntService;

	@Autowired
	private AdfsTokenGeneration adfsTokenGenerator;

	@Autowired
	private UserMngmntHelper userMngmntHelper;

	@ApiOperation(value = "usrmngmentHlth", nickname = "usrmngmentHlth")
	@ApiResponses(value = { @ApiResponse(code = 400, message = "Bad Request"),
			@ApiResponse(code = 500, message = "Internal Server Error"),
			@ApiResponse(code = 503, message = "Service Unavailable"), @ApiResponse(code = 404, message = "Not Found"),
			@ApiResponse(code = 200, message = "OK", response = String.class, responseContainer = "String") })
	@RequestMapping(value = "/usrmngmentHlth", method = RequestMethod.GET)
	public @ResponseBody String wmsHealth() {
		LOGGER.info("UserManagement Health is sucessful");
		return "UserManagement Health is sucessful";
	}

	@ApiOperation(value = "getRoles", nickname = "getRoles")
	@ApiResponses(value = { @ApiResponse(code = 400, message = "Bad Request"),
			@ApiResponse(code = 500, message = "Internal Server Error"),
			@ApiResponse(code = 503, message = "Service Unavailable"), @ApiResponse(code = 404, message = "Not Found"),
			@ApiResponse(code = 200, message = "OK", response = String.class, responseContainer = "String") })
	@RequestMapping(value = "/getRoles", method = RequestMethod.GET)
	public @ResponseBody Object getDcDtls() throws Exception {
		LOGGER.info("Entering into getDcDtls ", System.currentTimeMillis());
		List<DcDto> dcLst = null;
		Object returnObj = null;
		try {
			dcLst = userMngmntService.getDcDetails();
			if (dcLst.isEmpty()) {
				returnObj = new WaalosErrorResponse(UserMngmtConstants.USR8001_CODE, UserMngmtConstants.USR8001_MSG);
			} else {
				returnObj = dcLst;
			}
		} catch (WaalosException wex) {
			LOGGER.error("Exception in getDcDtls of Entering {}", wex);
			return new WaalosErrorResponse(wex.getErrorCode(), wex.getMessage());
		} finally {
			LOGGER.info("Exiting getDcDtls ", System.currentTimeMillis());
		}
		return returnObj;
	}

	@SuppressWarnings("unchecked")
	@ApiOperation(value = "pagination", nickname = "pagination")
	@ApiResponses(value = { @ApiResponse(code = 400, message = "Bad Request"),
			@ApiResponse(code = 500, message = "Internal Server Error"),
			@ApiResponse(code = 503, message = "Service Unavailable"), @ApiResponse(code = 404, message = "Not Found"),
			@ApiResponse(code = 200, message = "OK", response = String.class, responseContainer = "String") })
	@RequestMapping(value = "/getFunctionDtls", method = RequestMethod.GET)
	public @ResponseBody Page<FunctionDto> getFunctionDtls(@RequestParam(value = "pageNumber") int pageNumber,
			@RequestParam(value = "pageSize") int pageSize) throws Exception {

		Page<FunctionDto> functionPage = userMngmntService.getFunctionDtls(pageNumber, pageSize);

		return functionPage;
	}

	/**
	 * Get the respective DC and Functionality information post login .
	 * 
	 * @return the Object with List of DCs and its applicable functionalities
	 */
	@ApiOperation(value = "getHomePageData", nickname = "getHomePageData")
	@ApiResponses(value = { @ApiResponse(code = 400, message = "Bad Request"),
			@ApiResponse(code = 500, message = "Internal Server Error"),
			@ApiResponse(code = 503, message = "Service Unavailable"), @ApiResponse(code = 404, message = "Not Found"),
			@ApiResponse(code = 200, message = "OK", response = String.class, responseContainer = "String") })
	@RequestMapping(value = "/getHomePageData", method = RequestMethod.POST)
	public @ResponseBody Object getHomePageData(@RequestBody HomePageUserDto homePageUserDto) throws Exception {
		LOGGER.info("Entering into getHomePageData ", System.currentTimeMillis());
		Object dataObj = null;
		try {
			if (null == homePageUserDto.getUsername().trim()) {
				LOGGER.error("UserName is empty in the request body from getHomePageData() method ... ");
				dataObj = new WaalosResponse(UserMngmtConstants.ERR9999_CODE, UserMngmtConstants.ERR9999_MSG);
			} else {
				dataObj = userMngmntService.getHomePageData(homePageUserDto.getUsername().trim());

			}
		} catch (Exception e) {
			LOGGER.error("Exception in getHomePageData of Entering {}", e.getMessage());
			dataObj = new WaalosErrorResponse(UserMngmtConstants.ERR9999_CODE, UserMngmtConstants.ERR9999_MSG);
		} finally {
			LOGGER.info("Exiting getHomePageData ", System.currentTimeMillis());
		}
		return dataObj;
	}

	/**
	 * This method is used to authenticate the user with AzureAD (earlier ADFS).
	 * 
	 * @param username
	 * @param password
	 * @return the Object with User Details
	 * 
	 */
	@SuppressWarnings("null")
	@RequestMapping(value = "/authenticateUser", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody Object authenticationWaalosUser(@RequestBody WaalosUserDto waalosUserdto) throws Exception {
		LOGGER.info("Entering authenticationWaalosUser ", System.currentTimeMillis());
		Object userRespnoseDto = null;
		String userResponseObject = null;
		Gson gson = null;
		Object loginDto = null;
		String ugName = null;
		Object returnObj = null;
		String decodedPassword = "";
		String defPrinterName = "";
		String defPrinterIp = "";
		int defPrinterId = 0;

		try {
			if (StringUtils.isEmpty(waalosUserdto.getUserName())) {
				returnObj = new WaalosResponse(UserMngmtConstants.USR8007_CODE, UserMngmtConstants.USR8007_MSG);
			} else if (StringUtils.isEmpty(waalosUserdto.getUserPassword())) {
				returnObj = new WaalosResponse(UserMngmtConstants.USR8008_CODE, UserMngmtConstants.USR8008_MSG);
			} else {
				LOGGER.info("Entering else {}", waalosUserdto.getUserName());
				if (waalosUserdto.getUserName().contains("\\")) {
				loginDto = userMngmntService.fetchUserCount(waalosUserdto.getUserName().toLowerCase());

				} else {
					returnObj = new WaalosResponse(UserMngmtConstants.USR8074_CODE, UserMngmtConstants.USR8074_MSG);
				}

				if ((((LoginDto) loginDto).getLoginErrorCd()) == null) {
					if ((((LoginDto) loginDto).getUgName()) == null) {
						returnObj = new WaalosResponse(UserMngmtConstants.USR8073_CODE, UserMngmtConstants.USR8073_MSG);
					} else {
						ugName = ((LoginDto) loginDto).getUgName().trim();

						if (((LoginDto) loginDto).getUsrDefPrinter() == null
								|| ((LoginDto) loginDto).getUsrDefPrinter().equalsIgnoreCase("")) {
							defPrinterIp = "";
						} else {
							defPrinterIp = ((LoginDto) loginDto).getUsrDefPrinter();
						}

						if (((LoginDto) loginDto).getUsrDefPrinterName() == null
								|| ((LoginDto) loginDto).getUsrDefPrinter().equalsIgnoreCase("")) {
							defPrinterName = "";
						} else {
							defPrinterName = ((LoginDto) loginDto).getUsrDefPrinterName();
						}

						defPrinterId = ((LoginDto) loginDto).getUsrDefPrinterId();

						decodedPassword = new String(
								DatatypeConverter.parseBase64Binary(waalosUserdto.getUserPassword()));
						 /*userRespnoseDto = adfsTokenGenerator.generateAdfsAccessToken(waalosUserdto.getUserName(),
								decodedPassword, ugName, (((LoginDto) loginDto).getFName()),
								((LoginDto) loginDto).getFLastName(), defPrinterIp, defPrinterName, defPrinterId, ((LoginDto) loginDto).getUserDefPrinterPort());
                        */
                      	// commented ADFS logic and added AzureAD Logic @Author - AkhilAduvala
                      	userRespnoseDto = adfsTokenGenerator.generateAzureadAccessToken(waalosUserdto.getUserName(),
									decodedPassword, ugName, ((LoginDto) loginDto).getUEmail(), (((LoginDto) loginDto).getFName()),
									((LoginDto) loginDto).getFLastName(), defPrinterIp, defPrinterName, defPrinterId, ((LoginDto) loginDto).getUserDefPrinterPort());

						if (userRespnoseDto == null) {
							returnObj = new WaalosResponse(UserMngmtConstants.USR8072_CODE,
									UserMngmtConstants.USR8072_MSG);
						} else {
							gson = new Gson();
							userResponseObject = gson.toJson(userRespnoseDto);
							LOGGER.info("userResponseObject {}", userResponseObject);
							returnObj = userResponseObject;
						}
					}
				} else {
					returnObj = new WaalosErrorResponse(UserMngmtConstants.ERR99111_CODE,
							UserMngmtConstants.ERR99111_MSG);
				}
			}
		} catch (Exception aex) {
			aex.printStackTrace();
			LOGGER.error("Exception in authenticationWaalosUser",aex);
			returnObj = new WaalosErrorResponse(UserMngmtConstants.ERR99100_CODE, UserMngmtConstants.ERR99100_MSG);
		} finally {
			LOGGER.info("Exiting authenticationWaalosUser ", System.currentTimeMillis());
		}
		return returnObj;
	}

	/**
	 * This method handles the searchAllUserDetails request from the client. It
	 * fetches all the user data from db and sends it to the client to be
	 * displayed in the UI
	 * 
	 * @param UserDto
	 * @return List of UserDto in case of success else
	 *         WaalosResponse/WaalosErrorResponse object
	 */

	@ApiOperation(value = "searchAllUserDetails", nickname = "searchAllUserDetails")
	@ApiResponses(value = { @ApiResponse(code = 400, message = "Bad Request"),
			@ApiResponse(code = 500, message = "Internal Server Error"),
			@ApiResponse(code = 503, message = "Service Unavailable"), @ApiResponse(code = 404, message = "Not Found"),
			@ApiResponse(code = 200, message = "OK", response = String.class, responseContainer = "String") })
	@RequestMapping(value = "/searchAllUserDetails", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)

	public @ResponseBody Object searchAllUserDetails(@RequestBody UserDto userDto) {
		LOGGER.info(" Entering into searchAllUserDetails method in Controller, current time : {} ",
				System.currentTimeMillis());
		List<UserDto> listUserDto = null;
		WaalosErrorResponse waalosErrResponse = null;
		UserMngmntDto usrMngmntDto = null;
		WaalosResponse waalosResponse = null;
		final int pgNum;
		final int pgSize;
		try {
			pgNum = userDto.getPageNumber();
			pgSize = userDto.getPageSize();

			LOGGER.info(" SearchAllUserDetails resquest from user : {} ", userDto.getUserName());

			usrMngmntDto = userMngmntService.searchAllUserDetails(pgNum, pgSize);
			listUserDto = usrMngmntDto.getPage().getPageItems();
			if (listUserDto.isEmpty()) {
				waalosResponse = new WaalosResponse(UserMngmtConstants.USR8023_CODE, UserMngmtConstants.USR8023_MSG);
				return waalosResponse;
			} else {
				return usrMngmntDto;
			}
		} catch (Exception ex) {
			LOGGER.error("Exception caught in Controller method searchAllUserDetails : ", ex);
			waalosErrResponse = new WaalosErrorResponse(WaalosConstants.ERR9999_CODE, WaalosConstants.ERR9999_MSG);
		} finally {
			LOGGER.info("Exiting searchAllUserDetails in UserMngmntCntrl in Controller, current time : {} ",
					System.currentTimeMillis());
		}
		return waalosErrResponse;
	}

	/**
	 * This method handles the searchUserByFilter request from the client. It is
	 * responsible for fetching the User details based on the search input from
	 * UI. Search Input: Any or combination of these fields (UserId,
	 * UserFirstName , UserlastName)
	 * 
	 * @param UserDto
	 * @return List of Page<UserDto> in case of success else
	 *         WaalosResponse/WaalosErrorResponse object
	 */

	@ApiOperation(value = "searchUserByFilter", nickname = "searchAllUserDetails")
	@ApiResponses(value = { @ApiResponse(code = 400, message = "Bad Request"),
			@ApiResponse(code = 500, message = "Internal Server Error"),
			@ApiResponse(code = 503, message = "Service Unavailable"), @ApiResponse(code = 404, message = "Not Found"),
			@ApiResponse(code = 200, message = "OK", response = String.class, responseContainer = "String") })
	@RequestMapping(value = "/searchUserByFilter", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)

	public @ResponseBody Object searchUserByFilter(@RequestBody UserDto userDto) {
		LOGGER.info(" Entering into searchUserByFilter method in Controller, current time : {} ",
				System.currentTimeMillis());
		Page<UserDto> userDtoLstPg = null;
		WaalosErrorResponse waalosErrResponse = null;
		WaalosResponse waalosResponse = null;
		try {
			LOGGER.info(" SearchUserByFilter resquest from user : {} ", userDto.getUserName());

			if (userMngmntHelper.isValidUsrFltrCriteria(userDto)) {
				userDtoLstPg = userMngmntService.searchUserByFilter(userDto);
				if (userDtoLstPg.getPageItems().isEmpty()) {
					waalosResponse = new WaalosResponse(UserMngmtConstants.USR8023_CODE,
							UserMngmtConstants.USR8023_MSG);
					return waalosResponse;
				} else {
					return userDtoLstPg;
				}
			} else {
				waalosErrResponse = new WaalosErrorResponse(UserMngmtConstants.USR8020_CODE,
						UserMngmtConstants.USR8020_MSG);
			}
		} catch (Exception ex) {
			LOGGER.error("Exception caught in Controller method searchUserByFilter ", ex);

			waalosErrResponse = new WaalosErrorResponse(WaalosConstants.ERR9999_CODE, WaalosConstants.ERR9999_MSG);
		} finally {
			LOGGER.info("Exiting searchUserByFilter in UserMngmntCntrl in Controller, current time : {}  ",
					System.currentTimeMillis());
		}
		return waalosErrResponse;
	}

	/**
	 * This method of the controller handles the ModifyUser request . It updates
	 * the user information passed from the UI
	 *
	 * @param UserDto
	 * @param userId
	 * @return UserDto in case of success else
	 *         WaalosResponse/WaalosErrorResponse object
	 */

	@ApiOperation(value = "modifyUser", nickname = "modifyUser")
	@ApiResponses(value = { @ApiResponse(code = 400, message = "Bad Request"),
			@ApiResponse(code = 500, message = "Internal Server Error"),
			@ApiResponse(code = 503, message = "Service Unavailable"), @ApiResponse(code = 404, message = "Not Found"),
			@ApiResponse(code = 200, message = "OK", response = String.class, responseContainer = "String") })
	@RequestMapping(value = "/modifyUser", method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)

	public @ResponseBody Object modifyUser(@RequestBody UserDto userDto) {

		LOGGER.info(" Entering into ModifyUser method in Controller, current time : {} ", System.currentTimeMillis());
		int updateCount = 0;
		WaalosErrorResponse waalosResponse = null;
		final WaalosCommonUtil waalosUtil = new WaalosCommonUtil();
		StringBuilder responseMsg;
		try {

			LOGGER.info(" ModifyUser resquest from user : {} ", userDto.getUserName());

			if (waalosUtil.isNullorEmpty(userDto.getUsrId()) || waalosUtil.isNullorEmpty(userDto.getEmailId())
					|| waalosUtil.isNullorEmpty(userDto.getUserGroup())
					|| waalosUtil.isNullorEmpty(userDto.getUsrActInd())) {
				waalosResponse = new WaalosErrorResponse(UserMngmtConstants.USR8009_CODE,
						UserMngmtConstants.USR8009_MSG);
			} else {
				// TODO The user is active or not needs to be verified via ADFS
				// before update
				updateCount = userMngmntService.modifyUser(userDto);
				if (updateCount > 0) {
					responseMsg = new StringBuilder();
					responseMsg.append(UserMngmtConstants.USR8010_MSG).append("[ ").append(updateCount)
							.append(WaalosConstants.UPDATE_COUNT_MSG);
					return new WaalosResponse(UserMngmtConstants.USR8010_CODE, responseMsg.toString());
				} else {
					LOGGER.error(UserMngmtConstants.USR8011_MSG);
					waalosResponse = new WaalosErrorResponse(WaalosConstants.ERR9999_CODE, WaalosConstants.ERR9999_MSG);
				}
			}
		} catch (Exception ex) {
			LOGGER.error("Exception caught in Controller method modifyUser ", ex);
			waalosResponse = new WaalosErrorResponse(WaalosConstants.ERR9999_CODE, WaalosConstants.ERR9999_MSG);
		} finally {
			responseMsg = null;
			LOGGER.info("Exiting modifyUser in UserMngmntCntrl in Controller, current time : {}  ",
					System.currentTimeMillis());
		}
		return waalosResponse;
	}

	/**
	 * This method of the controller handles the delete user request from the
	 * client. It marks the users Active indicator flag as 'N' in db.
	 * 
	 * @param List
	 *            of UserDto
	 * @return WaalosResponse/WaalosErrorResponse object with success or failure
	 *         code and message
	 */

	@ApiOperation(value = "deactivateUser", nickname = "deactivateUser")
	@ApiResponses(value = { @ApiResponse(code = 400, message = "Bad Request"),
			@ApiResponse(code = 500, message = "Internal Server Error"),
			@ApiResponse(code = 503, message = "Service Unavailable"), @ApiResponse(code = 404, message = "Not Found"),
			@ApiResponse(code = 200, message = "OK", response = String.class, responseContainer = "String") })
	@RequestMapping(value = "/deactivateUser", method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)

	public @ResponseBody Object deactivateUser(@RequestBody List<UserDto> userDtoLst) {
		LOGGER.info(" Entering into deactivateUser method in Controller, current time : {} ",
				System.currentTimeMillis());
		int usrsDeactivated = 0;
		StringBuilder responseMsg;
		WaalosErrorResponse waalosResponse = null;

		try {
			LOGGER.info(" deactivateUser resquest from user : {} ", userDtoLst.get(0).getUserName());

			usrsDeactivated = userMngmntService.deactivateUser(userDtoLst);
			if (usrsDeactivated < 1) {
				LOGGER.error(UserMngmtConstants.USR8012_MSG);
				waalosResponse = new WaalosErrorResponse(WaalosConstants.ERR9999_CODE, WaalosConstants.ERR9999_MSG);
			} else {
				responseMsg = new StringBuilder();
				responseMsg.append(UserMngmtConstants.USR8013_MSG).append("[ ").append(usrsDeactivated)
						.append(WaalosConstants.DELETE_COUNT_MSG);
				return new WaalosResponse(UserMngmtConstants.USR8013_CODE, responseMsg.toString());
			}
		} catch (Exception ex) {
			LOGGER.error("Exception caught in Controller method deactivateUser : ", ex);
			waalosResponse = new WaalosErrorResponse(WaalosConstants.ERR9999_CODE, WaalosConstants.ERR9999_MSG);
		} finally {
			LOGGER.info("Exiting deactivateUser in Controller, current time : {} ", System.currentTimeMillis());
			responseMsg = null;
		}
		return waalosResponse;
	}

	/**
	 * This method of the controller handles the user add request from the
	 * client.
	 * 
	 * @param UserDto
	 * @return WaalosResponse/WaalosErrorResponse object with success or failure
	 *         code and message
	 */

	@ApiOperation(value = "addUser", nickname = "addUser")
	@ApiResponses(value = { @ApiResponse(code = 400, message = "Bad Request"),
			@ApiResponse(code = 500, message = "Internal Server Error"),
			@ApiResponse(code = 503, message = "Service Unavailable"), @ApiResponse(code = 404, message = "Not Found"),
			@ApiResponse(code = 200, message = "OK", response = String.class, responseContainer = "String") })
	@RequestMapping(value = "/addUser", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)

	public @ResponseBody Object addUser(@RequestBody UserDto userDto) {
		LOGGER.info(" Entering into addUser method in Controller, current time : {} ", System.currentTimeMillis());
		WaalosErrorResponse waalosErrResponse = null;
		WaalosResponse response = null;
		try {
			LOGGER.info(" AddUser resquest from user : {} ", userDto.getUserName());
			waalosErrResponse = userMngmntHelper.validateAddUsrInpt(userDto);
			if (waalosErrResponse == null) {
				response = userMngmntService.addUser(userDto);
				if (response.getResCode().equalsIgnoreCase(UserMngmtConstants.USR8014_CODE)) {
					return response;
				} else if (response.getResCode().equalsIgnoreCase(UserMngmtConstants.USR8016_CODE)) {
					waalosErrResponse = new WaalosErrorResponse(UserMngmtConstants.USR8016_CODE,
							UserMngmtConstants.USR8016_MSG);
				} else if (response.getResCode().equalsIgnoreCase(UserMngmtConstants.USR8015_CODE)) {
					LOGGER.error("User add opertion failed....");
					waalosErrResponse = new WaalosErrorResponse(WaalosConstants.ERR9999_CODE,
							WaalosConstants.ERR9999_MSG);
				}
			}
		} catch (Exception ex) {
			waalosErrResponse = new WaalosErrorResponse(WaalosConstants.ERR9999_CODE, WaalosConstants.ERR9999_MSG);
		} finally {
			LOGGER.info("Exiting addUser in Controller, current time : {} ", System.currentTimeMillis());
		}
		return waalosErrResponse;
	}

	/**
	 * This method of the controller handles the getUserRoles request from the
	 * client. It fetches all the user roles data from db and sends it to the
	 * client in json format
	 * 
	 * @return List of UserRolesDto in case of success else WaalosErrorResponse
	 *         object
	 */

	@ApiOperation(value = "getUserRoles", nickname = "getUserRoles")
	@ApiResponses(value = { @ApiResponse(code = 400, message = "Bad Request"),
			@ApiResponse(code = 500, message = "Internal Server Error"),
			@ApiResponse(code = 503, message = "Service Unavailable"), @ApiResponse(code = 404, message = "Not Found"),
			@ApiResponse(code = 200, message = "OK", response = String.class, responseContainer = "String") })
	@RequestMapping(value = "/getUserRoles", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)

	public @ResponseBody Object getUserRoles() {
		LOGGER.info(" Entering into getUserRoles method in Controller, current time : {} ", System.currentTimeMillis());
		WaalosErrorResponse waalosResponse = null;
		List<UserRolesDto> usrRolesDtoLst;
		try {
			usrRolesDtoLst = userMngmntService.fetchUserRoles();
			if (usrRolesDtoLst.isEmpty()) {
				waalosResponse = new WaalosErrorResponse(UserMngmtConstants.USR8018_CODE,
						UserMngmtConstants.USR8018_MSG);
			} else {
				return usrRolesDtoLst;
			}
		} catch (Exception ex) {
			LOGGER.error("Exception caught in Controller method getUserRoles : ", ex);
			waalosResponse = new WaalosErrorResponse(WaalosConstants.ERR9999_CODE, WaalosConstants.ERR9999_MSG);
		} finally {
			LOGGER.info("Exiting getUserRoles in UserMngmntCntrl in Controller, current time : {} ",
					System.currentTimeMillis());
		}
		return waalosResponse;
	}

	/**
	 * Get the Printer Details for particular DC.
	 * 
	 * @param dcName
	 * 
	 * @return List of PrinterDto objects.
	 */
	@SuppressWarnings("unchecked")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "OK", response = PrinterDto.class, responseContainer = "List") })
	@RequestMapping(method = RequestMethod.GET, value = "/printerDtls", produces = "application/hal+json")
	public @ResponseBody Object getPrinterDtls(@RequestParam(value = "dcName") String dcName) throws Exception {
		LOGGER.info("Entering getDimensions at {} ", System.currentTimeMillis());
		List<PrinterDto> printerLst = null;
		try {
			printerLst = (List<PrinterDto>) userMngmntService.getPrinterDtls(dcName);

			if (printerLst.isEmpty()) {
				return new WaalosResponse(UserMngmtConstants.USR9004_CODE, UserMngmtConstants.USR9004_MSG);
			} else {
				return printerLst;
			}
		} catch (WaalosException dmex) {
			LOGGER.error("Exception in getPrinterDtls", dmex);
			return new WaalosErrorResponse(dmex.getErrorCode(), dmex.getMessage());
		} finally {
			LOGGER.info("Exiting getPrinterDtls at {} ", System.currentTimeMillis());
		}
	}
	
	
	/**
	 * Get All Printer Details.
	 * 
	 * @param dcName
	 * 
	 * @return List of PrinterDto objects.
	 */
	@SuppressWarnings("unchecked")
	  @ApiResponses(value = {
			@ApiResponse(code = 200, message = "OK", response = PrinterDto.class, responseContainer = "List") })
	@RequestMapping(method = RequestMethod.GET, value = "/printerAllDtls", produces = "application/hal+json")
	public @ResponseBody Object getAllPrinterDtls(@RequestParam(value = "userName") String userName) throws Exception {
		LOGGER.info("Entering getDimensions at {} ", System.currentTimeMillis());
		List<PrinterDto> printerAllLst = null;
		try {
			printerAllLst = (List<PrinterDto>) userMngmntService.getPrinterAllDtls(userName);

			if (printerAllLst.isEmpty()) {
				return new WaalosResponse(UserMngmtConstants.USR9004_CODE, UserMngmtConstants.USR9004_MSG);
			} else {
				return printerAllLst;
			}
		} catch (WaalosException dmex) {
			LOGGER.error("Exception in getPrinterDtls", dmex);
			return new WaalosErrorResponse(dmex.getErrorCode(), dmex.getMessage());
		} finally {
			LOGGER.info("Exiting getPrinterDtls at {} ", System.currentTimeMillis());
		}
	}

	/**
	 * Assign Default Printer Details to particular User
	 * 
	 * @param dcName
	 * 
	 * @return List of PrinterDto objects.
	 */
	@SuppressWarnings("unchecked")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "OK", response = PrinterDto.class, responseContainer = "Object") })
	@RequestMapping(method = RequestMethod.POST, value = "/setprinterDtls", produces = "application/hal+json")
	public @ResponseBody Object updateDefPrinterDtls(@RequestBody DefaultPrinterDto defaultPrinterDto)
			throws Exception {
		LOGGER.info("Entering getDimensions at {} ", System.currentTimeMillis());
		int updatePrinterCnt = 0;
		try {
			updatePrinterCnt = userMngmntService.updateDefPrinterDtls(defaultPrinterDto);

			if (updatePrinterCnt > 0) {
				return new WaalosResponse(UserMngmtConstants.USR9005_CODE, UserMngmtConstants.USR9005_MSG);
			} else {
				return new WaalosResponse(UserMngmtConstants.ERR91121_CODE, UserMngmtConstants.ERR91121_MSG);
			}

		} catch (WaalosException dmex) {
			LOGGER.error("Exception in getPrinterDtls", dmex);
			return new WaalosErrorResponse(dmex.getErrorCode(), dmex.getMessage());
		} finally {
			LOGGER.info("Exiting getPrinterDtls at {} ", System.currentTimeMillis());
		}
	}

	/**
	 * Get All Printer Details.
	 * 
	 * @param dcName
	 * 
	 * @return List of PrinterDto objects.
	 */
	@SuppressWarnings("unchecked")
	  @ApiResponses(value = {
			@ApiResponse(code = 200, message = "OK", response = PrinterDto.class, responseContainer = "List") })
	@RequestMapping(method = RequestMethod.GET, value = "/dcprinterDtls", produces = "application/hal+json")
	public @ResponseBody Object getDCPrinterDtls(@RequestParam(value = "dcName") String dcName,@RequestParam(value = "userName") String userName) throws Exception {
		LOGGER.info("Entering getDCPrinterDtls at {} ", System.currentTimeMillis());
		List<PrinterDto> printerAllLst = null;
		try {
			printerAllLst = (List<PrinterDto>) userMngmntService.getDCPrinterDtls(dcName,userName);

			if (printerAllLst.isEmpty()) {
				return new WaalosResponse(UserMngmtConstants.USR9004_CODE, UserMngmtConstants.USR9004_MSG);
			} else {
				return printerAllLst;
			}
		} catch (WaalosException dmex) {
			LOGGER.error("Exception in getDCPrinterDtls", dmex);
			return new WaalosErrorResponse(dmex.getErrorCode(), dmex.getMessage());
		} finally {
			LOGGER.info("Exiting getDCPrinterDtls at {} ", System.currentTimeMillis());
		}
	}
}
