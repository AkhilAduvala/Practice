package com.adidas.usermngment.config;

import java.util.Arrays;
import java.util.concurrent.TimeUnit;

import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.guava.GuavaCache;
import org.springframework.cache.support.SimpleCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.google.common.cache.CacheBuilder;

@Configuration
@EnableCaching
public class UserMngmntCacheConfig {
	@Bean
	public CacheManager cacheManager() {
		final SimpleCacheManager wallosCacheManger = new SimpleCacheManager();
		
		final GuavaCache rolesByGuavaCache = new GuavaCache("LIST_OF_BOOKS",
				CacheBuilder.newBuilder().maximumSize(500).
					expireAfterWrite(8, TimeUnit.HOURS).build());
		
		wallosCacheManger.setCaches(Arrays.asList(rolesByGuavaCache));
		
		
		
		return wallosCacheManger;
	}
}