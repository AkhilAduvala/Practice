package com.adidas.usermngment.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import com.adidas.waaloscommon.dto.usermngmntdto.UserRolesDto;

/**
 * UserRolesMapper class maps each row returned from the database to 
 * UserRolesDto object * 
 * 
 * @author infosys
 *
 */
public class UserRolesMapper implements RowMapper<UserRolesDto>{

	@Override
	public UserRolesDto mapRow(ResultSet rset, int rowNum) throws SQLException {
		final UserRolesDto usrRolesDto = new UserRolesDto();
		usrRolesDto.setRoleId(rset.getString("ROLE_ID"));
		usrRolesDto.setRoleName(rset.getString("ROLE_NM"));		
		return usrRolesDto;
	}

}
