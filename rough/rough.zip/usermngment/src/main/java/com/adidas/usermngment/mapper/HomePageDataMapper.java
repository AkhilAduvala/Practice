package com.adidas.usermngment.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.TreeMap;
import java.util.Map;
import java.util.List;
import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.RowMapper;



@SuppressWarnings("rawtypes")
public class HomePageDataMapper implements RowMapper {
	private static final Logger LOGGER = LoggerFactory.getLogger(HomePageDataMapper.class);
	
	@Override
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		List<TreeMap<String,String>> dcInfo = null;
		Map<String,List<TreeMap<String,String>>> finalData = null;
		TreeMap<String,String> functionalities = null;
		Object returnObj = null;
			try {
				if(rs==null) {
					returnObj = null;
				}else {
					finalData = new TreeMap<String, List<TreeMap<String,String>>>();
					do {
                    	if (finalData.containsKey(rs.getString("dc_nm").toString())) {
							dcInfo = finalData.get(rs.getString("dc_nm").toString());
                    	}else {
							dcInfo = new ArrayList<TreeMap<String,String>>();
                    	}
                    	
                    	functionalities = new TreeMap<String,String>();
            			functionalities.put("functnal_id", rs.getString("functnal_id").toString());
            			functionalities.put("functnal_nm", rs.getString("functnal_nm").toString());
            			dcInfo.add(functionalities);
                    	finalData.put(rs.getString("dc_nm").toString(), dcInfo);
					}while(rs.next());
					returnObj = finalData;
				}
			}catch(Exception ex) {
				LOGGER.info("Exception while preparing the JSON at Row Mapper");
				LOGGER.error("Exception caught at Row Mapper...... ",ex.getMessage());

				returnObj = null;
			}finally {
				dcInfo = null;
				functionalities = null;
				finalData = null;
			}
			return returnObj;
	}
}
