package com.adidas.usermngment.dao.impl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import com.adidas.usermngment.config.UserMngmntQueries;
import com.adidas.usermngment.dao.PermissionMngmentDao;
import com.adidas.usermngment.mapper.DcsDataMapper;
import com.adidas.usermngment.mapper.FunsDataMapper;
import com.adidas.usermngment.mapper.GetFavoritesMapper;
import com.adidas.usermngment.mapper.GetUGDataMapper;
import com.adidas.usermngment.mapper.RoleNamesMapper;
import com.adidas.usermngment.mapper.RolesDataMapper;
import com.adidas.usermngment.mapper.UGDashboardDataMapper;
import com.adidas.usermngment.util.UserMngmtConstants;
import com.adidas.waaloscommon.dto.usermngmntdto.GetUGDataDto;
import com.adidas.waaloscommon.dto.usermngmntdto.ManageFavoritesDto;
import com.adidas.waaloscommon.dto.usermngmntdto.UGDashboardDto;
import com.adidas.waaloscommon.dto.usermngmntdto.UGSearchDto;
import com.adidas.waaloscommon.dto.usermngmntdto.UserGroupMappingsDto;
import com.adidas.waaloscommon.exception.WaalosErrorResponse;
import com.adidas.waaloscommon.exception.WaalosException;
import com.adidas.waaloscommon.exception.WaalosResponse;


@Repository
@SuppressWarnings("squid:S1200")
public class PermissionMngmntDaoImpl implements PermissionMngmentDao {

	private static final Logger LOGGER = LoggerFactory.getLogger(PermissionMngmntDaoImpl.class);

	@Autowired
	@Qualifier("waalosOrclTemplate")
	private JdbcTemplate waalosOrclTemplate;
	
	@Autowired
	@Qualifier("waalosTransMngr")
	private PlatformTransactionManager waalosTransMngr;
	
	@Autowired
	private UserMngmntQueries queries;

	@PostConstruct
	public void init() {
		try {
			LOGGER.info(waalosOrclTemplate.getDataSource().getConnection().toString());
		} catch (SQLException e) {
			e.printStackTrace(); 
		} 
	}
	
	
	@SuppressWarnings("unchecked")
	@Override
	public Object getUGDashboard(final String username) throws Exception {
		LOGGER.info(" Entering into getUserGroupDataData method in PermissionMngmntDaoImpl : {}", System.currentTimeMillis());
		Object returnObj = null;
		List dataList= null;
		JdbcTemplate tempOrclTemplate = null;
		UGDashboardDto dtoObj = null;
		try{
			tempOrclTemplate = waalosOrclTemplate;
			if(tempOrclTemplate == null) {
				LOGGER.error("To Verify Database Connectivity ...",UserMngmtConstants.USR8002_MSG);
				throw new WaalosException(UserMngmtConstants.ERR9999_CODE, UserMngmtConstants.ERR9999_MSG);
			}else{
				LOGGER.info(" Start of executing getUGDashboard Query from PermissionMngmntDaoImpl : {}", System.currentTimeMillis());
				dataList = tempOrclTemplate.query(queries.getQueries().get(UserMngmtConstants.UGDASHBOARD_QRY_STRING), new UGDashboardDataMapper());
				LOGGER.info(" End of executing getUGDashboard Query from PermissionMngmntDaoImpl : {}", System.currentTimeMillis());
				if(dataList.isEmpty()) {
					returnObj = new WaalosErrorResponse(UserMngmtConstants.USR8060_CODE, UserMngmtConstants.USR8060_MSG);
				}else{
					dtoObj = new UGDashboardDto();
					dtoObj.setUgNames(getUGNames());
					dtoObj.setMappingData(dataList);
					returnObj = dtoObj;
				}
			}
		}catch(Exception ex){
			LOGGER.error("Exception caught in the implementation of getUserGroupDataData(). >>> ",ex.getMessage());
			throw new WaalosException(UserMngmtConstants.ERR9999_CODE, UserMngmtConstants.ERR9999_MSG);
		}finally{
			tempOrclTemplate = null;
			dataList = null;
			dtoObj = null;
			LOGGER.info(" Exiting from getUserGroupDataData method in PermissionMngmntDaoImpl : {}", System.currentTimeMillis());
		}
		return returnObj;		
	}



	@SuppressWarnings("unchecked")
	@Override
	public Object searchUGS(final String ugName) throws Exception {
		LOGGER.info(" Entering into searchUGS method in PermissionMngmntDaoImpl : {}", System.currentTimeMillis());
		Object returnObj = null;
		List<String> dataList= new ArrayList<String>();
		JdbcTemplate tempOrclTemplate = null;
		StringBuilder sb = new StringBuilder();
		String ugnameLower = null;
		try{
			Locale locale = Locale.getDefault();
			ugnameLower = ugName.toLowerCase(locale);
			tempOrclTemplate = waalosOrclTemplate;
			if(tempOrclTemplate==null) {
				LOGGER.error("To Verify Database Connectivity ...{}",UserMngmtConstants.USR8002_MSG);
				throw new WaalosException(UserMngmtConstants.ERR9999_CODE, UserMngmtConstants.ERR9999_MSG);
			}else{
				LOGGER.info(" Start of executing searchUGS Query from PermissionMngmntDaoImpl : {}", System.currentTimeMillis());
				sb = sb.append("%").append(ugnameLower).append("%");
				dataList= (List<String>) (tempOrclTemplate.query(queries.getQueries().get(UserMngmtConstants.SEARCH_UG_QRY_STRING),new Object[] {sb.toString()}, new RoleNamesMapper()));
				LOGGER.info(" End of executing searchUGS Query from PermissionMngmntDaoImpl : {}", System.currentTimeMillis());
				if(dataList.isEmpty()) {
					returnObj = new WaalosResponse(UserMngmtConstants.USR8023_CODE, UserMngmtConstants.USR8023_MSG);					
				}else {
					UGSearchDto dtoObj = new UGSearchDto();
					dtoObj.setUgNames(dataList.get(0));
					returnObj = dtoObj;
				}
			}
		}catch(Exception ex){
			LOGGER.error("Exception caught in the implementation of searchUGS(). >>> ",ex.getMessage());
			throw new WaalosException(UserMngmtConstants.ERR9999_CODE, UserMngmtConstants.ERR9999_MSG);
		}finally{
			tempOrclTemplate = null;
			dataList = null;
			sb = null;
			dataList = null;
			ugnameLower = null;
			LOGGER.info(" Exiting from searchUGS method in PermissionMngmntDaoImpl : {}", System.currentTimeMillis());
		}
		return returnObj;		
	}




	@SuppressWarnings("unchecked")
	@Override
	public Object deleteUserGroup(final String ugName) throws Exception {
		LOGGER.info(" Entering into deleteUserGroup method in PermissionMngmntDaoImpl : {}", System.currentTimeMillis());
		Object returnObj = null;
		JdbcTemplate tempOrclTemplate = null;
		PlatformTransactionManager tManager = null;
		TransactionStatus status = null;
		String sql = null;
		List<Map<String, Integer>> rMap = null;
		int masterRowsDeleted=0;
		try{
			tempOrclTemplate = waalosOrclTemplate;
			TransactionDefinition def = new DefaultTransactionDefinition();
			tManager = waalosTransMngr;
			if(tempOrclTemplate == null  || tManager == null ) {
				LOGGER.error("To Verify Database Connectivity ...",UserMngmtConstants.USR8002_MSG);
				throw new WaalosException(UserMngmtConstants.ERR9999_CODE, UserMngmtConstants.ERR9999_MSG);
			}else {

				rMap = getRolesMap();
				int delRoleID;
				try {
					delRoleID = (rMap.get(0)).get(ugName);
				}catch(Exception e) {
					throw new WaalosException(UserMngmtConstants.USR8069_CODE,UserMngmtConstants.USR8069_MSG);
				}
				
						status = tManager.getTransaction(def);
						
						LOGGER.info("Start of executing deleteUserGroup Queries -- {} ", System.currentTimeMillis());
						sql = queries.getQueries().get(UserMngmtConstants.DELETE_UG_USERS_QRY).toString();
						tempOrclTemplate.update(sql,new Object []{delRoleID});
						
						sql = queries.getQueries().get(UserMngmtConstants.DELETE_UG_METADATA_QRY).toString();
						tempOrclTemplate.update(sql,new String []{ugName.trim()});
						
						sql = queries.getQueries().get(UserMngmtConstants.DELETE_UG_MASTERDATA_QRY).toString();
						masterRowsDeleted = tempOrclTemplate.update(sql,new String []{ugName.trim()});
						
						// Checking only on masterDataRows as it doesn't allow to delete unless the foriegn key entries were already.
						if(masterRowsDeleted>0) {
							tManager.commit(status);
							LOGGER.info("End of executing deleteUserGroup Queries -- {} ", System.currentTimeMillis());
							returnObj = new WaalosResponse(UserMngmtConstants.USR8062_CODE,UserMngmtConstants.USR8062_MSG);
						}else {
							tManager.rollback(status);
							returnObj = new WaalosErrorResponse(UserMngmtConstants.ERR9999_CODE,UserMngmtConstants.ERR9999_MSG);
						}
			}
		}catch(Exception ex){
			LOGGER.error("Exception caught in the implementation of deleteUserGroup(). >>> ",ex.getMessage());
			throw new WaalosException(UserMngmtConstants.ERR9999_CODE, UserMngmtConstants.ERR9999_MSG);
		}finally{
			tempOrclTemplate = null;
			tManager = null;
			LOGGER.info(" Exiting from deleteUserGroup method in PermissionMngmntDaoImpl : {}", System.currentTimeMillis());
		}
		return returnObj;		
	}


	
	@SuppressWarnings("unchecked")
	
	public Object getUserGroupData(final GetUGDataDto ugDto) throws Exception {
		LOGGER.info(" Entering into getUserGroupData method in PermissionMngmntDaoImpl : {}", System.currentTimeMillis());
		Object returnObj = null;
		List dataList= null;
		JdbcTemplate tempOrclTemplate = null;
		try{
			tempOrclTemplate = waalosOrclTemplate;
			if(tempOrclTemplate == null ) {
				LOGGER.error("To Verify Database Connectivity ...{}",UserMngmtConstants.USR8002_MSG);
				throw new WaalosException(UserMngmtConstants.ERR9999_CODE, UserMngmtConstants.ERR9999_MSG);
			}else{
				LOGGER.info(" Start of executing UserGroupData Query from PermissionMngmntDaoImpl : {}", System.currentTimeMillis());
				dataList = tempOrclTemplate.query(queries.getQueries().get(UserMngmtConstants.DISPLAY_UGDATA_QRY), new Object[] {ugDto.getUgName().trim(),ugDto.getUsername()}, new GetUGDataMapper());
				LOGGER.info(" End of executing UserGroupData Query from PermissionMngmntDaoImpl : {}", System.currentTimeMillis());
				if(dataList.isEmpty()){
					returnObj = new WaalosErrorResponse(UserMngmtConstants.USR8060_CODE, UserMngmtConstants.USR8060_MSG);					
				}else {
					returnObj = dataList;					
				}
			}
		}catch(Exception ex){
			LOGGER.error("Exception caught in the implementation of getUserGroupData(). >>> ",ex.getMessage());
			throw new WaalosException(UserMngmtConstants.ERR9999_CODE, UserMngmtConstants.ERR9999_MSG);
		}finally{
			tempOrclTemplate = null;
			dataList = null;
			LOGGER.info(" Exiting from getUserGroupData method in PermissionMngmntDaoImpl : {}", System.currentTimeMillis());
		}
		return returnObj;		
	}

	

	/**
	 * To Add the New User Groups with DC & Functionality mappings provided. 
	 * 
	 * @param UserGroupMappingsDto in request as Object 
	 * 			
	 * @return a success/failure message to the User
	 */
	@SuppressWarnings({"squid:MethodCyclomaticComplexity","squid:S138"})
	public Object addNewUG(final UserGroupMappingsDto mappingsDto) throws WaalosException{
		JdbcTemplate tempOrclTemplate = null;
		Object returnObj = null;
		PlatformTransactionManager tManager = null;
		TransactionStatus status = null;
		String sql=null;
		Map<String, List<String>> dcReqTemp = null;
		List<String> funReqTemp = null;
		List<Map<String, Integer>> rMap = null;
		List<Map<String, Integer>> dMap = null;
		List<Map<String, Integer>> fMap = null;
		
		try{
			if(mappingsDto.getMappingData().isEmpty() || mappingsDto.getUgName().trim().length()==0 || mappingsDto.getUsername().trim().length()== 0 ) {
				returnObj = new WaalosErrorResponse(UserMngmtConstants.USR8063_CODE,UserMngmtConstants.USR8063_MSG);
			}else {
					TransactionDefinition def = new DefaultTransactionDefinition();
					tempOrclTemplate = waalosOrclTemplate;
					tManager = waalosTransMngr;
					if(tempOrclTemplate == null || tManager==null) {
						LOGGER.error("To Verify Database Connectivity or Transaction Manager connection from implementation class addNewUserGroup(): {} ");
						throw new WaalosException(UserMngmtConstants.ERR9999_CODE,UserMngmtConstants.ERR9999_CODE);
					}else{
						
						sql = queries.getQueries().get(UserMngmtConstants.ADD_NEWUGMASTER_QRY);
						LOGGER.info(" Start of executing addNewUserGroup Master table Query from PermissionMngmntDaoImpl : {}", System.currentTimeMillis());
						int rowsInserted = tempOrclTemplate.update(sql, new Object[] {mappingsDto.getUgName().trim().toString(),mappingsDto.getUgName().trim().toString(),mappingsDto.getUsername().trim().toString(),mappingsDto.getUgName().trim().toString()});
						LOGGER.info(" End of executing addNewUserGroup Master table Query from PermissionMngmntDaoImpl : {}", System.currentTimeMillis());
						
						LOGGER.info(" MappingsData.. : {}", mappingsDto.getMappingData());
						if(rowsInserted>0) {
							rMap = getRolesMap();
							try {
								int addRoleID = (rMap.get(0)).get(mappingsDto.getUgName().trim().toString());
								
								if(mappingsDto.getMappingData().isEmpty()) {
									returnObj = new WaalosErrorResponse(UserMngmtConstants.USR8065_CODE,UserMngmtConstants.USR8065_MSG);
								}else {
									dcReqTemp = mappingsDto.getMappingData();
									int dcID,functnalID ;
									dMap = getDcsMap();
									fMap = getFunsMap();
									
									Iterator<Entry<String,List<String>>> dcReqIT = dcReqTemp.entrySet().iterator(); 
									int mappingsInserted = 0;
									int totalMappingsReceived=0;
									
									status = tManager.getTransaction(def);
									
			        	       		while(dcReqIT.hasNext()) {
			        	       			Map.Entry<String, List<String>> dcPair = dcReqIT.next();
			        	       			try {
				        	       			dcID = dMap.get(0).get(dcPair.getKey().trim());
			        	       			}catch(Exception e) {
			        	       				throw new WaalosException(UserMngmtConstants.USR8066_CODE,UserMngmtConstants.USR8066_MSG); 
			        	       			}
				        	       		 
			        	       			funReqTemp = dcPair.getValue();
		        	       				if(funReqTemp.isEmpty()) {
		        	       					throw new WaalosException(UserMngmtConstants.USR8068_CODE,UserMngmtConstants.USR8068_MSG);
		        	       				}else {
		        	       					int sizeOfFuns = funReqTemp.size();
		        	       					totalMappingsReceived += sizeOfFuns;
		        	       					LOGGER.info(" Start of executing addNewUserGroup ROLE_DC_MAP table Query from PermissionMngmntDaoImpl : {}", System.currentTimeMillis());
			        	       				for(int i=0;i<sizeOfFuns;i++) {
			        	       					try {
			        	       						functnalID = fMap.get(0).get(funReqTemp.get(i));
			        	       					}catch(Exception e) {
			        	       						throw new WaalosException(UserMngmtConstants.USR8067_CODE,UserMngmtConstants.USR8067_MSG);
			        	       					}
				        	       					
			        	       					sql = queries.getQueries().get(UserMngmtConstants.INSERT_UG_MAPPINGS);
			        	       					rowsInserted = tempOrclTemplate.update(sql, new Object[] {addRoleID,dcID,functnalID,mappingsDto.getUsername().trim()});
			        	       					mappingsInserted+=rowsInserted;
			        	       				}
		        	       				}
			        	       		}
			        	       		
			        	       		if(mappingsInserted==totalMappingsReceived) {
		        	       				tManager.commit(status);
		        	       				LOGGER.info(" End of executing addNewUserGroup ROLE_DC_MAP table Query from PermissionMngmntDaoImpl : {}", System.currentTimeMillis());
		        	       				returnObj = new WaalosResponse(UserMngmtConstants.USR8070_CODE,UserMngmtConstants.USR8070_MSG);
		        	       			}else {
		        	       				tManager.rollback(status);
		        	       				
		        	       				LOGGER.info(" Start of executing removing ROLE_MST upon receiving Exception from addNewUserGroup Query from PermissionMngmntDaoImpl : {}", System.currentTimeMillis());
		        						sql = queries.getQueries().get(UserMngmtConstants.DELETE_UG_MASTERDATA_QRY).toString();
		        						tempOrclTemplate.update(sql,new Object []{addRoleID});
		        						LOGGER.info(" End of executing removing ROLE_MST upon receiving Exception from addNewUserGroup Query from PermissionMngmntDaoImpl : {}", System.currentTimeMillis());
										returnObj = new WaalosErrorResponse(UserMngmtConstants.ERR9999_CODE,UserMngmtConstants.ERR9999_MSG);
		        	       			}
								}
							}catch(Exception e) {
								LOGGER.error("Exception caught in the retrieving the RoleMap/DcsMap/FunsMap. Object. >>> ",e.getMessage());
								throw new WaalosException(UserMngmtConstants.ERR9999_CODE, UserMngmtConstants.ERR9999_MSG);
							}
						}else {
							returnObj = new WaalosErrorResponse(UserMngmtConstants.USR8064_CODE,UserMngmtConstants.USR8064_MSG);
						}
					}
			}
			}catch(Exception ex) {
				LOGGER.error("Exception caught in implementation of addNewUserGroup().......",ex.getMessage());
				throw new WaalosException(UserMngmtConstants.ERR9999_CODE,UserMngmtConstants.ERR9999_CODE);
			}finally{
					tempOrclTemplate=null;
					tManager = null;
					status=null;
					dcReqTemp=null;
					funReqTemp=null;
					fMap=null;
					dMap=null;
					rMap = null;
			}
		return returnObj;
	}
	

	/**
	 * To Update the Existing User Groups with DC & Functionality mappings provided. 
	 * 
	 * @param UserGroupMappingsDto in request as Object 
	 * 			
	 * @return a success/failure message to the User
	 */
	@SuppressWarnings({"squid:MethodCyclomaticComplexity","squid:S138"})
	public Object updateUG(final UserGroupMappingsDto mappingsDto) throws WaalosException{
		JdbcTemplate tempOrclTemplate = null;
		Object returnObj = null;
		PlatformTransactionManager tManager = null;
		TransactionStatus status = null;
		String sql=null;
		Map<String, List<String>> dcReqTemp = null;
		List<String> funReqTemp = null;
		List<Map<String, Integer>> rMap = null;
		List<Map<String, Integer>> dMap = null;
		List<Map<String, Integer>> fMap = null;
		
		try{
			if(mappingsDto.getMappingData().isEmpty() || mappingsDto.getUgName().trim().length()==0 || mappingsDto.getUsername().trim().length()== 0 ) {
				returnObj = new WaalosErrorResponse(UserMngmtConstants.USR8063_CODE,UserMngmtConstants.USR8063_MSG);
			}else {
					TransactionDefinition def = new DefaultTransactionDefinition();
					tempOrclTemplate = waalosOrclTemplate;
					tManager = waalosTransMngr;
					
					if(tempOrclTemplate == null || tManager==null) {
						LOGGER.error("To Verify Database Connectivity or Transaction Manager connection from implementation class addNewUserGroup(): {} ");
						throw new WaalosException(UserMngmtConstants.ERR9999_CODE,UserMngmtConstants.ERR9999_CODE);
					}else{
						int rowsInserted;
						rMap = getRolesMap();
						try {
							int updRoleID;
							try {
								updRoleID = (rMap.get(0)).get(mappingsDto.getUgName().trim().toString());
							}catch(Exception e) {
								throw new WaalosException(UserMngmtConstants.USR8069_CODE,UserMngmtConstants.USR8069_MSG);
							}
							
							if(mappingsDto.getMappingData().isEmpty()) {
								returnObj = new WaalosErrorResponse(UserMngmtConstants.USR8065_CODE,UserMngmtConstants.USR8065_MSG);
							}else {
								dcReqTemp = mappingsDto.getMappingData();
								int dcID,functnalID ;
								dMap = getDcsMap();
								fMap = getFunsMap();
								
								Iterator<Entry<String,List<String>>> dcReqIT = dcReqTemp.entrySet().iterator(); 
								int mappingsInserted = 0;
								int totalMappingsReceived=0;
								status = tManager.getTransaction(def);
								
								sql = queries.getQueries().get(UserMngmtConstants.DELETE_UG_MAPPINGS);
    							LOGGER.info(" Start of executing updateUserGroup deleting from ROLES_DC_MAP table Query from PermissionMngmntDaoImpl : {}", System.currentTimeMillis());
    							tempOrclTemplate.update(sql, new Object[] {updRoleID});
    							LOGGER.info(" End of executing updateUserGroup deleting from ROLES_DC_MAP table Query from PermissionMngmntDaoImpl : {}", System.currentTimeMillis());
    							
			        	      		while(dcReqIT.hasNext()) {
			        	      			Map.Entry<String, List<String>> dcPair = dcReqIT.next();
			        	      			try {
				               			dcID = dMap.get(0).get(dcPair.getKey().trim());
			        	      			}catch(Exception e) {
			        	      				throw new WaalosException(UserMngmtConstants.USR8066_CODE,UserMngmtConstants.USR8066_MSG); 
			        	      			}
				               		 
			        	      			funReqTemp = dcPair.getValue();
		        	      				if(funReqTemp.isEmpty()) {
		        	      					throw new WaalosException(UserMngmtConstants.USR8068_CODE,UserMngmtConstants.USR8068_MSG);
		        	      				}else {
		        	      					int sizeOfFuns = funReqTemp.size();
		        	      					
		        	      					totalMappingsReceived += sizeOfFuns;
		        	      					
		        	      					LOGGER.info(" Start of executing updateUserGroup ROLE_DC_MAP table Query from PermissionMngmntDaoImpl : {}", System.currentTimeMillis());
			        	      				for(int i=0;i<sizeOfFuns;i++) {
			        	      					try {
			        	      						functnalID = fMap.get(0).get(funReqTemp.get(i));
			        	      					}catch(Exception e) {
			        	      						throw new WaalosException(UserMngmtConstants.USR8067_CODE,UserMngmtConstants.USR8067_MSG);
			        	      					}
				               					
			        	      					sql = queries.getQueries().get(UserMngmtConstants.INSERT_UG_MAPPINGS);
			        	      					rowsInserted = tempOrclTemplate.update(sql, new Object[] {updRoleID,dcID,functnalID,mappingsDto.getUsername().trim()});
			        	      					mappingsInserted+=rowsInserted;
			        	      				}
		        	      				}
			        	      		}
			        	      		
			        	      		if(mappingsInserted==totalMappingsReceived) {
		        	      				tManager.commit(status);
		        	      				LOGGER.info(" End of executing updateUserGroup ROLE_DC_MAP table Query from PermissionMngmntDaoImpl : {}", System.currentTimeMillis());
		        	      				returnObj = new WaalosResponse(UserMngmtConstants.USR8061_CODE,UserMngmtConstants.USR8061_MSG);
		        	      				
		        	      			}else {
		        	      				tManager.rollback(status);
		        	      				returnObj = new WaalosErrorResponse(UserMngmtConstants.ERR9999_CODE,UserMngmtConstants.ERR9999_MSG);
		        	      			}
								}
							}catch(Exception e) {
								LOGGER.error("Exception caught in the retrieving the RoleMap/DcsMap/FunsMap. Object. >>> ",e.getMessage());
								throw new WaalosException(UserMngmtConstants.ERR9999_CODE, UserMngmtConstants.ERR9999_MSG);
							}
					}
			}
			}catch(Exception ex) {
				if(null!=tManager) {
					tManager.rollback(status);
				}
				LOGGER.error("Exception caught in implementation of updateUserGroup().......",ex.getMessage());
				throw new WaalosException(UserMngmtConstants.ERR9999_CODE,UserMngmtConstants.ERR9999_CODE);
			}finally{
					tempOrclTemplate=null;
					tManager = null;
					status=null;
					dcReqTemp=null;
					funReqTemp=null;
					fMap=null;
					dMap=null;
					rMap = null;
			}
		return returnObj;
	}
	
	


	@SuppressWarnings({"squid:MethodCyclomaticComplexity","squid:S138"})
	public Object addFavorite(final ManageFavoritesDto favDto) throws WaalosException{
		JdbcTemplate tempOrclTemplate = null;
		Object returnObj = null;
		List<Map<String, Integer>> dMap = null;
		List<Map<String, Integer>> fMap = null;
		
		try{
			if(favDto.getFunName().length()==0 || favDto.getUsername().trim().length()==0 || favDto.getDcName().trim().length()== 0 ) {
				returnObj = new WaalosErrorResponse(UserMngmtConstants.USR8063_CODE,UserMngmtConstants.USR8063_MSG);
			}else {
					tempOrclTemplate = waalosOrclTemplate;
					if(tempOrclTemplate == null ) {
						LOGGER.error("To Verify Database Connectivity from implementation class addFavorite(): {} ");
						throw new WaalosException(UserMngmtConstants.ERR9999_CODE,UserMngmtConstants.ERR9999_CODE);
					}else{
						
							try {
									int dcID,functnalID ;
									dMap = getDcsMap();
									fMap = getFunsMap();
			        	       		try {
				        	       		dcID = dMap.get(0).get(favDto.getDcName().trim());
	        	       					functnalID = fMap.get(0).get(favDto.getFunName().trim());
	        	       					
	        	       					if(getFavList(favDto.getUsername().trim(),dcID, functnalID).isEmpty()) {
	        	       						if(getFavList(favDto.getUsername().trim(),0,0).size()<5) {
	        	       						
		        	       						LOGGER.info(" Start of executing addFavorite from PermissionMngmntDaoImpl : {}", System.currentTimeMillis());
												int rowsInserted = tempOrclTemplate.update(queries.getQueries().get(UserMngmtConstants.USR_ADD_FAVORITE), new Object[] {favDto.getUsername().trim(),functnalID,dcID,favDto.getUsername().trim()});
												LOGGER.info(" End of executing addFavorite from PermissionMngmntDaoImpl : {}", System.currentTimeMillis());
	
						        	       		if(rowsInserted>0) {
					        	       				returnObj = new WaalosResponse(UserMngmtConstants.USR8090_CODE,UserMngmtConstants.USR8090_MSG);
					        	       			}else {
													returnObj = new WaalosErrorResponse(UserMngmtConstants.ERR9999_CODE,UserMngmtConstants.ERR9999_MSG);
					        	       			}
	        	       						}else {
	        	       							returnObj = new WaalosErrorResponse(UserMngmtConstants.USR8094_CODE,UserMngmtConstants.USR8094_MSG);
	        	       						}
	        	       					}else {
				        	       			returnObj = new WaalosErrorResponse(UserMngmtConstants.USR8093_CODE,UserMngmtConstants.USR8093_MSG);	        	       						
	        	       					}
			        	       		}catch(Exception e) {
			        	       			returnObj = new WaalosErrorResponse(UserMngmtConstants.USR8092_CODE,UserMngmtConstants.USR8092_MSG); 
			        	       		}
							}catch(Exception e) {
								e.printStackTrace();
								LOGGER.error("Exception caught in the retrieving the RoleMap/DcsMap/FunsMap. Object. >>> ",e.getMessage());
								throw new WaalosException(UserMngmtConstants.ERR9999_CODE, UserMngmtConstants.ERR9999_MSG);
							}
					}
			}
			}catch(Exception ex) {
				LOGGER.error("Exception caught in implementation of addFavorite().......",ex.getMessage());
				throw new WaalosException(UserMngmtConstants.ERR9999_CODE,UserMngmtConstants.ERR9999_CODE);
			}finally{
					tempOrclTemplate=null;
					fMap=null;
					dMap=null;
			}
		return returnObj;
	}



	@SuppressWarnings({"squid:MethodCyclomaticComplexity","squid:S138"})
	public Object deleteFavorite(final ManageFavoritesDto favDto) throws WaalosException{
		JdbcTemplate tempOrclTemplate = null;
		Object returnObj = null;
		List<Map<String, Integer>> dMap = null;
		List<Map<String, Integer>> fMap = null;
		
		try{
			if(favDto.getFunName().length()==0 || favDto.getUsername().trim().length()==0 || favDto.getDcName().trim().length()== 0 ) {
				returnObj = new WaalosErrorResponse(UserMngmtConstants.USR8063_CODE,UserMngmtConstants.USR8063_MSG);
			}else {
					tempOrclTemplate = waalosOrclTemplate;
					if(tempOrclTemplate == null ) {
						LOGGER.error("To Verify Database Connectivity from implementation class deleteFavorite(): {} ");
						throw new WaalosException(UserMngmtConstants.ERR9999_CODE,UserMngmtConstants.ERR9999_CODE);
					}else{
							try {
									int dcID,functnalID ;
									dMap = getDcsMap();
									fMap = getFunsMap();
			        	       		try {
				        	       		dcID = dMap.get(0).get(favDto.getDcName().trim());
	        	       					functnalID = fMap.get(0).get(favDto.getFunName().trim());
	        	       					LOGGER.info(" Start of executing deleteFavorite from PermissionMngmntDaoImpl : {}", System.currentTimeMillis());
										int rowsDeleted = tempOrclTemplate.update(queries.getQueries().get(UserMngmtConstants.USR_DELETE_FAVORITE), new Object[] {favDto.getUsername().trim(),functnalID,dcID});
										LOGGER.info(" End of executing deleteFavorite from PermissionMngmntDaoImpl : {}", System.currentTimeMillis());

				        	       		if(rowsDeleted>0) {
			        	       				returnObj = new WaalosResponse(UserMngmtConstants.USR8091_CODE,UserMngmtConstants.USR8091_MSG);
			        	       			}else {
			        	       				returnObj = new WaalosResponse(UserMngmtConstants.USR8023_CODE,UserMngmtConstants.USR8023_MSG);
			        	       			}
			        	       		}catch(Exception e) {
			        	       			returnObj = new WaalosErrorResponse(UserMngmtConstants.USR8092_CODE,UserMngmtConstants.USR8092_MSG); 
			        	       		}
							}catch(Exception e) {
								e.printStackTrace();
								LOGGER.error("Exception caught in the retrieving the RoleMap/DcsMap/FunsMap. Object. >>>{} ",e.getMessage());
								throw new WaalosException(UserMngmtConstants.ERR9999_CODE, UserMngmtConstants.ERR9999_MSG);
							}
					}
			}
			}catch(Exception ex) {
				LOGGER.error("Exception caught in implementation of deleteFavorite().......",ex.getMessage());
				throw new WaalosException(UserMngmtConstants.ERR9999_CODE,UserMngmtConstants.ERR9999_CODE);
			}finally{
					tempOrclTemplate=null;
					fMap=null;
					dMap=null;
			}
		return returnObj;
	}


	
	@SuppressWarnings("unchecked")
	@Override
	public Object getFavorites(final String username) throws Exception {
		Object returnObj = null;
		JdbcTemplate tempOrclTemplate = null;
		try{
			tempOrclTemplate = waalosOrclTemplate;
			if(tempOrclTemplate == null) {
				LOGGER.error("To Verify Database Connectivity ...{}",UserMngmtConstants.USR8002_MSG);
				throw new WaalosException(UserMngmtConstants.ERR9999_CODE, UserMngmtConstants.ERR9999_MSG);
			}else{
				LOGGER.info(" Start of executing getFavorites Query from PermissionMngmntDaoImpl : {}", System.currentTimeMillis());
				returnObj = getFavList(username,0,0);
				LOGGER.info(" End of executing getFavorites Query from PermissionMngmntDaoImpl : {}", System.currentTimeMillis());
			}
		}catch(Exception ex){
			LOGGER.error("Exception caught in the implementation of getUserGroupDataData(). >>> ",ex.getMessage());
			throw new WaalosException(UserMngmtConstants.ERR9999_CODE, UserMngmtConstants.ERR9999_MSG);
		}finally{
			tempOrclTemplate = null;
			LOGGER.info(" Exiting from getUserGroupDataData method in PermissionMngmntDaoImpl : {}", System.currentTimeMillis());
		}
		return returnObj;		
	}


	
	private List getFavList(final String username,int dcID, int functnalID) {
		List data = null;
		JdbcTemplate tempOrclTemplate = null;
		try {
			tempOrclTemplate = waalosOrclTemplate;
			if(dcID==0 && functnalID==0) {
				data = tempOrclTemplate.query(queries.getQueries().get(UserMngmtConstants.DISPLAY_FAVORITES_QRY),new Object[] {username}, new GetFavoritesMapper());				
			}else {
				data = tempOrclTemplate.query(queries.getQueries().get(UserMngmtConstants.USRFAV_EXISTS_QRY),new Object[] {username,dcID,functnalID}, new GetFavoritesMapper());
			}
		}catch(Exception e) {
			LOGGER.info("Exception caught while populating the favorites in getFavList() ...{}",e.getMessage());
		}finally {
			tempOrclTemplate = null;
		}
		return data;
	}
	
	/* 
	 * To capture the functionalities data from TB_WAALOS_FUNCTNAL_DTLS into List<Map> Object
	 * Key being FUNCTNAL_NM
	 * Value being FUNCTNAL_ID 
	 *  
	 */
	private List<Map<String, Integer>> getFunsMap() {
		List<Map<String, Integer>> fMap = null;
		JdbcTemplate tempOrclTemplate = null;
		try {
			tempOrclTemplate = waalosOrclTemplate;
			fMap = tempOrclTemplate.query(queries.getQueries().get(UserMngmtConstants.ALL_FUNCTIONALITIES_QRY), new FunsDataMapper());
		}catch(Exception e) {
			LOGGER.info("Exception caught while populating the functionalities in getFunsMap() ...{}",e.getMessage());
		}finally {
			tempOrclTemplate = null;
		}
		return fMap;
	}

	

	/* 
	 * To capture the dcs data from TB_WAALOS_DC_DTLS into List<Map> Object
	 * Key being DC_NM
	 * Value being DC_ID 
	 *  
	 */
	private List<Map<String, Integer>> getDcsMap() {
		List<Map<String, Integer>> dMap = null;
		JdbcTemplate tempOrclTemplate = null;
		try {
			tempOrclTemplate = waalosOrclTemplate;
			dMap = tempOrclTemplate.query(queries.getQueries().get(UserMngmtConstants.ALL_DCS_QRY), new DcsDataMapper());
		}catch(Exception e) {
			LOGGER.info("Exception caught while populating the functionalities in getDcsMap() ...{}",e.getMessage());
		}finally {
			tempOrclTemplate = null;
		}
		return dMap;
	}

	
	/* 
	 * To capture the user groups data from TB_WAALOS_DC_DTLS into List<Map> Object
	 * Key being ROLE_NM
	 * Value being ROLE_ID 
	 *  
	 */
	private List<Map<String, Integer>> getRolesMap() {
		List<Map<String, Integer>> rMap = null;
		JdbcTemplate tempOrclTemplate = null;
		try {
			tempOrclTemplate = waalosOrclTemplate;
			rMap = tempOrclTemplate.query(queries.getQueries().get(UserMngmtConstants.ALL_USERGROUPS_QRY), new RolesDataMapper());
		}catch(Exception e) {
			LOGGER.info("Exception caught while populating the functionalities in getDcsMap() ...{}",e.getMessage());
		}finally {
			tempOrclTemplate = null;
		}
		return rMap;
	}
	
	/* 
	 * To capture the all the available UserGroups into List Object
	 *  Being usergroup name being its fields
	 *  
	 */
	private List<String> getUGNames() {
		List<String> rList = new ArrayList<String>();
		JdbcTemplate tempOrclTemplate = null;
		try {
			tempOrclTemplate = waalosOrclTemplate;
			rList= (List<String>) (tempOrclTemplate.query(queries.getQueries().get(UserMngmtConstants.ALL_USERGROUPS_QRY), new RoleNamesMapper())).get(0);
		}catch(Exception e) {
			LOGGER.info("Exception caught while populating the functionalities in getDcsMap() ...{}",e.getMessage());
		}finally {
			tempOrclTemplate = null;
		}
		return rList;
	}
	
	
}