package com.adidas.usermngment.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.adidas.waaloscommon.dto.usermngmntdto.UserDto;

/**
 * UserDetailsMapper class maps each row returned from the database to 
 * IPGoalsChangerDto object * 
 * 
 * @author infosys
 *
 */

public class UserDetailsMapper implements RowMapper<UserDto> {

	@Override
	public UserDto mapRow(ResultSet resultSet, int rowNum) throws SQLException {
		final UserDto userDto = new UserDto();
		userDto.setUsrId(resultSet.getString("USR_ID"));		
		userDto.setUsrFirstName(resultSet.getString("USR_FRST_NM"));
		userDto.setUsrMiddleName(resultSet.getString("USR_MDL_NM"));
		userDto.setUsrLastName(resultSet.getString("USR_LST_NM"));
		userDto.setEmailId(resultSet.getString("USR_EMAIL"));
		userDto.setCity(resultSet.getString("USR_CITY"));
		userDto.setState(resultSet.getString("USR_STATE"));
		userDto.setCountry(resultSet.getString("USR_CNTRY"));
		userDto.setLastLogin(resultSet.getTimestamp("USR_LAST_LGN"));
		userDto.setUsrActInd(resultSet.getString("USR_ACTV_IND"));
		userDto.setRoleId(resultSet.getInt("ROLE_ID"));
		userDto.setCreatedBy(resultSet.getString("CRTD_BY"));
		userDto.setCreatedDate(resultSet.getTimestamp("CRTD_DT"));
		userDto.setUpdatedBy(resultSet.getString("UPDT_BY"));
		userDto.setUpdatedDate(resultSet.getTimestamp("UPDT_DT"));
		userDto.setDomainUserId(resultSet.getString("DOMAIN_USER_ID"));
		userDto.setUserGroup(resultSet.getString("ROLE_NM"));
		return userDto ;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
