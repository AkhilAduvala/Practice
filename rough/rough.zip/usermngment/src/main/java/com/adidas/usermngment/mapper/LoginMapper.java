package com.adidas.usermngment.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.RowMapper;

import com.adidas.waaloscommon.dto.usermngmntdto.LoginDto;

public class LoginMapper implements RowMapper {
	private static final Logger LOGGER = LoggerFactory.getLogger(LoginMapper.class);

	@Override
	public LoginDto mapRow(ResultSet rs, int rowNum) throws SQLException {
		LOGGER.info("Entering mapRow DcDto{} ", System.currentTimeMillis());
		LoginDto loginDto = null;
		try {
			loginDto = new LoginDto();
			loginDto.setUgName(rs.getString("ROLE_NM"));
			loginDto.setFName(rs.getString("USR_FRST_NM"));
			loginDto.setFLastName(rs.getString("USR_LST_NM"));
			loginDto.setUsrDefPrinter(rs.getString("PRINTER_IP"));
			loginDto.setUsrDefPrinterName(rs.getString("PRINTER_NAME"));
			loginDto.setUsrDefPrinterId(rs.getInt("PRITER_ID"));
			loginDto.setUserDefPrinterPort(rs.getString("PRINTER_PORT"));
          	loginDto.setUEmail(rs.getString("USR_EMAIL"));
			return loginDto;
			
		} finally {
			LOGGER.info("Exiting mapRow DcDto{} ", System.currentTimeMillis());
		}
	}
}
