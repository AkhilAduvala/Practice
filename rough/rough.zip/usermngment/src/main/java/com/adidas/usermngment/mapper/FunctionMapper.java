package com.adidas.usermngment.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.RowMapper;

import com.adidas.waaloscommon.dto.usermngmntdto.FunctionDto;

public class FunctionMapper implements RowMapper {
	private static final Logger LOGGER = LoggerFactory.getLogger(FunctionMapper.class);

	@Override
	public FunctionDto mapRow(ResultSet rs, int rowNum) throws SQLException {
		LOGGER.info("Entering mapRow DcDto{} ", System.currentTimeMillis());
		FunctionDto functionaMapperDto = null;
		try {
			functionaMapperDto = new FunctionDto();
			functionaMapperDto.setFunctionId(rs.getInt("FUNCTNAL_ID"));
			functionaMapperDto.setFunctionName(rs.getString("FUNCTNAL_NM"));
			return functionaMapperDto;
		} finally {
			LOGGER.info("Exiting mapRow DcDto{} ", System.currentTimeMillis());
		}
	}
}
