package com.adidas.usermngment.dao.impl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import com.adidas.usermngment.config.UserMngmntQueries;
import com.adidas.usermngment.dao.UserMngmntDao;
import com.adidas.usermngment.helper.UserMngmntHelper;
import com.adidas.usermngment.mapper.DcMapper;
import com.adidas.usermngment.mapper.FunctionMapper;
import com.adidas.usermngment.mapper.HomePageDataMapper;
import com.adidas.usermngment.mapper.LoginMapper;
import com.adidas.usermngment.mapper.PrinterAllMapper;
import com.adidas.usermngment.mapper.PrinterMapper;
import com.adidas.usermngment.mapper.UserDetailsMapper;
import com.adidas.usermngment.mapper.UserRolesMapper;
import com.adidas.usermngment.util.UserMngmtConstants;
import com.adidas.usermngment.util.UserPaginationHelper;
import com.adidas.waaloscommon.constants.WaalosConstants;
import com.adidas.waaloscommon.dto.usermngmntdto.DcDto;
import com.adidas.waaloscommon.dto.usermngmntdto.DefaultPrinterDto;
import com.adidas.waaloscommon.dto.usermngmntdto.FunctionDto;
import com.adidas.waaloscommon.dto.usermngmntdto.LoginDto;
import com.adidas.waaloscommon.dto.usermngmntdto.UserDto;
import com.adidas.waaloscommon.dto.usermngmntdto.UserRolesDto;
import com.adidas.waaloscommon.dto.wmsdto.PrinterDto;
import com.adidas.waaloscommon.exception.WaalosException;
import com.adidas.waaloscommon.exception.WaalosResponse;
import com.adidas.waaloscommon.pagination.Page;

@Repository
@SuppressWarnings("squid:S1200")
public class UserMngmntDaoImpl implements UserMngmntDao {

	private static final Logger LOGGER = LoggerFactory.getLogger(UserMngmntDaoImpl.class);

	@Autowired
	@Qualifier("waalosOrclTemplate")
	private JdbcTemplate waalosOrclTemplate;

	@Autowired
	private UserMngmntQueries queries;

	@Autowired

	private UserPaginationHelper pagHelper;

	@Autowired
	private UserMngmntHelper userMngmntHelper;

	@Autowired
	@Qualifier("waalosTransMngr")
	private PlatformTransactionManager transManager;

	@PostConstruct
	public void init() {
		try {
			LOGGER.info(waalosOrclTemplate.getDataSource().getConnection().toString());
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<DcDto> getDcDetails() throws Exception {
		List<DcDto> dcLst = null;
		JdbcTemplate jdbcTemplate = null;
		try {
			jdbcTemplate = waalosOrclTemplate;
			if (jdbcTemplate == null) {
				throw new WaalosException(UserMngmtConstants.USR8002_CODE, UserMngmtConstants.USR8002_MSG);
			} else {
				jdbcTemplate.setFetchSize(10);
				dcLst = jdbcTemplate.query(queries.getQueries().get("bookQuery"), new DcMapper());
			}
		} catch (Exception ex) {
			LOGGER.error("Exception caught in the implementation of getDcDetails(). >>> ", ex);
			throw new WaalosException(UserMngmtConstants.USR8003_CODE, UserMngmtConstants.USR8003_MSG);
		} finally {
			jdbcTemplate = null;
		}
		return dcLst;
	}

	@SuppressWarnings("unchecked")
	public Page<FunctionDto> getFunctionDtls(int pageNumber, int pageSize) throws Exception {
		Page<FunctionDto> pageFunDtls = null;
		JdbcTemplate jdbcTemplate = null;
		try {
			jdbcTemplate = waalosOrclTemplate;
			pageFunDtls = pagHelper.fetchPage(jdbcTemplate, queries.getQueries().get("waalosFunCntQry"),
					queries.getQueries().get("waalosFunQry"), new Object[] {}, pageNumber, pageSize,
					new FunctionMapper());
		} catch (Exception functionEx) {
			LOGGER.error("Exception caught in the implementation of getFunctionDtls(). >>> ", functionEx);
			throw new WaalosException(UserMngmtConstants.USR8004_CODE, UserMngmtConstants.USR8004_MSG);
		} finally {
			jdbcTemplate = null;
		}
		return pageFunDtls;
	}

	@SuppressWarnings("unchecked")
	@Override
	public Object getHomePageData(final String username) throws Exception {
		LOGGER.info(" Entering into getHomePageData method in UserMngmntDaoImpl : {}", System.currentTimeMillis());
		Object returnObj = null;
		List dataList = null;
		JdbcTemplate tempOrclTemplate = null;
		try {
			tempOrclTemplate = waalosOrclTemplate;
			if (tempOrclTemplate == null) {
				LOGGER.error("To Verify Database Connectivity ...", UserMngmtConstants.USR8002_MSG);
				throw new WaalosException(UserMngmtConstants.ERR9999_CODE, UserMngmtConstants.ERR9999_MSG);
			} else {
				LOGGER.info(" Start of executing HomePage Query from UserMngmntDaoImpl : {}",
						System.currentTimeMillis());
				Locale locale = Locale.getDefault();
				String usernameLocal = username.toLowerCase(locale);

				dataList = tempOrclTemplate.query(queries.getQueries().get(UserMngmtConstants.HOMEPAGE_QRY_STRING),
						new Object[] { usernameLocal }, new HomePageDataMapper());
				LOGGER.info(" End of executing HomePage Query from UserMngmntDaoImpl : {}", System.currentTimeMillis());
				if (dataList.isEmpty()) {
					returnObj = new WaalosResponse(UserMngmtConstants.USR8006_CODE, UserMngmtConstants.USR8006_MSG);
				} else {
					returnObj = dataList;
				}
			}
		} catch (Exception ex) {
			LOGGER.error("Exception caught in the implementation of getHomePageData(). >>> ", ex);
			throw new WaalosException(UserMngmtConstants.ERR9999_CODE, UserMngmtConstants.ERR9999_MSG);
		} finally {
			tempOrclTemplate = null;
			dataList = null;
			LOGGER.info(" Exiting from getHomePageData method in UserMngmntDaoImpl : {}", System.currentTimeMillis());
		}
		return returnObj;
	}

	@SuppressWarnings("unchecked")
	public Object fetchUserCount(String userId) throws Exception {
		LOGGER.info("Entering into fetchUserCount method in UserMngmntDaoImpl : {}", System.currentTimeMillis());
		LoginDto loginDto = null;
		String[] modifedUser = null;
		String userName = null;
		JdbcTemplate jdbcTemplate = null;
		try {
			if (userId.contains("\\")) {
				modifedUser = userId.split(Pattern.quote("\\"));
				userName = modifedUser[1];
				LOGGER.info("Splitted userName .........{}", userName);
			} else {
				userName = userId;
				LOGGER.info("in else userName.........{}", userName);
			}
			jdbcTemplate = waalosOrclTemplate;
			loginDto = (LoginDto) jdbcTemplate.queryForObject(queries.getQueries().get("fetchUserCount"),
					new Object[] { userName }, new LoginMapper());

			LOGGER.info("waalosUerCnt indao........{}", loginDto.getUgName());
			LOGGER.error("printerid .......{}", loginDto.getUsrDefPrinter() + loginDto.getUsrDefPrinterName());

		} catch (EmptyResultDataAccessException era) {
			LOGGER.error("Exception caught in the implementation of fetchUserCount(). >>> ", era);
			LoginDto loginErroDto = new LoginDto();
			loginErroDto.setLoginErrorCd(UserMngmtConstants.ERR99111_CODE);
			return loginErroDto;
		} catch (Exception ex) {
			LOGGER.error("Exception caught in the implementation of fetchUserCount(). >>> ", ex);
			ex.printStackTrace();
			throw new WaalosException(UserMngmtConstants.ERR9999_CODE, UserMngmtConstants.ERR9999_MSG);
		} finally {
			jdbcTemplate = null;
			LOGGER.info(" Entering into fetchUserCount method in UserMngmntDaoImpl : {}", System.currentTimeMillis());
		}

		return loginDto;
	}

	/**
	 * Fetches all users data and uses server side pagination
	 * 
	 * @param pgNum
	 * @param pgSize
	 * @return Page<UserDto>
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Page<UserDto> searchAllUserDetails(int pgNum, int pgSize) {
		LOGGER.info(" Entering searchAllUserDetails method in UserMngmntDaoImpl {} ", System.currentTimeMillis());
		String getAllUrsCountQry = "";
		String getAllUrsQry = "";
		final int pageNum = pgNum;
		final int pageSize = pgSize;
		Page<UserDto> usrDtoLst;
		JdbcTemplate jdbcTemplate = null;
		try {
			jdbcTemplate = waalosOrclTemplate;
			if (jdbcTemplate == null) {
				LOGGER.error("Failed to create database connection in searchAllUserDetails method");
				throw new WaalosException(WaalosConstants.ERR9002_CODE, WaalosConstants.ERR9002_MSG);
			} else {
				getAllUrsCountQry = queries.getQueries().get(UserMngmtConstants.USRM_GET_ALL_USRS_COUNT_QRY);
				getAllUrsQry = queries.getQueries().get(UserMngmtConstants.USRM_GET_ALL_USRS_QRY);
				jdbcTemplate.setFetchSize(WaalosConstants.FETCHSIZE_150);

				LOGGER.debug("Query to search user : {} ", getAllUrsQry);
				LOGGER.debug("Query to get user count : {} ", getAllUrsCountQry);
				usrDtoLst = pagHelper.fetchPage(waalosOrclTemplate, getAllUrsCountQry, getAllUrsQry, new Object[] {},
						pageNum, pageSize, new UserDetailsMapper());
			}
		} catch (Exception ex) {
			LOGGER.error("Fatal Exception caught ", ex);
			throw new WaalosException(WaalosConstants.ERR9999_CODE, WaalosConstants.ERR9999_MSG);
		} finally {
			LOGGER.info(" Exiting from searchAllUserDetails method in UserMngmntDaoImpl {}",
					System.currentTimeMillis());
			jdbcTemplate = null;
		}
		return usrDtoLst;

	}

	/**
	 * Method to fetch user data based on the input search criteria
	 * 
	 * @param userDto
	 * @return List<UserDto>
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Page<UserDto> searchUserByFilter(UserDto userDto) {
		LOGGER.info(" Entering searchUserByFilter method in UserMngmntDaoImpl", System.currentTimeMillis());
		String sqlQuery = "";
		String sqlCountQuery = "";
		final int pageNum;
		final int pageSize;
		Page<UserDto> usrDtoLst;
		JdbcTemplate jdbcTemplate = null;
		try {
			jdbcTemplate = waalosOrclTemplate;
			if (jdbcTemplate == null) {
				LOGGER.error("Failed to create database connection in searchUserByFilter method");
				throw new WaalosException(WaalosConstants.ERR9002_CODE, WaalosConstants.ERR9002_MSG);
			} else {
				pageNum = userDto.getPageNumber();
				pageSize = userDto.getPageSize();
				int finalPgNum = 0;
				int finalPgSize = 0;
				if (pageNum == 0) {
					finalPgNum = 1;
				} else {
					finalPgNum = pageNum;
				}
				if (pageSize == 0) {
					finalPgSize = 15;
				} else {
					finalPgSize = pageSize;
				}
				sqlQuery = userMngmntHelper.createUserSearchQry(userDto, UserMngmtConstants.USRM_USR_QRY_ALL);
				sqlCountQuery = userMngmntHelper.createUserSearchQry(userDto, UserMngmtConstants.USRM_USR_QRY_COUNT);
				jdbcTemplate.setFetchSize(WaalosConstants.FETCHSIZE_15);

				LOGGER.info("Query to search user  {} ", sqlQuery);
				final Object[] params = userMngmntHelper.usrSearchQryParam(userDto);

				usrDtoLst = pagHelper.fetchPage(jdbcTemplate, sqlCountQuery, sqlQuery, params, finalPgNum, finalPgSize,
						new UserDetailsMapper());
			}
		} catch (Exception ex) {
			LOGGER.error("Fatal Exception caught ", ex);
			throw new WaalosException(WaalosConstants.ERR9999_CODE, WaalosConstants.ERR9999_MSG);
		} finally {
			jdbcTemplate = null;
			LOGGER.info(" Exiting searchUserByFilter method in UserMngmntDaoImpl {}", System.currentTimeMillis());
		}
		return usrDtoLst;
	}

	/**
	 * Method to update user data
	 * 
	 * @param userDto
	 * @return int (count of records modified)
	 */
	public int modifyUser(UserDto userDto) {
		LOGGER.info(" Entering modifyUser method in UserMngmntDaoImpl {}", System.currentTimeMillis());
		String sqlQuery = "";
		int rowUpdated = 0;
		JdbcTemplate jdbcTemplate = null;
		try {
			jdbcTemplate = waalosOrclTemplate;
			if (waalosOrclTemplate == null) {
				LOGGER.error("Failed to create database connection in modifyUser method");
				throw new WaalosException(WaalosConstants.ERR9002_CODE, WaalosConstants.ERR9002_MSG);
			} else {
				final Object[] params = new Object[] { userDto.getUsrFirstName(), userDto.getUsrLastName(),
						userDto.getEmailId(), userDto.getUserName(), userDto.getUsrActInd(), userDto.getUserGroup(),
						userDto.getUsrId().toLowerCase(Locale.getDefault()) };
				sqlQuery = queries.getQueries().get(UserMngmtConstants.USRM_UPDATE_USR_QRY);
				LOGGER.debug("Query to search user : {} ", sqlQuery);

				rowUpdated = jdbcTemplate.update(sqlQuery, params);
			}
		} catch (Exception ex) {
			LOGGER.error("Fatal Exception caught ", ex);
			throw new WaalosException(WaalosConstants.ERR9999_CODE, WaalosConstants.ERR9999_MSG);
		} finally {
			jdbcTemplate = null;
			LOGGER.info("Exiting modifyUser method in UserMngmntDaoImpl : {}", System.currentTimeMillis());
		}
		return rowUpdated;

	}

	/**
	 * Method to (soft) delete users from db
	 * 
	 * @param userDtoLst
	 *            (list of users)
	 * @return int (count of users deactivated)
	 */
	@Override
	public int deactivateUser(List<UserDto> userDtoLst) {
		LOGGER.info(" Entering deactivateUser method in UserMngmntDaoImpl {} ", System.currentTimeMillis());
		String deactivateQuery = "";
		int totalRowsUpdtd = 0;
		List<Object[]> params = null;
		JdbcTemplate jdbcTemplate = waalosOrclTemplate;
		PlatformTransactionManager tManager = transManager;
		TransactionStatus status = null;
		int[] rowsUpdated;
		try {
			if (jdbcTemplate == null || tManager == null) {
				LOGGER.error("Failed to create database connection in deactivateUser method");
				throw new WaalosException(WaalosConstants.ERR9002_CODE, WaalosConstants.ERR9002_MSG);
			} else {
				final TransactionDefinition def = new DefaultTransactionDefinition();
				status = tManager.getTransaction(def);
				deactivateQuery = queries.getQueries().get(UserMngmtConstants.USRM_DEACTIVATE_USRS_QRY);
				LOGGER.info("Query to deactivate users: {} ", deactivateQuery);
				params = new ArrayList<>();
				for (final UserDto usrDto : userDtoLst) {
					params.add(
							new Object[] { usrDto.getUserName(), usrDto.getUsrId().toLowerCase(Locale.getDefault()) });
				}
				rowsUpdated = jdbcTemplate.batchUpdate(deactivateQuery, params);
				for (int rows : rowsUpdated) {
					if (rows == -2) {
						rows = 1;
					}
					totalRowsUpdtd = totalRowsUpdtd + rows;
				}
				if (totalRowsUpdtd == userDtoLst.size()) {
					tManager.commit(status);
				} else {
					LOGGER.error("No of user deactivated : {} don't match users to be deactivated, which is {}",
							totalRowsUpdtd, userDtoLst.size());
					LOGGER.error("ROLLING back transaction..!!!");
					tManager.rollback(status);
					totalRowsUpdtd = 0;
				}
				LOGGER.info("Total no. of users deactivated : {} ", totalRowsUpdtd);
			}
		} catch (Exception ex) {
			LOGGER.error("Fatal Exception caught ", ex);
			if (tManager != null) {
				tManager.rollback(status);
			}
			throw new WaalosException(WaalosConstants.ERR9999_CODE, WaalosConstants.ERR9999_MSG);
		} finally {
			tManager = null;
			jdbcTemplate = null;
			LOGGER.info(" Exiting deactivateUser method in UserMngmntDaoImpl {}", System.currentTimeMillis());
		}
		return totalRowsUpdtd;
	}

	/**
	 * Method to add a new user
	 * 
	 * @param userDto
	 * @return WaalosResponse
	 */
	@Override
	public WaalosResponse addUser(UserDto userDto) {
		LOGGER.info(" Entering into addUser method in UserMngmntDaoImpl {} ", System.currentTimeMillis());
		String addUsrQry = "";
		int recAdded = 0;
		String verifyUserExistsQry = "";
		int usrCount = 0;
		WaalosResponse response = null;
		StringBuilder successMsg;
		JdbcTemplate jdbcTemplate = null;
		try {
			jdbcTemplate = waalosOrclTemplate;
			if (jdbcTemplate == null) {
				LOGGER.error("Failed to create database connection in deleteUser method");
				throw new WaalosException(WaalosConstants.ERR9002_CODE, WaalosConstants.ERR9002_MSG);
			} else {
				// Verify is the user already exists, if yes return valid
				// message else proceed with adding the new user
				verifyUserExistsQry = queries.getQueries().get(UserMngmtConstants.USRM_USR_EXISTS_QRY);
				LOGGER.info("Query to verify if user exists : {} ", verifyUserExistsQry);

				usrCount = jdbcTemplate.queryForObject(verifyUserExistsQry,
						new Object[] { userDto.getUsrId().toLowerCase(Locale.getDefault()) }, Integer.class);
				if (usrCount == 0) {
					addUsrQry = queries.getQueries().get(UserMngmtConstants.USRM_ADD_USR_QRY);
					LOGGER.info("Query to add user: {} ", addUsrQry);
					recAdded = jdbcTemplate.update(addUsrQry, userMngmntHelper.addUsrQryParam(userDto));
					if (recAdded > 0) {
						successMsg = new StringBuilder(UserMngmtConstants.USR8014_MSG).append("[ ").append(recAdded)
								.append(WaalosConstants.ADD_COUNT_MSG);
						response = new WaalosResponse(UserMngmtConstants.USR8014_CODE, successMsg.toString());
					} else {
						response = new WaalosResponse(UserMngmtConstants.USR8015_CODE, UserMngmtConstants.USR8015_MSG);
					}
					LOGGER.info("No. of User added : {} ", recAdded);
				} else {
					response = new WaalosResponse(UserMngmtConstants.USR8016_CODE, UserMngmtConstants.USR8016_MSG);
				}
			}
		} catch (Exception ex) {
			LOGGER.error("Fatal Exception caught ", ex);
			throw new WaalosException(WaalosConstants.ERR9999_CODE, WaalosConstants.ERR9999_MSG);
		} finally {
			jdbcTemplate = null;
			successMsg = null;
			LOGGER.info(" Exiting into addUser method in UserMngmntDaoImpl {}", System.currentTimeMillis());
		}
		return response;
	}

	/**
	 * Method to fetch all user roles
	 * 
	 * @return list of UserRolesDto
	 */
	@Override
	public List<UserRolesDto> fetchUserRoles() {
		LOGGER.info(" Entering fetchUserRoles method in UserMngmntDaoImpl", System.currentTimeMillis());
		List<UserRolesDto> usrRolesDtoLst = null;
		String sqlQuery = "";
		JdbcTemplate jdbcTemplate = null;
		try {
			jdbcTemplate = waalosOrclTemplate;
			if (jdbcTemplate == null) {
				LOGGER.error("Failed to create database connection in fetchUserRoles method");
				throw new WaalosException(WaalosConstants.ERR9002_CODE, WaalosConstants.ERR9002_MSG);
			} else {
				sqlQuery = queries.getQueries().get(UserMngmtConstants.USRM_FETCH_USR_ROLES_QRY);
				jdbcTemplate.setFetchSize(WaalosConstants.FETCHSIZE_15);

				LOGGER.info("Query to search user roles  {} ", sqlQuery);

				usrRolesDtoLst = jdbcTemplate.query(sqlQuery, new UserRolesMapper());
			}
		} catch (Exception ex) {
			LOGGER.error("Fatal Exception caught ", ex);
			throw new WaalosException(WaalosConstants.ERR9999_CODE, WaalosConstants.ERR9999_MSG);
		} finally {
			jdbcTemplate = null;
			LOGGER.info(" Exiting fetchUserRoles method in UserMngmntDaoImpl {}", System.currentTimeMillis());
		}
		return usrRolesDtoLst;
	}

	public String getMasheryKey() throws Exception {
		LOGGER.info(" Entering fetchUserRoles method in UserMngmntDaoImpl", System.currentTimeMillis());
		String masheryKey = "";
		JdbcTemplate jdbcTemplate = null;
		try {
			jdbcTemplate = waalosOrclTemplate;
			if (jdbcTemplate == null) {
				LOGGER.error("Failed to create database connection in fetchUserRoles method");
				throw new WaalosException(WaalosConstants.ERR9002_CODE, WaalosConstants.ERR9002_MSG);
			} else {
				masheryKey = jdbcTemplate.queryForObject(queries.getQueries().get("masheryToken"), new Object[] {},
						String.class);
			}
		} catch (Exception ex) {
			LOGGER.error(" Exiting fetchUserRoles method in UserMngmntDaoImpl {}", ex);
		} finally {
			jdbcTemplate = null;
		}
		return masheryKey;
	}

	/**
	 * To get the details from NSNC Rule Table.
	 * 
	 * @RequestBody to receive the NSNCRuleDto
	 * 
	 * @return List<NSNCRuleDto>
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Object getPrinterDtls(String dcName) throws Exception {
		JdbcTemplate jdbcTemplate = null;
		try {
			if (dcName.length() > 0) {
				jdbcTemplate = waalosOrclTemplate;

				if (jdbcTemplate == null) {
					throw new WaalosException(UserMngmtConstants.USR9001_CODE, UserMngmtConstants.USR9001_MSG);
				} else {
					final List<PrinterDto> printerLst = jdbcTemplate.query(queries.getQueries().get("printerquery"),
							new Object[] { dcName }, new PrinterMapper());

					return printerLst;
				}
			} else {
			     	throw new WaalosException(UserMngmtConstants.USR9002_CODE, UserMngmtConstants.USR9002_MSG);
			}
		} catch (Exception ex) {
			LOGGER.error("Exception caught in the implementation of getPrinterDtls().......{}", ex);
			throw new WaalosException(UserMngmtConstants.ERR99112_CODE, UserMngmtConstants.ERR99112_MSG);
		} finally {
			jdbcTemplate = null;
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	 public Object getPrinterAllDtls(String userName) throws Exception {
		JdbcTemplate jdbcTemplate = null;
		try {
			if (userName.length() > 0) {
				jdbcTemplate = waalosOrclTemplate;

				if (jdbcTemplate == null) {
					throw new WaalosException(UserMngmtConstants.USR9001_CODE, UserMngmtConstants.USR9001_MSG);
				} else {
					final List<PrinterDto> printerAllLst = jdbcTemplate.query(queries.getQueries().get("printerallquery"),
							new Object[] { userName }, new PrinterAllMapper());

					return printerAllLst;
				}
			} else {
				throw new WaalosException(UserMngmtConstants.USR9002_CODE, UserMngmtConstants.USR9002_MSG);
			}
		} catch (Exception ex) {
			LOGGER.error("Exception caught in the implementation of getPrinterDtls().......{}", ex);
			throw new WaalosException(UserMngmtConstants.ERR99114_CODE, UserMngmtConstants.ERR99114_MSG);
		} finally {
			jdbcTemplate = null;
		}
	}

	public int updateDefPrinterDtls(DefaultPrinterDto defaultPrinterDto) throws Exception {
		JdbcTemplate jdbcTemplate = null;
		int selectPrintCnt = 0;
		int printUpdateCnt = 0;
		try {
			jdbcTemplate = waalosOrclTemplate;
			if (jdbcTemplate == null) {
				throw new WaalosException(UserMngmtConstants.USR9001_CODE, UserMngmtConstants.USR9001_MSG);
			} else {
				selectPrintCnt = jdbcTemplate.queryForObject(queries.getQueries().get("getDefprinter"), new Object[] {
						defaultPrinterDto.getUserId(), defaultPrinterDto.getDcName()},Integer.class);
				if(selectPrintCnt>0) {
				printUpdateCnt = jdbcTemplate.update(queries.getQueries().get("updatedefprinter"), new Object[] {
						Integer.parseInt(defaultPrinterDto.getPrinterId()), defaultPrinterDto.getUserId(), defaultPrinterDto.getDcName() });
				}else {
					printUpdateCnt = jdbcTemplate.update(queries.getQueries().get("insertdefprinter"), new Object[] {
							defaultPrinterDto.getUserId(), defaultPrinterDto.getDcName(), Integer.parseInt(defaultPrinterDto.getPrinterId()), defaultPrinterDto.getUserId() });
				}
			}
		} catch (Exception ex) {
			LOGGER.error("Exception caught in the implementation of updateDefPrinterDtls().......{}", ex);
			throw new WaalosException(UserMngmtConstants.ERR99112_CODE, UserMngmtConstants.ERR99112_MSG);
		} finally {
			jdbcTemplate = null;
		}
		return printUpdateCnt;
	}

	public Object getDCPrinterDtls(String dcName,String userName) throws Exception{
		JdbcTemplate jdbcTemplate = null;
		try {
			if (userName.length() > 0) {
				jdbcTemplate = waalosOrclTemplate;

				if (jdbcTemplate == null) {
					throw new WaalosException(UserMngmtConstants.USR9001_CODE, UserMngmtConstants.USR9001_MSG);
				} else {
					final List<PrinterDto> dcPrinterLst = jdbcTemplate.query(queries.getQueries().get("dcprinterquery"),
							new Object[] { dcName,userName }, new PrinterMapper());

					return dcPrinterLst;
				}
			} else {
				throw new WaalosException(UserMngmtConstants.USR9002_CODE, UserMngmtConstants.USR9002_MSG);
			}
		} catch (Exception ex) {
			LOGGER.error("Exception caught in the implementation of getPrinterDtls().......{}", ex);
			throw new WaalosException(UserMngmtConstants.ERR99114_CODE, UserMngmtConstants.ERR99114_MSG);
		} finally {
			jdbcTemplate = null;
		}
	}
}
