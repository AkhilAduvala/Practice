package com.adidas.usermngment.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.RowMapper;

public class DcsDataMapper implements RowMapper {
	private static final Logger LOGGER = LoggerFactory.getLogger(DcsDataMapper.class);

	Map<String, Integer> dcsMap = new HashMap<String, Integer>();
	
	@Override
	public Map<String, Integer> mapRow(ResultSet rs, int rowNum) throws SQLException {
		LOGGER.info("Entering mapRow DcsDataMapper {} ", System.currentTimeMillis());
		
		try {
			dcsMap.put(rs.getString("dc_nm").toString(), Integer.parseInt(rs.getString("dc_id").toString()));
		} finally {
			LOGGER.info("Exiting mapRow DcsDataMapper{} ", System.currentTimeMillis());
		}
		return dcsMap;
	}
}
