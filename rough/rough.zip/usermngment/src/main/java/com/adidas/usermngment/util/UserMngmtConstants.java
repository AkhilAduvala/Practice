package com.adidas.usermngment.util;

public class UserMngmtConstants {

	public static final String USR8000_CODE = "USR8000";
	public static final String USR8000_MSG = "DC is Empty";

	public static final String USR8001_CODE = "USR8001";
	public static final String USR8001_MSG = "No data found for particular DC";

	public static final String USR8002_CODE = "USR8002";
	public static final String USR8002_MSG = "Please verify database connectivity";

	public static final String USR8003_CODE = "USR8003";
	public static final String USR8003_MSG = "Error in Fetching Role Information";

	public static final String USR8004_CODE = "USR8003";
	public static final String USR8004_MSG = "Error in Fetching Function Information";

	public static final String HOMEPAGE_QRY_STRING = "homePageDataQuery";

	public static final String USR8005_CODE = "USR8005";
	public static final String USR8005_MSG = "Error in Fetching Home Page Information from database";

	public static final String USR8006_CODE = "USR8006";
	public static final String USR8006_MSG = " Invalid User, Please contact WAALOS Support";

	public static final String ERR9999_CODE = "ERR9999";
	public static final String ERR9999_MSG = "System Failed. Please try again or contact WAALOS Support";

	public static final String USR8007_CODE = "USR8007";
	public static final String USR8007_MSG = "Please provide UserName";

	public static final String USR8008_CODE = "USR8008";
	public static final String USR8008_MSG = "Please provide password";

	public static final String ERR99100_CODE = "ERR99100";
	public static final String ERR99100_MSG = "Error in authentication Waalos User";

	public static final String ERR99102_CODE = "ERR99102";
	public static final String ERR99102_MSG = "Error in generating ADFS token";

	public static final String ERR99103_CODE = "ERR99103";
	public static final String ERR99103_MSG = "Error in decoding ADFS token";

	public static final String UGDASHBOARD_QRY_STRING = "usergroupDashboardQuery";
    public static final String SEARCH_UG_QRY_STRING = "searchUGQuery";
	public static final String DELETE_UG_USERS_QRY = "deleteUGUsersQuery";
	public static final String DELETE_UG_METADATA_QRY = "deleteUGMetaDataQuery";
	public static final String DELETE_UG_MASTERDATA_QRY = "deleteUGMasterDataQuery";
	public static final String DISPLAY_UGDATA_QRY = "displayUGDataQuery";
	public static final String ADD_NEWUGMASTER_QRY = "addUserGroupMstQuery";
	public static final String ALL_FUNCTIONALITIES_QRY = "functionalitiesDataMapQuery";
	public static final String ALL_DCS_QRY = "dcsDataMapQuery";
	public static final String ALL_USERGROUPS_QRY = "userGroupsDataMapQuery";
	public static final String INSERT_UG_MAPPINGS = "insertUGMappingsQuery";
	public static final String DELETE_UG_MAPPINGS = "deleteUGMappingsQuery";

	public static final String USR8060_CODE = "USR8060";
	public static final String USR8060_MSG = "You don't have sufficient privileges to view this Page. Please contact WAALOS Support";

	public static final String USR8061_CODE = "USR8061";
	public static final String USR8061_MSG = "User Group & its Mappings Updated Successfully";

	public static final String USR8062_CODE = "USR8062";
	public static final String USR8062_MSG = "User Group Deleted Successfully [ 1 Record Deleted ]";

	public static final String USR8063_CODE = "USR8063";
	public static final String USR8063_MSG = "Invalid Mappings. Please Choose DC-Functionality Mappings Correctly";

	public static final String USR8064_CODE = "USR8064";
	public static final String USR8064_MSG = "User Group can't be added as it already exists. Please Check";

	public static final String USR8065_CODE = "USR8065";
	public static final String USR8065_MSG = "Invalid DC-Functionalities Received. Please Check";

	public static final String USR8066_CODE = "USR8066";
	public static final String USR8066_MSG = "Invalid DC Name Received. Please Check";

	public static final String USR8067_CODE = "USR8067";
	public static final String USR8067_MSG = "Invalid Functionality Name Received. Please Check";

	public static final String USR8068_CODE = "USR8068";
	public static final String USR8068_MSG = "Please Choose atleast One Functionality for every DC Selected";

	public static final String USR8069_CODE = "USR8069";
	public static final String USR8069_MSG = "Invalid User Group Received. Please Check";

	public static final String USR8070_CODE = "USR8070";
	public static final String USR8070_MSG = "User Group & its Mappings Added Successfully";

	public static final String USR8071_CODE = "USR8071";
	public static final String USR8071_MSG = "Invalid User Group Received. Please Check";

	public static final String USR8072_CODE = "USR8072";
	public static final String USR8072_MSG = "Invalid Username or Password";

	public static final String USR8073_CODE = "USR8073";
	public static final String USR8073_MSG = "Unauthorized access to Waalos System. Please contact Administrator";
  
  	public static final String USR8074_CODE = "USR8074";
	public static final String USR8074_MSG = "Invalid Domain, Please check";

	public static final String ERR9499_CODE = "ERR9499";
	public static final String ERR9499_MSG = "Error in Fetch User Count";

	// UserManagement Constants <Start>
	public static final String USR8009_CODE = "USR8009";
	public static final String USR8009_MSG = "Cannot update user as mandatory filed(s) is/are empty";

	public static final String USR8010_CODE = "USR8010";
	public static final String USR8010_MSG = "User updated successfully";

	public static final String USR8011_CODE = "USR8011";
	public static final String USR8011_MSG = "User update failed";

	public static final String USR8012_CODE = "USR8012";
	public static final String USR8012_MSG = "Failed to delete User";

	public static final String USR8013_CODE = "USR8013";
	public static final String USR8013_MSG = "User(s) deleted successfully";

	public static final String USR8014_CODE = "USR8014";
	public static final String USR8014_MSG = "User added successfully";

	public static final String USR8015_CODE = "USR8015";
	public static final String USR8015_MSG = "Failed to add user";

	public static final String USR8016_CODE = "USR8016";
	public static final String USR8016_MSG = "Cannot add user as user already exists";

	public static final String USR8017_CODE = "USR8017";
	public static final String USR8017_MSG = "No data found";

	public static final String USR8018_CODE = "USR8018";
	public static final String USR8018_MSG = "No user roles found";

	public static final String USR8020_CODE = "USR8020";
	public static final String USR8020_MSG = "Failed to search user! All the search fields provided are empty";
	
	public static final String USR8021_CODE = "USR8021";
	public static final String USR8021_MSG = "Manadtory field 'User Login' is missing";
	
	public static final String USR8022_CODE = "USR8022";
	public static final String USR8022_MSG = "Manadtory field 'User Group' is missing";

	public static final String USRM_GET_ALL_USRS_QRY = "usrMngmnt.getAllUsers";
	public static final String USRM_GET_ALL_USRS_COUNT_QRY = "usrMngmnt.getAllUsersCount";
	public static final String USRM_SRCHUSR_QRY = "usrMngmnt.srchUsrInitialPrt";
	public static final String USRM_SRCHUSR_COUNT_QRY = "usrMngmnt.srchUsrCntInitialPrt";
	public static final String USRM_SRCHUSR_LIKE_ID = "usrMngmnt.srchUsrIDLike";
	public static final String USRM_SRCHUSR_LIKE_FRSTNM = "usrMngmnt.srchUsrFrstNameLike";
	public static final String USRM_SRCHUSR_LIKE_LSTNM = "usrMngmnt.srchUsrLstNameLike";
	public static final String USRM_UPDATE_USR_QRY = "usrMngmnt.updateUser";
	public static final String USRM_DEACTIVATE_USRS_QRY = "usrMngmnt.deactivateUser";
	public static final String USRM_ADD_USR_QRY = "usrMngmnt.addUser";
	public static final String USRM_USR_EXISTS_QRY = "usrMngmnt.userExists";
	public static final String USRM_FETCH_USR_ROLES_QRY = "usrMngmnt.fetchUserRoles";
	public static final String USRM_USR_QRY_ALL = "ALL";
	public static final String USRM_USR_QRY_COUNT = "COUNT";
	
	public static final String ERR99111_CODE = "ERR99111";
	public static final String ERR99111_MSG = "You are not Active User. Please contact administrator";
	
	public static final String USR8023_CODE = "USR8023";
	public static final String USR8023_MSG = "No Record(s) Found";
	// UserManagement Constants <End>
	
	public static final String DISPLAY_FAVORITES_QRY = "getFavoritiesDataQry";
	public static final String USRFAV_EXISTS_QRY = "checkFavoriteQry";
	public static final String USR_ADD_FAVORITE= "addFavorite";
	public static final String USR_DELETE_FAVORITE= "deleteFavorite";
	
	public static final String USR8090_CODE = "USR8090";
	public static final String USR8090_MSG = "Favorite Added Successfully";
	
	public static final String USR8091_CODE = "USR8091";
	public static final String USR8091_MSG = "Favorite Deleted Successfully";

	public static final String USR8092_CODE = "USR8092";
	public static final String USR8092_MSG = "Invalid Favorite Selection, Please contact administrator";

	public static final String USR8093_CODE = "USR8093";
	public static final String USR8093_MSG = "Favorite couldn't be added as it already exists";
	
	 public static final String USR8094_CODE = "USR8094";
	public static final String USR8094_MSG = "Only maximum of 5 favorites can be added. Please delete any one of available favorites and choose again";
	
	public static final String USR9001_CODE = "USR001_CODE";
	  public static final String USR9001_MSG = "Please verify Database Connection";
	   
	public static final String USR9002_CODE = "USR9002_CODE";
	public static final String USR9002_MSG = "No Printer Details Found";
	
	public static final String USR9003_CODE = "USR9003_CODE";
	public static final String USR9003_MSG = "No Printer Details Found";
	
	public static final String USR9004_CODE = "USR9004_CODE";
	public static final String USR9004_MSG = "No Printer Details Found";
	
	public static final String ERR99112_CODE = "ERR99112_CODE";
	public static final String ERR99112_MSG = "Error in fetching Printer Details";
	
	public static final String ERR99113_CODE = "ERR99113_CODE";
	public static final String ERR99113_MSG = "Error in updating Default Printer Details";
	

	public static final String ERR99114_CODE = "ERR99114_CODE";
	public static final String ERR99114_MSG = "Error in fetching all Printer Details";
	
	public static final String USR9005_CODE = "USR9005_CODE";
	public static final String USR9005_MSG = "Printer Details Updated Sucessfully";
	
	public static final String ERR91121_CODE = "ERR99121_CODE";
	public static final String ERR91121_MSG = "Error in updating Printer Details";
	
	
}
