package com.adidas.usermngment.dao;

import java.util.List;

import org.springframework.stereotype.Component;

import com.adidas.waaloscommon.dto.usermngmntdto.DcDto;
import com.adidas.waaloscommon.dto.usermngmntdto.DefaultPrinterDto;
import com.adidas.waaloscommon.dto.usermngmntdto.FunctionDto;
import com.adidas.waaloscommon.dto.usermngmntdto.UserDto;
import com.adidas.waaloscommon.dto.usermngmntdto.UserRolesDto;
import com.adidas.waaloscommon.exception.WaalosResponse;
import com.adidas.waaloscommon.pagination.Page;

@Component
public interface UserMngmntDao {

	List<DcDto> getDcDetails() throws Exception;

	Page<UserDto> searchUserByFilter(UserDto userDto);

	Page<UserDto> searchAllUserDetails(int pgNum, int pgSize);

	int modifyUser(UserDto userDto);

	int deactivateUser(List<UserDto> userDtoLst);

	WaalosResponse addUser(UserDto userDto);

	List<UserRolesDto> fetchUserRoles();

	Page<FunctionDto> getFunctionDtls(int pageNumber, int pageSize) throws Exception;

	Object getHomePageData(final String username) throws Exception;

	Object fetchUserCount(String userId) throws Exception;

	String getMasheryKey() throws Exception;

	public Object getPrinterDtls(String dcName) throws Exception;
	
	public Object getPrinterAllDtls(String userName) throws Exception;

	public int updateDefPrinterDtls(DefaultPrinterDto defaultPrinterDto) throws Exception;
	
	public Object getDCPrinterDtls(String dcName,String userName) throws Exception;

}
