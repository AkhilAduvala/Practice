package com.adidas.usermngment.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.RowMapper;

import com.adidas.waaloscommon.dto.usermngmntdto.DcDto;

public class DcMapper implements RowMapper {
	private static final Logger LOGGER = LoggerFactory.getLogger(DcMapper.class);

	@Override
	public DcDto mapRow(ResultSet rs, int rowNum) throws SQLException {
		LOGGER.info("Entering mapRow DcDto{} ", System.currentTimeMillis());
		DcDto dateMapperDto = null;
		try {
			dateMapperDto = new DcDto();
			dateMapperDto.setDcId(rs.getInt("DC_ID"));
			dateMapperDto.setDcName(rs.getString("DC_NM"));
			return dateMapperDto;
		} finally {
			LOGGER.info("Exiting mapRow DcDto{} ", System.currentTimeMillis());
		}
	}
}
