package com.adidas.usermngment.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.adidas.usermngment.service.PermissionMngmentService;
import com.adidas.usermngment.util.UserMngmtConstants;
import com.adidas.waaloscommon.dto.usermngmntdto.DeleteUGDto;
import com.adidas.waaloscommon.dto.usermngmntdto.FavoritesDto;
import com.adidas.waaloscommon.dto.usermngmntdto.GetUGDataDto;
import com.adidas.waaloscommon.dto.usermngmntdto.HomePageUserDto;
import com.adidas.waaloscommon.dto.usermngmntdto.ManageFavoritesDto;
import com.adidas.waaloscommon.dto.usermngmntdto.UserGroupMappingsDto;
import com.adidas.waaloscommon.exception.WaalosErrorResponse;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/permissnCntrl")
public class PermissionMngmntCntrl {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(PermissionMngmntCntrl.class);

	@Autowired
	private PermissionMngmentService permMngmntService;
	
	@ApiOperation(value = "permissnHlth", nickname = "permissnHlth")
	@ApiResponses(value = { @ApiResponse(code = 400, message = "Bad Request"),
			@ApiResponse(code = 500, message = "Internal Server Error"),
			@ApiResponse(code = 503, message = "Service Unavailable"),
			@ApiResponse(code = 404, message = "Not Found"),
			@ApiResponse(code = 200, message = "OK", response = String.class, 
			responseContainer = "String") })
	@RequestMapping(value = "/permissnHlth", method = RequestMethod.GET)
	public @ResponseBody String wmsHealth(){
		return "PermissionMngmnt Health is sucessful";
	}
	
	/**
	 * Get the User Group Data for respective DC and Functionality information post login .
	 *  			
	 * @return the Object with List of UserGroups, DCs and its applicable functionalities 
	 */
	@ApiOperation(value = "getUGDashboard", nickname = "getUGDashboard")
	@ApiResponses(value = { @ApiResponse(code = 400, message = "Bad Request"),
			@ApiResponse(code = 500, message = "Internal Server Error"),
			@ApiResponse(code = 503, message = "Service Unavailable"),
			@ApiResponse(code = 404, message = "Not Found"),
			@ApiResponse(code = 200, message = "OK", response = String.class, responseContainer = "String") })
	@RequestMapping(value = "/getUGDashboard", method = RequestMethod.POST)
	public @ResponseBody Object getHomePageData(@RequestBody HomePageUserDto homePageUserDto) throws Exception {
		LOGGER.info("Entering into getUGDashboard ", System.currentTimeMillis());
		Object dataObj = null;
		try {
			if(null==homePageUserDto.getUsername().trim()) {
				LOGGER.error("UserName is empty in the request body from getUGDashboard() method ... ");
				dataObj = new WaalosErrorResponse(UserMngmtConstants.ERR9999_CODE, UserMngmtConstants.ERR9999_MSG);
			}else {
				dataObj = permMngmntService.getUGDashboard(homePageUserDto.getUsername().trim());	
			}
		}catch(Exception e) {
			LOGGER.error("Exception in getUGDashboard of Entering {}", e.getMessage());
			dataObj = new WaalosErrorResponse(UserMngmtConstants.ERR9999_CODE, UserMngmtConstants.ERR9999_MSG);
		}
		finally {
			LOGGER.info("Exiting getUGDashboard ", System.currentTimeMillis());
		}
		return dataObj;
	}
	

	/**
	 * Get the User Group Data for respective DC and Functionality information post login .
	 *  			
	 * @return the Object with List of UserGroups, DCs and its applicable functionalities 
	 */
	@ApiOperation(value = "deleteUserGroup", nickname = "deleteUserGroup")
	@ApiResponses(value = { @ApiResponse(code = 400, message = "Bad Request"),
			@ApiResponse(code = 500, message = "Internal Server Error"),
			@ApiResponse(code = 503, message = "Service Unavailable"),
			@ApiResponse(code = 404, message = "Not Found"),
			@ApiResponse(code = 200, message = "OK", response = String.class, responseContainer = "String") })
	@RequestMapping(value = "/deleteUserGroup", method = RequestMethod.POST)
	public @ResponseBody Object deleteUserGroup(@RequestBody DeleteUGDto delUGDto) throws Exception {
		LOGGER.info("Entering into getUGDashboard ", System.currentTimeMillis());
		Object dataObj = null;
		try {
			if(null==delUGDto.getUgName().trim()) {
				LOGGER.error("UserGroup is empty in the request body from deleteUserGroup() method ... ");
				dataObj = new WaalosErrorResponse(UserMngmtConstants.ERR9999_CODE, UserMngmtConstants.ERR9999_MSG);
			}else {
				dataObj = permMngmntService.deleteUserGroup(delUGDto.getUgName().trim());	
			}
		}catch(Exception e) {
			LOGGER.error("Exception in deleteUserGroup of Entering {}", e.getMessage());
			dataObj = new WaalosErrorResponse(UserMngmtConstants.ERR9999_CODE, UserMngmtConstants.ERR9999_MSG);
		}
		finally {
			LOGGER.info("Exiting deleteUserGroup ", System.currentTimeMillis());
		}
		return dataObj;
	}
	
	
	
	/**
	 * Get the respective DC and Functionality information for the selected User Group .
	 *  			
	 * @return the Object with List of DCs and its applicable functionalities for the selected User Group 
	 */
	@ApiOperation(value = "getUserGroupData", nickname = "getUserGroupData")
	@ApiResponses(value = { @ApiResponse(code = 400, message = "Bad Request"),
			@ApiResponse(code = 500, message = "Internal Server Error"),
			@ApiResponse(code = 503, message = "Service Unavailable"),
			@ApiResponse(code = 404, message = "Not Found"),
			@ApiResponse(code = 200, message = "OK", response = String.class, responseContainer = "String") })
	@RequestMapping(value = "/getUserGroupData", method = RequestMethod.POST)
	public @ResponseBody Object getUserGroupData(@RequestBody GetUGDataDto ugDto) throws Exception {
		LOGGER.info("Entering into getUserGroupData ", System.currentTimeMillis());
		Object dataObj = null;
		try {
			if(null==ugDto.getUgName().trim() || null==ugDto.getUsername().trim() ) {
				LOGGER.error("UserGroup is empty in the request body from getUserGroupData() method ... ");
				dataObj = new WaalosErrorResponse(UserMngmtConstants.ERR9999_CODE, UserMngmtConstants.ERR9999_MSG);
			}else {
				dataObj = permMngmntService.getUserGroupData(ugDto);	
			}
		}catch(Exception e) {
			LOGGER.error("Exception in getUserGroupData of Entering {}", e.getMessage());
			dataObj = new WaalosErrorResponse(UserMngmtConstants.ERR9999_CODE, UserMngmtConstants.ERR9999_MSG);
		}
		finally {
			LOGGER.info("Exiting getUserGroupData ", System.currentTimeMillis());
		}
		return dataObj;
	}

	

	/**
	 * Add the New UserGroup along with its meta-data into the WAALOS.
	 *  			
	 * @returns the Success/Failure Message upon performing the action. 
	 */
	@ApiOperation(value = "addNewUserGroup", nickname = "addNewUserGroup")
	@ApiResponses(value = { @ApiResponse(code = 400, message = "Bad Request"),
			@ApiResponse(code = 500, message = "Internal Server Error"),
			@ApiResponse(code = 503, message = "Service Unavailable"),
			@ApiResponse(code = 404, message = "Not Found"),
			@ApiResponse(code = 200, message = "OK", response = String.class, responseContainer = "String") })
	@RequestMapping(value = "/addNewUserGroup", method = RequestMethod.POST)
	public @ResponseBody Object addNewUserGroup(@RequestBody UserGroupMappingsDto mappingsDto) throws Exception {
		LOGGER.info("Entering into addNewUserGroup ", System.currentTimeMillis());
		Object dataObj = null;
		try {
			if(null==mappingsDto.getUgName().trim()) {
				LOGGER.error("UserGroup is empty in the request body from addNewUserGroup() method ... ");
				dataObj = new WaalosErrorResponse(UserMngmtConstants.ERR9999_CODE, UserMngmtConstants.ERR9999_MSG);
			}else {
				dataObj = permMngmntService.addNewUG(mappingsDto);	
			}
		}catch(Exception e) {
			LOGGER.error("Exception in addNewUserGroup of Entering {}", e.getMessage());
			dataObj = new WaalosErrorResponse(UserMngmtConstants.ERR9999_CODE, UserMngmtConstants.ERR9999_MSG);
		}
		finally {
			LOGGER.info("Exiting addNewUserGroup ", System.currentTimeMillis());
		}
		return dataObj;
	}

	/**
	 * Update the existing UserGroup along with its meta-data into the WAALOS.
	 *  			
	 * @returns the Success/Failure Message upon performing the action. 
	 */
	@ApiOperation(value = "updateUserGroup", nickname = "updateUserGroup")
	@ApiResponses(value = { @ApiResponse(code = 400, message = "Bad Request"),
			@ApiResponse(code = 500, message = "Internal Server Error"),
			@ApiResponse(code = 503, message = "Service Unavailable"),
			@ApiResponse(code = 404, message = "Not Found"),
			@ApiResponse(code = 200, message = "OK", response = String.class, responseContainer = "String") })
	@RequestMapping(value = "/updateUserGroup", method = RequestMethod.POST)
	public @ResponseBody Object updateUserGroup(@RequestBody UserGroupMappingsDto mappingsDto) throws Exception {
		LOGGER.info("Entering into updateUserGroup ", System.currentTimeMillis());
		Object dataObj = null;
		try {
			if(null==mappingsDto.getUgName().trim()) {
				LOGGER.error("UserGroup is empty in the request body from updateUserGroup() method ... ");
				dataObj = new WaalosErrorResponse(UserMngmtConstants.ERR9999_CODE, UserMngmtConstants.ERR9999_MSG);
			}else {
				dataObj = permMngmntService.updateUG(mappingsDto);	
			}
		}catch(Exception e) {
			LOGGER.error("Exception in updateUserGroup of Entering {}", e.getMessage());
			dataObj = new WaalosErrorResponse(UserMngmtConstants.ERR9999_CODE, UserMngmtConstants.ERR9999_MSG);
		}
		finally {
			LOGGER.info("Exiting updateUserGroup ", System.currentTimeMillis());
		}
		return dataObj;
	}



	/**
	 * Search for the User Group Data for respective DC and Functionality information post login .
	 *  			
	 * @return the Object with List of UserGroups with the searched Value 
	 */
	@ApiOperation(value = "searchUGS", nickname = "searchUGS")
	@ApiResponses(value = { @ApiResponse(code = 400, message = "Bad Request"),
			@ApiResponse(code = 500, message = "Internal Server Error"),
			@ApiResponse(code = 503, message = "Service Unavailable"),
			@ApiResponse(code = 404, message = "Not Found"),
			@ApiResponse(code = 200, message = "OK", response = String.class, responseContainer = "String") })
	@RequestMapping(value = "/searchUGS", method = RequestMethod.POST)
	public @ResponseBody Object searchUGS(@RequestBody GetUGDataDto dto) throws Exception {
		LOGGER.info("Entering into searchUGS {} ", System.currentTimeMillis());
		Object dataObj = null;
		try {
			if(null==dto.getUgName().trim()) {
				LOGGER.error("UserName is empty in the request body from searchUGS method ... ");
				dataObj = new WaalosErrorResponse(UserMngmtConstants.ERR9999_CODE, UserMngmtConstants.ERR9999_MSG);
			}else {
				dataObj = permMngmntService.searchUGS(dto.getUgName().trim());	
			}
		}catch(Exception e) {
			LOGGER.error("Exception in searchUGS of Entering {}", e.getMessage());
			dataObj = new WaalosErrorResponse(UserMngmtConstants.ERR9999_CODE, UserMngmtConstants.ERR9999_MSG);
		}
		finally {
			LOGGER.info("Exiting searchUGS {} ", System.currentTimeMillis());
		}
		return dataObj;
	}
	

	/**
	 * Add the New Favorite to the User.
	 *  			
	 * @returns the Success/Failure Message upon performing the action. 
	 */
	@ApiOperation(value = "addFavorite", nickname = "addFavorite")
	@ApiResponses(value = { @ApiResponse(code = 400, message = "Bad Request"),
			@ApiResponse(code = 500, message = "Internal Server Error"),
			@ApiResponse(code = 503, message = "Service Unavailable"),
			@ApiResponse(code = 404, message = "Not Found"),
			@ApiResponse(code = 200, message = "OK", response = String.class, responseContainer = "String") })
	@RequestMapping(value = "/addFavorite", method = RequestMethod.POST)
	public @ResponseBody Object addFavorite(@RequestBody ManageFavoritesDto favDto) throws Exception {
		LOGGER.info("Entering into addFavorite ", System.currentTimeMillis());
		Object dataObj = null;
		try {
				dataObj = permMngmntService.addFavorite(favDto);	
		}catch(Exception e) {
			LOGGER.error("Exception in addFavorite of Entering {}", e.getMessage());
			dataObj = new WaalosErrorResponse(UserMngmtConstants.ERR9999_CODE, UserMngmtConstants.ERR9999_MSG);
		}
		finally {
			LOGGER.info("Exiting addFavorite ", System.currentTimeMillis());
		}
		return dataObj;
	}


	/**
	 * Delete an existing Favorite of the User.
	 *  			
	 * @returns the Success/Failure Message upon performing the action. 
	 */
	@ApiOperation(value = "deleteFavorite", nickname = "deleteFavorite")
	@ApiResponses(value = { @ApiResponse(code = 400, message = "Bad Request"),
			@ApiResponse(code = 500, message = "Internal Server Error"),
			@ApiResponse(code = 503, message = "Service Unavailable"),
			@ApiResponse(code = 404, message = "Not Found"),
			@ApiResponse(code = 200, message = "OK", response = String.class, responseContainer = "String") })
	@RequestMapping(value = "/deleteFavorite", method = RequestMethod.POST)
	public @ResponseBody Object deleteFavorite(@RequestBody ManageFavoritesDto favDto) throws Exception {
		LOGGER.info("Entering into deleteFavorite ", System.currentTimeMillis());
		Object dataObj = null;
		try {
				dataObj = permMngmntService.deleteFavorite(favDto);	
		}catch(Exception e) {
			LOGGER.error("Exception in deleteFavorite of Entering {}", e.getMessage());
			dataObj = new WaalosErrorResponse(UserMngmtConstants.ERR9999_CODE, UserMngmtConstants.ERR9999_MSG);
		}
		finally {
			LOGGER.info("Exiting deleteFavorite ", System.currentTimeMillis());
		}
		return dataObj;
	}

	/**
	 * Get the User Favorites Data to highlight the same post login .
	 *  			
	 * @return the Object with List DCs and Functionalities  
	 */
	@ApiOperation(value = "getFavorites", nickname = "getFavorites")
	@ApiResponses(value = { @ApiResponse(code = 400, message = "Bad Request"),
			@ApiResponse(code = 500, message = "Internal Server Error"),
			@ApiResponse(code = 503, message = "Service Unavailable"),
			@ApiResponse(code = 404, message = "Not Found"),
			@ApiResponse(code = 200, message = "OK", response = String.class, responseContainer = "String") })
	@RequestMapping(value = "/getFavorites", method = RequestMethod.POST)
	public @ResponseBody Object getFavorites(@RequestBody HomePageUserDto favDto) throws Exception {
		LOGGER.info("Entering into getFavorites ", System.currentTimeMillis());
		Object dataObj = null;
		try {
			if(null==favDto.getUsername().trim()) {
				LOGGER.error("UserName is empty in the request body from getFavorites() method ... ");
				dataObj = new WaalosErrorResponse(UserMngmtConstants.ERR9999_CODE, UserMngmtConstants.ERR9999_MSG);
			}else {
				dataObj = permMngmntService.getFavorites(favDto.getUsername().trim());	
			}
		}catch(Exception e) {
			LOGGER.error("Exception in getFavorites of Entering {}", e.getMessage());
			dataObj = new WaalosErrorResponse(UserMngmtConstants.ERR9999_CODE, UserMngmtConstants.ERR9999_MSG);
		}
		finally {
			LOGGER.info("Exiting getFavorites ", System.currentTimeMillis());
		}
		return dataObj;
	}

	
	
}