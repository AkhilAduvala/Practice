package com.adidas.usermngment.controller;

public class CleanupController {

}
