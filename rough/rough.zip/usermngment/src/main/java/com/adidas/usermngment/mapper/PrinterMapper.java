package com.adidas.usermngment.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.RowMapper;

import com.adidas.waaloscommon.dto.wmsdto.PrinterDto;

public class PrinterMapper implements RowMapper {
	private static final Logger LOGGER = LoggerFactory.getLogger(PrinterMapper.class);

	@Override
	 public PrinterDto mapRow(ResultSet rs, int rowNum) throws SQLException {
		PrinterDto printerAllDto = null;
		try {
			 printerAllDto = new PrinterDto();
			   printerAllDto.setPrinterIp(rs.getString("PRINTER_IP"));
			printerAllDto.setPrinterName(rs.getString("PRINTER_NAME"));
			printerAllDto.setPrinterId(rs.getInt("PRINTER_ID"));
			printerAllDto.setPrinterPort(rs.getString("PRINTER_PORT"));
						
			return printerAllDto;
			
		} finally {
			LOGGER.info("Exiting mapRow DcDto{} ", System.currentTimeMillis());
		}
	}
}
