package com.adidas.usermngment.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Data;

/**
 * This is a simple Spring Configuration class that will get uri and pattern
 * details from application.yml
 *
 */
@Component
@Data
@ConfigurationProperties(value = "config")
public class ApplicationConfiguration {
	/*
    @Value("${config.client.accessTokenUri}")
	private String tokenUri;

	@Value("${config.client.clientId}")
	private String clientId;

	@Value("${config.client.clientSecret}")
	private String clientsecret;
	
	@Value("${config.client.resourceUri}")
	private String resourceUri;
  */
	@Value("${config.client.azureAccessTokenUri}")
	private String azureAccessTokenUri;

	@Value("${config.client.azureClientId}")
	private String azureClientId;
  
	@Value("${config.client.azureClientSecret}")
	private String azureClientSecret;
  
	@Value("${config.client.azureScope}")
	private String azureScope;
  
  	@Value("${config.client.azureGrantType}")
	private String azureGrantType;
}
