package com.adidas.usermngment.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.RowMapper;

public class DeleteUGCheckMapper implements RowMapper {
	private static final Logger LOGGER = LoggerFactory.getLogger(DeleteUGCheckMapper.class);

	@Override
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		LOGGER.info("Entering mapRow DeleteUGCheckMapper{} ", System.currentTimeMillis());
		try {
			return Integer.parseInt(rs.getString("USER_NUM").toString());
		} finally {
			LOGGER.info("Exiting mapRow DeleteUGCheckMapper{} ", System.currentTimeMillis());
		}
	}
}
