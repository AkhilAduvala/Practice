package com.adidas.usermngment.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.RowMapper;

public class RoleNamesMapper implements RowMapper {
	private static final Logger LOGGER = LoggerFactory.getLogger(RoleNamesMapper.class);
	List<String> rolesList = new ArrayList<String>();
	
	
	@Override
	public List<String> mapRow(ResultSet rs, int rowNum) throws SQLException {
		LOGGER.info("Entering mapRow RolesDataMapper {} ", System.currentTimeMillis());
		try {
			rolesList.add(rs.getString("role_nm").toString());
		} finally {
			LOGGER.info("Exiting mapRow RolesDataMapper{} ", System.currentTimeMillis());
		}
		return rolesList;
	}
}
