package com.adidas.usermngment.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.RowMapper;

import com.adidas.waaloscommon.dto.usermngmntdto.FavoritesDto;
import com.adidas.waaloscommon.dto.usermngmntdto.FunctionDto;

public class GetFavoritesMapper implements RowMapper {

	@Override
	public FavoritesDto mapRow(ResultSet rs, int rowNum) throws SQLException {
		FavoritesDto dto = null;
			dto = new FavoritesDto();
			dto.setDcName(rs.getString("DC_NM"));
			dto.setFunName(rs.getString("FUNCTNAL_NM"));
		return dto;
	}
	
}
