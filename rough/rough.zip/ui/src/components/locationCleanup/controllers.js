
var app = angular.module('LocationCleanup', ['ngAnimate', 'ui.grid', 'ui.grid.selection',  'ui.grid.pagination', 'ui.grid.edit']);

app.controller('LocationCleanupCtrl', ['$scope', '$http', '$q', '$interval', 'uiGridValidateService', '$timeout','urlService','uiGridConstants','commonService', function ($scope, $http, $q, $interval, uiGridValidateService, $timeout,urlService,uiGridConstants,commonService) {
 
  $scope.disable = true;
  $scope.disableyes = true;
  $scope.isSuccess = false;
  $scope.isFailed = false;
  $scope.isClicked = false;
  $scope.pagefunctionality = $scope.functionality;
  $scope.pagedc = $scope.dcName;
  
  $("#showloader").css("display", "none");

  $scope.today = function () {
    $scope.dt = new Date();
  };
  $scope.today();

  $scope.clear = function () {
    $scope.dt = null;
  };

  $scope.inlineOptions = {
    customClass: getDayClass,
    minDate: new Date(),
    maxDate: new Date(),
    showWeeks: true
  };
  $scope.dateOptions = {
    formatYear: 'yy',
    maxDate : new Date(new Date().getTime()-(6*24*60*60*1000)),//new Date(),
    startingDay: 1
  };


  $scope.open1 = function () {
    $scope.popup1.opened = true;
  };


  $scope.setDate = function (year, month, day) {
    $scope.dt = new Date(year, month, day);
  };

  $scope.formats = ['dd-MMMM-yyyy', 'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate'];
  $scope.format = $scope.formats[0];
  $scope.altInputFormats = ['M!/d!/yyyy'];

  $scope.popup1 = {
    opened: false
  };


  var tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  var afterTomorrow = new Date();
  afterTomorrow.setDate(tomorrow.getDate() + 1);
  $scope.events = [{
    date: tomorrow,
    status: 'full'
  }, {
    date: afterTomorrow,
    status: 'partially'
  }];

  function getDayClass(data) {
    var date = data.date,
      mode = data.mode;
    if (mode === 'day') {
      var dayToCheck = new Date(date).setHours(0, 0, 0, 0);

      for (var i = 0; i < $scope.events.length; i++) {
        var currentDay = new Date($scope.events[i].date).setHours(0, 0, 0, 0);

        if (dayToCheck === currentDay) {
          return $scope.events[i].status;
        }
      }
    }

    return '';
  }
  $scope.dt ="";
  $scope.changedate = function(){

    $scope.isSuccess = false;
    $scope.isFailed = false;

    if( $scope.dt != "" && $scope.dt != undefined){
      $scope.disable = false;
    }else{
      $scope.disable = true;
      $scope.isFailed = true; 
      $scope.resmessage = "Please enter current or past date only, in format [DD-Month-YYYY]";
    }
if($scope.dt){
var date = new Date(new Date().getTime()-(6*24*60*60*1000));
var currentdate = date.getFullYear() + '-' + ('0' + (date.getMonth() + 1)).slice(-2) + '-' + ('0' + date.getDate()).slice(-2);
var actual = $scope.dt.getFullYear() + '-' + ('0' + ($scope.dt.getMonth() + 1)).slice(-2) + '-' + ('0' + $scope.dt.getDate()).slice(-2);
if(actual > currentdate){ $scope.disable = true; $scope.isFailed = true; 
        $scope.resmessage = "Please enter current or past date only, in format [DD-Month-YYYY]"; } 
}
  };

  $scope.setCleanupDate = function () {
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $("#showloader").css("display", "block");
    var date = $scope.dt.getFullYear() + '-' + ('0' + ($scope.dt.getMonth() + 1)).slice(-2) + '-' + ('0' + $scope.dt.getDate()).slice(-2);
    var record = {
      "dcName": $scope.pagedc,
      "userName": sessionStorage.userName,
      "cleanUpDate" : date,
      "functionality":"ClearOldLPN"
    };
  
      var res = $http.put(urlService.LOCATION_CLEANUP_PUT_BOTH, record, {
      headers: { 'x-api-key': sessionStorage.apikey }
    });
    res.success(function (data, status, headers, config) {
      $("#showloader").css("display", "none");
      if (data.errorMessage) {
        $scope.isFailed = true;
        $scope.resmessage = data.errorMessage;
    
      } else if (data.resMessage) {
            
        $scope.isSuccess = true;
        $scope.resmessage = data.resMessage;
      } 
    });

    res.error(function (data, status, headers, config) {
      $("#showloader").css("display", "none");
      $scope.isFailed = true;
      $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
    });
  };



  $scope.ClearMnlPalletizing = function () {
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $("#showloader").css("display", "block");
    
    var record = {
      "dcName": $scope.pagedc,
      "userName": sessionStorage.userName,
      "functionality":"ClearMnlPalletizing"
     };
  
      var res = $http.put(urlService.LOCATION_CLEANUP_PUT_BOTH, record, {
      headers: { 'x-api-key': sessionStorage.apikey }
    });
    res.success(function (data, status, headers, config) {
      $("#showloader").css("display", "none");
      if (data.errorMessage) {
        $scope.isFailed = true;
        $scope.resmessage = data.errorMessage;
    
      } else if (data.resMessage) {
            
        $scope.isSuccess = true;
        $scope.resmessage = data.resMessage;
      } 
    });

    res.error(function (data, status, headers, config) {
      $("#showloader").css("display", "none");
      $scope.isFailed = true;
      $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
    });
  };

  $scope.getCount = function(functionality){
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $("#showloader").css("display", "block");
    var date;
    if(functionality == "ClearMnlPalletizing"){
       date = "";
   }else{
     date = $scope.dt.getFullYear() + '-' + ('0' + ($scope.dt.getMonth() + 1)).slice(-2) + '-' + ('0' + $scope.dt.getDate()).slice(-2);
   }

    var url = urlService.LOCATION_CLEANUP_GET_COUNT.replace('dName', $scope.pagedc);
    url = url.replace('uName', sessionStorage.userName);
    if(functionality == "ClearMnlPalletizing"){
      url = url.replace('date', "");
      
    }else{
      url = url.replace('date', date);
    }
     
    url = url.replace('functionName', functionality);

    var res = $http.get(url, {
      headers: { 'x-api-key': sessionStorage.apikey }
    });
 

    res.success(function (data, status, headers, config) {
      $("#showloader").css("display", "none");
      if (data.errorMessage) {
        $scope.isFailed = true;
        $scope.resmessage = data.errorMessage;
    
      } else if (data.resMessage) {
        if(functionality == "ClearMnlPalletizing"){
           $('#palletizingModel').modal('show');
          if(data.resMessage == 0){
           $scope.disableyes = true;
	}else{
          $scope.disableyes = false;
           }
        }else{
          $('#dateconfirmModel').modal('show'); 
          if(data.resMessage == 0){
           $scope.disableyes = true;
	   }else{
	   $scope.disableyes= false;
           }
        }
        
       $scope.count = data.resMessage;
      } 
    });

    res.error(function (data, status, headers, config) {
      $("#showloader").css("display", "none");
      $scope.isFailed = true;
      $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
    });
  };

//user favourites code start
$scope.isClicked = false;
$scope.addToFavourate = function(isClicked){
  $("#showloader").css("display", "block");
   if(typeof isClicked !== "boolean"){
    commonService.postServiceResponse(urlService.GET_FAVOURITES,{"username": sessionStorage.userName})
      .then(function(response){
    $("#showloader").css("display", "none");
          _.each(response,function(val,key){
            if(val.funName == $scope.functionality && val.dcName == $scope.dcName){
              $scope.isClicked = true;      
            }
          });
      },function(error){
    $("#showloader").css("display", "none");
    $scope.isClicked = false;  
      });
      //$scope.isClicked = ;
   }else{
    if(!$scope.isClicked){
      commonService.postServiceResponse(urlService.ADD_FAVOURITE,{"username": sessionStorage.userName,"dcName":$scope.dcName,"funName":$scope.functionality})
      .then(function(response){
    $("#showloader").css("display", "none");
    if(response.errorMessage){
      $scope.isClicked = isClicked;
      $scope.isFavouriteAdded= false; 
     $scope.$broadcast('showAlert',['']);
    }else{
      $scope.isClicked = !isClicked;
      $scope.isFavouriteAdded= true; 
      $scope.favouriteMsg = response.resMessage;
      $scope.$broadcast('ClickedOnFavourate',[$scope.dcName,$scope.functionality,$scope.isClicked]);
    } 
      },function(error){
    $("#showloader").css("display", "none");
      });
      
    }
   }
  
};
 
$scope.addToFavourate('load');
//user favourites code ends
}]);

