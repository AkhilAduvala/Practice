//'use strict';	
var myApp = angular.module('DemandForecast');
$("#showloader").css("display", "none");
myApp.directive('fileModel', ['$parse', function ($parse) {
	return {
		restrict: 'A',
		link: function(scope, element, attrs) {
			var model = $parse(attrs.fileModel);
			var modelSetter = model.assign;			
			element.bind('change', function(){
				scope.$apply(function(){
				modelSetter(scope, element[0].files[0]);
				});
			});
		}
	};
}]);
      
myApp.service('demandForecastService', ['$http', function ($http) {
	this.uploadFileToUrl = function(dcName,userName,lotId, uploadUrl,$scope,mode){
		document.getElementById('list').innerHTML = '';
		document.getElementById('nextStep').innerHTML = '';
		$scope.isFailed=false;
		document.getElementById('nextStep').innerHTML = '';
		$scope.errorMessagesArray=[];
		var fd = new FormData();
		fd.append('dcName', dcName);
		fd.append('userName', userName);
		fd.append('lotId', lotId);
		fd.append('mode', mode);
		//fd.append('isAfterDN',isAfterDN);			
		$http.post(uploadUrl, fd, {
			transformRequest: angular.identity,
			headers: {'Content-Type': undefined, 'x-api-key': sessionStorage.apikey}
		})
		.success(function(response){
			console.log(JSON.stringify(response));
			document.getElementById('list').innerHTML = '';
			document.getElementById('nextStep').innerHTML = '';			
			$("#showloader").css("display", "none");
			if(response.errorMessage){
				$scope.uploadError = response.errorMessage;
			}else{
				$("#uploadCL").attr("disabled",true);
				$scope.selectedMode = "";
				$("#modeDropdown").attr("disabled",true);
				document.getElementById('list').innerHTML = response.resMessage;
				$scope.errorMessagesArray = [];
			}
		})
		.error(function(error){
			$("#showloader").css("display", "none");
			$scope.isFailedload = true;
			document.getElementById('list').innerHTML = '';
			document.getElementById('nextStep').innerHTML = '';
		});
	};
}]);

myApp.controller('DemandForecastController', ['$scope','$rootScope','$http','$window','demandForecastService','urlService','commonService', '$filter',function ($scope,$rootScope,$http,$window,demandForecastService,urlService,commonService,$filter) {
	$("#showloader").css("display", "none");
	$("#uploadSpan,#uploadFileCL").removeAttr("disabled");
	//$scope.allCustomers = "WEEKLY";
	$scope.selectedMode = "";	
	$scope.disableDownload = true;
	$scope.isClicked = false;	
	$scope.disable = true;
	$scope.pagefunctionality = $scope.functionality;
	$scope.pagedc = $scope.dcName;
	$scope.lotId  = "";
	$scope.isFailedload = false;
	//search functionality
	$scope.isSearchEnabled = false;
	$scope.disableyes = true;
	$scope.isSuccess = false;
	$scope.isFailed = false;
	$scope.fromDt = "";
	$scope.toDt = "";
	$scope.jobId = "";
	$scope.isTable = false;

	$scope.getSelectedMode = function(selectedMode) {
		$scope.allCustomers = selectedMode;
		$scope.selectedMode = selectedMode;
		$("#uploadCL").removeAttr('disabled');
	}																		
	$scope.uploadFileCL = function(){	
		$("#showloader").css("display", "block");		 
		var file = $scope.myFile;
		var dcName = $rootScope.dcName;		
		var userName = sessionStorage.userName;
		var lotId = $scope.lotId;
		//var isAfterDN = $scope.isAfterDN;
		var uploadUrl = urlService.DEMAND_FORECAST_UPLOAD_FILE;	 
		demandForecastService.uploadFileToUrl(dcName,userName,lotId, uploadUrl,$scope,$scope.selectedMode);
	};
 	
	$scope.clearFile = function(){
		$scope.isFailed = false;
		$scope.excelReadErrors = false;
		$scope.errorMessagesArray = [];
		$scope.excelErrors = false;
		document.getElementById('list').innerHTML = '';
		document.getElementById('nextStep').innerHTML = '';
		$scope.disableDownload = true;		
	};

	var fileInput = document.getElementById("uploadFileCL");
	fileInput.onchange = function (evt) {
	 	var target = evt.target || evt.srcElement;
	 	if(target.value.length == 0) {		 
		 
	   	}else {		 
			$scope.excelErrors = false;
			$scope.isFailedload = false;
			$scope.excelReadErrors = false;
			$scope.isFailed = false;
			$scope.uploadError = false;
			document.getElementById('list').innerHTML = '';
			document.getElementById('nextStep').innerHTML = '';
			$scope.errorMessagesArray = [];
			fileExtension = target.value.substr(target.value.lastIndexOf(".")+1);
			if (fileExtension == "xls") {
				$scope.isFailed = true;
				$scope.resmessage = "Please save this xls file into xlsx format and try again to Choose File";
				return false;
			}
			if (evt.target.value.indexOf(".xlsx") < 0) {
				$scope.isFailed = true;
				$scope.resmessage = "Please choose only XLSX file";
				return false;
			}				
			var dcName = $scope.dcName;
			var userName = sessionStorage.userName;
			var files = evt.target.files; // FileList object
			var fileval = $("input[type='file']").val();
			var output = [];
			if(fileval == '' || fileval == undefined || fileval == null){
				document.getElementById('list').innerHTML = '';
				document.getElementById('nextStep').innerHTML = '';
				$scope.disable = true;
			}else{
				$("#showloader").css("display", "block");
				var uploadUrl = urlService.DEMAND_FORECAST_CHOOSE_FILE;
				for (var i = 0, f; f = files[i]; i++) {
					output.push('<li><strong>', escape(f.name), '</strong> was choosen successfully</li>');
					localStorage.setItem("choosenFile",files[i]);
					var file = files[i];
					var fd = new FormData();
					fd.append('dcName', dcName);
					fd.append('userName', userName);				
					fd.append('file', file);
					if(files[i].size < 1024*1024*10){
						$http.post(uploadUrl, fd, {
							transformRequest: angular.identity,
							headers: {'Content-Type': undefined, 'x-api-key': sessionStorage.apikey}
						})				
						.success(function(response){
							console.log(JSON.stringify(response));
							if(response.lotId){								
								//$scope.isAfterDN = response.isAfterDN;
								$scope.lotId = response.lotId;
								console.log(JSON.stringify(response));
								if(response.totalCount === response.errorCount){
									$("#uploadCL").attr('disabled',true);
									$scope.disableDownload = false;
									document.getElementById('nextStep').innerHTML = response.errorCount +' '+ 'Out of' +' '+ response.totalCount+' '+'records are invalid';
									$scope.errorMessagesArray=response.errorDtoLst;
									$("#showloader").css("display", "none");
								}else{ 
									if(response.errorCount === 0){$scope.disableDownload = true;}else{$scope.disableDownload = false;}
									$("#modeDropdown").removeAttr('disabled');
									document.getElementById('list').innerHTML = response.successCount +' '+ 'Out of' +' '+ response.totalCount+' '+'records are valid -Please Proceed to Upload';
									$scope.errorMessagesArray = response.errorDtoLst;
									$("#showloader").css("display", "none");
								}				 
							}else if(response.errorMessage){
								$("#uploadCL").attr('disabled',true);
								$scope.disableDownload = true;
								$scope.excelReadErrors = true;
								$scope.excelReadError = response;								
								$("#showloader").css("display", "none");
							}else{
								$("#uploadCL").attr('disabled',true);			   
								$scope.excelErrorsData = response;
								$scope.excelErrors = true;
								$("#showloader").css("display", "none");							
							}
						})           
						.error(function(err){
							$("#showloader").css("display", "none");
							$scope.isFailedload = true;
						});
					}else{
						$("#showloader").css("display", "none");
						$scope.isFailed = true;
						$scope.resmessage = "File size should not exceed 10MB";
					}
				
				}
			}
		} 		
	}; 
	$("#uploadFileCL").click(function(evt) {
		var target = evt.target || evt.srcElement;	
		if (target.value.length == 0) {

		}else if (target.value.length > 0) {
			target.value = null;
			var input = document.getElementById("uploadFileCL");
			input.value = '';
			input.type = '';
			input.type = 'file';
			document.getElementById("uploadFileCL").value = null;
		}
	});

	//user favourites code start
	$scope.addToFavourate = function(isClicked){
		$("#showloader").css("display", "block");
		if(typeof isClicked !== "boolean"){
			commonService.postServiceResponse(urlService.GET_FAVOURITES,{"username": sessionStorage.userName})
			.then(function(response){
			$("#showloader").css("display", "none");
				_.each(response,function(val,key){
				if(val.funName == $scope.functionality && val.dcName == $scope.dcName){
					$scope.isClicked = true;      
				}
				});
			},function(error){
			$("#showloader").css("display", "none");
			$scope.isClicked = false; 
			});
		}else{
			if(!$scope.isClicked){
				commonService.postServiceResponse(urlService.ADD_FAVOURITE,{"username": sessionStorage.userName,"dcName":$scope.dcName,"funName":$scope.functionality})
				.then(function(response){
				$("#showloader").css("display", "none");
				if(response.errorMessage){
					$scope.isFavouriteAdded= false; 
					$scope.isClicked = false;      
					$scope.$broadcast('showAlert',['']);
				}else{
					$scope.isClicked = true;      
					$scope.isClicked = !isClicked;
					$scope.isFavouriteAdded= true; 
					$scope.favouriteMsg = response.resMessage;
				$scope.$broadcast('ClickedOnFavourate',[$scope.dcName,$scope.functionality,$scope.isClicked]);
				}
					
				},function(error){
				$scope.isClicked = false;
				$("#showloader").css("display", "none");
				});
				$scope.isClicked = !isClicked;
			}else{
				$("#showloader").css("display", "none");
			}
		}    
	};
	$scope.addToFavourate('load');
	//user favourites code end

	$scope.downloadExcel = function(row) {
		console.log("row :::: ",row);
		$scope.isFailed = false;
		$("#showloader").css("display", "block");
		var url;
		url = urlService.DEMAND_FORECAST_DOWNLOAD_EXCEL;
		if(row) {
			$scope.lotId = row.entity.jobId;
			url = url.replace('LID',$scope.lotId);
			url = url.replace('jCode',"DSF"); 
		} else {
			url = url.replace('LID',$scope.lotId);
			url = url.replace('jCode',"DFT");
		}
		url = url.replace('dName',$scope.dcName);
		$http({
			method: 'GET',
			url: url,
			headers: {				
				'Content-type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'x-api-key': sessionStorage.apikey
			},
			responseType: 'arraybuffer'
		})
		.success( function(data, status, headers) {
			$("#showloader").css("display", "none");
			if(data.byteLength == 55){
				$scope.isFailed = true;
				$('#alert-box').modal('show');
			}else if(data.byteLength == 98){
				$scope.isFailed = true;
				$scope.resmessage = "Error in Downloading Excel file";
				return;
			}else{				
				var octetStreamMime = 'application/octet-stream';
				var success = false;
				var blob;
				// Get the headers
				headers = headers();
				// Get the filename from the x-filename header or default to "download.bin"
				var filename = headers['x-filename'] || 'Demand_Forecast.xlsx';
				// Determine the content type from the header or default to "application/octet-stream"
				var contentType = headers['content-type'] || octetStreamMime;
				try {
					// Try using msSaveBlob if supported
					console.log("Trying saveBlob method ...");
					blob = new Blob([data], { type: contentType });
					if(navigator.msSaveBlob)
						navigator.msSaveBlob(blob, filename);
					else {
						// Try using other saveBlob implementations, if available
						var saveBlob = navigator.webkitSaveBlob || navigator.mozSaveBlob || navigator.saveBlob;
						if(saveBlob === undefined) throw "Not supported";
						saveBlob(blob, filename);
					}
					console.log("saveBlob succeeded");
					success = true;
				} catch(ex) {
					console.log("saveBlob method failed with the following exception:");
					console.log(ex);
				}
				if(!success) {
					// Get the blob url creator
					var urlCreator = window.URL || window.webkitURL || window.mozURL || window.msURL;
					if(urlCreator) {
						// Try to use a download link
						var link = document.createElement('a');
						if('download' in link) {
							// Try to simulate a click
							try {
								// Prepare a blob URL
								console.log("Trying download link method with simulated click ...");
								blob = new Blob([data], { type: contentType });
								url = urlCreator.createObjectURL(blob);
								link.setAttribute('href', url);
								// Set the download attribute (Supported in Chrome 14+ / Firefox 20+)
								link.setAttribute("download", filename);
								// Simulate clicking the download link
								var event = document.createEvent('MouseEvents');
								event.initMouseEvent('click', true, true, window, 1, 0, 0, 0, 0, false, false, false, false, 0, null);
								link.dispatchEvent(event);
								console.log("Download link method with simulated click succeeded");
								success = true;
							} catch(ex) {
								console.log("Download link method with simulated click failed with the following exception:");
								console.log(ex);
							}
						}
						if(!success) {
							// Fallback to window.location method
							try {
								// Prepare a blob URL
								// Use application/octet-stream when using window.location to force download
								console.log("Trying download link method with window.location ...");
								blob = new Blob([data], { type: octetStreamMime });
								url = urlCreator.createObjectURL(blob);
								window.location = url;
								console.log("Download link method with window.location succeeded");
								success = true;
							} catch(ex) {
								console.log("Download link method with window.location failed with the following exception:");
								console.log(ex);
							}
						}
					}
				}
				if(!success) {
					// Fallback to window.open method
					console.log("No methods worked for saving the arraybuffer, using last resort window.open");
					window.open(rowData.pathName, '_blank', '');
				}
			}
		})
		.error(function(data, status, config) {
			console.log("Request failed with status: " + status);
			$("#showloader").css("display", "none");
			$scope.isFailed = true;
			$scope.resmessage = "Error in downloading Excel File";
		});
	};

	//search functionality
	$scope.search = function() {
		$scope.isSearchEnabled = true;
	};
	$scope.openFromDate = function () {
		$scope.popup1.opened = true;
	};
	$scope.openToDate = function () {
		$scope.popup2.opened = true;
	};
	$scope.setDate = function (year, month, day) {
		$scope.dt = new Date(year, month, day);
	};
	$scope.formats = ['dd-MMMM-yyyy', 'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate'];
	$scope.format = $scope.formats[0];
	$scope.altInputFormats = ['M!/d!/yyyy'];
	$scope.popup1 = {
		opened: false
	};
	$scope.popup2 = {
		opened: false
	};
	$scope.validateDFSearchData = function(){
		$scope.isSuccess = false;
		$scope.isFailed = false;		
		if($scope.jobId || ($scope.fromDt && $scope.toDt)){
			$scope.disable = false;
			if($scope.jobId) {
				$("#fromDate *").attr("disabled", "disabled");
				$("#toDate *").attr("disabled", "disabled");
				return;
			} else {
				$("#jobId").attr("disabled", "disabled");
				if(new Date($scope.fromDt) > new Date()){
					$scope.disable = true; 
					$scope.isFailed = true;					 
					$scope.resmessage = "From date should be before today date, in the format [DD-Month-YYYY]";
					return false;
				} 
				if(new Date($scope.fromDt) > new Date($scope.toDt)){
					$scope.disable = true; 
					$scope.isFailed = true;
					$scope.resmessage = 'To Date should be greater than from date';
					return false;
				}	
			}
	  	}else{
		  	$scope.disable = true;
		  	$scope.isFailed = true; 
			$scope.resmessage = "Please enter Job Id or from and to date in the format [DD-Month-YYYY]";
			$("#jobId").removeAttr("disabled");
		  	$("#fromDate *").removeAttr("disabled");
			$("#toDate *").removeAttr("disabled");
	  	}
	};
	$scope.gridOptions = {
		paginationPageSizes: [15, 25, 50, 100],
		paginationPageSize: 15,
		enableSorting: true,
		useExternalPagination: true,
		enableColumnMenus: false,
		 enableHorizontalScrollbar: false,
	};
	$scope.gridOptions.onRegisterApi = function (gridApi) {
		//set gridApi on scope
		$scope.gridApi = gridApi;
	
		$scope.gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
			$scope.pageNo =  newPage;
			$scope.pageSize = pageSize;
			$scope.getDemandforecastData();
	   });
	};
	$scope.$watch('fromDt', function (newValue) {
		$scope.formattedFDate = $filter('date')(newValue, 'yyyy-MM-dd'); 
	});
	$scope.$watch('toDt', function (newValue) {
		$scope.formattedTDate = $filter('date')(newValue, 'yyyy-MM-dd'); 
	});
	$scope.getDemandforecastData = function () {
		$scope.resmessage = "";
		$scope.isSuccess = false;
		$scope.isFailed = false;
		$scope.isFieldValidate = false;
		$("#showloader").css("display", "block");
		$scope.pageNo = $scope.pageNo ? $scope.pageNo : 1;
		$scope.pageSize = $scope.pageSize ? $scope.pageSize: $scope.gridOptions.paginationPageSize;	
		var url = urlService.DEMAND_FORECAST_SEARCH_Data.replace('uName',sessionStorage.userName);
		url = url.replace('pNumber', $scope.pageNo);
		url = url.replace('pSize', $scope.pageSize);
		url = url.replace('fDate', $scope.formattedFDate);
		url = url.replace('tDate', $scope.formattedTDate);
		if($scope.jobId) {
			url = url.replace('sCriteria', 'jobid');
		} else {
			url = url.replace('sCriteria', 'date');
		}
		url = url.replace('jobId', $scope.jobId);		 
		var res = $http({
			method: 'GET',
			url: url,
			headers: {				
				'Content-type': 'application/json', 'x-api-key': sessionStorage.apikey
			}
		});	  
		res.success(function (data, status, headers, config) {	
			$("#showloader").css("display", "none");		
			if (data.errorMessage) {
				$scope.isTable = false;
				$scope.isFailed = true;
				$scope.resmessage = data.errorMessage;
			}
			else if(data.resMessage){
				$scope.isTable = false;
				$scope.isSuccess = true;
				$scope.resmessage = data.resMessage;
			}
			else if(data.length === 0){
				$scope.isTable = false;
				$scope.isFailed = true;
				$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
			}
			else {
				$scope.isTable = true;
				$scope.isCopy = false;		
				$scope.gridOptions.columnDefs = [
					{ name: 'jobId', displayName: 'Job Id', visible: true},
					{ name: 'jobStartTime', displayName: 'Job Start Time', cellTooltip: true, headerTooltip: true },
					{ name: 'jobEndTime', displayName: 'Job End Time', cellTooltip: true, headerTooltip: true},
					{ name: 'status', displayName: 'Status', cellTooltip: true, headerTooltip: true},
					{ name: 'usrId', displayName: 'User Id', cellTooltip: true, headerTooltip: true},
					{ name: 'download', displayName:'Download', cellTemplate: '<div class="ngCellText ui-grid-cell-contents"><span class="glyphicon glyphicon-download-alt downloadIcon" ng-click="grid.appScope.downloadExcel(row)"></span></div>'}					
				];		
				$scope.gridOptions.totalItems  = data.totalNoOfRecords;  
				$scope.gridOptions.data = data.pageItems;		
				if ($scope.gridOptions.data.length > 10) {
					$scope.gridOptions.enableVerticalScrollbar = 1;
					$scope.gridOptions.enableHorizontalScrollbar = 1;
				} else {
					$scope.gridOptions.enableVerticalScrollbar = 0;
					$scope.gridOptions.enableHorizontalScrollbar = 1;
				}
			}		  
		});	
		res.error(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			$scope.isFailed = true;
			$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
		});
		setTimeout(function(){  $('.ui-grid-pager-control-input').attr( "disabled", true );  }, 2000);		
	};
}]);
  