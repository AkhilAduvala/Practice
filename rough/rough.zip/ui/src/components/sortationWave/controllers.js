var app = angular.module('SortationWave', ['ngAnimate','ui.bootstrap', 'ui.multiselect','ui.grid', 'ui.grid.selection', 'ui.grid.pagination', 'ui.grid.autoResize', 'ui.grid.exporter']);
app.controller('SortationWaveController', ['$scope', '$http', '$q', '$interval', '$timeout', 'urlService', 'uiGridConstants', 'commonService', function ($scope, $http, $q, $interval, $timeout, urlService, uiGridConstants, commonService) {

  $scope.isSuccess = false;
  $scope.isFailed = false;
  $scope.pagefunctionality = $scope.functionality;
  $scope.pagedc = $scope.dcName;
  $scope.taskval = 'standardCase';
  $scope.isCreateTask = true;
  $scope.isTablestandardCase= false;
  $scope.isTabledemandTask= false;
  $scope.isTablecleanupTask= false;

	$scope.gridOptions = {
		paginationPageSizes: [15, 25, 50, 100],
		paginationPageSize: 15,
		useExternalPagination: true,
		enableSorting: true,
		enableColumnMenus: false,
		multiSelect: true,
		enableHorizontalScrollbar: false,

  };
  
  $scope.gridOptions.onRegisterApi = function (gridApi) {
      $scope.gridApi = gridApi;
      $scope.gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
      $scope.pageNo = newPage;
      $scope.pageSize = pageSize;
    if(taskval == 'standardCase'){
     $scope.standardCasedata();
    }else if(taskval == 'demandTask'){
    $scope.demandTaskData();
    }else if(taskval == 'cleanupTask'){
     $scope.cleanupTaskData();
    }

    });
    

    gridApi.selection.on.rowSelectionChangedBatch($scope, function (rows) {
      $scope.isSuccess = false;
      $scope.isFailed = false;
      if ($scope.gridApi.selection.getSelectedRows().length == 0) {
        $scope.isCreateTask = true;
      } else {
        $scope.isCreateTask = false;
     
      }
    });
 
    gridApi.selection.on.rowSelectionChanged($scope, function (row) {
      $scope.isSuccess = false;
      $scope.isFailed = false;
      if ($scope.gridApi.selection.getSelectedRows().length > 0) {
        $scope.isCreateTask = false;
       } else {
        $scope.isCreateTask = true;
       }
    });

  };
 

  $scope.task = function(taskval){

  $scope.isSuccess = false;
  $scope.isFailed = false;
  $scope.resMessage = "";
  $scope.pageNo = 1;
  $scope.pageSize =15;

    $scope.isTablestandardCase= false;
    $scope.isTabledemandTask= false;
    $scope.isTablecleanupTask= false;

    if(taskval == 'standardCase'){
      $scope.standardCase.minappstandardCase = "";
      $scope.standardCase.minftwstandardCase = "";
      $scope.standardCase.cleanupTask = false;
      $scope.standardCase.disablestandardCase = false;
      
    }else if(taskval == 'demandTask'){
      $scope.demandTask.minappdemandTask = "";
      $scope.demandTask.minftwdemandTask = "";
      $scope.demandTask.maxUnitLoc = "";

    }else if(taskval == 'cleanupTask'){
      $scope.cleanupTask.date = "";
     $scope.cleanupTask.maxUnitsinLocation ="";
     $scope.cleanupTask.selectedValues = [];
     getCleardaskdropdown();
    }


    };
   
  $scope.cleanupTask= {
    "date" :"",
    "maxUnitsinLocation":"",
    "selectedValues":[]
  };

  $scope.today = function () {
    $scope.cleanupTask.date = new Date();
  };
  
  $scope.clear = function () {
    $scope.cleanupTask.date = null;
  };

  $scope.inlineOptions = {
    customClass: getDayClass,
    minDate: new Date(),
    showWeeks: true
  };
  $scope.dateOptions = {
    formatYear: 'yy',
    startingDay: 1
  };

  $scope.open1 = function () {
    $scope.popup1.opened = true;
  };

  $scope.setDate = function (year, month, day) {
    $scope.dt = new Date(year, month, day);
  };

  $scope.formats = ['dd-MMMM-yyyy', 'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate'];
  $scope.format = $scope.formats[0];
  $scope.altInputFormats = ['M!/d!/yyyy'];

  $scope.popup1 = {
    opened: false
  };

  var tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  var afterTomorrow = new Date();
  afterTomorrow.setDate(tomorrow.getDate() + 1);
  $scope.events = [{
    date: tomorrow,
    status: 'full'
  }, {
    date: afterTomorrow,
    status: 'partially'
  }];

  function getDayClass(data) {
    var date = data.date,
      mode = data.mode;
    if (mode === 'day') {
      var dayToCheck = new Date(date).setHours(0, 0, 0, 0);

      for (var i = 0; i < $scope.events.length; i++) {
        var currentDay = new Date($scope.events[i].date).setHours(0, 0, 0, 0);

        if (dayToCheck === currentDay) {
          return $scope.events[i].status;
        }
      }
    }
    return '';
  }

 
//$scope.getClearDropDatas = [ null, "17F",    "18F",    "F18",    "19S",    "18S",    "F17"];

  function getCleardaskdropdown() {
    $("#showloader").css("display", "block");
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $scope.resmessage = "";

    var url = urlService.SORTATION_WAVE_DROPDOWN.replace('dName',$scope.pagedc);
    url = url.replace('uName',sessionStorage.userName);
		var headers = {	headers: {'x-api-key': sessionStorage.apikey}  };
		commonService.getServiceResponse(url,headers).then(function(data) {
      $("#showloader").css("display", "none");
          if(data.resMessage){
						   $scope.isSuccess = true;
						   $scope.resmessage = data.resMessage; 
						 
					   }else if(data.errorMessage){
						  $scope.isFailed = true;
						  $scope.resmessage = data.errorMessage; 
						 
					   }else{
                $scope.getClearDropDatas = data;
             
              }
				   },
					function(errResponse){
					
						$scope.isFailed = true;
						 $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
						 $("#showloader").css("display", "none");
					}
        );

  }
  


  $scope.validateDateChange = function () {
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $scope.resmessage = "";

  if($scope.cleanupTask.date == "" || $scope.cleanupTask.date == undefined ){
    $scope.isFailed = true;
    $scope.resmessage = "Please enter current or past date only, in format [DD-Month-YYYY]";
    return false;
   }
   
   };


   $scope.validateUnitsinLocation = function () {
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $scope.resmessage = "";

    var reg = /^[0-9\_ ]+$/;

  if($scope.cleanupTask.maxUnitsinLocation == "" || $scope.cleanupTask.maxUnitsinLocation == undefined || !(reg.test($scope.cleanupTask.maxUnitsinLocation))){
    $scope.isFailed = true;
    $scope.resmessage = "Please Enter valid data";
    return false;
   }

   if($scope.cleanupTask.maxUnitsinLocation == "0"){
    $scope.isFailed = true;
    $scope.resmessage = "Invalid input! Input data has to be greater than 0 and less than 1000";
    return false;
   }
   
   };




  $scope.cleanupTaskData = function() {
    
     $scope.isSuccess = false;
     $scope.isFailed = false;
     $scope.resmessage = "";

    if($scope.validateDateChange() == false){  
      $scope.isFailed = true;
      $scope.resmessage = "Date is mandatory field";
      return false;
    }
    if($scope.validateUnitsinLocation() == false){
      $scope.isFailed = true;
      $scope.resmessage = "Max Units in Location is mandatory field";
      return false;
    }
    if($scope.cleanupTask.selectedValues.length == 0){
      $scope.isFailed = true;
      $scope.resmessage = "Please Select minimum one session";
      return false;
    }


     $scope.pageNo = $scope.pageNo ? $scope.pageNo : 1;
     $scope.pageSize = $scope.pageSize ? $scope.pageSize : $scope.gridOptions.paginationPageSize;
     var dateVal = $scope.cleanupTask.date.getFullYear() + '-' + ('0' + ($scope.cleanupTask.date.getMonth() + 1)).slice(-2) + '-' + ('0' + $scope.cleanupTask.date.getDate()).slice(-2);
     
     var url = urlService.SORTATION_WAVE_GET_CLEANUP_TASK.replace('maxcleanupTask',$scope.cleanupTask.maxUnitsinLocation);
     url = url.replace('datecleanupTask',dateVal);
     url = url.replace('seasonsCleanupTask',$scope.cleanupTask.selectedValues);
     url = url.replace('dName',$scope.pagedc);
     url = url.replace('uName',sessionStorage.userName);
     url = url.replace('pNumber', $scope.pageNo);
      url = url.replace('pSize', $scope.pageSize);
      $("#showloader").css("display", "block");
     var headers = {	headers: {'x-api-key': sessionStorage.apikey}  };
     commonService.getServiceResponse(url,headers).then(function(data) {
       $("#showloader").css("display", "none");
           if(data.resMessage){
                $scope.isSuccess = true;
                $scope.resmessage = data.resMessage; 
                $scope.isTablecleanupTask = false;
              }else if(data.errorMessage){
               $scope.isFailed = true;
               $scope.resmessage = data.errorMessage;
               $scope.isTablecleanupTask = false;
              }else{
              $scope.isTablecleanupTask = true;
         $scope.gridOptions.columnDefs = [
           { name: 'skuId', displayName: 'SKU ID', visible: true },
           { name: 'style', displayName: 'Style', cellTooltip: true, headerTooltip: true },
           { name: 'color', displayName: 'Color', cellTooltip: true, headerTooltip: true },
           { name: 'sizeDesc', displayName: 'Size Desc', cellTooltip: true, headerTooltip: true },
           { name: 'coo', displayName: 'COO', cellTooltip: true, headerTooltip: true },
           { name: 'prodGroup', displayName: 'Product Group', cellTooltip: true, headerTooltip: true },
           { name: 'stdCaseQty', displayName: 'Std Case Qty', cellTooltip: true, headerTooltip: true},
           { name: 'qtyInInventory', displayName: 'Qty in WCS', cellTooltip: true, headerTooltip: true },
           { name: 'qty', displayName: 'Qty for Sort', cellTooltip: true, headerTooltip: true},
           { name: 'estimatedCases', displayName: 'Est Cases', cellTooltip: true, headerTooltip: true },
           { name: 'taskCreateTemplate',visible: false, displayName: 'Task Create Template', cellTooltip: true, headerTooltip: true }
        ];
 
         $scope.gridOptions.totalItems = data.totalNoOfRecords;
         $scope.gridOptions.data = data.pageItems;
 
         if ($scope.gridOptions.data.length > 10) {
           $scope.gridOptions.enableVerticalScrollbar = 1;
           $scope.gridOptions.enableHorizontalScrollbar = 1;
         } else {
           $scope.gridOptions.enableVerticalScrollbar = 0;
           $scope.gridOptions.enableHorizontalScrollbar = 1;
         }
               }
            },
           function(errResponse){
              $scope.isFailed = true;
              $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
              $("#showloader").css("display", "none");
           }
         );
   };
 

  
  $scope.demandTask = {
    "minappdemandTask" :"",
    "minftwdemandTask":"",
    "maxUnitLoc":""
  };

  $scope.validateDemandTaskapp = function () {
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $scope.resmessage = "";

    var reg = /^[0-9\_ ]+$/;

  if($scope.demandTask.minappdemandTask == "" || $scope.demandTask.minappdemandTask == undefined || !(reg.test($scope.demandTask.minappdemandTask))){
    $scope.isFailed = true;
    $scope.resmessage = "Please Enter valid data";
    return false;
   }
   if($scope.demandTask.minappdemandTask == "0"){
    $scope.isFailed = true;
    $scope.resmessage = "Invalid input! Input data has to be greater than 0 and less than 1000";
    return false;
   }
   
   };

   $scope.validateDemandTaskftw = function () {
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $scope.resmessage = "";

    var reg = /^[0-9\_ ]+$/;

  if($scope.demandTask.minftwdemandTask == "" || $scope.demandTask.minftwdemandTask == undefined || !(reg.test($scope.demandTask.minftwdemandTask))){
    $scope.isFailed = true;
    $scope.resmessage = "Please Enter valid data";
    return false;
   }

   if($scope.demandTask.minftwdemandTask == "0"){
    $scope.isFailed = true;
    $scope.resmessage = "Invalid input! Input data has to be greater than 0 and less than 1000";
    return false;
   }
   
   };

   $scope.validateDemandTask= function () {
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $scope.resmessage = "";

    var reg = /^[0-9\_ ]+$/;

  if($scope.demandTask.maxUnitLoc == "" || $scope.demandTask.maxUnitLoc == undefined || !(reg.test($scope.demandTask.maxUnitLoc))){
    $scope.isFailed = true;
    $scope.resmessage = "Please Enter valid data";
    return false;
   }


  if($scope.demandTask.maxUnitLoc=="0"){
    $scope.isFailed = true;
    $scope.resmessage = "Invalid input! Input data has to be greater than 0 and less than 1000";
    return false;
   }
   
   };
  

  $scope.demandTaskData = function() {
   
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $scope.resmessage = "";
    $scope.pageNo = $scope.pageNo ? $scope.pageNo : 1;
    $scope.pageSize = $scope.pageSize ? $scope.pageSize : $scope.gridOptions.paginationPageSize;

    if($scope.validateDemandTaskapp() == false){  
      $scope.isFailed = true;
      $scope.resmessage = "Min Nbr of Units (APP) mandatory field";
      return false;
    }
    if($scope.validateDemandTaskftw() == false){
      $scope.isFailed = true;
      $scope.resmessage = "Min Nbr of Units (FTW) mandatory field";
      return false;
    }
    if($scope.validateDemandTask() == false){
      $scope.isFailed = true;
      $scope.resmessage = "Max Nbr of Units CDC/EFC mandatory field";
      return false;
    }

    var url = urlService.SORTATION_WAVE_GET_DEMAND.replace('minNbrAppNum',$scope.demandTask.minappdemandTask);
    url = url.replace('minNbrFtwNum',$scope.demandTask.minftwdemandTask);
    url = url.replace('maxNbrUnitNum',$scope.demandTask.maxUnitLoc);
    url = url.replace('dName',$scope.pagedc);
    url = url.replace('uName',sessionStorage.userName);
    url = url.replace('pNumber', $scope.pageNo);
   	url = url.replace('pSize', $scope.pageSize);
     $("#showloader").css("display", "block");
		var headers = {	headers: {'x-api-key': sessionStorage.apikey}  };
		commonService.getServiceResponse(url,headers).then(function(data) {
      $("#showloader").css("display", "none");
          if(data.resMessage){
						   $scope.isSuccess = true;
						   $scope.resmessage = data.resMessage; 
               $scope.isTabledemandTask = false;
					   }else if(data.errorMessage){
						  $scope.isFailed = true;
						  $scope.resmessage = data.errorMessage;
						  $scope.isTabledemandTask = false;
					   }else{
             $scope.isTabledemandTask = true;
        $scope.gridOptions.columnDefs = [
          { name: 'skuId', displayName: 'SKU ID', visible: true },
          { name: 'style', displayName: 'Style', cellTooltip: true, headerTooltip: true },
          { name: 'color', displayName: 'Color', cellTooltip: true, headerTooltip: true },
          { name: 'sizeDesc', displayName: 'Size Desc', cellTooltip: true, headerTooltip: true },
          { name: 'coo', displayName: 'COO', cellTooltip: true, headerTooltip: true },
          { name: 'prodGroup', displayName: 'Product Group', cellTooltip: true, headerTooltip: true },
          { name: 'stdCaseQty', displayName: 'Std Case Qty', cellTooltip: true, headerTooltip: true},
          { name: 'qtyInInventory', displayName: 'Qty in WCS', cellTooltip: true, headerTooltip: true },
          { name: 'qty', displayName: 'Qty for Sort', cellTooltip: true, headerTooltip: true},
          { name: 'estimatedCases', displayName: 'Est Cases', cellTooltip: true, headerTooltip: true },
          { name: 'taskCreateTemplate',visible: false, displayName: 'Task Create Template', cellTooltip: true, headerTooltip: true }
       ];

        $scope.gridOptions.totalItems = data.totalNoOfRecords;
        $scope.gridOptions.data = data.pageItems;

        if ($scope.gridOptions.data.length > 10) {
          $scope.gridOptions.enableVerticalScrollbar = 1;
          $scope.gridOptions.enableHorizontalScrollbar = 1;
        } else {
          $scope.gridOptions.enableVerticalScrollbar = 0;
          $scope.gridOptions.enableHorizontalScrollbar = 1;
        }
              }
				   },
					function(errResponse){
      			 $scope.isFailed = true;
						 $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
						 $("#showloader").css("display", "none");
					}
        );
  };
  
$scope.createTask = function(){

  $scope.isSuccess = false;
  $scope.isFailed = false;
  $("#showloader").css("display", "block");
  var url = urlService.SORTATION_WAVE_DEMAND_POST_CREATE_TASK;
  var headers = {	headers: {'x-api-key': sessionStorage.apikey}  };
  var postRecords = [];
  angular.forEach($scope.gridApi.selection.getSelectedRows(), function (data, index) {
    var records = {
    "skuId":data.skuId,
    "coo":data.coo,
    };
    postRecords.push(records);
  });

  var inputData ={
  "dcName": $scope.pagedc,
  "userName": sessionStorage.userName,
  "returnsSortationWaveDtoLst" :postRecords
};

  commonService.putServiceResponse(url,inputData,headers)
    .then(
       function(data) {
      $("#showloader").css("display", "none");
         if(data.errorMessage){
           $scope.isFailed = true;
            $scope.resmessage = data.errorMessage;
         }else if(data.resMessage){
          $scope.gridApi.selection.clearSelectedRows();
          $scope.isSuccess = true;
          $scope.resmessage = data.resMessage;
        

         }
      },
      function(errResponse){
      
        $scope.isFailed = true;
         $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
         $("#showloader").css("display", "none");
      }
    );
};

  $scope.standardCase = {
    "minappstandardCase" :"",
    "minftwstandardCase":"",
    "cleanupTask":false,
    "disablestandardCase":false,
    "disablestandardCasebutton":true
  
  };
  $scope.standardCaseflag = function(cleanupTaskflag){
    if(cleanupTaskflag == true){
      $scope.isSuccess = false;
      $scope.isFailed = false;
      $scope.resmessage = "";
    $scope.standardCase.disablestandardCase = true;
    $scope.standardCase.disablestandardCasebutton = false;
    }else{
      $scope.standardCase.disablestandardCase = false; 
      $scope.standardCase.disablestandardCasebutton = true;
    }
    if($scope.standardCase.minftwstandardCase && $scope.standardCase.minftwstandardCase && cleanupTaskflag==false){
      $scope.standardCase.disablestandardCasebutton = false;
    }
  };


  $scope.validatestandardCaseapp = function () {
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $scope.resmessage = "";

    var reg = /^[0-9\_ ]+$/;

  if($scope.standardCase.minappstandardCase == "" || $scope.standardCase.minappstandardCase == undefined || !(reg.test($scope.standardCase.minappstandardCase))){
    $scope.isFailed = true;
    $scope.resmessage = "Please Enter valid data";
    return false;
   }

   if($scope.standardCase.minappstandardCase =="0"){
    $scope.isFailed = true;
    $scope.resmessage = "Invalid input! Input data has to be greater than 0 and less than 1000";
    return false;
   }
   
   };

    $scope.validatestandardCaseftw = function () {
      $scope.isSuccess = false;
      $scope.isFailed = false;
      $scope.resmessage = "";
  
      var reg = /^[0-9\_ ]+$/;
  
    if($scope.standardCase.minftwstandardCase == "" || $scope.standardCase.minftwstandardCase == undefined || !(reg.test($scope.standardCase.minftwstandardCase))){
      $scope.isFailed = true;
      $scope.resmessage = "Please Enter valid data";
      return false;
    }   

    if($scope.standardCase.minftwstandardCase=="0"){
      $scope.isFailed = true;
      $scope.resmessage = "Invalid input! Input data has to be greater than 0 and less than 1000";
      return false;
     }
  
      };
  


  $scope.standardCasedata = function() {
 
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $scope.resmessage = "";
    var minapp;
    var minftw;
    $scope.pageNo = $scope.pageNo ? $scope.pageNo : 1;
    $scope.pageSize = $scope.pageSize ? $scope.pageSize : $scope.gridOptions.paginationPageSize;
    if($scope.standardCase.cleanupTask == true){
      minapp = 0;
      minftw = 0;
    }else{
      if($scope.validatestandardCaseapp() == false){  
        $scope.isFailed = true;
        $scope.resmessage = "Min Nbr of Units (APP) mandatory field";
        return false;
      }
      if($scope.validatestandardCaseftw() == false){
        $scope.isFailed = true;
        $scope.resmessage = "Min Nbr of Units (FTW) mandatory field";
        return false;
      }
 
      minapp = $scope.standardCase.minappstandardCase;
      minftw = $scope.standardCase.minftwstandardCase;
    }
    var url = urlService.SORTATION_WAVE_GET_STANDARED.replace('minNbrAppNum',minapp);
    url = url.replace('minNbrFtwNum',minftw);
    url = url.replace('fullcaseBoolean',$scope.standardCase.cleanupTask);
    url = url.replace('dName',$scope.pagedc);
    url = url.replace('uName',sessionStorage.userName);
    url = url.replace('pNumber', $scope.pageNo);
   	url = url.replace('pSize', $scope.pageSize);
     $("#showloader").css("display", "block");
		var headers = {	headers: {'x-api-key': sessionStorage.apikey}  };
		commonService.getServiceResponse(url,headers).then(function(data) {
      $("#showloader").css("display", "none");
      if(data.resMessage){
           $scope.isSuccess = true;
           $scope.resmessage = data.resMessage; 
           $scope.isTablestandardCase = false;
         }else if(data.errorMessage){
          $scope.isFailed = true;
          $scope.resmessage = data.errMessage; 
          $scope.isTablestandardCase = false;
         }else{
         $scope.isTablestandardCase = true;
    $scope.gridOptions.columnDefs = [
      { name: 'skuId', displayName: 'SKU ID', visible: true },
      { name: 'style', displayName: 'Style', cellTooltip: true, headerTooltip: true },
      { name: 'color', displayName: 'Color', cellTooltip: true, headerTooltip: true },
      { name: 'sizeDesc', displayName: 'Size Desc', cellTooltip: true, headerTooltip: true },
      { name: 'coo', displayName: 'COO', cellTooltip: true, headerTooltip: true },
      { name: 'prodGroup', displayName: 'Product Group', cellTooltip: true, headerTooltip: true },
      { name: 'stdCaseQty', displayName: 'Std Case Qty', cellTooltip: true, headerTooltip: true},
      { name: 'qtyInInventory', displayName: 'Qty in WCS', cellTooltip: true, headerTooltip: true },
      { name: 'qty', displayName: 'Qty for Sort', cellTooltip: true, headerTooltip: true},
      { name: 'estimatedCases', displayName: 'Est Cases', cellTooltip: true, headerTooltip: true },
      { name: 'taskCreateTemplate',visible: false, displayName: 'Task Create Template', cellTooltip: true, headerTooltip: true }
   ];

    $scope.gridOptions.totalItems = data.totalNoOfRecords;
    $scope.gridOptions.data = data.pageItems;

    if ($scope.gridOptions.data.length > 10) {
      $scope.gridOptions.enableVerticalScrollbar = 1;
      $scope.gridOptions.enableHorizontalScrollbar = 1;
    } else {
      $scope.gridOptions.enableVerticalScrollbar = 0;
      $scope.gridOptions.enableHorizontalScrollbar = 1;
    }
          }
       },
					function(errResponse){
      			 $scope.isFailed = true;
						 $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
						 $("#showloader").css("display", "none");
					}
        );
  };



//user favourites code starts
$scope.isClicked = false;
$scope.addToFavourate = function(isClicked){
  $("#showloader").css("display", "block");
   if(typeof isClicked !== "boolean"){
    commonService.postServiceResponse(urlService.GET_FAVOURITES,{"username": sessionStorage.userName})
      .then(function(response){
        $("#showloader").css("display", "none");
          _.each(response,function(val,key){
            if(val.funName == $scope.functionality && val.dcName == $scope.dcName){
              $scope.isClicked = true;      
            }
          });
      },function(error){
        $("#showloader").css("display", "none");
        $scope.isClicked = false; 
      });
      //$scope.isClicked = ;
   }else{
    if(!$scope.isClicked){
      commonService.postServiceResponse(urlService.ADD_FAVOURITE,{"username": sessionStorage.userName,"dcName":$scope.dcName,"funName":$scope.functionality})
      .then(function(response){
        $("#showloader").css("display", "none");
        if(response.errorMessage){
          $scope.isFavouriteAdded= false; 
          $scope.isClicked = false;      
          $scope.$broadcast('showAlert',['']);
        }else{
          $scope.isClicked = true;      
          $scope.isClicked = !isClicked;
          $scope.isFavouriteAdded= true; 
          $scope.favouriteMsg = response.resMessage;
        $scope.$broadcast('ClickedOnFavourate',[$scope.dcName,$scope.functionality,$scope.isClicked]);
        }
          
      },function(error){
        $scope.isClicked = false;
        $("#showloader").css("display", "none");
      });
      $scope.isClicked = !isClicked;
    }else{
      $("#showloader").css("display", "none");
    }
   }
  
};
$scope.addToFavourate('load');
 

}]);


