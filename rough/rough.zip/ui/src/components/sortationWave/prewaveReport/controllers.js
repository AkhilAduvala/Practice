var app = angular.module('prewaveReport', ['ui.bootstrap', 'ngTouch', 'ui.grid', 'ui.grid.selection', 'ui.grid.pagination', 'ui.grid.exporter','ui.grid.autoResize']);

app.controller('prewaveReportCtrl', ['$scope', '$http', '$q', '$interval', '$timeout', 'urlService', 'uiGridConstants', 'commonService', function ($scope, $http, $q, $interval, $timeout, urlService, uiGridConstants, commonService) {
    var pr = this;
    pr.pagedc = $scope.dcName;
    pr.pagefunctionality = $scope.functionality;
    pr.isMianpage = false;
    pr.isClicked = false;
    pr.numberGridOptionssuccess = false;
    pr.numberGridOptionserror = false;
    pr.estimationDataBtn = false;
    pr.estimation = {};
    pr.selectedRowValues = [];
    pr.wavePlanning = false;
    pr.transPlanning = false;
    pr.maniFest = false;
    pr.nopermProfile = false;
    pr.replenishment = false;
    pr.estimationsInfo = false;

    pr.iswavePlanning = true;
    pr.istransPlanning = true;
    pr.ismaniFest= true;
    pr.isnopermProfile = true;
    pr.isreplenishment = true;
    pr.isestimationsInfo = true;

    //ui grid options
    pr.numberGridOptions = {
        enableColumnMenus: false,
        enableSorting: true,
        enableRowSelection: true,//we can remove it later no use  of this
        enableSelectAll: true,//we can remove it later no use  of this             
        enableCellEdit: false, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
        enableCellEditOnFocus: true, // set any editable column to allow edit on focus
   
    };
    pr.gridOptions = angular.copy(pr.numberGridOptions);
    pr.TransPlanninggridOptions = angular.copy(pr.numberGridOptions);
	pr.estimationsGridOptions = angular.copy(pr.numberGridOptions);

    pr.gridOptions.onRegisterApi = function (gridApi) {

    };
    pr.TransPlanninggridOptions.onRegisterApi = function (gridApi) {

    };
    //on RegisterApi calls
    pr.numberGridOptions.onRegisterApi = function (gridApi) {
        //set gridApi on scope
        pr.gridApi = gridApi;
        gridApi.selection.on.rowSelectionChangedBatch(null, function (row) {
           
	     pr.isSuccess = false;
            pr.isFailed = false;
            var booleanValues = [];
            _.each(row, function (value, key) {
                booleanValues.push(value.isSelected);
		pr.selectedRowValues.push({ 'number': value.entity.prewaveNumbers, 'isSelected': value.isSelected });

            });

            if (booleanValues.indexOf(true) >= 0) {
                pr.searchDisable = false;
            } else {
                pr.searchDisable = true;
            }
        });
        gridApi.selection.on.rowSelectionChanged(null, function (row) {
            var booleanValues = [];
		 
            var number = _.find(pr.selectedRowValues, function (obj) {
                return obj.number == row.entity.prewaveNumbers;
            });
            if (!number) {
                pr.selectedRowValues.push({ 'number': row.entity.prewaveNumbers, 'isSelected': row.isSelected });
            } else {
                _.each(pr.selectedRowValues, function (value, key) {
                    if (value.number == row.entity.prewaveNumbers) {
                        pr.selectedRowValues[key].isSelected = row.isSelected;
                        pr.selectedRowValues = _.reject(pr.selectedRowValues, function (d) {
                            return d.isSelected == false;
                        });
                    }
                });
            }
            _.each(pr.selectedRowValues, function (value, key) {
                booleanValues.push(value.isSelected);
            });
            if (booleanValues.indexOf(true) >= 0) {
                pr.searchDisable = false;
            } else {
                pr.searchDisable = true;
            }
            // pr.prewaveNmuber = '';
            pr.isSuccess = false;
            pr.isFailed = false;
        });
    };

    //searching thorugh selection and input text
    pr.getDimensionData = function (modelValue) {
        if (modelValue == 'valueChanged') {
            pr.searchDisable = pr.selectedRowValues.length ? false : true;
            //pr.gridApi.selection.clearSelectedRows();
        } else {
            //pr.prewaveReportdata(pr.prewaveNmuber ? pr.prewaveNmuber :pr.selectedRowValues); 
            var searchedValues = [];
            _.each(pr.selectedRowValues, function (val, key) {
                searchedValues.push(val.number); 
            });
             $scope.searchedValues = searchedValues;
            pr.prewaveClearCache(searchedValues);
           
        }
    };
    //function to seperate the keys and values from json as Object.values is not supproted in IE
    function convertJsontoArray(values){
        var keyValues = {
            'keys' : [],
            'values' : []
        };
        if(values.length){
            _.each(values, function (val, key) {
                _.each(val, function (val, key) { 
                        keyValues.keys.push(key);
                        keyValues.values.push(val); 
                });
            });
        }else{
            _.each(values, function (val, key) {  
                        keyValues.keys.push(key);
                        keyValues.values.push(val); 
            });
        }
        
        return  keyValues;
    }
    pr.fillEstimations = function(){
        
            if(pr.estimatedTabData){
                $("#showloader").css("display", "none");
                pr.estimationsGridInstSpecKeys = convertJsontoArray(pr.tableData).keys;
                pr.estimationsGridInstSpecValues = convertJsontoArray(pr.tableData).values;
                pr.showInstallationSpecificDiv = false;
                pr.estimationsGridInstSpecKeys[pr.estimationsGridInstSpecKeys.indexOf('locnsNeededVal')] = "Locns Needed";
                pr.estimationsGridInstSpecKeys[pr.estimationsGridInstSpecKeys.indexOf('missingDimsVal')] = "Missing Dim";
                pr.estimationsGridInstSpecKeys[pr.estimationsGridInstSpecKeys.indexOf('missingInventoryVal')] = "Missing Inv";
                _.each(pr.estimationsGridInstSpecValues, function (val, key) {
                    if(pr.estimationsGridInstSpecKeys[key] == 'missingInventory' && typeof pr.estimationsGridInstSpecValues[key] == "object"){
                        pr.estimationsGridInstSpecKeys.splice(key,1);
                        var objVal = pr.estimationsGridInstSpecValues[key];
                        pr.estimationsGridInstSpecValues.splice(key,1);
                      _.each(objVal,function(value,keys){
                          pr.estimationsGridInstSpecKeys.push(keys);
                          pr.estimationsGridInstSpecValues.push(value);
                      });
                  }
                  
                    if (val && val > 0) {
                        pr.showInstallationSpecificDiv = true;
                    }    
                }); 

                _.each(pr.estimationsGridInstSpecKeys,function(val,key){
                    pr.installSpecificDatakeys.push(val);
                });
                _.each(pr.estimationsGridInstSpecValues,function(val,key){
                    val  = val == null?'0.0':val;
                    pr.installSpecificDataValues.push(val);
                });
                pr.estimationDataBtn = true;
            }else{
                $("#showloader").css("display", "none");
            }
        
    };
    pr.fnResetData =function(){
        pr.estimation = {};
        pr.isMianpage = false;
        pr.searchshow = false;
        pr.searchDisable = false;
        pr.baseInfoData=''; 
        pr.estimationsGridOptions.data="";
        pr.estimationsGridOptions.columnDefs = [];
        pr.estimatedTabData = '';
        pr.estimatedTabGridData  = '';
        pr.estimationDataBtn=false;
    };
    //function to retrieve Estimation tab data when clicked on button
    pr.getEstimationsData = function(){
        pr.isTable = true;
        $("#showloader").css("display", "block");
        if(pr.estimation.length > 0){
            pr.estimationsGridOptions.columnDefs = [
                
                     { name: "codeInfo", displayName: "Code Info", enableCellEdit: false,width: 140 },
                     { name: "int1Cases", displayName: "INT 1 Cases", enableCellEdit: false,width: 140 },
                    { name: "int1Units", displayName: "INT 1 Units", enableCellEdit: false,width: 140 },
                     { name: "int2Cases", displayName: "INT 2 Cases", enableCellEdit: false,width: 140 },
                     { name: "int2Units", displayName: "INT 2 Units", enableCellEdit: false,width: 140 },
                     { name: "int150Cases", displayName: "INT 50 Units", enableCellEdit: false,width: 140 },
                     { name: "int150Units", displayName: "INT 150 Units", enableCellEdit: false,width: 130 },
                     { name: "vasInt2Cases", displayName: "VAS Full", enableCellEdit: false,width: 130 },
                     { name: "vasInt2Units", displayName: "VAS Full Units", enableCellEdit: false,width: 130 }
          
                 ];
                 pr.estimationsGridOptions.data = pr.estimation;
                 $("#showloader").css("display", "none");
        }else{
            var res = $http.post(urlService.GET_ESTIMATIONS, { "dcName": $scope.dcName, "prewaveNumbers": $scope.searchedValues },
            {
                headers: {'x-api-key': sessionStorage.apikey},
    
            });
          res.success(function (data, status, headers, config) {
            pr.searchDisable = true;
            pr.estimationDataBtn = true;
            pr.searchshow = true;
            if (data.errorMessage) {
                pr.isTable = false;
                pr.isFailed = true;
                pr.resmessage = data.errorMessage;
                $("#showloader").css("display", "none");
            } else if (data.resMessage) {
                pr.isTable = false;
                pr.isSuccess = true;
                pr.resmessage = data.resMessage;
                $("#showloader").css("display", "none");
            } else {  
                pr.tableData = [];
                pr.gridData = {};
              
                pr.estimationsGridOptions.columnDefs = [
               
                  { name: "codeInfo", displayName: "Code Info", enableCellEdit: false,width: 140 },
                    { name: "int1Cases", displayName: "INT 1 Cases", enableCellEdit: false,width: 140 },
                   { name: "int1Units", displayName: "INT 1 Units", enableCellEdit: false,width: 140 },
                    { name: "int2Cases", displayName: "INT 2 Cases", enableCellEdit: false,width: 140 },
                    { name: "int2Units", displayName: "INT 2 Units", enableCellEdit: false,width: 140 },
                    { name: "int150Cases", displayName: "INT 50 Units", enableCellEdit: false,width: 140 },
                    { name: "int150Units", displayName: "INT 150 Units", enableCellEdit: false,width: 130 },
                    { name: "vasInt2Cases", displayName: "VAS Full", enableCellEdit: false,width: 130 },
                    { name: "vasInt2Units", displayName: "VAS Full Units", enableCellEdit: false,width: 130 }
         
                ];
                pr.estimationsGridOptions.data = data;
                pr.estimation = data;
                pr.estimationDataBtn = true;
               $("#showloader").css("display", "none");
            }
        });
        }
        
            
    };
    //function to get the data for grid on load and while navigating from tab to tab
    pr.prewaveReportdata = function (tabnumber, searchedValues) {

   

        if(pr.estimation.length > 0){
            pr.estimationDataBtn = true;
        }else{
            pr.estimationDataBtn = false;
        }
        pr.isSuccess = false;
        pr.isTable = false;
        pr.isFailed = false;
        pr.isEdit = true;
        pr.isDelete = true;
        pr.isMianpage = true;
        pr.isEditdataSources = false;

        $("#showloader").css("display", "block");

        //var url = urlService.ATE_SLOTTING_SJ.replace('dName', $scope.pagedc);
        //url = url.replace('uName', sessionStorage.userName);
        if(pr.baseInfoData && (tabnumber == '0' || !tabnumber)){
           
            pr.isTable = true;
            var data = pr.baseInfoData;
            pr.basegridDatakeys = convertJsontoArray(data.basegridData).keys;
            pr.basegridDataValues = convertJsontoArray(data.basegridData).values;
            pr.installSpecificDatakeys = convertJsontoArray(data.installSpecificData).keys;
            pr.installSpecificDataValues = convertJsontoArray(data.installSpecificData).values;
            pr.prodTypeKeys = convertJsontoArray(data.prodTypeData).keys; 
            pr.prodTypeValues =convertJsontoArray(data.prodTypeData).values; 
           
            if(!tabnumber){
                
                pr.getEstimationsData();
            }else{
                pr.fillEstimations();
            }
            
            
            
          
        }else{
        
        var url = '';
        if (tabnumber == '0') {
            url = urlService.GET_BASE_INFO_DETAILS;
        } else if (tabnumber == '1') {
            url = urlService.GET_REPLEN_DETAILS;
        } else if (tabnumber == '2') {
            url = urlService.GET_DIM_ISSUES_DETAILS;
        } else if (tabnumber == '3') {
            url = urlService.GET_TRANSPLAN_DETAILS;
        } else if (tabnumber == '4') {
            url = urlService.GET_WAVE_PLAN_DETAILS;
        } else if (tabnumber == '5') {
            url = urlService.GET_MISSING_INV_DETAILS;
        } else if (tabnumber == '6') {
            url = urlService.NO_PERM_PROFILE_DETAILS;
        }else if (tabnumber == '9') {
            url = urlService.GET_MANIFEST_DATA;
        }  

        var res = $http.post(url, { "dcName": $scope.dcName, "prewaveNumbers": searchedValues ? searchedValues : $scope.searchedValues },
            {
                headers: {'x-api-key': sessionStorage.apikey},

            });
        res.success(function (data, status, headers, config) {
              if(pr.estimation.length > 0){
            pr.estimationDataBtn = true;
        }else{
            pr.estimationDataBtn = false;
        }
            pr.searchDisable = true;
            pr.searchshow = true;
 		if(pr.pagedc  == "CDC"){
                pr.estimationDataBtn =  true;
            }
            if (data.errorMessage) {
                pr.isTable = false;
                if(data.errorMessage == "This tab-information is not applicable to the DC selected" && tabnumber == '3'){pr.transPlanning = true;}
                pr.isFailed = true;
                pr.resmessage = data.errorMessage;
                $("#showloader").css("display", "none");
            } else if (data.resMessage) {
                pr.isTable = false;
                pr.isSuccess = true;
                pr.resmessage = data.resMessage;
                $("#showloader").css("display", "none");
            } else {

                pr.isTable = true;
                
                if (tabnumber == '0') {
                    
                    pr.baseInfoData = data;
                    pr.basegridDatakeys = convertJsontoArray(data.basegridData).keys;
                    pr.basegridDataValues = convertJsontoArray(data.basegridData).values;
                    pr.installSpecificDatakeys = convertJsontoArray(data.installSpecificData).keys;
                    pr.installSpecificDataValues = convertJsontoArray(data.installSpecificData).values;
                    pr.prodTypeKeys = convertJsontoArray(data.prodTypeData).keys; 
                    pr.prodTypeValues =convertJsontoArray(data.prodTypeData).values; 
                    $("#showloader").css("display", "none");
                   
                } else if (tabnumber == '1') {

                } else if (tabnumber == '2') {
                    pr.gridOptions.columnDefs = [
                        { name: "pick_wave_nbr", displayName: "Pick Wave Number", enableCellEdit: false, width: 180 },
                        { name: "pickticket", displayName: "Pick Ticket", enableCellEdit: false, width: 180 },
                        { name: "dsp_sku", displayName: "DSP SKU", enableCellEdit: false, width: 180 },
                        { name: "season", displayName: "Season", enableCellEdit: false, width: 180 },
                        { name: "style", displayName: "Style", enableCellEdit: false, width: 180 },
                        { name: "style_sfx", displayName: "Style Sfx", enableCellEdit: false, width: 180 },
                        { name: "color", displayName: "Color", enableCellEdit: false, width: 180 },
                        { name: "color_sfx", displayName: "Color Sfx", enableCellEdit: false, width: 180 },
                        { name: "size_desc", displayName: "Size Description", enableCellEdit: false, width: 180 },
                        { name: "oper_code", displayName: "Oper Code", enableCellEdit: false, width: 180 },
                        { name: "sku_brcd", displayName: "SKU Barcode", enableCellEdit: false, width: 180 },
                        { name: "unit_ht", displayName: "Unit Height", enableCellEdit: false, width: 180 },
                        { name: "unit_len", displayName: "Unit Length", enableCellEdit: false, width: 180 },
                        { name: "unit_width", displayName: "Unit Width", enableCellEdit: false, width: 180 },
                        { name: "unit_wt", displayName: "Unit Weight", enableCellEdit: false, width: 180 },
                        { name: "unit_vol", displayName: "Unit Volume", enableCellEdit: false, width: 180 },
                        { name: "std_case_ht", displayName: "Std Case Height", enableCellEdit: false, width: 180 },
                        { name: "std_case_len", displayName: "Std Case length", enableCellEdit: false, width: 180 },
                        { name: "std_case_width", displayName: "Std Case Width", enableCellEdit: false, width: 180 },
                        { name: "std_case_vol", displayName: "Std Case Volume", enableCellEdit: false, width: 180 },
                        { name: "std_case_wt", displayName: "Std Case Weight", enableCellEdit: false, width: 180 },
                        { name: "std_case_qty", displayName: "Std Case Quantity", enableCellEdit: false, width: 180 },
                        { name: "std_plt_qty", displayName: "Std Plt Quantity ", enableCellEdit: false, width: 180 }
                    ];
                    pr.isTable = true;
                    pr.gridOptions.data = data;

                    $("#showloader").css("display", "none");
                } else if (tabnumber == '3') {
                    // pr.estCartonModeData = Object.values(data.estCartonModeData[0]);
                    // pr.estCartonModekeys = Object.keys(data.estCartonModeData[0]);
                    // pr.estCartonShipviaData = Object.values(data.estCartonShipviaData[0]);
                    // pr.estCartonShipviakeys = Object.keys(data.estCartonShipviaData[0]);
                    // var  estCubingData = data.estCubingData;
                    pr.gridOptions.columnDefs = [
                        { name: "shipToCntry", displayName: "Ship to Country", enableCellEdit: false },
                        { name: "estShipVia", displayName: "Estimated Ship Via", enableCellEdit: false },
                        { name: "billShipVia", displayName: "Bill Ship Via", enableCellEdit: false },
                        { name: "estCartons", displayName: "Estimated Cartons", enableCellEdit: false },
                        { name: "estVol", displayName: "Estimated Volume", enableCellEdit: false },
                        { name: "estWt", displayName: "Estimated Weight", enableCellEdit: false },
                    ];
                    pr.TransPlanninggridOptions.columnDefs = [
                        { name: "estCartons", displayName: "Estimated Cartons", enableCellEdit: false },
                        { name: "estVol", displayName: "Estimated Volume", enableCellEdit: false },
                        { name: "estWt", displayName: "Estimated Weight", enableCellEdit: false },
                        { name: "mode", displayName: "Mode", enableCellEdit: false }
                    ];
                    pr.isTable = true;
                    pr.gridOptions.data = data.estCartonShipviaData;
                    pr.TransPlanninggridOptions.data = data.estCartonModeData;

                    $("#showloader").css("display", "none");

                }
                else if (tabnumber == '4') {
                    var estCubingData = data.estCubingData;
                    pr.gridOptions.columnDefs = [
                        { name: "pickTicket", displayName: "Pick Ticket", enableCellEdit: false },
                        { name: "estCartons", displayName: "Estimated Cartons", enableCellEdit: false },
                        { name: "estRepacks", displayName: "Estimated Repacks", enableCellEdit: false },
                        { name: "estShipVia", displayName: "Estimated Ship Via", enableCellEdit: false },
                        { name: "estVol", displayName: "Estimated Volume", enableCellEdit: false },
                        { name: "estWt", displayName: "Estimated Weight", enableCellEdit: false }

                    ];
                    pr.isTable = true;
                    pr.gridOptions.data = estCubingData;


                    pr.cusSuppliedLabelKeys = convertJsontoArray(data.cusSuppliedLabelData).keys; 
                    pr.cusSuppliedLabelData = convertJsontoArray(data.cusSuppliedLabelData).values; 
                    pr.specVASWorkStationKeys = convertJsontoArray(data.specVASWorkStationData).keys;
                    pr.specVASWorkStationData = convertJsontoArray(data.specVASWorkStationData).values;
                    pr.repacksCartonKeys = convertJsontoArray(data.repacksCartonData).keys;
                    pr.repacksCartonData = convertJsontoArray(data.repacksCartonData).values;
                    pr.fullCasesKeys = convertJsontoArray(data.fullCasesData).keys;
                    pr.fullCasesData = convertJsontoArray(data.fullCasesData).values;
                    pr.vasOutboundPrepKeys = convertJsontoArray(data.vasOutboundPrepData).keys;
                    pr.vasOutboundPrepData = convertJsontoArray(data.vasOutboundPrepData).values;
                    pr.looseUnitsByAreaKeys = convertJsontoArray(data.looseUnitsByArea).keys;
                    pr.looseUnitsByArea = convertJsontoArray(data.looseUnitsByArea).values;

                    if (pr.gridOptions.data > 10) {
                        pr.gridOptions.enableVerticalScrollbar = true;
                        pr.gridOptions.enableHorizontalScrollbar = 1;
                    } else {
                        pr.gridOptions.enableVerticalScrollbar = false;
                        pr.gridOptions.enableHorizontalScrollbar = 1;
                    }
                    $("#showloader").css("display", "none");
                } else if (tabnumber == '6') {
                    pr.gridOptions.columnDefs = [
                        { name: "ship_wave_nbr", displayName: "Pick Wave Number", enableCellEdit: false, width: 180 },
                        { name: "pkt_ctrl_nbr", displayName: "Pick Ticket", enableCellEdit: false, width: 180 },
                        { name: "dsp_sku", displayName: "Dsp SKU", enableCellEdit: false, width: 180 },
                        { name: "season", displayName: "Season", enableCellEdit: false, width: 180 },
                        { name: "style", displayName: "Style", enableCellEdit: false, width: 180 },
                        { name: "style_sfx", displayName: "Style Sfx", enableCellEdit: false, width: 180 },
                        { name: "color", displayName: "Color", enableCellEdit: false, width: 180 },
                        { name: "color_sfx", displayName: "Color Sfx", enableCellEdit: false, width: 180 },
                        { name: "size_desc", displayName: "Size Description", enableCellEdit: false, width: 180 },
                        { name: "sku_brcd", displayName: "SKU Barcode", enableCellEdit: false, width: 180 },
                        { name: "slot_misc_4", displayName: "Slot Misc 4", enableCellEdit: false, width: 180 },
                        { name: "prod_type", displayName: "Product Type", enableCellEdit: false, width: 180 },
                        { name: "prod_group", displayName: "Product Group", enableCellEdit: false, width: 180 },
                        { name: "std_case_qty", displayName: "Std Case Quantity", enableCellEdit: false, width: 180 },
                        { name: "carton_type", displayName: "Carton Type", enableCellEdit: false, width: 180 }
                    ];
                    pr.isTable = true;
                    pr.gridOptions.data = data;

                    $("#showloader").css("display", "none");
                } else if (tabnumber == '5') {
                    pr.gridOptions.columnDefs = [
                        { name: "pick_wave_nbr", displayName: "Pick Wave Number", enableCellEdit: false },
                        { name: "pkt_ctrl_nbr", displayName: "Pick Ticket", enableCellEdit: false },
                        { name: "dsp_sku", displayName: "Dsp Sku", enableCellEdit: false },
                        { name: "season", displayName: "Season", enableCellEdit: false },
                        { name: "style", displayName: "Style", enableCellEdit: false },
                        { name: "style_sfx", displayName: "Style Sfx", enableCellEdit: false },
                        { name: "color", displayName: "Color", enableCellEdit: false },
                        { name: "color_sfx", displayName: "Color Sfx", enableCellEdit: false },
                        { name: "size_desc", displayName: "Size Description", enableCellEdit: false },
                        { name: "code_desc", displayName: "Code Description", enableCellEdit: false },
                        { name: "qty", displayName: "Quantity", enableCellEdit: false }
                    ];
                    pr.isTable = true;
                    pr.downloadfile = true;
                    pr.gridOptions.data = data;
		$("#showloader").css("display", "none");
                }else if (tabnumber == '9') {
                    pr.gridOptions.columnDefs = [
                        { name: "pickWaveNbr", displayName: "Wave", enableCellEdit: false,width: 150 },
                        { name: "pktCntrlNbr", displayName: "Pickticket", enableCellEdit: false ,width: 150},
                        { name: "noShipTo", displayName: "No Ship To", enableCellEdit: false,width: 150 },
                        { name: "shipToCity", displayName: "No City", enableCellEdit: false,width: 150 },
                        { name: "shipToState", displayName: "No State", enableCellEdit: false,width: 150 },
                        { name: "shipToCntry", displayName: "No Country", enableCellEdit: false,width: 150 },
                        { name: "shipVia", displayName: "No Ship Via", enableCellEdit: false,width: 150 },
                        { name: "noTel", displayName: "No Telephone", enableCellEdit: false ,width: 150},
                        { name: "noShipToContact", displayName: "No Contact", enableCellEdit: false,width: 150 },
                        { name: "commitDate", displayName: "No Commit Date", enableCellEdit: false,width: 150 },
                        { name: "collectAcctNbr", displayName: "No Act Nbr", enableCellEdit: false,width: 150 },
						{ name: "shipZip", displayName: "No Zip", enableCellEdit: false ,width: 150}
                    ];
                    pr.isTable = true;
                    pr.gridOptions.data = data;
					$("#showloader").css("display", "none");
                }

            }

            if(pr.pagedc == "US1" || pr.pagedc == "US2" || pr.pagedc == "Brazil" || pr.pagedc == "Chile" || pr.pagedc == "Panama" || pr.pagedc == "Mexico" || pr.pagedc == "Montreal" ){
                pr.wavePlanning = true;
                pr.transPlanning = true;

                pr.iswavePlanning = false;
                pr.istransPlanning = false;

                $("#wavePlanning").attr("title", "This information is not applicable to your DC");
                $("#transPlanning").attr("title", "This information is not applicable to your DC");
            }

            if(pr.pagedc == "Suzhou" || pr.pagedc == "Tianjin"){
                pr.wavePlanning = true;
                pr.transPlanning = true;
                pr.maniFest = true;

                pr.iswavePlanning = false;
                pr.istransPlanning = false;
                pr.ismaniFest = false;

                $("#wavePlanning").attr("title", "This information is not applicable to your DC");
                $("#transPlanning").attr("title", "This information is not applicable to your DC");
		$("#maniFest").attr("title", "This information is not applicable to your DC");
            }
	if(pr.pagedc == "Scheinfeld-2"){
                pr.wavePlanning = true;
                pr.transPlanning = true;
                pr.maniFest = true;
		pr.nopermProfile = true;
		pr.replenishment = true;

                pr.iswavePlanning = false;
                pr.istransPlanning = false;
                pr.ismaniFest = false;
		pr.isnopermProfile = false;
		pr.isreplenishment = false;

                $("#wavePlanning").attr("title", "This information is not applicable to your DC");
                $("#transPlanning").attr("title", "This information is not applicable to your DC");
		$("#maniFest").attr("title", "This information is not applicable to your DC");
		$("#nopermProfile").attr("title", "This information is not applicable to your DC");
		$("#replenishment").attr("title", "This information is not applicable to your DC");

            }

             if(pr.pagedc == "CDC"){
              
                pr.maniFest = true;
		pr.nopermProfile = true;
		pr.replenishment = true;
                pr.estimationsInfo = true;
             
                pr.ismaniFest = false;
		pr.isnopermProfile = false;
		pr.isreplenishment = false;
                pr.isestimationsInfo = false;

                $("#estimationsInfo").attr("title", "This information is not applicable to your DC");
		$("#maniFest").attr("title", "This information is not applicable to your DC");
		$("#nopermProfile").attr("title", "This information is not applicable to your DC");
		$("#replenishment").attr("title", "This information is not applicable to your DC");

            }



            $('.ui-grid-pager-control input').prop("disabled", true);
        });
        res.error(function (data, status, headers, config) {
            pr.searchDisable = true;
            pr.searchshow = true;
 		if(pr.pagedc  == "CDC"){
            pr.estimationDataBtn =  true;
        }
            $("#showloader").css("display", "none");
            pr.isFailed = true;
            pr.resmessage = "System failed. Please try again or contact WAALOS Support";

        });
    }
    };
    pr.esttab = function(){
     
        pr.isSuccess=false;
        pr.isFailed=false;
        if(pr.estimation.length > 0){
            pr.isTable = true;
        }else{
            pr.isTable = false;
        }
     
        if(pr.pagedc  == "CDC"){
            pr.estimationDataBtn =  true;
	     pr.cdcTab = true;
        }else{
            if(pr.estimation.length > 0){
                pr.estimationDataBtn = true;
            }else{
                pr.estimationDataBtn = false;
            }
           
		pr.cdcTab = false;
        }
    };

    pr.prewaveClearCache = function(searchedValues){
        pr.isSuccess=false;
        pr.isFailed=false;
        $("#showloader").css("display", "block");

        var url = urlService.GET_PREWAVE_CLEAR_CACHE;
        
        var res = $http.get(url, {
            headers: {'x-api-key': sessionStorage.apikey}
        });
        res.success(function (data, status, headers, config) {
            $("#showloader").css("display", "none");
            if (data.errorMessage) {
                pr.prewaveReportdata('0', searchedValues);
            } else if (data.resMessage) {
                pr.prewaveReportdata('0', searchedValues);
            }

        });
        res.error(function (data, status, headers, config) {
            pr.prewaveReportdata('0', searchedValues);
        });
    };
    // function to get the number which need to be selected and pass in search 
    pr.getPrewaveNumbers = function () {
        pr.isMianpage = false;
        $("#showloader").css("display", "block");
        pr.numberGridOptions.data = [];
        pr.numberGridOptions.columnDefs = [];
        var url = urlService.GET_PREWAVE_NUMBERS.replace('dName', $scope.dcName);
        url = url.replace('uName', sessionStorage.userName);
        var res = $http.get(url, {
            headers: {'x-api-key': sessionStorage.apikey}
        });
        res.success(function (data, status, headers, config) {
            delete data.dcName;

            if (data.errorMessage) {

                pr.numberGridOptionssuccess = false;
                pr.numberGridOptionserror = true;
                pr.resmessage = data.errorMessage;
                $("#showloader").css("display", "none");
            } else if (data.resMessage) {
                pr.numberGridOptionssuccess = true;
                pr.numberGridOptionserror = false;
                pr.resmessage = data.resMessage;
                $("#showloader").css("display", "none");
            } else {
                var prewaveNumbers = [];
                _.each(data.prewaveNumbers, function (val, key) {
                    prewaveNumbers.push({ "prewaveNumbers": val });
                });
                //regular expression to provide spaces at camel case notation and capitalize first letter in the word
                pr.numberGridOptions.columnDefs.push({ name: 'prewaveNumbers', displayName: "Prewave Numbers", enableCellEdit: false });
                pr.isTable = true;

                pr.numberGridOptions.data = prewaveNumbers;
                $("#showloader").css("display", "none");
                if (prewaveNumbers > 10) {
                    pr.numberGridOptions.enableVerticalScrollbar = true;
                    pr.numberGridOptions.enableHorizontalScrollbar = 1;
                } else {
                    pr.numberGridOptions.enableVerticalScrollbar = false;
                    pr.numberGridOptions.enableHorizontalScrollbar = 1;
                }
               
            }

        });
        res.error(function (data, status, headers, config) {
            pr.numberGridOptionssuccess = false;
            pr.numberGridOptionserror = true;
            pr.resmessage = "System failed. Please try again or contact WAALOS Support";
            $("#showloader").css("display", "none");
            $scope.numberGridOptions.enableGridMenu = false;
        });
    };

    pr.addToFavourate = function (isClicked) {
        $("#showloader").css("display", "block");
        if (typeof isClicked !== "boolean") {
            commonService.postServiceResponse(urlService.GET_FAVOURITES, { "username": sessionStorage.userName })
                .then(function (response) {
                    $("#showloader").css("display", "none");
                    _.each(response, function (val, key) {
                        if (val.funName == $scope.functionality && val.dcName == $scope.dcName) {
                            pr.isClicked = true;
                        }
                    });
                }, function (error) {
                    $("#showloader").css("display", "none");
                });
            //pr.isClicked = ;
        } else {
            if (!pr.isClicked) {
                commonService.postServiceResponse(urlService.ADD_FAVOURITE, { "username": sessionStorage.userName, "dcName": $scope.dcName, "funName": $scope.functionality })
                    .then(function (response) {
                        $("#showloader").css("display", "none");
                        if (response.errorMessage) {
                            pr.isClicked = isClicked;
                            pr.isFavouriteAdded = false;
                            $scope.$broadcast('showAlert', ['']);
                        } else {
                            pr.isClicked = !isClicked;
                            pr.isFavouriteAdded = true;
                            pr.favouriteMsg = response.resMessage;
                            $scope.$broadcast('ClickedOnFavourate', [pr.dcName, $scope.functionality, pr.isClicked]);
                        }

                    }, function (error) {
                        $("#showloader").css("display", "none");
                    });
                pr.isClicked = !isClicked;
            } else {
                $("#showloader").css("display", "none");
            }
        }

    };

    pr.addToFavourate('load');
    pr.getPrewaveNumbers();





    $scope.downloadExcel = function(jcode) {
        $scope.isFailed = false;
        $("#showloader").css("display", "block");
        var url;
        url = urlService.GET_PREWAVE_DOWNLOAD_NOPREM;
        var griddata;
	var datatosend = [{}];
    if(jcode == 'ET'){
        griddata = pr.estimationsGridOptions.data;
    }
else if(jcode == 'TP'){
griddata = [{}];
	datatosend = [{
estCartonModeData : pr.TransPlanninggridOptions.data,
estCartonShipviaData : pr.gridOptions.data
}]

        
    }else{
        griddata = pr.gridOptions.data;
    }
    
    $http({
            method: 'POST',
            url: url,
            data: {"jobcode":jcode,"getGenericDto":griddata,"getPWTransDto":datatosend},
            headers: {				
                'Content-type': 'application/json', 'x-api-key': sessionStorage.apikey
            },
            responseType: 'arraybuffer'
        
        })
    .success( function(data, status, headers) {
    
    $("#showloader").css("display", "none");
   
        if(data.byteLength == 55){
           $scope.isFailed = true;
           pr.isSuccess = true;
           pr.resmessage = "No Record(s) Found";
           return false;    
                  }else if(data.byteLength == 98){
            pr.isFailed = true;
            pr.resmessage = "Error in Downloading Excel file";
            return;
        }else{
            
            var octetStreamMime = 'application/octet-stream';
            var success = false;
    
            // Get the headers
            headers = headers();
            var filename;
            var blob;
            // Get the filename from the x-filename header or default to "download.bin"
              if(jcode == 'NPP'){
             filename = headers['x-filename'] || 'NoPermProfileData.xlsx';
            }else if(jcode == 'MI'){
                 filename = headers['x-filename'] || 'MissingInvData.xlsx';
            }else if(jcode == 'ET'){
                 filename = headers['x-filename'] || 'EstimationsData.xlsx'; 
            }else if(jcode == 'DI'){
                 filename = headers['x-filename'] || 'DimensionIssuesData.xlsx';
            }else if(jcode == 'MF'){
                 filename = headers['x-filename'] || 'ManiFestData.xlsx';
            }else if(jcode == 'TP'){
                 filename = headers['x-filename'] || 'TransPlanning.xlsx';
            }

    
            // Determine the content type from the header or default to "application/octet-stream"
            var contentType = headers['content-type'] || octetStreamMime;
    
            try
            {
                // Try using msSaveBlob if supported
                console.log("Trying saveBlob method ...");
                 blob = new Blob([data], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
                if(navigator.msSaveBlob)
                    navigator.msSaveBlob(blob, filename);
                else {
                    // Try using other saveBlob implementations, if available
                    var saveBlob = navigator.webkitSaveBlob || navigator.mozSaveBlob || navigator.saveBlob;
                    if(saveBlob === undefined) throw "Not supported";
                    saveBlob(blob, filename);
                }
                console.log("saveBlob succeeded");
                success = true;
            } catch(ex)
            {
                console.log("saveBlob method failed with the following exception:");
                console.log(ex);
            }
    
            if(!success)
            {
                // Get the blob url creator
                var urlCreator = window.URL || window.webkitURL || window.mozURL || window.msURL;
                if(urlCreator)
                {
                    // Try to use a download link
                    var link = document.createElement('a');
                    if('download' in link)
                    {
                        // Try to simulate a click
                        try
                        {
                            // Prepare a blob URL
                            console.log("Trying download link method with simulated click ...");
                             blob = new Blob([data], { type: contentType });
                             url = urlCreator.createObjectURL(blob);
                            link.setAttribute('href', url);
    
                            // Set the download attribute (Supported in Chrome 14+ / Firefox 20+)
                            link.setAttribute("download", filename);
    
                            // Simulate clicking the download link
                            var event = document.createEvent('MouseEvents');
                            event.initMouseEvent('click', true, true, window, 1, 0, 0, 0, 0, false, false, false, false, 0, null);
                            link.dispatchEvent(event);
                            console.log("Download link method with simulated click succeeded");
                            success = true;
    
                        } catch(ex) {
                            console.log("Download link method with simulated click failed with the following exception:");
                            console.log(ex);
                        }
                    }
    
                    if(!success)
                    {
                        // Fallback to window.location method
                        try
                        {
                            // Prepare a blob URL
                            // Use application/octet-stream when using window.location to force download
                            console.log("Trying download link method with window.location ...");
                             blob = new Blob([data], { type: octetStreamMime });
                             url = urlCreator.createObjectURL(blob);
                            window.location = url;
                            console.log("Download link method with window.location succeeded");
                            success = true;
                        } catch(ex) {
                            console.log("Download link method with window.location failed with the following exception:");
                            console.log(ex);
                        }
                    }
    
                }
            }
    
            if(!success)
            {
                // Fallback to window.open method
                console.log("No methods worked for saving the arraybuffer, using last resort window.open");
                window.open(rowData.pathName, '_blank', '');
            }
        }
    })
    .error(function(data, status, config) {
    
        console.log("Request failed with status: " + status);
    $("#showloader").css("display", "none");
        // Optionally write the error out to scope
        //$scope.errorDetails = "Request failed with status: " + status;
    pr.isFailed = true;
            pr.resmessage = "Error in downloading Excel File";
    
    });
    };
    

}]);