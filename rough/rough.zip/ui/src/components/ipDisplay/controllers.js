var app = angular.module('IPDisplay', ['ngAnimate', 'ui.grid', 'ui.grid.selection',  'ui.grid.pagination', 'ui.grid.edit']);
app.controller('IPDisplayMainCtrl', ['$scope', '$http', '$q', '$interval', 'uiGridValidateService', '$timeout','urlService','commonService', function ($scope, $http, $q, $interval, uiGridValidateService, $timeout,urlService,commonService) {

  $scope.isTable = false;
  $scope.disable = true;
  $scope.isupdate = true;
  $scope.isSuccess = false;
  $scope.isFailed = false;
  $scope.isClicked = false;
  $scope.isFailedload = false;
  $scope.isFieldValidate = false; //show validation error message
  $scope.pagefunctionality = $scope.functionality;
  $scope.pagedc = $scope.dcName;
  $("#showloader").css("display", "none");

  $scope.gridOptions = {
    paginationPageSizes: [15, 25, 50, 100],
    paginationPageSize: 15,
    useExternalPagination: true,
    enableColumnMenus: false,
    enableSorting: true,
     };


  $scope.gridOptions.onRegisterApi = function (gridApi) {
    $scope.gridApi = gridApi;

    $scope.gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
      $scope.pageNo =  newPage;
      $scope.pageSize = pageSize;
      $scope.ipDisplay();
   });

    gridApi.selection.on.rowSelectionChangedBatch($scope, function (rows) {
      $scope.isSuccess = false;
      $scope.isFailed = false;
      if ($scope.gridApi.selection.getSelectedRows().length == 0) {
        $scope.isupdate = true;
      } else {
        $scope.isupdate = false;
        validateDataAndEnableUpdate();
      }
    });

    gridApi.selection.on.rowSelectionChanged($scope, function (row) {
      $scope.isSuccess = false;
      $scope.isFailed = false;
      if ($scope.gridApi.selection.getSelectedRows().length > 0) {
        $scope.isupdate = false;
        validateDataAndEnableUpdate();
      } else {
        $scope.isupdate = true;
        validateDataAndEnableUpdate();
      }
    });

    function validateDataAndEnableUpdate() {
      $timeout(function () {
        var found = $('.ui-grid-cell-contents');
        if (found.hasClass('invalid')) {
          $scope.$apply(function () {
            $scope.isFieldValidate = true;
            $scope.isupdate = true;
          });
        } else if ($scope.gridApi.selection.getSelectedRows().length === 0) {
          $scope.$apply(function () {
            $scope.isupdate = true;
          });
        } else {
          $scope.$apply(function () {
            $scope.isFieldValidate = false;
            $scope.isupdate = false;
          });
        }
      });
    }

    // Just disabling update button while entering data on row input control.
    gridApi.edit.on.beginCellEdit($scope, function (rowEntity, colDef) {
      $scope.isSuccess = false;
      $scope.isFailed = false;
      $scope.$apply(function () {
        $scope.isupdate = true;
      });
    });

    gridApi.edit.on.afterCellEdit($scope, function (rowEntity, colDef, newValue, oldValue) {
      //$scope.msg.lastCellEdited = 'edited row id:' + rowEntity.id + ' Column:' + colDef.name + ' newValue:' + newValue + ' oldValue:' + oldValue ;
      $scope.isSuccess = false;
      $scope.isFailed = false;
      $scope.isFailedload = false;

      if (newValue != oldValue || newValue !== oldValue) {// To check old and new values same or not
        if (newValue == "") {
          //alert(colDef.name+" should not be Empty");

          //rowEntity[colDef.name] = oldValue;
          //  return;
        } else if (+(newValue) == oldValue) {

        } else {
          $scope.gridApi.selection.selectRow(rowEntity);
        }
      }

      $timeout(function () {
        var found = $('.ui-grid-cell-contents');
        if (found.hasClass('invalid')) {
          $scope.$apply(function () {

            $scope.isFieldValidate = true;
            $scope.isupdate = true;
          });
        } else if (found.hasClass('ui-grid-cell-contents-hidden')) {
          $scope.isupdate = true;

        } else if (newValue != oldValue || newValue !== oldValue) {
          $scope.$apply(function () {
            $scope.isFieldValidate = false;
            $scope.isupdate = false;
          });
        } else if ($scope.gridApi.selection.getSelectedRows().length !== 0) {
          $scope.$apply(function () {
            $scope.isupdate = false;
            $scope.isFieldValidate = false;
          });
        }

      }, 100);

      $scope.$apply();
    });
  };

  uiGridValidateService.setValidator('numberChecker',
    function (argument) {
      return function (newValue, oldValue, rowEntity, colDef) {
        if (!newValue) {
          return /^[0-9]{1,20}$/.test(oldValue);
        } else {
          if (!(/^[0-9]{1,20}$/.test(oldValue))) {
            $scope.isupdate = true;
            $scope.$apply(function () {
              $scope.gridOptions.enableRowSelection = false;
            });
          } else {
            $scope.isupdate = false;
            $scope.gridOptions.enableRowSelection = true;
          }
          return /^[0-9]{1,20}$/.test(oldValue);
        }
      };
    },
    function (argument) {
      return 'Only numbers are allowed and minimum one digit maximum 10 digits can enter';
    }
  );

  $scope.ipDisplay = function () {

    $scope.resmessage = "";
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $scope.isFieldValidate = false;

    $("#showloader").css("display", "block");
    $scope.pageNo = $scope.pageNo ? $scope.pageNo : 1;
    $scope.pageSize = $scope.pageSize ? $scope.pageSize: $scope.gridOptions.paginationPageSize;
    var user = localStorage.userName;
    var dc = $scope.pagedc;
    
    /*var postDetails = {
      "dcName" : $scope.pagedc,
      "userName":sessionStorage.userName,
      "pageNumber": $scope.pageNo,
      "pageSize": $scope.pageSize
      
    };

  var res = $http.post(urlService.IP_GOAL_CHANGER, postDetails);*/

 var url = urlService.IP_GOAL_CHANGER.replace('dName',$scope.pagedc);
    url = url.replace('uName',sessionStorage.userName);
    url = url.replace('pNumber',$scope.pageNo);
    url = url.replace('pSize',$scope.pageSize);
 
  //var res = $http.get(url);
  var res = $http.get(url, {
    headers: {'x-api-key': sessionStorage.apikey}
});
    res.success(function (data, status, headers, config) {
      $("#showloader").css("display", "none");
      if (data.errorMessage) {
        $scope.isTable = false;
        $scope.isFailed = true;
        $scope.resmessage = data.errorMessage;
      }
      else if (data.resMessage) {
        $scope.isTable = false;
        $scope.isSuccess = true;
        $scope.resmessage = data.resMessage;
      }
      else if (data.length === 0) {
        $scope.isTable = false;
        $scope.isFailed = true;
        $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
      } else {
        $scope.isTable = true;
        $scope.gridOptions.columnDefs = [
          { field: 'goalId', displayName: 'Goal ID', enableCellEdit: false, },
          { name: 'goalAmount', displayName: 'Goal Amount', enableCellEdit: true,  validators: { required: true,  numberChecker: true }, cellTemplate: 'ui-grid/cellTitleValidator' }
        ];

        $scope.gridOptions.totalItems  = data.totalNoOfRecords;  
        $scope.gridOptions.data = data.pageItems;

        if ($scope.gridOptions.data > 10) {
          $scope.gridOptions.enableVerticalScrollbar = true;
        } else {
          $scope.gridOptions.enableVerticalScrollbar = false;
          $scope.gridOptions.enableHorizontalScrollbar = 0;
        }
        
      }
      $('.ui-grid-pager-control input').prop( "disabled", true );
    });
    res.error(function (data, status, headers, config) {
      $("#showloader").css("display", "none");
      $scope.isFailed = true;
      $scope.resmessage = "System failed. Please try again or contact WAALOS Support";

    });
  };

  $scope.ipDisplay();

  $scope.updateRecord = function () {
    $scope.resmessage = "";
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $scope.isFieldValidate = false;
    $("#showloader").css("display", "block");
    var postRecords = [];
    angular.forEach($scope.gridApi.selection.getSelectedRows(), function (data, index) {
      var records = {
        "goalId": data.goalId,
        "goalAmount": data.goalAmount,
        "dcName": $scope.dcName,
        "userName": sessionStorage.userName
      };
      postRecords.push(records);
    });

    //var res = $http.put(urlService.WMS_CNTRL_IP_GOAL_CHANGER, postRecords);
  var res = $http.put(urlService.WMS_CNTRL_IP_GOAL_CHANGER, postRecords, {
    headers: {'x-api-key': sessionStorage.apikey}
});

    res.success(function (data, status, headers, config) {
      $("#showloader").css("display", "none");
      if (data.errorMessage) {
        $scope.isFailed = true;
        $scope.resmessage = data.errorMessage;
        $scope.disable = true;
      } else {
        $scope.ipDisplay();
        $scope.isupdate = true;
        $scope.isSuccess = true;
        $scope.resmessage = data.resMessage;
      }
    });
    res.error(function (data, status, headers, config) {
      $("#showloader").css("display", "none");
      $scope.isFailed = true;
      $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
    });
  };

  //user favourites code starts
  $scope.addToFavourate = function(isClicked){
    $("#showloader").css("display", "block");
     if(typeof isClicked !== "boolean"){
      commonService.postServiceResponse(urlService.GET_FAVOURITES,{"username": sessionStorage.userName})
        .then(function(response){
          $("#showloader").css("display", "none");
            _.each(response,function(val,key){
              if(val.funName == $scope.functionality && val.dcName == $scope.dcName){
                $scope.isClicked = true;      
              }
            });
        },function(error){
          $("#showloader").css("display", "none");
          $scope.isClicked = false; 
        });
        //$scope.isClicked = ;
     }else{
      if(!$scope.isClicked){
        commonService.postServiceResponse(urlService.ADD_FAVOURITE,{"username": sessionStorage.userName,"dcName":$scope.dcName,"funName":$scope.functionality})
        .then(function(response){
          $("#showloader").css("display", "none");
          if(response.errorMessage){
            $scope.isFavouriteAdded= false; 
            $scope.isClicked = false;      
            $scope.$broadcast('showAlert',['']);
          }else{
            $scope.isClicked = true;      
            $scope.isClicked = !isClicked;
            $scope.isFavouriteAdded= true; 
            $scope.favouriteMsg = response.resMessage;
          $scope.$broadcast('ClickedOnFavourate',[$scope.dcName,$scope.functionality,$scope.isClicked]);
          }
            
        },function(error){
          $scope.isClicked = false;
          $("#showloader").css("display", "none");
        });
        $scope.isClicked = !isClicked;
      }else{
        $("#showloader").css("display", "none");
      }
     }
    
  };
  $scope.addToFavourate('load');
  //user favourites code ends
}]);
