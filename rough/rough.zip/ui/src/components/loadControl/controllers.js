var app = angular.module('LoadControl', [ 'ui.grid.pagination','ngAnimate', 'ui.grid', 'ui.grid.selection','ui.grid.resizeColumns', 'ui.bootstrap','ui.grid.autoResize','ui.grid.exporter' ]);
app.controller('LoadControlCtrl', ['$scope', '$http', '$q', '$interval', '$rootScope', 'uiGridValidateService', '$timeout','urlService','uiGridConstants','commonService', function ($scope, $http, $q, $interval, $rootScope, uiGridValidateService, $timeout,urlService,uiGridConstants,commonService) {

  $scope.isTable = false;
  $scope.isSuccess = false;
  $scope.isFailed = false;
  $scope.pagefunctionality = $scope.functionality;
  $scope.pagedc = $scope.dcName;
 
		/**	This function is used to get the printers based on the dc name	**/
   $scope.getdefaultPrinter = function(){
                                var url = urlService.DEFAULT_PRINTERS.replace("dName",$scope.pagedc);
                                url = url.replace('uName',sessionStorage.userName);
                                var res = $http.get(url, {
                                 // headers: {'x-api-key': sessionStorage.apikey} 
                                });

                                res.success(function (data, status, headers, config) {
                                  if (data.errorMessage) {
                                               // $scope.isFailed = true;
                                               // $scope.resmessage = data.errorMessage;
                                                $scope.getPrinterList();
                                                }else if(data.resMessage){
                                                 // $scope.isSuccess = true;
                                                 // $scope.resmessage = data.resMessage;
                                                  $scope.getPrinterList();
                                                }else{
                                                                $scope.defaultprinter = data;
                                                                $scope.printerip = data[0].printerIp;
                                                                $scope.getPrinterList();
                                                }
                                });
                                res.error(function (data, status, headers, config) {
                                  //$scope.isFailed = true;
                                  //$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
                                  $scope.getPrinterList();
                                });  
  };
    $scope.getdefaultPrinter();
  
  
  
    $scope.getPrinterList = function(){
      var url = urlService.PRINTER_LIST.replace("dName",$scope.pagedc);
      url = url.replace('uName',sessionStorage.userName);
      var res = $http.get(url, {
        //headers: {'x-api-key': sessionStorage.apikey} 
      });
  
      res.success(function (data, status, headers, config) {
        if (data.errorMessage) {
          $scope.isFailed = true;
          $scope.resmessage = data.errorMessage;
          }else if(data.resMessage){
            $scope.isSuccess = true;
            $scope.resmessage = data.resMessage;
          }else{
            $scope.printerslist = data;
            
            for (var i = 0; i < $scope.printerslist.length; i++) {
              if($scope.printerip){
                if ($scope.printerslist[i].printerIp == $scope.printerip) {
                  $scope.printer = $scope.printerslist[i];
                  break;
                }
              }else{
                $scope.printer = $scope.printerslist[0];
              }
            }        
          }
      });
      res.error(function (responce, status, headers, config) {
        $scope.isFailed = true;
        $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
      });  
    };
  

  //Main page Big grid
      $scope.gridOptionsBig = {
      paginationPageSizes: [15, 25, 50, 100, "All"],
      paginationPageSize: 100,
      useExternalPagination: true,
      enableColumnMenus: false,
      enableSorting: true,
    exporterMenuCsv: false,
    exporterMenuPdf: false,
    enableGridMenu: true,
    exporterExcelSheetName: 'Sheet1',
    exporterExcelFilename: 'shipment_Wave_CtrlNbr.xlsx',
    multiSelect: false,
    enableColumnResizing: true,
    gridMenuShowHideColumns: false,
    exporterMenuVisibleData: false,
    enableRowSelection: false,//we can remove it later no use  of this
    enableSelectAll: false,//we can remove it later no use  of this             
    enableCellEdit: false, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
    enableCellEditOnFocus: true // set any editable column to allow edit on focus
  };
  
  $scope.gridOptionsBig.onRegisterApi = function (gridApi) {
    //set gridApi on scope

    $scope.gridApi = gridApi;
    $scope.isSuccesszone = false;
    $scope.isFailedzone = false;

    $scope.gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {

      $scope.pageNo =  newPage;
      if(pageSize == "All"){
	$scope.pageSize = $scope.bigGrid;
        $scope.gridOptionsBig.paginationPageSize = $scope.bigGrid;
      }else{
      $scope.pageSize = pageSize;
      }
     
      $scope.bigGridPagination();
    });

  };
  
//Main page Small grid
  $scope.gridOptionsSmall = {
    paginationPageSizes: [ 15, 25, 50, 100, "All"],
    paginationPageSize: 100,
    useExternalPagination: true,
    enableColumnMenus: false,
    enableSorting: true,
    exporterMenuCsv: false,
    exporterMenuPdf: false,
    enableGridMenu: true,
    exporterExcelSheetName: 'Sheet1',
    exporterExcelFilename: 'Locations.xlsx',
    multiSelect: false,
    enableColumnResizing: true,
    gridMenuShowHideColumns: false,
    exporterMenuVisibleData: false,
    enableRowSelection: false,//we can remove it later no use  of this
    enableSelectAll: false,//we can remove it later no use  of this             
    enableCellEdit: false, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
    enableCellEditOnFocus: true // set any editable column to allow edit on focus

  };
  $scope.gridOptionsSmall.onRegisterApi = function (gridApi) {

    $scope.gridApi = gridApi;

    $scope.isSuccessprob = false;
    $scope.isFailedprob = false;
    
    $scope.gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
       $scope.pageNo =  newPage;
      if(pageSize == "All"){
	$scope.pageSize = $scope.smallGrid;
        $scope.gridOptionsSmall.paginationPageSize = $scope.smallGrid;
      }else{
      $scope.pageSize = pageSize;
      }
      $scope.smallGridPagination();
    });

  };

  //Shipment wave number grid options
  $scope.gridOptions = {
    paginationPageSizes: [15, 25, 50, 100],
    paginationPageSize: 100,
    useExternalPagination: true,
    enableColumnMenus: false,
    enableSorting: true,
    exporterMenuCsv: false,
    exporterMenuPdf: false,
    enableGridMenu: true,
    exporterExcelSheetName: 'Sheet1',
    exporterExcelFilename: 'Pallet_numbers.xlsx',
    multiSelect: false, 
    enableColumnResizing: true,
    gridMenuShowHideColumns: false,
    exporterMenuVisibleData: false,
    enableRowSelection: false,//we can remove it later no use  of this
    enableSelectAll: false,//we can remove it later no use  of this             
    enableCellEdit: false, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
    enableCellEditOnFocus: true // set any editable column to allow edit on focus

  };
  
  $scope.gridOptions.onRegisterApi = function (gridApi) {
    
        $scope.gridApi = gridApi;
    
        $scope.isSuccessprob = false;
        $scope.isFailedprob = false;
        
        $scope.gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
          $scope.pageNo =  newPage;
          $scope.pageSize = pageSize;
if($scope.shipwavecntnum){
$scope.shipmentId($scope.shipwavecntnum);
}else{
$scope.clickedpallet();
}

          
        });
    
      };
  	$scope.booleanval = {
		
		"palletFlag": true,
		"numberofCartonlFlag": true,
        };
 
 
  //Search based grid
  $scope.loadBasegrid = function($event){    
    var keyCode = $event.which || $event.keyCode;
    //$scope.userData = $event.currentTarget.value;
    $scope.userInput = $scope.loadNum;
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $scope.isFieldValidate = false;
    $scope.isTable = false;
    $scope.isTable1 = false;
    var reg = /^[0-9a-zA-Z\_ ]+$/;
   
    if($scope.loadNum  && keyCode === 13){
      if($scope.loadNum.length < 5){

       $scope.booleanval.palletFlag = true;
        $scope.booleanval.numberofCartonlFlag= true;
        $scope.isFieldValidate = true;
   	$scope.inputType =false;
        $scope.isTable = false;
        $scope.isTable2 = false;
        
       return false;
       
      }else if($scope.loadNum == '' || $scope.loadNum == null || $scope.loadNum == undefined || $scope.loadNum == 32 || !(reg.test($scope.loadNum))){
        $scope.booleanval.palletFlag = true;
        $scope.booleanval.numberofCartonlFlag= true;
	$scope.inputType =false;
        $scope.isFieldValidate = true;
   	$scope.isTable = false;
        $scope.isTable2 = false;
 
        return false;
      }
      $("#showloader").css("display", "block");
      var url = urlService.SEARCH_LOAD_CONTROL.replace('dName',$scope.pagedc);
      url = url.replace('userinput',$scope.loadNum );
      url = url.replace('uName',sessionStorage.userName);
  
      var res = $http.get(url, {
       headers: {'x-api-key': sessionStorage.apikey}
      });
      $scope.loadNum = "";
        res.success(function (data, status, headers, config) {
          $("#showloader").css("display", "none");          
          //$scope.userInput = $scope.userData;

          if (data.errorMessage) {
            $scope.isTable = false;
            $scope.isFailed = true;
            $scope.resmessage = data.errorMessage;
  	     $scope.booleanval.palletFlag = true;
$scope.isTable = false;
            $scope.isTable2 = false;
        $scope.booleanval.numberofCartonlFlag= true;
	$scope.inputType =false;          }
          else if (data.resMessage) {
            $scope.isTable = false;
            $scope.isSuccess = true;
            $scope.resmessage = data.resMessage;
 	     $scope.booleanval.palletFlag = true;
        $scope.booleanval.numberofCartonlFlag= true;
$scope.isTable = false;
            $scope.isTable2 = false;
	$scope.inputType =false;          }
          else if (data.length === 0) {
            $scope.isTable = false;
            $scope.isFailed = true;
            $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
 	     $scope.booleanval.palletFlag = true;
        $scope.booleanval.numberofCartonlFlag = true;
	$scope.inputType =false;
$scope.isTable = false;
            $scope.isTable2 = false;

          } else {
            $scope.pageNo = $scope.pageNo ? $scope.pageNo : 1;
           $scope.pageSize = $scope.pageSize ? $scope.pageSize: $scope.gridOptionsSmall.paginationPageSize;
            $scope.isTable = true;
            $scope.isTable2 = false;
            $scope.gridOptionsBig.columnDefs = [
             
                { name: 'shipWaveCtrlNbr', displayName: 'SWC', enableCellEdit: false,  cellTooltip: true, headerTooltip: true, cellTemplate:  '<div class="ui-grid-cell-contents" ng-click=\"grid.appScope.shipmentId(row.entity,col)\" style="cursor : pointer;"  title="{{COL_FIELD}}"><a href="javascript:void(0)">{{COL_FIELD}}</a></div>'},
                { name: 'shipTo', displayName: 'Shipto_Name', enableCellEdit: false, cellTooltip: true,sort: { direction: uiGridConstants.DESC, priority: 1 }, headerTooltip: true},
                { name: 'country', displayName: 'CNT', enableCellEdit: false, cellTooltip: true, headerTooltip: true, visibility: false },
                { name: 'city', displayName: 'City', enableCellEdit: false, cellTooltip: true, headerTooltip: true},
                { name: 'pgi', displayName: 'PGI', enableCellEdit: false, cellTooltip: true, headerTooltip: true},
                { name: 'palletComplete', displayName: 'Pallet Complete', enableCellEdit: false, cellTooltip: true, headerTooltip: true},
                { name: 'complete', displayName: 'Complete', enableCellEdit: false, cellTooltip: true, headerTooltip: true },
                { name: 'incomplete', displayName: 'Incomplete', enableCellEdit: false,  cellTooltip: true, headerTooltip: true,cellClass: function (grid, row, col, rowRenderIndex, colRenderIndex) {
                  if (grid.getCellValue(row, col) == "0") {
                    return 'greenbg';
                  }
                  return 'bluebg';
                } 
              },
                { name: 'split', displayName: 'Split', enableCellEdit: false, cellTooltip: true, headerTooltip: true }
                
            ];
    	    $scope.bigGrid = data.swcDtoList.totalNoOfRecords;
            $scope.gridOptionsBig.totalItems  = data.swcDtoList.totalNoOfRecords; 
            $scope.gridOptionsBig.data = data.swcDtoList.pageItems;
    
            if ($scope.gridOptionsBig.data.length > 10) {
              $scope.gridOptionsBig.enableVerticalScrollbar = 1;
              $scope.gridOptionsBig.enableHorizontalScrollbar = 1;
            } else {
              $scope.gridOptionsBig.enableVerticalScrollbar = 0;
              $scope.gridOptionsBig.enableHorizontalScrollbar = 1;
            }


            $scope.pageNo = $scope.pageNo ? $scope.pageNo : 1;
            $scope.pageSize = $scope.pageSize ? $scope.pageSize: $scope.gridOptionsSmall.paginationPageSize;
             $scope.isTable1 = true;
             $scope.gridOptionsSmall.columnDefs = [
              
                 { name: 'location', displayName: 'Location', enableCellEdit: false,   cellTooltip: true, headerTooltip: true },
                 { name: 'pallets', displayName: 'Pallets', enableCellEdit: false,sort: { direction: uiGridConstants.DESC, priority: 1 }, cellTooltip: true, headerTooltip: true},
                 { name: 'cartons', displayName: 'Cartons', enableCellEdit: false, cellTooltip: true, headerTooltip: true, visibility: false }
                
             ];
     	     $scope.SmallGrid = data.palletLocDtlsDtoList.totalNoOfRecords;
             $scope.gridOptionsSmall.totalItems  = data.palletLocDtlsDtoList.totalNoOfRecords;  
             $scope.gridOptionsSmall.data = data.palletLocDtlsDtoList.pageItems;
     
             if ($scope.gridOptionsSmall.data.length > 10) {
               $scope.gridOptionsSmall.enableVerticalScrollbar = 1;
               $scope.gridOptionsSmall.enableHorizontalScrollbar = 0;
             } else {
               $scope.gridOptionsSmall.enableVerticalScrollbar = 0;
               $scope.gridOptionsSmall.enableHorizontalScrollbar = 1;
             }
             
           }
  
          if(data.loadCtrlBasicDtlsDto){$scope.palletidInfo = data.loadCtrlBasicDtlsDto.palletId;}
         if(data.inputType == "Pallet"){
           $scope.inputType =true;
           $scope.booleanval.palletFlag = false;
           $scope.booleanval.numberofCartonlFlag = false;
           $scope.loadNbr = data.palletHdrDto.loadNbr;
           $scope.palletId = data.palletHdrDto.palletId;
           $scope.swc = data.palletHdrDto.swc;
           $scope.packInstr = data.palletHdrDto.packInstr;
           $scope.packInstr2 = data.palletHdrDto.packInstr2;
           $scope.packInfo = data.palletHdrDto.packInfo;
           $scope.palletLabel = data.loadCtrlLabelResponseDto.palletLabel;
           $scope.loadLabel = data.loadCtrlLabelResponseDto.loadLabel;
           $scope.palletLabelColors = {
            "color" : data.loadCtrlLabelResponseDto.palletLabelColor
                   
          };
          $scope.loadLabelColors = {
            "color" : data.loadCtrlLabelResponseDto.loadLabelColor
         };

      if($scope.palletLabelColors.color == null){
            $scope.palletLabelColors = {
            "color" : "Gray"
          };

         }else if($scope.palletLabelColors.color == "Yellow"){
                 $scope.palletLabelColors = {
                 "color" : "#f2b300"
                 };
         }
         if($scope.loadLabelColors == null ){
            $scope.loadLabelColors = {
            "color" :  "Gray"
            };
         }else if($scope.loadLabelColors.color == "Yellow"){
                 $scope.loadLabelColors = {
                 "color" : "#f2b300"
                 };
         }


         }

 	if(data.inputType == "Carton" || data.inputType == "Lpn"){
           $scope.inputType =true;
           $scope.booleanval.palletFlag = false;
           $scope.booleanval.numberofCartonlFlag = false;
           $scope.loadNbr = data.loadCtrlBasicDtlsDto.loadNbr;
           $scope.palletId = data.loadCtrlBasicDtlsDto.palletId;
           $scope.swc = data.loadCtrlBasicDtlsDto.swc;
           $scope.packInstr = data.palletHdrDto.packInstr;
           $scope.packInstr2 = data.palletHdrDto.packInstr2;
           $scope.packInfo = data.palletHdrDto.packInfo;
           $scope.palletLabel = data.loadCtrlLabelResponseDto.palletLabel;
           $scope.loadLabel = data.loadCtrlLabelResponseDto.loadLabel;
           $scope.palletLabelColors = {
            "color" : data.loadCtrlLabelResponseDto.palletLabelColor
                   
          };
          $scope.loadLabelColors = {
            "color" : data.loadCtrlLabelResponseDto.loadLabelColor
                   
          };

         if($scope.palletLabelColors.color == null){
            $scope.palletLabelColors = {
            "color" : "Gray"
          };
         }else if($scope.palletLabelColors.color == "Yellow"){
                 $scope.palletLabelColors = {
                 "color" : "#f2b300"
                 };
         }

         if($scope.loadLabelColors == null ){
            $scope.loadLabelColors = {
            "color" :  "Gray"
            };
         }else if($scope.loadLabelColors.color == "Yellow"){
                 $scope.loadLabelColors = {
                 "color" : "#f2b300"
                 };
         }


         }

         if(data.inputType == "Load"){
          $scope.inputType =true;
           $scope.booleanval.palletFlag = true;
           $scope.booleanval.numberofCartonlFlag = true;
           $scope.loadNbr = data.loadCtrlBasicDtlsDto.loadNbr;
           $scope.palletId = data.loadCtrlBasicDtlsDto.palletId;
           $scope.swc = data.loadCtrlBasicDtlsDto.swc;
           $scope.packInstr = "";
           $scope.packInstr2 = "";
           $scope.packInfo = "";
           $scope.palletLabel = data.loadCtrlLabelResponseDto.palletLabel;
           $scope.loadLabel = data.loadCtrlLabelResponseDto.loadLabel;
           $scope.palletLabelColors = {
            "color" : data.loadCtrlLabelResponseDto.palletLabelColor
                   
          };
          $scope.loadLabelColors = {
            "color" : data.loadCtrlLabelResponseDto.loadLabelColor
                   
          };
	  if($scope.palletLabelColors.color == null){
            $scope.palletLabelColors = {
            "color" : "Gray"
          };
         }else if($scope.palletLabelColors.color == "Yellow"){
                 $scope.palletLabelColors = {
                 "color" : "#f2b300"
                 };
         }

         if($scope.loadLabelColors == null ){
            $scope.loadLabelColors = {
            "color" :  "Gray"
            };
         }else if($scope.loadLabelColors.color == "Yellow"){
                 $scope.loadLabelColors = {
                 "color" : "#f2b300"
                 };
         }

       }

         if(data.showStoLogiChkPrompt == true){
          $("#messageModel").modal('show');
         // $scope.altMsg = data.loadCtrlLabelResponseDto.multiCoOMsg;
          //$scope.altMsg = "Multiple coO in one Carton <br/> Please send Pallet to OB Prep for sortation !";
			$scope.altMsg = data.loadCtrlLabelResponseDto.palletLabel + '. '+ data.loadCtrlLabelResponseDto.loadLabel;

         }
        

          $('.ui-grid-pager-control input').prop( "disabled", true );
        });
        res.error(function (data, status, headers, config) {
          $("#showloader").css("display", "none");
          $scope.isFailed = true;
          $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
    
        });
            
     
  }

  };

  $scope.bigGridPagination = function(){
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $("#showloader").css("display", "block");
    $scope.pageNo = $scope.pageNo ? $scope.pageNo : 1;
    $scope.pageSize = $scope.pageSize ? $scope.pageSize: $scope.gridOptionsSmall.paginationPageSize;
        


    var url = urlService.LOAD_CONTROL_BIG.replace('dName',$scope.pagedc);
    url = url.replace('loadnum',$scope.loadNbr);
    url = url.replace('swcnum',$scope.swc);
    url = url.replace('uName',sessionStorage.userName);
    url = url.replace('pNumber',$scope.pageNo);
    url = url.replace('pSize',$scope.pageSize);
   
    var res = $http.get(url, {
     headers: {'x-api-key': sessionStorage.apikey}
    });

    res.success(function (data, status, headers, config) {
      $("#showloader").css("display", "none");
     
      if (data.errorMessage){
        $scope.isFailed = true;
        $scope.resmessage = data.errorMessage;
      }
      else if (data.resMessage) {
         $scope.isSuccess = true;
        $scope.resmessage = data.resMessage;
      }
      else {

        $scope.gridOptionsBig.columnDefs = [
             
                { name: 'shipWaveCtrlNbr', displayName: 'SWC', enableCellEdit: false, sort: { direction: uiGridConstants.ASC, priority: 1 },  cellTooltip: true, headerTooltip: true, cellTemplate:  '<div class="ui-grid-cell-contents" ng-click=\"grid.appScope.shipmentId(row.entity,col)\" style="cursor : pointer;"  title="{{COL_FIELD}}"><a href="javascript:void(0)">{{COL_FIELD}}</a></div>'},
                { name: 'shipTo', displayName: 'Shipto_Name', enableCellEdit: false, cellTooltip: true, headerTooltip: true},
                { name: 'country', displayName: 'CNT', enableCellEdit: false, cellTooltip: true, headerTooltip: true, visibility: false },
                { name: 'city', displayName: 'City', enableCellEdit: false, cellTooltip: true, headerTooltip: true},
                { name: 'pgi', displayName: 'PGI', enableCellEdit: false, cellTooltip: true, headerTooltip: true},
                { name: 'palletComplete', displayName: 'Pallet Complete', enableCellEdit: false, cellTooltip: true, headerTooltip: true},
                { name: 'complete', displayName: 'Complete', enableCellEdit: false, cellTooltip: true, headerTooltip: true },
                { name: 'incomplete', displayName: 'Incomplete', enableCellEdit: false,  cellTooltip: true, headerTooltip: true,cellClass: function (grid, row, col, rowRenderIndex, colRenderIndex) {
                  if (grid.getCellValue(row, col) == "0") {
                    return 'greenbg';
                  }
                  return 'bluebg';
                } 
              },
                { name: 'split', displayName: 'Split', enableCellEdit: false, cellTooltip: true, headerTooltip: true }
                
            ];
    
        $scope.gridOptionsBig.totalItems  = data.totalNoOfRecords;  
        $scope.gridOptionsBig.data = data.pageItems;

        if ($scope.gridOptionsBig.data.length > 10) {
          $scope.gridOptionsBig.enableVerticalScrollbar = 1;
          $scope.gridOptionsBig.enableHorizontalScrollbar = 1;
        } else {
          $scope.gridOptionsBig.enableVerticalScrollbar = 0;
          $scope.gridOptionsBig.enableHorizontalScrollbar = 1;
        }
      }

      
      $('.ui-grid-pager-control input').prop( "disabled", true );
    });
    res.error(function (data, status, headers, config) {
      $("#showloader").css("display", "none");
      $scope.isFailed = true;
      $scope.resmessage = "System failed. Please try again or contact WAALOS Support";

    });

  };

  $scope.smallGridPagination = function(){
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $("#showloader").css("display", "block");
 $scope.pageSize = $scope.pageSize ? $scope.pageSize: $scope.gridOptionsSmall.paginationPageSize;
	if($scope.pageSize == "All"){
	$scope.pageSize = $scope.smallGrid;
        $scope.gridOptionsSmall.paginationPageSize =  $scope.smallGrid;

   }
    $scope.pageNo = $scope.pageNo ? $scope.pageNo : 1;
   
    
    var url = urlService.LOAD_CONTROL_SMALL.replace('dName',$scope.pagedc);
    url = url.replace('loadnum',$scope.loadNbr);
    url = url.replace('swcnum',$scope.swc);
    url = url.replace('uName',sessionStorage.userName);
    url = url.replace('pNumber',$scope.pageNo);
    url = url.replace('pSize',$scope.pageSize);
   
    var res = $http.get(url, {
     headers: {'x-api-key': sessionStorage.apikey}
    });

    res.success(function (data, status, headers, config) {
      $("#showloader").css("display", "none");
     
      if (data.errorMessage) {
        $scope.isTable = false;
        $scope.isFailed = true;
        $scope.resmessage = data.errorMessage;
      }
      else if (data.resMessage) {
        $scope.isTable = false;
        $scope.isSuccess = true;
        $scope.resmessage = data.resMessage;
      }
      else {
       
     

         $scope.isTable1 = true;
         $scope.gridOptionsSmall.columnDefs = [
          
             { name: 'location', displayName: 'Location', enableCellEdit: false, sort: { direction: uiGridConstants.ASC, priority: 1 },  cellTooltip: true, headerTooltip: true },
             { name: 'pallets', displayName: 'Pallets', enableCellEdit: false, cellTooltip: true, headerTooltip: true},
             { name: 'cartons', displayName: 'Cartons', enableCellEdit: false, cellTooltip: true, headerTooltip: true, visibility: false }
            
         ];
 
         $scope.gridOptionsSmall.totalItems  = data.totalNoOfRecords;  
         $scope.gridOptionsSmall.data = data.pageItems;
 
         if ($scope.gridOptionsSmall.data.length > 10) {
           $scope.gridOptionsSmall.enableVerticalScrollbar = 1;
           $scope.gridOptionsSmall.enableHorizontalScrollbar = 1;
         } else {
           $scope.gridOptionsSmall.enableVerticalScrollbar = 0;
           $scope.gridOptionsSmall.enableHorizontalScrollbar = 0;
         }
         
       }

      $('.ui-grid-pager-control input').prop( "disabled", true );
    });
    res.error(function (data, status, headers, config) {
      $("#showloader").css("display", "none");
      $scope.isFailed = true;
      $scope.resmessage = "System failed. Please try again or contact WAALOS Support";

    });

  };

$scope.printLabel = function(){
  $scope.isSuccess = false;
  $scope.isFailed = false;
  $("#showloader").css("display", "block");
  $("#anynumber").focus();
  var obj =
  
        {
          "printerIp": $scope.printer.printerIp,
          "printerPort": $scope.printer.printerPort,
          "palletId": $scope.palletId,
          "loadNbr": $scope.loadNbr,
          "swc": $scope.swc,
          "nbrOfCartons":$scope.cartonvalue,
          "dcName":$scope.pagedc,
          "userName":sessionStorage.userName
          
        };
      var res = $http.post(urlService.LOAD_CONTROL_PRINT, obj, {
      headers: {'x-api-key': sessionStorage.apikey}
      });

      res.success(function (data, status, headers, config) {
        $("#showloader").css("display", "none");
       
        if (data.errorMessage) {
  
          $scope.isFailed = true;
          $scope.resmessage = data.errorMessage;
        }
        else if (data.resMessage) {

          $scope.isSuccess = true;
          $scope.resmessage = data.resMessage;
        }

      });
      res.error(function (data, status, headers, config) {
        $("#showloader").css("display", "none");
        $scope.isFailed = true;
        $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
  
      });
};


   $scope.shipmentId = function(row,col) {

    $scope.isSuccess = false;
    $scope.isFailed = false;

    $scope.isTable = false;
    $scope.isTable1 = false;
  
  $("#showloader").css("display", "block");
if(row.shipWaveCtrlNbr){
$scope.shipwavecntnum = row.shipWaveCtrlNbr;
}else{
$scope.shipwavecntnum = row;
}


 if(col){
	$scope.pageNo = 1;
        $scope.pageSize = 100;
	}else{
	$scope.pageNo = $scope.pageNo ? $scope.pageNo : 1;
        $scope.pageSize = $scope.pageSize ? $scope.pageSize: $scope.gridOptions.paginationPageSize;
	} 

  var url = urlService.LOAD_CONTROL_SWC.replace('dName',$scope.pagedc);
  url = url.replace('loadnum',$scope.loadNbr);
  url = url.replace('swcnum',$scope.shipwavecntnum);
  url = url.replace('uName',sessionStorage.userName);
  url = url.replace('pNumber',$scope.pageNo);
  url = url.replace('pSize',$scope.pageSize);

  var res = $http.get(url, {
   headers: {'x-api-key': sessionStorage.apikey}
  });

    res.success(function (data, status, headers, config) {
      $("#showloader").css("display", "none");
     $scope.isTable2 = true;
     $scope.isBack = true;
     $scope.gridOptions.columnDefs = [
      
      { name: 'palletId', displayName: 'Pallet Id', enableCellEdit: false, sort: { direction: uiGridConstants.ASC, priority: 1 },  cellTooltip: true, headerTooltip: true, width: 170},
      { name: 'cartonNbr', displayName: 'Carton Nbr', enableCellEdit: false, cellTooltip: true, headerTooltip: true, visibility: false, width: 180 },
      { name: 'cartonLpn', displayName: 'Carton Lpn', enableCellEdit: false, cellTooltip: true, headerTooltip: true, width: 140 },
      { name: 'cartonSize', displayName: 'Carton Size', enableCellEdit: false, cellTooltip: true, headerTooltip: true, width: 140 },
      { name: 'status', displayName: 'Status', enableCellEdit: false, cellTooltip: true, headerTooltip: true, width: 128 },
      { name: 'totalQty', displayName: 'Total Qty', enableCellEdit: false, width: 80, cellTooltip: true, headerTooltip: true },
      { name: 'cartMarking', displayName: 'Cart Marking', enableCellEdit: false, width: 120, cellTooltip: true, headerTooltip: true },
      { name: 'sla', displayName: 'Sla', enableCellEdit: false, width: 120, cellTooltip: true, headerTooltip: true },
      { name: 'shipVia', displayName: 'Ship Via', enableCellEdit: false, width: 120, cellTooltip: true, headerTooltip: true },
      { name: 'loadNbr', displayName: 'Load Nbr', enableCellEdit: false, width: 120, cellTooltip: true, headerTooltip: true },
      { name: 'swc', displayName: 'Swc', enableCellEdit: false, width: 120, cellTooltip: true, headerTooltip: true },
      { name: 'pktCtrlNbr', displayName: 'Pkt CtrlNbr', enableCellEdit: false, width: 120, cellTooltip: true, headerTooltip: true },
      { name: 'shipto', displayName: 'shipto', enableCellEdit: false, width: 120, cellTooltip: true, headerTooltip: true },
      { name: 'shiptoCntry', displayName: 'Shipto Cntry', enableCellEdit: false, width: 120, cellTooltip: true, headerTooltip: true },
      { name: 'shiptoCity', displayName: 'Shipto City', enableCellEdit: false, width: 120, cellTooltip: true, headerTooltip: true },
      { name: 'shipmentNbr', displayName: 'Shipment Nbr', enableCellEdit: false, width: 120, cellTooltip: true, headerTooltip: true },
      { name: 'lock', displayName: 'Lock', enableCellEdit: false, width: 120, cellTooltip: true, headerTooltip: true },
      { name: 'loaction', displayName: 'Loaction', enableCellEdit: false, width: 120, cellTooltip: true, headerTooltip: true },
      { name: 'modDate', displayName: 'Mod Date', enableCellEdit: false, width: 120, cellTooltip: true, headerTooltip: true },
      { name: 'cooCount', displayName: 'COO Count', enableCellEdit: false, width: 120, cellTooltip: true, headerTooltip: true },
      { name: 'skuCount', displayName: 'SKU Count', enableCellEdit: false, width: 120, cellTooltip: true, headerTooltip: true }
     ];

     $scope.gridOptions.totalItems  = data.totalNoOfRecords;  
     $scope.gridOptions.data = data.pageItems;

     if ($scope.gridOptions.data.length > 10) {
       $scope.gridOptions.enableVerticalScrollbar = 1;
       $scope.gridOptions.enableHorizontalScrollbar = 1;
     } else {
       $scope.gridOptions.enableVerticalScrollbar = 0;
       $scope.gridOptions.enableHorizontalScrollbar = 1;
     }

  
     if(col){$scope.gridOptions.paginationCurrentPage  = 1;}
      setTimeout(function(){  $('.ui-grid-pager-control-input').attr( "disabled", true );  }, 2000);    });
    res.error(function (data, status, headers, config) {
      $("#showloader").css("display", "none");
      $scope.isFailed = true;
      $scope.resmessage = "System failed. Please try again or contact WAALOS Support";

    });

  };


  $scope.clickedpallet = function(val) {
    $scope.isSuccess = false;
    $scope.isFailed = false;

    $scope.isTable = false;
    $scope.isTable1 = false;
  
    $("#showloader").css("display", "block");

 if(val == 'clicked'){
	$scope.pageNo = 1;
$scope.shipwavecntnum = "";
	}else{
	$scope.pageNo = $scope.pageNo ? $scope.pageNo : 1;
	}    
$scope.pageSize = $scope.pageSize ? $scope.pageSize: $scope.gridOptions.paginationPageSize;
    var url = urlService.CHECK_PALLET_LOAD_CONTROL.replace('dName',$scope.pagedc);
    url = url.replace('palletID',$scope.palletidInfo);
    url = url.replace('uName',sessionStorage.userName);
    url = url.replace('pSize',$scope.pageSize);
    url = url.replace('pNumber',$scope.pageNo);
   
    
    var res = $http.get(url, {
     headers: {'x-api-key': sessionStorage.apikey}
    });

    res.success(function (data, status, headers, config) {
    
      $("#showloader").css("display", "none");
    
    $scope.isTable2 = true;
    $scope.isBack = true;
    $scope.gridOptions.columnDefs = [
         { name: 'palletId', displayName: 'palletId', enableCellEdit: false, sort: { direction: uiGridConstants.ASC, priority: 1 },  cellTooltip: true, headerTooltip: true, width: 170},
         { name: 'cartonNbr', displayName: 'cartonNbr', enableCellEdit: false, cellTooltip: true, headerTooltip: true, visibility: false, width: 180 },
         { name: 'cartonLpn', displayName: 'cartonLpn', enableCellEdit: false, cellTooltip: true, headerTooltip: true, width: 140 },
         { name: 'cartonSize', displayName: 'cartonSize', enableCellEdit: false, cellTooltip: true, headerTooltip: true, width: 140 },
         { name: 'status', displayName: 'status', enableCellEdit: false, cellTooltip: true, headerTooltip: true, width: 128 },
         { name: 'totalQty', displayName: 'totalQty', enableCellEdit: false, width: 80, cellTooltip: true, headerTooltip: true },
         { name: 'cartMarking', displayName: 'cartMarking', enableCellEdit: false, width: 120, cellTooltip: true, headerTooltip: true },
         { name: 'sla', displayName: 'sla', enableCellEdit: false, width: 120, cellTooltip: true, headerTooltip: true },
         { name: 'shipVia', displayName: 'shipVia', enableCellEdit: false, width: 120, cellTooltip: true, headerTooltip: true },
         { name: 'loadNbr', displayName: 'loadNbr', enableCellEdit: false, width: 120, cellTooltip: true, headerTooltip: true },
         { name: 'swc', displayName: 'swc', enableCellEdit: false, width: 120, cellTooltip: true, headerTooltip: true },
         { name: 'pktCtrlNbr', displayName: 'pktCtrlNbr', enableCellEdit: false, width: 120, cellTooltip: true, headerTooltip: true },
         { name: 'shipto', displayName: 'shipto', enableCellEdit: false, width: 120, cellTooltip: true, headerTooltip: true },
         { name: 'shiptoCntry', displayName: 'shiptoCntry', enableCellEdit: false, width: 120, cellTooltip: true, headerTooltip: true },
         { name: 'shiptoCity', displayName: 'shiptoCity', enableCellEdit: false, width: 120, cellTooltip: true, headerTooltip: true },
         { name: 'shipmentNbr', displayName: 'shipmentNbr', enableCellEdit: false, width: 120, cellTooltip: true, headerTooltip: true },
         { name: 'lock', displayName: 'lock', enableCellEdit: false, width: 120, cellTooltip: true, headerTooltip: true },
         { name: 'loaction', displayName: 'loaction', enableCellEdit: false, width: 120, cellTooltip: true, headerTooltip: true },
         { name: 'modDate', displayName: 'modDate', enableCellEdit: false, width: 120, cellTooltip: true, headerTooltip: true },
         { name: 'cooCount', displayName: 'cooCount', enableCellEdit: false, width: 120, cellTooltip: true, headerTooltip: true },
         { name: 'skuCount', displayName: 'skuCount', enableCellEdit: false, width: 120, cellTooltip: true, headerTooltip: true }
         
     ];

     $scope.gridOptions.totalItems  = data.totalNoOfRecords;  
     $scope.gridOptions.data = data.pageItems;

     if ($scope.gridOptions.data.length > 10) {
       $scope.gridOptions.enableVerticalScrollbar = 1;
       $scope.gridOptions.enableHorizontalScrollbar = 1;
     } else {
       $scope.gridOptions.enableVerticalScrollbar = 0;
       $scope.gridOptions.enableHorizontalScrollbar = 1;
     }
     if(val == "clicked"){$scope.gridOptions.paginationCurrentPage  = 1;}
      setTimeout(function(){  $('.ui-grid-pager-control-input').attr( "disabled", true );  }, 2000);
  
  
    });
    res.error(function (data, status, headers, config) {
      $("#showloader").css("display", "none");
      $scope.isFailed = true;
      $scope.resmessage = "System failed. Please try again or contact WAALOS Support";

    });

  };


$scope.isback  = function(){
  $scope.isSuccess = false;
  $scope.isFailed = false;

  $scope.isTable = true;
  $scope.isTable1 = true;
  $scope.isTable2 = false;
  $scope.isBack = false;
};

$scope.numberofCartons = function(){
 if($scope.cartonvalue.length > 0 && $scope.cartonvalue.length < 3){
   $scope.GenrateLabelFlag = false;
 }else if($scope.cartonvalue == undefined){
  $scope.GenrateLabelFlag = true;
 }
 else{
  $scope.GenrateLabelFlag = true;
 }

};

//user favourites code start
$scope.isClicked = false;

$scope.addToFavourate = function(isClicked){
    $("#showloader").css("display", "block");
     if(typeof isClicked !== "boolean"){
      commonService.postServiceResponse(urlService.GET_FAVOURITES,{"username": sessionStorage.userName})
        .then(function(response){
          $("#showloader").css("display", "none");
            _.each(response,function(val,key){
              if(val.funName == $scope.functionality && val.dcName == $scope.dcName){
                $scope.isClicked = true;      
              }
            });
        },function(error){
          $("#showloader").css("display", "none");
          $scope.isClicked = false; 
        });
        //$scope.isClicked = ;
     }else{
      if(!$scope.isClicked){
        commonService.postServiceResponse(urlService.ADD_FAVOURITE,{"username": sessionStorage.userName,"dcName":$scope.dcName,"funName":$scope.functionality})
        .then(function(response){
          $("#showloader").css("display", "none");
          if(response.errorMessage){
            $scope.isFavouriteAdded= false; 
            $scope.isClicked = false;      
            $scope.$broadcast('showAlert',['']);
          }else{
            $scope.isClicked = true;      
            $scope.isClicked = !isClicked;
            $scope.isFavouriteAdded= true; 
            $scope.favouriteMsg = response.resMessage;
          $scope.$broadcast('ClickedOnFavourate',[$scope.dcName,$scope.functionality,$scope.isClicked]);
          }
            
        },function(error){
          $scope.isClicked = false;
          $("#showloader").css("display", "none");
        });
        $scope.isClicked = !isClicked;
      }else{
        $("#showloader").css("display", "none");
      }
     }
    
  };
  $scope.addToFavourate('load');
  //user favourites code ends
}]);