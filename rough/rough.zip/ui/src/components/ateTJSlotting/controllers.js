var app = angular.module('AteTJSlotting', ['ui.bootstrap', 'ngTouch', 'ui.grid', 'ui.grid.selection', 'ui.grid.edit','ui.grid.autoResize','ui.grid.validate']);

app.controller('AteTJSlottingCtrl', ['$scope', '$http', '$q', '$interval', '$timeout', 'urlService', 'uiGridConstants','commonService', function ($scope, $http, $q, $interval, $timeout, urlService, uiGridConstants,commonService) {

	//$scope.numberValidation = false;
	$scope.dsReleaseGrid = false;
	//$scope.ZoneValue = '0';

	/******************manualZones start*************************/
	$scope.isMianpage = true;
	$scope.locationUpdateFlag = true;
	$scope.manualZones = {};
	$scope.dsGrid = false;
	$scope.dsGridPanel = false;
	$scope.automaticZones = {};
	$scope.pagefunctionality = $scope.functionality;
	$scope.pagedc = $scope.dcName;

	$scope.forecastValues = {
		forecastFile : '',
		minCasesPerSku : '',
		maxCasesPerSku : ''	
	};

	$scope.zonesManualLocking = function () {
		$scope.isSuccess = false;
		$scope.isFailed = false;
		$scope.locationUpdateFlag = true;
		$scope.getZonesData();
		$scope.getLocationData();
	};

	$scope.getZonesData = function () {
		$scope.manualZones.zone = "ALL";
		$scope.manualZones.level = "ALL";

		$scope.isSuccess = false;
		$scope.isFailed = false;
		//$("#showloader").css("display", "block");
		var url = urlService.ATE_SLOTTING_TJ_GET_ZONES_DATA.replace('dName', $scope.dcName);//$scope.dcName
		url = url.replace('uName', sessionStorage.userName);

		var res = $http.get(url, {
			 headers: {'x-api-key': sessionStorage.apikey}

		});

		res.success(function (data, status, headers, config) {
		$("#showloader").css("display", "none");
		
			if (data.errorMessage) {
				$scope.isFailed = true;
				$scope.errormessage = data.errorMessage;
				
			} else if (data.length > 0) {
				$scope.zonesData = data;
				var obj = {};
				//obj.zone = "ALL";
				//$scope.zonesData.unshift(obj);
				//$scope.manualZones.zone = $scope.zonesData[0].zone;
				$scope.levelsData = [ "1", "2", "3"];
				//$scope.manualZones.level = $scope.levelsData[0];
				
			}
		});
		res.error(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			$scope.isFailed = true;
			$scope.errormessage = "System failed. Please try again or contact WAALOS Support";

		});
	};

	$scope.getLocationData = function () {
		$("#showloader").css("display", "block");
		$scope.isSuccess = false;
		$scope.isFailed = false;

		var url = urlService.ATE_SLOTTING_TJ_GET_ZONE_LOCATION_DATA.replace('dName', $scope.dcName);//$scope.dcName
		url = url.replace('uName', sessionStorage.userName);

		var res = $http.get(url, {
			 headers: {'x-api-key': sessionStorage.apikey}

		});

		res.success(function (data, status, headers, config) {

			if (data.errorMessage) {
				$scope.isFailed = true;
				$scope.errormessage = data.errorMessage;
				$("#showloader").css("display", "none");
			} else if (data.length > 0) {
				$scope.locationsData = data;
				$scope.manualZones.location = data[0].locnBrcd;
				$("#showloader").css("display", "none");
			}
		});
		res.error(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			$scope.isFailed = true;
			$scope.errormessage = "System failed. Please try again or contact WAALOS Support";

		});
	};

	$scope.enableUpdate = function (val) {
		var len = $(".location_check:checked").length;
		if (len > 0) {
			$scope.locationUpdateFlag = false;
		} else {
			$scope.locationUpdateFlag = true;
		}
	};

	$scope.zoneUpdate = function (arg) {
		$("#showloader").css("display", "block");
		var dataObj = {};
		dataObj.dcName = $scope.dcName;//$scope.dcName
		dataObj.userName = sessionStorage.userName;
		dataObj.zone = $scope.manualZones.zone;//($scope.manualZones.zone == "ALL") ? "" : $scope.manualZones.zone;
		dataObj.lvl = $scope.manualZones.level;//($scope.manualZones.level == "ALL") ? "" : $scope.manualZones.level;
		dataObj.locnBrcd = '';
		dataObj.lockInPlace = arg;

		var url = urlService.ATE_SLOTTING_TJ_ZONE_UPDATE;
		var res = $http.put(url, dataObj, {
			 headers: {'x-api-key': sessionStorage.apikey}		});

		res.success(function (data, status, headers, config) {
			if (data.errorMessage) {
				$scope.isFailed = true;
				$scope.errormessage = data.errorMessage;
				$("#showloader").css("display", "none");
			} else {
				$scope.isSuccess = true;
				$scope.resmessage = data.resMessage;
				$("#showloader").css("display", "none");
			}
		});
		res.error(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			$scope.isFailed = true;
			$scope.errormessage = "System failed. Please try again or contact WAALOS Support";

		});
	};

	$scope.locationUpdate = function () {
	$scope.isFailed = false;
	$scope.isSuccess = false;
	$scope.errormessage = "";
	$scope.resmessage = "";
		var checkedLocations = $(".location_check:checked");
		var locationDetails = "";
		var location;
		if (checkedLocations.length > 0) {
			for (var i = 0; i < checkedLocations.length; i++) {
				locationDetails = locationDetails + "'" + checkedLocations[i].value + "',";
				location = locationDetails.substr(0, locationDetails.lastIndexOf(","));
			}
		}
		else{
				location = "";
		}

			
			
			

			$("#showloader").css("display", "block");
			var dataObj = {};
			dataObj.dcName = $scope.dcName;//$scope.dcName
			dataObj.userName = sessionStorage.userName;
			dataObj.zone = $scope.manualZones.zone;
			dataObj.lvl = $scope.manualZones.level;
			dataObj.locnBrcd = location;
			dataObj.lockInPlace = '';

			var url = urlService.ATE_SLOTTING_TJ_LOCATION_UPDATE;
			var res = $http.put(url, dataObj, {
				 headers: {'x-api-key': sessionStorage.apikey}
			});

			res.success(function (data, status, headers, config) {
				if (data.errorMessage) {
					$scope.isFailed = true;
					$scope.errormessage = data.errorMessage;
					$("#showloader").css("display", "none");
				} else {
					$scope.isSuccess = true;
					$scope.resmessage = data.resMessage;
					$(".location_check").removeAttr("checked");
					$scope.locationUpdateFlag = true;
					$("#showloader").css("display", "none");
				}
			});
			res.error(function (data, status, headers, config) {
				$("#showloader").css("display", "none");
				$scope.isFailed = true;
				$scope.errormessage = "System failed. Please try again or contact WAALOS Support";
			});
		
	};

	$scope.clearMessages = function () {
		$scope.isSuccess = false;
		$scope.isFailed = false;
	};

	/******************manualZones end*************************/


	/******************zonesAutomaticLocking Start*******************************/
	$scope.gridOptions = {
		paginationPageSizes: [15, 25, 50, 100],
		paginationPageSize: 15,
		//useExternalPagination: true,
		enableColumnMenus: false,
		enableSorting: true,
		multiSelect: false,
		enableRowSelection: true,//we can remove it later no use  of this
		enableSelectAll: true,//we can remove it later no use  of this             
		enableCellEdit: true, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
		enableCellEditOnFocus: true // set any editable column to allow edit on focus
	
	};
	$scope.dsGridOptions  = {
		paginationPageSizes: [15, 25, 50, 100],
		paginationPageSize: 15,
		//useExternalPagination: true,
		enableColumnMenus: false,
		enableSorting: true,
		multiSelect: false,
		enableRowSelection: true,//we can remove it later no use  of this
		enableSelectAll: true,//we can remove it later no use  of this             
		enableCellEdit: true, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
		enableCellEditOnFocus: true // set any editable column to allow edit on focus
	};
	$scope.dsReleaseGriddata = {
		enableColumnMenus: false,
		enableSorting: true

	};
	$scope.dsReleaseGriddata.onRegisterApi = function (gridApi) {
	};
	$scope.gridOptions.onRegisterApi = function (gridApi) {
		//set gridApi on scope
		$scope.gridApi = gridApi;

		gridApi.edit.on.afterCellEdit(null, function (rowEntity, colDef, newValue, oldValue) {
		$scope.isSuccessAZ =  false;
		$scope.isFailedAZ = false;
			// if (rowEntity.locationsBlocked == 0 || rowEntity.locationsBlocked == "0" || (rowEntity.locationsBlocked == rowEntity.defaultValue)) {
			// 	rowEntity.locationsBlocked = oldValue;
			// 	$scope.numberValidation = true;
			// } else {
			// 	$scope.numberValidation = false;
			// }
		});
		gridApi.selection.on.rowSelectionChangedBatch($scope, function (row) {
			$scope.isSuccess = false;
			$scope.isFailed = false;
			var rowCount = $scope.gridApi.selection.getSelectedRows().length;
			//$scope.gridApi.selection.setMultiSelect(false);
			if (rowCount != 10 && row[0].isSelected) {
				$scope.isEdit = false;
				//$scope.isDelete = false;
			} else {
				$scope.isEdit = true;
				//$scope.isDelete = true;
			}
			
		});
		gridApi.selection.on.rowSelectionChanged($scope, function (row) {
			
			$scope.numberValidation = false;
			$scope.isSuccess = false;
			$scope.isFailed = false;
			//$scope.gridApi.selection.setMultiSelect(false);
			var rowCount = $scope.gridApi.selection.getSelectedRows().length;
			if (rowCount > 0 && rowCount != 10) {
				$scope.isEdit = false;
				//$scope.isDelete = false;
			} else {
				$scope.isEdit = true;
				//$scope.isDelete = true; 
			}
		});
	};
	$scope.dsGridOptions.onRegisterApi = function (gridApi) {
		//set gridApi on scope
		$scope.gridApi = gridApi;
		gridApi.selection.on.rowSelectionChanged($scope, function (row) { 
			$scope.datascourceTemplateID = row.entity.templateId;
			if (row.isSelected) {
				$scope.isEdit = false; 
			} else {
				$scope.isEdit = true; 		 

			}
		});
		// gridApi.edit.on.afterCellEdit(null, function (rowEntity, colDef, newValue, oldValue) {
		 
		// });
	};

	$scope.zonesAutomaticLocking = function () {
		$scope.tabClicked = 'za';
		$scope.getZonesAutomaticLocationData(urlService.ATE_SLOTTING_SJ_GET_ZONES_AUTOMATIC_LOC_DATA, 'za');
	};
	$scope.fndataSources = function () {
		$scope.tabClicked = 'ds';
		$scope.getZonesAutomaticLocationData(urlService.ATE_SLOTTING_TJ_GET_DATASOURCE_DETAILS, 'ds');
	};
	$scope.getZonesAutomaticLocationData = function (tabUrl, type) {
		$scope.isSuccessAZ = false;
		$scope.isFailedAZ = false;
		$scope.isSuccess = false;
		$scope.isFailed = false;
		$scope.isEdit = true;
		$("#showloader").css("display", "block");

		var url = tabUrl.replace('dName', $scope.dcName);//$scope.pagedc
		url = url.replace('uName', sessionStorage.userName);
		var res = $http.get(url, {
			 headers: {'x-api-key': sessionStorage.apikey}
		});
		res.success(function (data, status, headers, config) {
			
			if (data.errorMessage) {
				$scope.isFailedAZ = true;
				$scope.resmessage = data.errorMessage;
			} else {
				if (type == 'za') {
					$scope.isTable = true;
					$scope.gridOptions.multiSelect = true;
					$scope.gridOptions.columnDefs = [
						{ name: 'zone', displayName: 'Zone', enableCellEdit: false, cellTooltip: true, headerTooltip: true},
						{ name: 'defaultValue', displayName: 'Default Value', enableCellEdit: false, cellTooltip: true, headerTooltip: true },
						{ name: 'changeLocations', displayName: 'Change # Of Locations?', enableCellEdit: false, cellTooltip: true, headerTooltip: true },
						{ name: 'locationsBlocked', displayName: 'Locations Blocked', enableCellEdit: false, cellTooltip: true, headerTooltip: true },
					];
				} else {
					$scope.dsGrid  = true;
					$scope.dsGridPanel = false;
					$scope.dsGridOptions.columnDefs = [
						{ name: 'templateId', displayName: 'Template Id', width: 120,enableCellEdit: false, cellTooltip: true, headerTooltip: true },
						{ name: 'name', displayName: 'Name', enableCellEdit: false,width: 150, cellTooltip: true, headerTooltip: true },
						{ name: 'hasAssoc', displayName: 'Has Slotting Association?', width: 200,enableCellEdit: false, cellTooltip: true, headerTooltip: true },
						{ name: 'hasTasks', displayName: 'Has Unreleased Tasks?',width: 200, enableCellEdit: false, cellTooltip: true, headerTooltip: true},
						{ name: 'lastCompletionTime', displayName: 'Last Completion Time',width: 200, enableCellEdit: false, cellTooltip: true, headerTooltip: true },
						{ name: 'status', displayName: 'Current Status',width: 170, enableCellEdit: false, cellTooltip: true, headerTooltip: true },
						{ name: 'runaslot', displayName: 'Run a Slot', width: 120,enableCellEdit: false, cellTemplate: '<div class="ui-grid-cell-contents"  ng-click=\"grid.appScope.runSlot(grid, row)\"><a href="">Run a Slot</a></div>' },
						{ name: 'releasetasks', displayName: 'Release Tasks', width: 170,enableCellEdit: false, cellTemplate: '<div class="ui-grid-cell-contents"  ng-click=\"grid.appScope.releaseSlot(grid, row)\"><a href="">Release Tasks</a></div>' }
					];

				} 
				if(type == 'ds'){
					 $scope.dsGridPanel = false;
					$scope.dsGridOptions.data = data;
				}else{
					$scope.gridOptions.data = data;
				}
				$scope.gridOptions.cellEditableCondition = function ($scope) {
					if (($scope.row.entity.locationsBlocked != "0" || $scope.row.entity.locationsBlocked != 0) && ($scope.row.entity.locationsBlocked != $scope.row.entity.defaultValue)) {
						return $scope.row.entity.locationsBlocked;
					}
				};
				 
				if ($scope.gridOptions.data > 10) {
					$scope.gridOptions.enableVerticalScrollbar = true;
					$scope.gridOptions.enableHorizontalScrollbar = 1;
				} else {
					$scope.gridOptions.enableVerticalScrollbar = false;
					$scope.gridOptions.enableHorizontalScrollbar = 1;
				}
			}
			$('.ui-grid-pager-control input').prop("disabled", true);
			$("#showloader").css("display", "none");
		});
		res.error(function (data, status, headers, config) {
			$scope.isTable = false;
			$scope.dsGrid = false;
			$("#showloader").css("display", "none");
			$scope.isFailed = true;
			$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
		});
	};
	//function to get back to the datasource tab data
	$scope.goBack = function(type){
		if(type == 'release'){
			$scope.isReleseTask = false;
			$scope.isMianpage = true;
			$scope.fndataSources();
		}
		$scope.dsGrid = true;
		$scope.dsGridPanel = false;
		$scope.dsReleaseGrid = false;
		$scope.isEdit = true;
		
	};
	$scope.locationsUsagePreview = [
		{name:"Available",isChedked : false},
		{name : "Filled Locations",isChedked : false},
		{name : "SKU's Excluded",isChedked : false},
		{name : "SKU's Move Location",isChedked : false},
		{name : "Locations Utilised",isChedked : false},
		{name : "Locations Remaining",isChedked : false},
		{name : "Locations Went Negative",isChedked : false}
	];
	//function to save generate and reset the edited datasource selected row
	$scope.fnSaveorGenerate = function(type){
		$scope.isSuccessDS = false;
		$scope.isFailedDS = false; 
		$("#showloader").css("display", "block");
		var url;
		if($scope.ZoneValue == "0"){
			$scope.defaultLocations= " ";
		}else{
			$scope.defaultLocations = $scope.defaultLocationValue;
		}
		if(type == "save"){
			var dataObj = {
                "dcName" : $scope.dcName,
                "userName" : sessionStorage.userName,
                "defaultLocnsBlock" : $scope.defaultLocations,
                "templateId" : $scope.datascourceTemplateID,
                "zoneLock" : $scope.ZoneValue,
                "minSKU" : $scope.forecastValues.minCasesPerSku,
                "maxSKU" : $scope.forecastValues.maxCasesPerSku,
                "forecastFile" : $scope.forecastValues.forecastFile
				};
			 
			url = urlService.EDIT_SCREEN_SAVE;
			var res = $http.post(url, dataObj, {
				 headers: {'x-api-key': sessionStorage.apikey}
			});
			
			res.success(function (data, status, headers, config) {
				
				$("#showloader").css("display", "none");
				if (data.errorMessage) {
					$scope.isSuccessDS = false;
					$scope.isFailedDS = true;
					$scope.resmessage = data.errorMessage;
				
				} else { 
					$scope.editDataSources();
					$scope.isSuccessDS = true;
					$scope.isFailedDS = false;
					$scope.resmessage = data.resMessage;
					
				}
			});
			res.error(function (data, status, headers, config) {
				
				$scope.isFailedAZ = true;
				$scope.isFailedAZ = true;
				$scope.resmessage = "System failed. Please try again or contact WAALOS Support";

			});
			
		}else if(type == "generate"){
			url = urlService.DATASOURCE_GENERATE_EDIT_SCREEN.replace('dName',$scope.dcName);
			url = url.replace('uName',sessionStorage.userName);
			$http.get(url,{
			 headers: {'x-api-key': sessionStorage.apikey}
			}).success(function(data){
				if (data.errorMessage) {  
					$scope.isSuccessDS = false;
					$scope.isFailedDS = true;
					$scope.resmessage = data.errorMessage;
					$("#showloader").css("display", "none");
				}else if(data.resMessage){
					$scope.isSuccessDS = true;
					$scope.isFailedDS = false; 
					$scope.resmessage = data.resMessage;
			 
					$("#showloader").css("display", "none");
					
				} else {  
					//$('#ateTJSlottingAlert').modal("show");
					$("#showloader").css("display", "none");
				}
			}).error(function(data){
				$scope.isSuccessDS = false;
				$scope.isFailedDS = true;
				$scope.resmessage = data;
				$("#showloader").css("display", "none");
			});
			
			
		}else{
			$scope.forecastValues.forecastFile = '';
			$scope.forecastValues.minCasesPerSku = '';
			$scope.forecastValues.maxCasesPerSku = '';
			$scope.defaultLocationValue  = '';
			$("#showloader").css("display", "none");
		}
	};

	$scope.runSlot = function(grid,row){
		if (grid) {
			$("#ateTJSlottingAlert").modal('show'); 
			$scope.runASlot = row;
		} else {
			$('#ateTJSlottingAlert').modal("hide");
			if($scope.runASlot.entity.hasAssoc == 'Y'){
				$("#showloader").css("display", "block");
				 var url =urlService.RUN_A_SLOT.replace('dName',$scope.dcName).replace('uName',sessionStorage.userName); 
				$http.get(url,{
					 headers: {'x-api-key': sessionStorage.apikey}
				})
				.success(function(data){
					if (data.errorMessage) {
					 
						$("#showloader").css("display", "none");
						$scope.resmessage = data.errorMessage;
						$scope.isFailed = true;
						$scope.isSuccess = false;
						}else if(data.resMessage){ 
						$("#showloader").css("display", "block");
						setTimeout(function(){ 
						$("#showloader").css("display", "none");
						$scope.fndataSources();
						$scope.resmessage = data.resMessage; 
						$scope.isFailed = false;
						$scope.isSuccess = true;
						}, 10000);
												
						
					} else { 
						$("#showloader").css("display", "block");
						setTimeout(function(){ 
						$("#showloader").css("display", "none");
						}, 10000);
						$scope.fndataSources();
						$scope.resmessage = data.resMessage; 
						$scope.isFailed = false;
						$scope.isSuccess = true;
						$("#showloader").css("display", "none");
					}
				}).error(function(data){
					$("#showloader").css("display", "none");
					$scope.isFailed = true;
					$scope.isSuccess = false;
					$scope.resmessage = data;
				});
			 }else{
				 return false;
			 }
		}
		 
	};
	$scope.releaseSlot = function(grid,row){
		$scope.isFailed = false;
		$scope.isSuccess = false;
		if(row.entity.hasAssoc == 'Y'){
			$scope.dsGrid = false;
			$scope.dsGridPanel = false;
			$scope.isEdit = false;
			$scope.dsReleaseGrid = true;
			$scope.isReleseTask = true;
			$scope.isMianpage = false;
		}else{
			return false;
		}
	};
	$scope.saveZonesAutomaticData = function () {
		$scope.isFailedAZ = false;
		$scope.isSuccessAZ = false;
		//$scope.numberValidation = false;

		$("#showloader").css("display", "block");
		var selected_rows = $scope.gridApi.selection.getSelectedRows();
		var dataObj = [];
		for (var i = 0; i < selected_rows.length; i++) {
			var obj = {};
			obj.dcName = $scope.dcName;
			obj.userName = sessionStorage.userName;
			obj.zone = selected_rows[i].zone.charAt(0);
			obj.lvl = selected_rows[i].zone.charAt(selected_rows[i].zone.length - 1);
			obj.rowNum = i+1;
			dataObj.push(obj);
		}

		var url = urlService.ATE_SLOTTING_SJ_UPDATE_ZONE_AUTOMATIC_LOC.replace("dName", $scope.dcName);
		var res = $http.put(url, dataObj, {
			 headers: {'x-api-key': sessionStorage.apikey}
		});
		res.success(function (data, status, headers, config) {
			if (data.errorMessage) {
				$scope.isFailedAZ = true;
				$scope.errormessage = data.errorMessage;
				$("#showloader").css("display", "none");
			} else {
				$scope.zonesAutomaticLocking();
				$scope.isSuccessAZ = true;
				$scope.isEdit = true;
				$scope.resmessage = data.resMessage;
				$("#showloader").css("display", "none");
			}
		});
		res.error(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			$scope.isFailedAZ = true;
			$scope.errormessage = "System failed. Please try again or contact WAALOS Support";

		});
	};

	$scope.gridOptions.isRowSelectable = function (row) {
		 	if($scope.tabClicked == 'za'){
				if (row.entity.locationsBlocked == 0 || row.entity.locationsBlocked == "0" || (row.entity.locationsBlocked == row.entity.defaultValue)) {
					return false;
				} else {
					return true;
				}
			 } 
	};
	$scope.dsGridOptions.isRowSelectable = function (row) {
		   if (row.entity.hasAssoc == 'Y'){
			   return true;
		   } else {
			   return false;
		   }
		
};

	$scope.fndataSources();
	$scope.slottype ={
		slottype : 'Deslot'
	}; 
$scope.fnDsRelease = function(type){
	$scope.isSuccess = false;
	$scope.isFailed = false;
	$scope.releaseGriddata = false;
	$("#showloader").css("display", "block");
	var url;
	if(type == 'add'){
		url ='';
		if($scope.slottype.slottype == 'Deslot'){
			url = urlService.ADD_DESLOT.replace('dName',$scope.dcName).replace('uName',sessionStorage.userName);
			url = url.replace('slottype',$scope.slottype.slottype);
		}else{
			url = urlService.ADD_NEW_SLOT.replace('dName',$scope.dcName).replace('uName',sessionStorage.userName);
			url = url.replace('slottype',$scope.slottype.slottype);
		}   
		$http.get(url,{
			 headers: {'x-api-key': sessionStorage.apikey}
		})
.success(function(data){
			
			if (data.errorMessage) { 
				$scope.isSuccess = false;
				$scope.isFailed = true;
				$scope.resmessage = data.errorMessage;  
				$("#showloader").css("display", "none");
				$scope.dsReleaseGriddata.data = [];
				$scope.resmessage = data.errorMessage;
			}else if(data.resMessage){ 
				$scope.isSuccess = true;
				$scope.isFailed = false; 
				$scope.dsReleaseGriddata.data = [];
				$scope.resmessage = data.resMessage; 
				$("#showloader").css("display", "none");
				
			} else {   
				$scope.dsReleaseGriddata.columnDefs = [
					{ name: 'fromZone', displayName: 'From Zone', enableCellEdit: false, cellTooltip: true, headerTooltip: true },
					{ name: 'fromLocn', displayName: 'From Location', enableCellEdit: false, cellTooltip: true, headerTooltip: true },
					{ name: 'displaySKU', displayName: 'Display SKU', enableCellEdit: false, cellTooltip: true, headerTooltip: true },
					{ name: 'actualInventory', displayName: 'Actual Inventory', enableCellEdit: false, cellTooltip: true, headerTooltip: true},
					{ name: 'toZone', displayName: 'To Zone', enableCellEdit: false, cellTooltip: true, headerTooltip: true },
					{ name: 'toLocn', displayName: 'To Location', width: 130,enableCellEdit: false, cellTooltip: true, headerTooltip: true},
					{ name: 'division', displayName: 'Division', width: 120,enableCellEdit: false, cellTooltip: true, headerTooltip: true }
				];
				$scope.releaseGriddata = true;
				$scope.releaseGrid = false;
				$scope.dsReleaseGriddata.data = data;
				if ($scope.dsReleaseGriddata.data > 10) {
					$scope.dsReleaseGriddata.enableVerticalScrollbar = true;
					$scope.dsReleaseGriddata.enableHorizontalScrollbar = 1;
				} else {
					$scope.dsReleaseGriddata.enableVerticalScrollbar = false;
					$scope.dsReleaseGriddata.enableHorizontalScrollbar = 1;
				}
				$("#showloader").css("display", "none");
			}
		}).error(function(data){ 
			$scope.isSuccess = false;
			$scope.isFailed = true;
			$scope.resmessage = data;   
			$("#showloader").css("display", "none");
		});
	}else if(type == 'release'){
		 url = $scope.slottype.slottype == 'Deslot' ? urlService.DESLOT_RELEASE : urlService.NEW_SLOT_RELEASE;
		var data = {
			"dcName" : $scope.dcName,
			"userName" : sessionStorage.userName,
			"templateId" : $scope.datascourceTemplateID,
			"workType" : $scope.slottype.slottype
		};
		$http.put(urlService.DESLOT_RELEASE,data,{
			 headers: {'x-api-key': sessionStorage.apikey}
		})
		.success(function(data){
			if (data.errorMessage) { 
				$("#showloader").css("display", "none"); 
				$scope.isSuccess = false;
				$scope.isFailed = true;
				$scope.resmessage = data.errorMessage; 
			}else if(data.resMessage){
				$scope.resmessage = data.resMessage; 
				$scope.goBack('release');
				 
				$timeout(function(){
					
				$scope.isSuccess = true;
				$scope.isFailed = false;
				$("#showloader").css("display", "none");
							},2000);
			} else {  
				$scope.resmessage = data.resMessage; 
				$scope.goBack('release');
				 
				$timeout(function(){
					
				$scope.isSuccess = true;
				$scope.isFailed = false;
				$("#showloader").css("display", "none");
							},2000);
			}
		}).error(function(data){
			$("#showloader").css("display", "none"); 
				$scope.isSuccess = false;
				$scope.isFailed = true;
				$scope.resmessage = data.errorMessage; 
		});
	}else if(type == 'reset'){
		 url = urlService.RUN_A_SLOT.replace('dName',$scope.dcName).replace('uName',sessionStorage.userName);
		 
		$http.get(url,{headers:{}}).success(function(data){
			
			if (data.errorMessage) { 
				$scope.isSuccess = false;
				$scope.isFailed = true;
				$("#showloader").css("display", "none");
				$scope.resmessage = data.errorMessage;
			}else if(data.resMessage){
				$scope.isSuccess = true;
				$scope.isFailed = false;
				$scope.resmessage = data.resMessage; 
				$("#showloader").css("display", "none");
				
			} else {  
				$scope.isSuccess = true;
				$scope.isFailed = false; 
				$("#showloader").css("display", "none");
			}
		}).error(function(data){
			$scope.isSuccess = false;
				$scope.isFailed = true;
			$scope.resmessage = data.errorMessage;
			$("#showloader").css("display", "none");
		});
	}
};

$scope.releaseGrid = true;
	$scope.editDataSources = function () {
		$scope.dsGrid = false;
		$scope.dsGridPanel = true;
		$scope.isSave = false;
		$scope.isFailed = false;
		$scope.isSuccess = false;
		$scope.isEdit = false;
		$("#showloader").css("display", "block");
		var url = urlService.ATE_SLOTTING_TJ_EDIT_DATASOURCE.replace('dName', $scope.pagedc);
		url = url.replace('uName', sessionStorage.userName);
		url = url.replace('gType', $scope.datascourceTemplateID);
		$scope.grpType =  $scope.datascourceTemplateID;
		var res = $http.get(url, {
			 headers: {'x-api-key': sessionStorage.apikey}

		}); 
		res.success(function (data, status, headers, config) {
			$scope.forecastValues.forecastFile = data[0].forecastFile;
			$scope.forecastValues.minCasesPerSku = data[0].minSKU;
			$scope.forecastValues.maxCasesPerSku = data[0].maxSKU;
			$scope.initialForeCastValues = data[0];
			$scope.ZoneValue = data[0].zoneLock;
			//if($scope.ZoneValue == "0"){
			//	$scope.defaultLocationValue= "";
			//}else{
				$scope.defaultLocationValue = data[0].defaultLocnsBlock;
				$scope.defaultLocationDefault = data[0].defaultLocnsBlock;
			//}
			if(data[0].defaultLocnsBlock == "0" || data[0].defaultLocnsBlock == "18"){
				$scope.isEdit = true;
			}else{
				$scope.isEdit = false;
			}
		
			$("#showloader").css("display", "none"); 
		});
		res.error(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			$scope.isFailed = true;
			$scope.resmessage = "System failed. Please try again or contact WAALOS Support";

		});
	};
	$scope.resetForecastValues = function(){
		//$scope.initialForeCastValues
		$scope.forecastValues = {
			forecastFile : $scope.initialForeCastValues.forecastFile,
			minCasesPerSku : $scope.initialForeCastValues.minSKU,
			maxCasesPerSku : $scope.initialForeCastValues.maxSKU	
		};
	};

	$scope.resetRelase = function(){
		$scope.isSuccess = false;
		$scope.isFailed = false;
		$scope.slottype.slottype = 'Deslot';
		$scope.releaseGriddata = false;
		$scope.releaseGrid = true;
	};

	$scope.reset = function () {
		$scope.isSuccess = false;
		$scope.isFailed = false;
	
		$("#showloader").css("display", "block");
		var dataObj = {
			"dcName": $scope.pagedc,
			"userName": sessionStorage.userName
		};

		var res = $http.put(urlService.RESET_DATA_SOURCE, dataObj, {
			 headers: {'x-api-key': sessionStorage.apikey}

		}); 
		res.success(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			if (data.errorMessage) {
				$scope.isFailed = true;
				$scope.resmessage = data.errorMessage;
			} else if (data.resMessage) {

				$("#resetModal").modal('show');

				$scope.resmessagereset = data.resMessage;
			}

		});
		res.error(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			$scope.isFailed = true;
			$scope.resmessage = "System failed. Please try again or contact WAALOS Support";

		});
	};

	$scope.orderFuturedata = function (type,data) {
		var numbers = /^[0-9]+$/;
		if(type == 'min'){
			if (data == "" || data == null || !(data.match(numbers)) ) {
				$scope.minFlag = true;
				$scope.isEdit = true;
			} else {
				$scope.minFlag = false;
				$scope.isEdit = false;
			}
		}else if(type == 'max'){
			if (data == "" || data == null || !(data.match(numbers)) ) {
				$scope.maxFlag = true;
				$scope.isEdit = true;
			} else {
				$scope.maxFlag = false;
				$scope.isEdit = false;
			}
		}else{
		       if (data == "" || data == null || data < 1 || data>17 ) { 
				$scope.zoneLockFlag = true;
				$scope.isEdit = true;
			} else {
				$scope.zoneLockFlag = false;
				$scope.isEdit = false; 
				$scope.defaultLocationValue= data;
				
			}
		}
	};
	 
	$scope.enableButtons = function(bool,data){

		if(bool == '0'){
			$scope.zoneLockFlag = false; 
			$scope.isEdit = false;
			$scope.ZoneValue = "0";
			$scope.defaultLocationValue = $scope.defaultLocationDefault;
		}else{
			$scope.zoneLockFlag = false;
			$scope.isEdit = true;
			$scope.ZoneValue = "1";
			$scope.defaultLocationValue = $scope.defaultLocationDefault;
		}
		
	};
//user favourites code start
$scope.isClicked = false;

$scope.addToFavourate = function(isClicked){
    $("#showloader").css("display", "block");
     if(typeof isClicked !== "boolean"){
      commonService.postServiceResponse(urlService.GET_FAVOURITES,{"username": sessionStorage.userName})
        .then(function(response){
          $("#showloader").css("display", "none");
            _.each(response,function(val,key){
              if(val.funName == $scope.functionality && val.dcName == $scope.dcName){
                $scope.isClicked = true;      
              }
            });
        },function(error){
          $("#showloader").css("display", "none");
          $scope.isClicked = false; 
        });
        //$scope.isClicked = ;
     }else{
      if(!$scope.isClicked){
        commonService.postServiceResponse(urlService.ADD_FAVOURITE,{"username": sessionStorage.userName,"dcName":$scope.dcName,"funName":$scope.functionality})
        .then(function(response){
          $("#showloader").css("display", "none");
          if(response.errorMessage){
            $scope.isFavouriteAdded= false; 
            $scope.isClicked = false;      
            $scope.$broadcast('showAlert',['']);
          }else{
            $scope.isClicked = true;      
            $scope.isClicked = !isClicked;
            $scope.isFavouriteAdded= true; 
            $scope.favouriteMsg = response.resMessage;
          $scope.$broadcast('ClickedOnFavourate',[$scope.dcName,$scope.functionality,$scope.isClicked]);
          }
            
        },function(error){
          $scope.isClicked = false;
          $("#showloader").css("display", "none");
        });
        $scope.isClicked = !isClicked;
      }else{
        $("#showloader").css("display", "none");
      }
     }
    
  };
  $scope.addToFavourate('load');
  //user favourites code ends
}]);