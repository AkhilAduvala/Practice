var app = angular.module('WmUserAddition', ['ui.grid.pagination', 'ngAnimate', 'ui.grid', 'ui.grid.selection', 'ui.bootstrap', 'ui.grid.autoResize']);
app.controller('WmUserAdditionCtrl', ['$scope', '$http', '$q', '$interval', '$rootScope', 'uiGridValidateService', '$timeout', 'urlService', 'uiGridConstants', 'commonService', function ($scope, $http, $q, $interval, $rootScope, uiGridValidateService, $timeout, urlService, uiGridConstants, commonService) {

	$scope.isTable = false;
	$scope.isSuccess = false;
	$scope.isFailed = false;
	$scope.isAdd = true;
	$scope.isDelete = false;
	$scope.disable = true;
	$scope.pagefunctionality = $scope.functionality;
	$scope.pagedc = $scope.dcName;
	
	$scope.deletebutton = true;

	$scope.checkValidation = function(){
		
		if($scope.delUserId == '' || $scope.delUserId == null || $scope.delUserId == undefined ) {
			$scope.deletebutton = true;
		}else{
			$scope.deletebutton = false;
		}
	};

	$scope.ValidateChange = function () {
$scope.isSuccess = false;
	$scope.isFailed = false;
        var reg = /^[0-9a-zA-Z\- ]+$/;
		if ( $scope.empID != "" || $scope.Fname != "" || $scope.Lname != ""  ) {
			$scope.disable = false;
		} else {
			$scope.disable = true;
		}
if($scope.empID){
if(reg.test($scope.empID)){
$scope.disable = false;
}else{
$scope.disable = true; 
$scope.isFailed = true; 
$scope.resmessage = "Please enter valid data";}
}

if($scope.Fname){
if(reg.test($scope.Fname)){$scope.disable = false;}else{$scope.disable = true; $scope.isFailed = true; $scope.resmessage = "Please enter valid data";}
}

if($scope.Lname){
if(reg.test($scope.Lname)){$scope.disable = false;}else{$scope.disable = true; $scope.isFailed = true; $scope.resmessage = "Please enter valid data";}
}

	};

	/* $scope.empIdChange = function () {
		if ($scope.empID == "" || $scope.empID == undefined) {
			$scope.disable = true;
		} else {
			$scope.disable = false;
		}
	};

	$scope.firstNameChange = function () {
		if ($scope.Fname == "" || $scope.Fname == undefined) {
			$scope.disable = true;
		} else {
			$scope.disable = false;
		}
	};

	$scope.lastNameChange = function () {
		if ($scope.Lname == "" || $scope.Lname == undefined) {
			$scope.disable = true;
		} else {
			$scope.disable = false;
		}
	};*/
	$scope.gridOptions = {
		paginationPageSizes: [15, 25, 50, 100],
		paginationPageSize: 15,
		useExternalPagination: true,
		enableSorting: true,
		enableColumnMenus: false,
		multiSelect: false,
		enableHorizontalScrollbar: false,

	};

	$scope.gridOptions.columnDefs = [
		{ name: 'empUserId', displayName: 'Employee ID', enableCellEdit: false, cellTooltip: true, headerTooltip: true },
		{ name: 'firstName', displayName: 'First Name', cellTooltip: true, headerTooltip: true, enableCellEdit: false },
		{ name: 'middleName', displayName: 'Middle Name', cellTooltip: true, headerTooltip: true, enableCellEdit: false },
		{ name: 'lastName', displayName: 'Last Name', cellTooltip: true, headerTooltip: true, enableCellEdit: false },
		{ name: 'sysDate', displayName: 'Start Date', cellTooltip: true, headerTooltip: true, enableCellEdit: false },
		{ name: 'dept', displayName: 'Department', cellTooltip: true, headerTooltip: true, enableCellEdit: false },
		{ name: 'projectedId', displayName: 'MH User ID', visible: true, cellTooltip: true, headerTooltip: true, enableCellEdit: false },
		{ name: 'alreadyExists', displayName: 'Is Exists', cellTooltip: true, headerTooltip: true, enableCellEdit: false, visible: false },
		{ name: 'pageNumber', displayName: 'pageNumber', visible: false },
		{ name: 'pageSize', displayName: 'pageSize', visible: false },
		{ name: 'empId', displayName: 'MH User ID', visible: false }

	];

	$scope.gridOptions.onRegisterApi = function (gridApi) {
		$scope.gridApi = gridApi;
		$scope.gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
			$scope.pageNo = newPage;
			$scope.pageSize = pageSize;
			$scope.getuserdata();
		});

		gridApi.selection.on.rowSelectionChanged($scope, function (row) {
			$scope.isSuccess = false;
			$scope.isFailed = false;
			if ($scope.gridApi.selection.getSelectedRows().length > 0) {
				var lname = row.entity.lastName;
				var fname = row.entity.firstName;
				if((lname&&lname.length>=5) && (fname&&fname.length>=3))
				{	
					var proid = lname.substring(0, 5) + fname.substring(0, 3);
				}	
				//console.log(proid);


				if (row.entity.alreadyExists == 'Y') {
					$scope.isDelete = false;
					$scope.isAdd = true;
				} else {
					$scope.isDelete = true;
					$scope.isAdd = false;
				}

			} else {
				$scope.isDelete = false;
				$scope.isAdd = true;
			}

		});
	};

	$scope.getuserdata = function () {
		$scope.isTable = false;
		$scope.isSuccess = false;
		$scope.isFailed = false;
		$scope.isAdd = true;
		$scope.isDelete = false;
		$scope.isBack = false;
		$scope.empID = "";
		$scope.Fname = "";
		$scope.Lname = "";
		$scope.disable = true;
		$("#showloader").css("display", "block");
		$scope.pageNo = $scope.pageNo ? $scope.pageNo : 1;
		$scope.pageSize = $scope.pageSize ? $scope.pageSize : $scope.gridOptions.paginationPageSize;

		var url = urlService.WM_USER_MGMT_ALL_USER_DATA.replace('dName', $scope.pagedc);
		url = url.replace('uName', sessionStorage.userName);
		url = url.replace('pNumber', $scope.pageNo);
		url = url.replace('pSize', $scope.pageSize);

		var res = $http.get(url, { headers: { 'x-api-key': sessionStorage.apikey } });
		res.success(function (data, status, headers, config) {

			if (data.errorMessage) {
				$scope.isFailed = true;
				$scope.resmessage = data.errorMessage;
				$("#showloader").css("display", "none");
			} else if (data.resMessage) {
				$scope.isSuccess = true;
				$scope.resmessage = data.resMessage;
				$("#showloader").css("display", "none");
			}
			else if (data.pageItems) {
				angular.forEach(data.pageItems, function (abc, index) {
					if (abc.alreadyExists == 'N') {
						abc.projectedId = "";
					}
				});
		
				$("#showloader").css("display", "none");
				$scope.isTable = true;
				$scope.gridOptions.totalItems = data.totalNoOfRecords;
				$scope.gridOptions.data = data.pageItems;
				if ($scope.gridOptions.data > 10) {
					$scope.gridOptions.enableVerticalScrollbar = true;
				} else {
					$scope.gridOptions.enableVerticalScrollbar = false;
					$scope.gridOptions.enableHorizontalScrollbar = 0;
				}

				$('.ui-grid-pager-control input').prop("disabled", true);
				$scope.disableinput();
			}
		});
		res.error(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			$scope.isFailed = true;
			$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
		});
	};


	$scope.getuserdata();




	$scope.searchRecords = function () {
		$scope.resmessage = "";
		$scope.isSuccess = false;
		$scope.isFailed = false;



		$("#showloader").css("display", "block");
		if ($scope.empID == undefined) {
			$scope.empID = "";
		}

		if ($scope.Fname == undefined) {
			$scope.Fname = "";
		}

		if ($scope.Lname == undefined) {
			$scope.Lname = "";
		}

		var url = urlService.WM_SEARCH_USERS.replace('dName', $scope.pagedc);
		url = url.replace('uName', sessionStorage.userName);

		url = url.replace('emID', $scope.empID);
		url = url.replace('fName', $scope.Fname);
		url = url.replace('lName', $scope.Lname);


		//var res = $http.get(url);
		var res = $http.get(url, {
			headers: { 'x-api-key': sessionStorage.apikey }
		});


		res.success(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			angular.forEach(data, function (abc, index) {
				if (abc.alreadyExists == 'N') {
					abc.projectedId = "";
				}
			});

			if (data.errorMessage) {
				$scope.isTable = false;
				$scope.isFailed = true;
				$scope.resmessage = data.errorMessage;
			}
			else if (data.resMessage) {
				$scope.isTable = false;
				$scope.isSuccess = true;
				$scope.resmessage = data.resMessage;
				$scope.isBack = true;
			}
			else if (data.length === 0) {
				$scope.isTable = false;
				$scope.isFailed = true;
				$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
			}
			else {
				$scope.isBack = true;
				$scope.isTable = true;

				$('.ui-grid-pager-panel').css("display", "none");
				$scope.gridOptions.data = data;

				if ($scope.gridOptions.data > 10) {
					$scope.gridOptions.enableVerticalScrollbar = true;
				} else {
					$scope.gridOptions.enableVerticalScrollbar = false;
					$scope.gridOptions.enableHorizontalScrollbar = 0;

				}
				$('.ui-grid-pager-control input').prop("disabled", true);

			}
		});
		res.error(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			$scope.isTable = false;
			$scope.isFailed = true;
			$scope.isBack = true;
			$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
		});
		$scope.disableinput();
	};

	$scope.disableinput = function () {
		setTimeout(function () { $('.ui-grid-pager-control-input').attr("disabled", true); }, 2000);

	};

	$scope.toggleDelModel = function () {
			if($scope.gridApi.selection.getSelectedRows().length > 0){	
				$("#deleteModel").modal();
			}
			else{
				$("#deleteuser").modal();
			}
	}	

	$scope.delRow = function () {
		$("#deleteuser").modal('hide');
		var mhuserId; 
		$scope.resmessage = "";
		$scope.isSuccess = false;
		$scope.isFailed = false;
		mhuserId = $scope.delUserId;
		//$("#myModal").modal('hide');
		$("#showloader").css("display", "block");
		if($scope.gridApi.selection.getSelectedRows().length > 0){
			var lname = $scope.gridApi.selection.getSelectedRows()[0].lastName;
			var fname = $scope.gridApi.selection.getSelectedRows()[0].firstName;
			if((lname&&lname.length>=5) && (fname&&fname.length>=3)){	
			var proid = lname.substring(0, 5) + fname.substring(0, 3);
			}
        }
		if(!mhuserId){		
			mhuserId = $scope.gridApi.selection.getSelectedRows()[0].projectedId;
		}	
		if (proid == 'MANH' || proid == 'WMOS' || proid == 'BRIDGE' || proid == 'TOWNEBUR' || proid == 'BOLTPHI' || proid == 'CUBISCAN') {
			$scope.isDelete = true;
			$scope.isAdd = true;
			$scope.isSuccess = true;
			$scope.resmessage = "User Cannot be deleted";
			$("#showloader").css("display", "none");
			return false;
		}
		var url = urlService.WM_DELETE_USER_DATA.replace('dName', $scope.dcName);
		url = url.replace('uName', sessionStorage.userName);
		url = url.replace('empId', mhuserId);

		var res = $http.delete(url, {
			headers: { 'x-api-key': sessionStorage.apikey }
		});

		res.success(function (data, status, headers, config) {
			$("#showloader").css("display", "none");

			if (data.errorMessage) {
				$scope.delUserId="";
				$scope.isFailed = true;
				$scope.resmessage = data.errorMessage;
			}
			else {
				$scope.delUserId="";
				$scope.getuserdata();
				$scope.isSuccess = true;
				$scope.resmessage = data.resMessage;

			}
		});
		res.error(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			$scope.isFailed = true;
			$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
		});
	};


	$scope.addRow = function (arg) {
		$scope.isFailed = false;
		$scope.isSuccess = false;
		$scope.resmessage = "";
	        $("#showloader").css("display", "block");
		//  $("#addModel").modal('hide');
                $scope.pageNo = $scope.pageNo ? $scope.pageNo : 1;
		$scope.pageSize = $scope.pageSize ? $scope.pageSize : $scope.gridOptions.paginationPageSize;
		var obj = {};
		obj.empUserId = $scope.gridApi.selection.getSelectedRows()[0].empUserId;
		obj.firstName = $scope.gridApi.selection.getSelectedRows()[0].firstName;
		obj.middleName = $scope.gridApi.selection.getSelectedRows()[0].middleName;
		obj.lastName = $scope.gridApi.selection.getSelectedRows()[0].lastName;
		obj.dept = $scope.gridApi.selection.getSelectedRows()[0].dept;
		obj.empId = $scope.gridApi.selection.getSelectedRows()[0].empId;
		obj.projectedId = null;
		 obj.pageNumber =  $scope.pageNo;
		obj.pageSize = $scope.pageSize;

		//obj.pageNumber = $scope.gridApi.selection.getSelectedRows()[0].pageNumber;
		//obj.pageSize = $scope.gridApi.selection.getSelectedRows()[0].pageSize;
		obj.dcName = $scope.dcName;
		obj.userName = sessionStorage.userName;
		obj.sysDate = $scope.gridApi.selection.getSelectedRows()[0].sysDate;
                obj.cloneUserId = $scope.cloneId;

		
		var url = urlService.WM_ADD_USER_DATA;

		var res = $http.post(url, obj, {
			headers: { 'x-api-key': sessionStorage.apikey }
		});
		res.success(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			if (data.errorMessage) {
				$scope.isFailed = true;
				$scope.resmessage = data.errorMessage;
			        $("#addModel").modal('hide');

			}else if(data.resCode == "WMS9102"){
				$scope.isError = true;
				$scope.errorcode = data.resMessage;
				$("#addModel").modal('show');
			} else {
				$("#addModel").modal('hide');
				$scope.getuserdata();
				$scope.isSuccess = true;
				$scope.resmessage = data.resMessage;
				
			}
		});
		res.error(function (data, status, headers, config) {
			$scope.isFailed = true;
			$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
			$("#showloader").css("display", "none");
                        $("#addModel").modal('hide');
		});
	};


	$scope.addpopup = function () {

		$scope.isFailed = false;
		$scope.isSuccess = false;
		$scope.resmessage = "";
		$("#showloader").css("display", "block");
		$scope.cloneId = "";
		$scope.iscloneId = true;
		$scope.isError = false;
                $scope.pageNo = $scope.pageNo ? $scope.pageNo : 1;
		$scope.pageSize = $scope.pageSize ? $scope.pageSize : $scope.gridOptions.paginationPageSize;
		var obj = {};
		obj.empUserId = $scope.gridApi.selection.getSelectedRows()[0].empUserId;
		obj.firstName = $scope.gridApi.selection.getSelectedRows()[0].firstName;
		obj.middleName = $scope.gridApi.selection.getSelectedRows()[0].middleName;
		obj.lastName = $scope.gridApi.selection.getSelectedRows()[0].lastName;
		obj.dept = $scope.gridApi.selection.getSelectedRows()[0].dept;
		obj.empId = $scope.gridApi.selection.getSelectedRows()[0].empId;
		obj.projectedId = null;
                obj.pageNumber =  $scope.pageNo;
		obj.pageSize = $scope.pageSize;

		//obj.pageNumber = $scope.gridApi.selection.getSelectedRows()[0].pageNumber;
		//obj.pageSize = $scope.gridApi.selection.getSelectedRows()[0].pageSize;
		obj.dcName = $scope.dcName;
		obj.userName = sessionStorage.userName;
		obj.sysDate = $scope.gridApi.selection.getSelectedRows()[0].sysDate;

		var url = urlService.WM_ADD_USER_GENARATE;

		var res = $http.post(url, obj, {
			headers: { 'x-api-key': sessionStorage.apikey }
		});

		res.success(function (data, status, headers, config) {

			$("#showloader").css("display", "none");
			if (data.errorMessage) {
				$("#addModel").modal('hide');
				$scope.isFailed = true;
				$scope.resmessage = data.errorMessage;

			}
			else {
				$("#addModel").modal('show');
				$scope.generatedId = data.resMessage;
			}
		});
		res.error(function (data, status, headers, config) {
			$scope.isFailed = true;
			$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
			$("#showloader").css("display", "none");
		});

	};
$scope.iscloneId = true;
$scope.isError = false;
	$scope.Changecloneid = function(){
		$scope.isFailed = false;
		$scope.isSuccess = false;
		$scope.resmessage = "";
		
		var reg = /^[0-9a-zA-Z\_ ]+$/;
		if($scope.cloneId == "" || $scope.cloneId == undefined || $scope.cloneId == null || $scope.cloneId.length > 20 || $scope.cloneId == 32 || !(reg.test($scope.cloneId)) ){
			$scope.iscloneId = true;
			$scope.isError = true;
			$scope.errorcode = "Please enter valid ConeID";
			
		}else{
			$scope.iscloneId = false;
			$scope.isError = false;
		}
	};

$scope.closeModel = function(){
$("#addModel").modal('hide');
};

	//user favourites code start
	$scope.isClicked = false;
	$scope.addToFavourate = function (isClicked) {
		$("#showloader").css("display", "block");
		if (typeof isClicked !== "boolean") {
			commonService.postServiceResponse(urlService.GET_FAVOURITES, { "username": sessionStorage.userName })
				.then(function (response) {
					$("#showloader").css("display", "none");
					_.each(response, function (val, key) {
						if (val.funName == $scope.functionality && val.dcName == $scope.dcName) {
							$scope.isClicked = true;
						}
					});
				}, function (error) {
					$("#showloader").css("display", "none");
					$scope.isClicked = false;
				});
		} else {
			if (!$scope.isClicked) {
				commonService.postServiceResponse(urlService.ADD_FAVOURITE, { "username": sessionStorage.userName, "dcName": $scope.dcName, "funName": $scope.functionality })
					.then(function (response) {
						$("#showloader").css("display", "none");
						if (response.errorMessage) {
							$scope.isFavouriteAdded = false;
							$scope.isClicked = false;
							$scope.$broadcast('showAlert', ['']);
						} else {
							$scope.isClicked = true;
							$scope.isClicked = !isClicked;
							$scope.isFavouriteAdded = true;
							$scope.favouriteMsg = response.resMessage;
							$scope.$broadcast('ClickedOnFavourate', [$scope.dcName, $scope.functionality, $scope.isClicked]);
						}

					}, function (error) {
						$scope.isClicked = false;
						$("#showloader").css("display", "none");
					});
				$scope.isClicked = !isClicked;
			} else {
				$("#showloader").css("display", "none");
			}
		}
	};
	$scope.addToFavourate('load');
	//user favourites code ends
}]);

