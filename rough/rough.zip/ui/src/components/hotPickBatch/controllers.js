var app = angular.module('HotPickBatch', ['ngAnimate', 'ui.grid', 'ui.grid.selection', 'ui.grid.edit', 'ui.grid.cellNav', 'ui.grid.validate', 'ui.grid.exporter']);

app.controller('HotPickBatchController', ['$scope', '$http', '$q', '$interval', 'uiGridValidateService', '$timeout', 'urlService', 'uiGridConstants', 'commonService', 'uiGridExporterService', 'uiGridExporterConstants', function ($scope, $http, $q, $interval, uiGridValidateService, $timeout, urlService, uiGridConstants, commonService, uiGridExporterService, uiGridExporterConstants) {
    var pr = this;
    $scope.pagefunctionality = $scope.functionality;
    $scope.pagedc = $scope.dcName;
    pr.isMianpage = false;
    $scope.secondpage = false;
    $scope.firstpage = true;
    $scope.secondpage = false;
    $scope.active = 1;
    $scope.gridApi1;
    pr.isClicked = false;
    $scope.selectedInventory = [];
    $scope.pickTickets = [];
    $scope.users = [];
    pr.numberGridOptionssuccess = false;
    pr.numberGridOptionserror = false;
    pr.estimationDataBtn = false;
    pr.estimation = {};
    pr.selectedRowValues = [];
    pr.wavePlanning = false;
    pr.transPlanning = false;
    pr.maniFest = false;
    pr.nopermProfile = false;
    pr.replenishment = false;
    pr.estimationsInfo = false;
    $scope.mysectedrows = [];
    $scope.disableTab = true;

    pr.iswavePlanning = true;
    pr.istransPlanning = true;
    pr.ismaniFest = true;
    pr.isnopermProfile = true;
    pr.isreplenishment = true;
    pr.isestimationsInfo = true;
    var transPlanningData = [];
    pr.piecePick = false;
    pr.isPiecePick = false;
    pr.int2 = false;
    $scope.inputs = [];
    pr.isInt2 = false;
    $scope.disableAddAll = true;
    $scope.disableRemoveAll = true;
    $scope.disableAddRule = false;
    $scope.disableRemoveRule = true;
    $scope.disableAdd = true;
    $scope.disableRemove = true;
    $scope.disableCreateBatch = false;
    $scope.disableUpdateBatch = true;
    $scope.disableDeleteBatch = true;
    $scope.hotPickValueReadOnly = false;
    $scope.hotPickDescReadOnly = false;
    $scope.hotPickId = "";
    $scope.hotPickDesc = "";
    $scope.operator = [];
    $scope.showBrand = true;
    $scope.showOpertor = true;
    $scope.secondRow = false;
    $scope.firstRow = false;
    $scope.thirdRow = false;
    $scope.counter = 0;
    $scope.createFormShow = false;
    $scope.updateFormShow = false;
    $scope.columnvalue = "test";
    $scope.firstOperator = [];
    $scope.firstcolumn = [];
    $scope.firstlogicalOperator = [];
    $scope.formData = {};
    $scope.pickticketDetailsTab = false;
    $scope.savePickTicket = true;
    $scope.disableTab = true;
    $scope.firstCompHide = false;
    $scope.secondCompHide = false;
    $scope.thirdCompHide = false;
	/*$scope.firstcolvalue="";
	$scope.firstOpervalue="",*/
    $scope.firstCompValue = "test";
	/*$scope.firstlogvalue="",
	$scope.secondcolvalue="",
	$scope.secondOpervalue="",
	$scope.secondCompValue="",
	$scope.secondlogValue="",
	$scope.thirdcolvalue="",
	$scope.thirdOpervalue="",
	$scope.thirdCompValue="",
	$scope.thirdBrandvalue="",*/

	/*$scope.formDetails = {
		"rules": [{ "Column": "TableName", "Operator": "GreaterThan", "ComparisonValue": "12313", "Andor": "AndOr" },
		{ "Column": "TableName", "Operator": "GreaterThan", "ComparisonValue": "12313", "Andor": "AndOr" },
		{ "Column": "TableName", "Operator": "GreaterThan", "ComparisonValue": "12313", "Brand": "Adidas" }
		]
	}*/


    $scope.gridOptions = {
        enableColumnMenus: false,
        enableSorting: true,
        multiSelect: false,
        enableRowSelection: true,//we can remove it later no use  of this
        enableSelectAll: true,//we can remove it later no use  of this             
        enableCellEdit: false, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
        enableCellEditOnFocus: true,



    };






    $scope.gridOptionsOne = {
        paginationPageSizes: [15, 25, 50, 100,10000],
        paginationPageSize: 15,
        useExternalPagination: true,
        enableColumnMenus: false,
        enableSorting: true,
        enablemultiSelect: false,
        enableRowSelection: true,//we can remove it later no use  of this
        enableSelectAll: true,//we can remove it later no use  of this             
        enableCellEdit: false, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
        enableCellEditOnFocus: true,
    };

    $scope.gridOptionsTwo = {
        enableColumnMenus: false,
        enableSorting: true,
        enablemultiSelect: false,
        enableRowSelection: true,//we can remove it later no use  of this
        enableSelectAll: true,//we can remove it later no use  of this             
        enableCellEdit: false, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
        enableCellEditOnFocus: true,
    };



    $scope.gridOptions.onRegisterApi = function (gridApi) {
        //set gridApi on scope
        $scope.gridApi = gridApi;
        gridApi.selection.on.rowSelectionChanged($scope, function (rows) {
            $scope.isSuccess = false;
            $scope.isFailed = false;
            if ($scope.gridApi.selection.getSelectedRows().length > 0) {
                $scope.disableUpdateBatch = false;
                $scope.disableDeleteBatch = false;
				$scope.disableCreateBatch = true;
            } else {
                //$scope.isupdate = false;
                $scope.disableUpdateBatch = true;
                $scope.disableDeleteBatch = true;
				$scope.disableCreateBatch = false;
            }
        });

    };


    $scope.gridOptionsOne.onRegisterApi = function (gridApi) {
        //set gridApi on scope
        $scope.gridApiOne = gridApi;
        $scope.mysectedrows = $scope.gridApiOne.selection.getSelectedRows();
        gridApi.selection.on.rowSelectionChanged($scope, function (rows) {
            if ($scope.gridApiOne.selection.getSelectedRows().length > 0) {
                $scope.disableAdd = false;
                $scope.disableAddAll = true;
            } else {
                //$scope.isupdate = false;
                $scope.disableAdd = true;
                $scope.disableAddAll = false;
            }
        });

        $scope.gridApiOne.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
            $scope.pageNo = newPage;
            $scope.pageSize = pageSize;
            $scope.submitPickRule("nextPagination");
        });


    };

    $scope.gridOptionsTwo.onRegisterApi = function (gridApi) {
        //set gridApi on scope
        $scope.gridApiTwo = gridApi;
        gridApi.selection.on.rowSelectionChanged($scope, function (rows) {
            $scope.isSuccess = false;
            $scope.isFailed = false;
            if ($scope.gridApiTwo.selection.getSelectedRows().length > 0) {

                $scope.disableRemove = false;
                $scope.disableRemoveAll = true;

            } else {
                //$scope.isupdate = false;
                $scope.disableRemove = true;
                $scope.disableRemoveAll = false;
            }
        });

    };

    $scope.gridOptionsOne.columnDefs = [
        { name: "tcOrderId", displayName: "Tc Order Id", enableCellEdit: false },
        { name: "dName", displayName: "D Name", enableCellEdit: false },
        { name: "dFacilityName", displayName: "D Facility Name", enableCellEdit: false },
        //{ name: "orderPr", displayName: "Order Id", enableCellEdit: false },
        { name: "extPurchaseOrder", displayName: "Ext Purchase Order", enableCellEdit: false },
        { name: "splInstrCode2", displayName: "Spl Instr Code2", enableCellEdit: false },
        { name: "totalNbrOfUnits", displayName: "Total Nbr Of Units", enableCellEdit: false },
        { name: "estLpn", displayName: "Est LPN", enableCellEdit: false },

    ];

    $scope.gridOptionsTwo.columnDefs = [
        { name: "tcOrderId", displayName: "Tc Order Id", enableCellEdit: false },
        { name: "dName", displayName: "D Name", enableCellEdit: false },
        { name: "dFacilityName", displayName: "D Facility Name", enableCellEdit: false },
        //{ name: "orderPr", displayName: "Order Id", enableCellEdit: false },
        { name: "extPurchaseOrder", displayName: "Ext Purchase Order", enableCellEdit: false },
        { name: "splInstrCode2", displayName: "Spl Instr Code2", enableCellEdit: false },
        { name: "totalNbrOfUnits", displayName: "Total Nbr Of Units", enableCellEdit: false },
        { name: "estLpn", displayName: "Est LPN", enableCellEdit: false },

    ];


    $scope.getDimensionData = function () {

        angular.forEach($scope.gridApiOne.selection.getSelectedRows(), function (data, index) {
            console.log(data);
        });


    };


    $scope.firstOperChange = function (operatorName) {
        console.log(operatorName);
        if (operatorName === 'firstOperator') {
            if ($scope.formData.firstOpervalue.indexOf('null') >= 0) {
                $scope.firstCompHide = true;
            }
            else {
                $scope.firstCompHide = false;
            }
        }
        else if (operatorName === 'secondOperator') {
            if ($scope.formData.secondOpervalue.indexOf('null') >= 0) {
                $scope.secondCompHide = true;
            }
            else {
                $scope.secondCompHide = false;
            }
        }
        else if (operatorName === 'thirdOperator') {
            if ($scope.formData.thirdOpervalue.indexOf('null') >= 0) {
                $scope.thirdCompHide = true;
            }
            else {
                $scope.thirdCompHide = false;
            }
        }
    };


    $scope.navigateTop = function () {
        document.body.scrollTop = 0;
        document.documentElement.scrollTop = 0;
    };

    $scope.navigateDown = function () {
        document.body.scrollTop = 500;
        document.documentElement.scrollTop = 500;
    };
    $scope.init = function () {
        $scope.active = 1;
    };

    $scope.addData = function () {
        angular.forEach($scope.gridApiOne.selection.getSelectedRows(), function (data, index) {
            $scope.gridOptionsTwo.data.push(data);
        });

        angular.forEach($scope.gridApiOne.selection.getSelectedRows(), function (data, index) {
            $scope.gridOptionsOne.data = $scope.gridOptionsOne.data.filter(function (dataOne) {
                return dataOne.orderPr !== data.orderPr;
            });
        });

        if ($scope.gridOptionsTwo.data.length > 0) {
            $scope.savePickTicket = false;
            $scope.disableRemoveAll = false;
        } else {
            $scope.savePickTicket = true;
            $scope.disableRemoveAll = true;
        }
        $scope.disableAdd = true
        if ($scope.gridOptionsOne.data.length > 0) {
            $scope.disableAddAll = false;
        }
        //$scope.disableAddAll=true;
        //$scope.disableRemoveAll=false;
        $scope.navigateDown();
    };

    $scope.addEntireData = function () {

        //$scope.gridOptionsTwo.data = angular.copy($scope.gridOptionsOne.data);

        angular.forEach($scope.gridOptionsOne.data, function (dataOne, index) {
            var isPresent = false;
            angular.forEach($scope.gridOptionsTwo.data, function (dataTwo, index) {
                if (dataOne.orderPr === dataTwo.orderPr) {
                    isPresent = true;
                }
            });
            if (isPresent === false) {
                $scope.gridOptionsTwo.data.push(dataOne);
            }
        });
        $scope.gridOptionsOne.data = [];
        $scope.disableAddAll = true;

        if ($scope.gridOptionsTwo.data.length > 0) {
            $scope.savePickTicket = false;
            $scope.disableRemoveAll = false;
        }
        $scope.navigateDown();
    };

    $scope.removeData = function () {
        angular.forEach($scope.gridApiTwo.selection.getSelectedRows(), function (data, index) {
            $scope.gridOptionsOne.data.push(data);
        });

        angular.forEach($scope.gridApiTwo.selection.getSelectedRows(), function (data, index) {
            $scope.gridOptionsTwo.data = $scope.gridOptionsTwo.data.filter(function (dataOne) {
                return dataOne.orderPr !== data.orderPr;
            });

        });

        if ($scope.gridOptionsTwo.data.length < 1) {
            $scope.savePickTicket = true;
            $scope.disableRemoveAll = true;
            $scope.disableRemove = true;
        } else {
            $scope.savePickTicket = false;
            $scope.disableRemoveAll = false;
        }
        $scope.disableRemove = true;
        $scope.disableAddAll = false;
        //$scope.disableAddAll=true;
        //$scope.disableRemoveAll=false;
        $scope.navigateTop();
    };

    $scope.removeEntireData = function () {

        $scope.disableAddAll = false;
        //$scope.gridOptionsOne.data = angular.copy($scope.gridOptionsTwo.data);
        angular.forEach($scope.gridOptionsTwo.data, function (data, index) {
            $scope.gridOptionsOne.data.push(data);
        });
        $scope.gridOptionsTwo.data = [];
        $scope.disableRemoveAll = true;
        if ($scope.gridOptionsTwo.data.length < 1) {
            $scope.savePickTicket = true;
            $scope.disableRemove = true;
            $scope.disableRemoveAll = true;
        }
        $scope.navigateTop();
    };

    //searching thorugh selection and input text

    $scope.addfield = function () {
        console.log($scope.inputs.length);
        //$scope.getHotPickBatchRules();
        if ($scope.inputs.length < 3) {
            $scope.showBrand = false;
            $scope.showOpertor = true;
            $scope.inputs.push({});
            if ($scope.inputs.length > 0) {
                $scope.disableRemoveRule = false;
            }
        }
        if ($scope.inputs.length > 2) {
            $scope.disableAddRule = true;
        }
        if ($scope.inputs.length == 3) {
            $scope.showBrand = true;
            $scope.showOpertor = false;
        }
        $scope.counter++;
        if ($scope.counter == 1) {
            $scope.firstRow = true;
        }
        if ($scope.counter == 2) {
            $scope.secondRow = true;
        }
        if ($scope.counter == 3) {
            $scope.thirdRow = true;
        }
        if ($scope.counter > 0) {
            $scope.disableRemoveRule = false;
        }

    };

    $scope.addfieldUpdate = function () {

        console.log($scope.inputs.length);
        //$scope.getHotPickBatchRules();
        if ($scope.inputs.length < 3) {
            $scope.showBrand = false;
            $scope.showOpertor = true;
            $scope.inputs.push({});
            if ($scope.inputs.length > 0) {
                $scope.disableRemoveRule = false;
            }
        }
        if ($scope.inputs.length > 2) {
            $scope.disableAddRule = true;
        }
        if ($scope.inputs.length == 3) {
            $scope.showBrand = true;
            $scope.showOpertor = false;
        }
        $scope.counter++;
        if ($scope.counter == 1) {
            $scope.firstRow = true;
        }
        if ($scope.counter == 2) {
            $scope.secondRow = true;
        }
        if ($scope.counter == 3) {
            $scope.thirdRow = true;
        }
        if ($scope.counter > 0) {
            $scope.disableRemoveRule = false;
        }

    };

    $scope.removefield = function () {

        $scope.inputs.pop({});
        if ($scope.inputs.length < 1) {
            $scope.disableRemoveRule = true;
        }
        if ($scope.inputs.length < 3) {
            $scope.showBrand = false;
            $scope.disableAddRule = false;
            $scope.showOpertor = true;
        }

        if ($scope.inputs.length == 3) {
            $scope.showOpertor = false;
            $scope.showBrand = true;
            $scope.showComparison = true;
        }

        if ($scope.counter == 1) {
            $scope.firstRow = false;
            $scope.formData.firstcolvalue = "";
            $scope.formData.firstOpervalue = "";
            $scope.formData.firstCompValue = "";
        }
        if ($scope.counter == 2) {

            $scope.secondRow = false;
            $scope.formData.secondcolvalue = "";
            $scope.formData.secondOpervalue = "";
            $scope.formData.secondCompValue = "";
            $scope.formData.firstlogvalue = "";
        }
        if ($scope.counter == 3) {

            $scope.thirdRow = false;
            $scope.formData.thirdcolvalue = "";
            $scope.formData.thirdOpervalue = "";
            $scope.formData.thirdCompValue = "";
            $scope.formData.secondlogValue = "";
            $scope.formData.thirdBrandvalue = "";
        }
        $scope.counter--;

    };

    $scope.submitRule = function () {
        if ($scope.pickTickets.length > 0) {
            $scope.disableAddAll = false;
            $scope.disableRemoveAll = true;
        }
        $scope.active = 2;
    };

    $scope.createBatch = function () {
        $scope.secondpage = true;
        $scope.hotPickValueReadOnly = false;
        $scope.hotPickDescReadOnly = false;
        $scope.hotPickId = "";
        $scope.hotPickDesc = "";
        $scope.createFormShow = true;
        $scope.updateFormShow = false;
        $scope.inputs = [];
        $scope.counter = 0;
        $scope.showBrand = true;
        $scope.showOpertor = true;
        $scope.secondRow = false;
        $scope.firstRow = false;
        $scope.thirdRow = false;
        $scope.pickticketDetailsTab = false;
        $scope.disableTab = true;
        $scope.disableAddRule = false;
        $scope.disableRemoveRule = true;
        $scope.active = 1;
        $scope.firstCompHide = false;
        $scope.secondCompHide = false;
        $scope.thirdCompHide = false;
        $scope.clearCache();
        $scope.getHotPickBatchRules();

    };

    $scope.toggleDelModel = function () {

        $("#deleteModel").modal();

    };
    $scope.toggleSaveModel = function () {

        $("#saveModel").modal();

    };

    $scope.clearCache = function () {
        $scope.hotPickBatchId = "";
        $scope.formData.hotPickBatchDescription = "";
        $scope.formData.firstcolvalue = "";
        $scope.formData.firstOpervalue = "";
        $scope.formData.firstCompValue = "";
        $scope.formData.firstlogvalue = "";
        $scope.formData.secondcolvalue = "";
        $scope.formData.secondOpervalue = "";
        $scope.formData.secondCompValue = "";
        $scope.formData.secondlogValue = "";
        $scope.formData.thirdcolvalue = "";
        $scope.formData.thirdOpervalue = "";
        $scope.formData.thirdCompValue = "";
        $scope.formData.thirdBrandvalue = "";

    };

    $scope.updateBatch = function () {
        $scope.secondpage = true;
        $scope.hotPickValueReadOnly = true;
        $scope.hotPickDescReadOnly = true;
        angular.forEach($scope.gridApi.selection.getSelectedRows(), function (data, index) {
            $scope.hotPickBatchId = data.batchId;
            $scope.formData.hotPickBatchDescription = data.batchDescription;
        });
        $scope.updateFormShow = true;
        $scope.createFormShow = false;
        $scope.disableTab = true;
        $scope.active = 1;
        $scope.pickticketDetailsTab = false;
        $scope.hotPickBatchIdVal = $scope.hotPickBatchId;
        $scope.hotPickBatchDescriptionVal = $scope.formData.hotPickBatchDescription;
        $scope.clearCache();
        $scope.getHotPickBatchRulesById($scope.hotPickBatchIdVal, $scope.hotPickBatchDescriptionVal);



    };

    $scope.deleteBatch = function () {
        $scope.secondpage = true;
    };

    $scope.mainPage = function () {

        $scope.isFailed = false;
        $scope.isSuccess = false;
        $scope.excelErrors = false;
        $scope.errorMessagesArray = [];
        $scope.disableDownload = true;
        $scope.secondpage = false;
        $scope.disableUpdateBatch = true;
        $scope.disableDeleteBatch = true;
		$scope.disableCreateBatch = false;
        $scope.getHotPickBatchDtls();
    };








    $scope.getHotPickBatchDtls = function (isSuccessMessage) {
        if (isSuccessMessage === 'display') {
            $scope.isSuccess = true;
        }
        else {
            $scope.isSuccess = false;
        }

        $scope.isFailed = false;
        $scope.isEdit = true;
        $scope.isDelete = true;
        $scope.isMianpage = true;
        $scope.isEditdataSources = false;
        $scope.isEditSlotGroup = false;
        

        $("#showloader").css("display", "block");

        var url = urlService.HOT_PICK_BATCH_GET_DTLS.replace('dName', $scope.pagedc);
        url = url.replace('uName', sessionStorage.userName);
        var res = $http.get(url, { headers: { 'x-api-key': sessionStorage.apikey } });

        res.success(function (data, status, headers, config) {
            $("#showloader").css("display", "none");
            if (data.errorMessage) {
                $scope.isFailed = true;
                $scope.resmessage = data.errorMessage;
            } else if (data.resMessage) {
                $scope.isSuccess = true;
                $scope.resmessage = data.resMessage;
            } else {


                $scope.isTable = true;
                $scope.isMianpage = true;
                $scope.gridOptions.data = data.hotPickBatchDtlsDto;

                if ($scope.gridOptions.data > 10) {
                    $scope.gridOptions.enableVerticalScrollbar = true;
                    $scope.gridOptions.enableHorizontalScrollbar = 1;
                } else {
                    $scope.gridOptions.enableVerticalScrollbar = false;
                    $scope.gridOptions.enableHorizontalScrollbar = 1;
                }
            }
            $('.ui-grid-pager-control input').prop("disabled", true);
        });
        res.error(function (data, status, headers, config) {
            $("#showloader").css("display", "none");
            $scope.isFailed = true;
            $scope.resmessage = "System failed. Please try again or contact WAALOS Support";

        });

        $scope.isTable = true;
        $scope.isMianpage = true;

    };

    $scope.getHotPickBatchDtls();

    $scope.saveRule = function () {
        $scope.isSuccess = false;
        $scope.isFailed = false;
        $scope.isEdit = true;
        $scope.isDelete = true;
        $scope.isMianpage = true;
        $scope.isEditdataSources = false;
        $scope.isEditSlotGroup = false;
        
        var value = $scope.formData.firstcolvalue;


        $("#showloader").css("display", "block");

        var payload = {
            "dcName": $scope.pagedc,
            "userName": "Test",
            "insertFlag": "true",
            "hotPickBatchId": $scope.hotPickBatchId,
            "hotPickBatchDescription": $scope.formData.hotPickBatchDescription,
            "ruleColOne": $scope.formData.firstcolvalue,
            "ruleOperOne": $scope.formData.firstOpervalue,
            "ruleCompValueOne": $scope.formData.firstCompValue,
            "ruleLogicalOperOne": $scope.formData.firstlogvalue,
            "ruleColTwo": $scope.formData.secondcolvalue,
            "ruleOperTwo": $scope.formData.secondOpervalue,
            "ruleCompValueTwo": $scope.formData.secondCompValue,
            "ruleLogicalOperTwo": $scope.formData.secondlogValue,
            "ruleColThree": $scope.formData.thirdcolvalue,
            "ruleOperThree": $scope.formData.thirdOpervalue,
            "ruleCompValueThree": $scope.formData.thirdCompValue,
            "ruleBrandName": $scope.formData.thirdBrandvalue
        }

        var res = $http.post(urlService.HOT_PICK_BATCH_SAVE_RULE, payload, {
            headers: { 'x-api-key': sessionStorage.apikey }
        });



        res.success(function (data, status, headers, config) {
            $("#showloader").css("display", "none");
            if (data.errorMessage) {
                $scope.isFailed = true;
                $scope.resmessage = data.errorMessage;
            } else if (data.resMessage) {
                $scope.isSuccess = true;
                $scope.resmessage = data.resMessage;
            } else {




                $("#showloader").css("display", "none");
            }
            $('.ui-grid-pager-control input').prop("disabled", true);
        });
        res.error(function (data, status, headers, config) {
            $("#showloader").css("display", "none");
            $scope.isFailed = true;
            //$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
            $scope.resmessage = "Unable to save batch:-Backend Not Integrated";

        });
    };

    $scope.submitPickRule = function (nextPagination) {
        $scope.isSuccess = false;
        $scope.isFailed = false;
        $scope.isEdit = true;
        $scope.isDelete = true;
        $scope.isMianpage = true;
        $scope.isEditdataSources = false;
        $scope.isEditSlotGroup = false;
        $scope.firstColumnOrigValue = "";
        $scope.secondColumnOrigValue = "";
        $scope.thirdColumnOrigValue = "";
        
        var firstval = $scope.formData.firstcolvalue;
        $scope.firstColumnValue = "";
        $scope.secondColumnValue = "";
        $scope.thirdColumnValue = "";
        $scope.disableTab = false;
        if (nextPagination !== "nextPagination") {
            $scope.gridOptionsTwo.data = [];
        }
        $scope.pageNo = $scope.pageNo ? $scope.pageNo : 1;
        $scope.pageSize = $scope.pageSize ? $scope.pageSize : $scope.gridOptionsOne.paginationPageSize;

        $("#showloader").css("display", "block");
        if ($scope.formData.firstcolvalue === "" || $scope.formData.firstcolvalue === undefined || $scope.formData.firstcolvalue === null) {
            console.log('The form data is empty');
        } else {
            $scope.firstColumnOrigValue = $scope.formData.firstcolvalue;
            $scope.formData.firstcolvalue = $scope.formData.firstcolvalue.split('(');
            $scope.firstColumnValue = $scope.formData.firstcolvalue[0];
        }
        if ($scope.formData.secondcolvalue === "" || $scope.formData.secondcolvalue === undefined || $scope.formData.secondcolvalue === null) {
            console.log('The form data is empty');
        } else {
            $scope.secondColumnOrigValue = $scope.formData.secondcolvalue;
            $scope.formData.secondcolvalue = $scope.formData.secondcolvalue.split('(');
            $scope.secondColumnValue = $scope.formData.secondcolvalue[0];
        }
        if ($scope.formData.thirdcolvalue === "" || $scope.formData.thirdcolvalue === undefined || $scope.formData.thirdcolvalue === null) {
            console.log('The form data is empty');
        } else {
            $scope.thirdColumnOrigValue = $scope.formData.thirdcolvalue;
            $scope.formData.thirdcolvalue = $scope.formData.thirdcolvalue.split('(');
            $scope.thirdColumnValue = $scope.formData.thirdcolvalue[0];
        }
        var payload = {
            "dcName": $scope.pagedc,
            "userName": "Test",
            "insertFlag": "true",
            "hotPickBatchId": $scope.hotPickBatchId,
            "hotPickBatchDescription": $scope.formData.hotPickBatchDescription,
            "ruleColOne": $scope.firstColumnValue,
            "ruleOperOne": $scope.formData.firstOpervalue,
            "ruleCompValueOne": $scope.formData.firstCompValue,
            "ruleLogicalOperOne": $scope.formData.firstlogvalue,
            "ruleColTwo": $scope.secondColumnValue,
            "ruleOperTwo": $scope.formData.secondOpervalue,
            "ruleCompValueTwo": $scope.formData.secondCompValue,
            "ruleLogicalOperTwo": $scope.formData.secondlogValue,
            "ruleColThree": $scope.thirdColumnValue,
            "ruleOperThree": $scope.formData.thirdOpervalue,
            "ruleCompValueThree": $scope.formData.thirdCompValue,
            "ruleBrandName": $scope.formData.thirdBrandvalue,
            "pageNumber": $scope.pageNo,
            "pageSize": $scope.pageSize
        }

		/*var resOne = $http.post(urlService.HOT_PICK_BATCH_SAVE_RULE, payload, {
			headers: { 'x-api-key': sessionStorage.apikey }
		});

		resOne.success(function (data, status, headers, config) {

			$("#showloader").css("display", "none");
			if (data.errorMessage) {
				$scope.isFailed = true;
				$scope.resmessage = data.errorMessage;
				$scope.navigateTop();
			} else {

			}


			$("#showloader").css("display", "none");

			$('.ui-grid-pager-control input').prop("disabled", true);
			$scope.pickticketDetailsTab = true;
		});
		resOne.error(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			$scope.isFailed = true;
			$scope.resmessage = "System failed. Please try again or contact WAALOS Support";

			$scope.pickticketDetailsTab = true;
			$scope.navigateTop();

		});*/

        var res = $http.post(urlService.HOT_PICK_BATCH_GET_PICKTICKETS, payload, {
            headers: { 'x-api-key': sessionStorage.apikey }
        });



        res.success(function (data, status, headers, config) {

			/*$scope.firstcolvalue = "";
			$scope.firstOpervalue = "";
			$scope.firstCompValue = "";
			$scope.firstlogvalue = "";
			$scope.secondcolvalue = "";
			$scope.secondOpervalue = "";
			$scope.secondCompValue = "";
			$scope.secondlogValue = "";
			$scope.thirdcolvalue = "";
			$scope.thirdOpervalue = "";
			$scope.thirdCompValue = "";
			$scope.thirdBrandvalue = "";*/
            //$scope.getHotPickBatchRules();
            $("#showloader").css("display", "none");
            if (data.errorMessage) {
                $scope.isFailed = true;
                $scope.resmessage = data.errorMessage;
                $scope.navigateTop();
            } else {
                if (data.pageItems) {
                    $scope.isTable = true;
                    $scope.isData = false;
                    $scope.gridOptionsOne.totalItems = data.totalNoOfRecords;
                    $scope.gridOptionsOne.data = data.pageItems;
                    if (data.totalNoOfRecords !== 0) {
                        if ($scope.gridOptionsOne.data > 10) {
                            $scope.gridOptionsOne.enableVerticalScrollbar = true;
                        } else {
                            $scope.gridOptionsOne.enableVerticalScrollbar = false;
                            $scope.gridOptionsOne.enableHorizontalScrollbar = 0;
                        }
                        if (data.pageItems.length > 0) {
                            $scope.disableAddAll = false;
                            $scope.disableRemoveAll = true;
                        }
                        $scope.active = 2;
                        $scope.pickticketDetailsTab = true;
                    } else {
                        $scope.isFailed = true;
                        $scope.resmessage = "No Data Found";
                        $scope.active = 2;
                        $scope.pickticketDetailsTab = true;
                    }
                } else {
                    $scope.isFailed = true;
                    $scope.resmessage1 = data.resMessage;
                }
            }
            $("#showloader").css("display", "none");
            $('.ui-grid-pager-control input').prop("disabled", true);
            $scope.pickticketDetailsTab = true;
        });
        res.error(function (data, status, headers, config) {
            $("#showloader").css("display", "none");
            $scope.isFailed = true;
            $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
            $scope.pickticketDetailsTab = true;
            $scope.navigateTop();

        });

        $scope.formData.firstcolvalue = $scope.firstColumnOrigValue;
        $scope.formData.secondcolvalue = $scope.secondColumnOrigValue;
        $scope.formData.thirdcolvalue = $scope.thirdColumnOrigValue;
    };

    $scope.getHotPickBatchRules = function () {
        $scope.isSuccess = false;
        $scope.isFailed = false;
        $scope.isEdit = true;
        $scope.isDelete = true;
        $scope.isMianpage = true;
        $scope.isEditdataSources = false;
        $scope.isEditSlotGroup = false;
        

        $("#showloader").css("display", "block");

        var url = urlService.HOT_PICK_BATCH_GET_RULES.replace('dName', $scope.pagedc);
        url = url.replace('uName', sessionStorage.userName);
        var res = $http.get(url, { headers: { 'x-api-key': sessionStorage.apikey } });

        res.success(function (data, status, headers, config) {
            $("#showloader").css("display", "none");
            if (data.errorMessage) {
                $scope.isFailed = true;
                $scope.resmessage = data.errorMessage;
            } else if (data.resMessage) {
                $scope.isSuccess = true;
                $scope.resmessage = data.resMessage;
            } else {

                $scope.hotPickBatchId = data.hotPickBatchId;
                $scope.hotPickBatchDescription = data.hotPickBatchDescription;
                $scope.firstOperator = data.ruleOperOne;
                $scope.firstcolumn = data.ruleColOne;
                $scope.firstlogicalOperator = data.ruleLogicalOperOne;
				/*$scope.firstcolvalue = $scope.firstcolumn[0];
				$scope.firstOpervalue = $scope.firstOperator[0];
				$scope.firstlogvalue=$scope.firstlogicalOperator[0];*/

                $scope.secondOperator = data.ruleOperTwo;
                $scope.secondcolumn = data.ruleColTwo;
                $scope.secondlogicalOperator = data.ruleLogicalOperTwo;
				/*$scope.secondcolvalue = $scope.secondcolumn[0];
				$scope.secondOpervalue = $scope.secondOperator[0];
				$scope.secondlogvalue=$scope.secondlogicalOperator[0];*/

                $scope.thirdOperator = data.ruleOperThree;
                $scope.thirdcolumn = data.ruleColThree;
                $scope.thirdBrandName = data.ruleBrandName;
				/*	$scope.thirdcolvalue = $scope.thirdcolumn[0];
					$scope.thirdOpervalue = $scope.thirdOperator[0];
					$scope.thirdBrandvalue=$scope.thirdBrandName[0];*/


                $("#showloader").css("display", "none");
            }
            $('.ui-grid-pager-control input').prop("disabled", true);
        });
        res.error(function (data, status, headers, config) {
            $("#showloader").css("display", "none");
            $scope.isFailed = true;
			/*data = {
				"dcName": "Test Dc",
				"userName": "",
				"insertFlag": "",
				"hotPickBatchId": "H0003",
				"hotPickBatchDescription": "",
				"ruleColOne": ["ORDERS.TC ORDER ID", "ORDERS.BILL_TO_FACILITY_NAME", "ORDERS.D_FACILITY_NAME", "ORDERS.EXT_PURCHASE_ORDER", "ITEM_CBO.PROD_TYPE"],
				"ruleOperOne": ["is less than", "is less than or equal to", "not equal to", "equals", "is greater than", "is greater than or equal to", "begins with", "contains", "ends with", "is like", "is not null", "is null"],
				"ruleCompValueOne": "",
				"ruleLogicalOperOne": ["and", "or"],
				"ruleColTwo": ["ORDERS.TC ORDER ID", "ORDERS.BILL_TO_FACILITY_NAME", "ORDERS.D_FACILITY_NAME", "ORDERS.EXT_PURCHASE_ORDER", "ITEM_CBO.PROD_TYPE"],
				"ruleOperTwo": ["is less than", "is less than or equal to", "not equal to", "equals", "is greater than", "is greater than or equal to", "begins with", "contains", "ends with", "is like", "is not null", "is null"],
				"ruleCompValueTwo": "",
				"ruleLogicalOperTwo": ["and", "or"],
				"ruleColThree": ["ORDERS.TC ORDER ID", "ORDERS.BILL_TO_FACILITY_NAME", "ORDERS.D_FACILITY_NAME", "ORDERS.EXT_PURCHASE_ORDER", "ITEM_CBO.PROD_TYPE"],
				"ruleOperThree": ["is less than", "is less than or equal to", "not equal to", "equals", "is greater than", "is greater than or equal to", "begins with", "contains", "ends with", "is like", "is not null", "is null"],
				"ruleCompValueThree": "",
				"ruleBrandName": ["Adidas", "Reebok"],
				"pageNumber": "",
				"pageSize": ""
			}
			$scope.hotPickBatchId = data.hotPickBatchId;
			$scope.hotPickBatchDescription = data.hotPickBatchDescription;
			$scope.firstOperator = data.ruleOperOne;
			$scope.firstcolumn = data.ruleColOne;
			$scope.firstlogicalOperator = data.ruleLogicalOperOne;
			/*$scope.firstcolvalue = $scope.firstcolumn[0];
			$scope.firstOpervalue = $scope.firstOperator[0];
			$scope.firstlogvalue=$scope.firstlogicalOperator[0];

			$scope.secondOperator = data.ruleOperTwo;
			$scope.secondcolumn = data.ruleColTwo;
			$scope.secondlogicalOperator = data.ruleLogicalOperTwo;
			/*$scope.secondcolvalue = $scope.secondcolumn[0];
			$scope.secondOpervalue = $scope.secondOperator[0];
			$scope.secondlogvalue=$scope.secondlogicalOperator[0];

			$scope.thirdOperator = data.ruleOperThree;
			$scope.thirdcolumn = data.ruleColThree;
			$scope.thirdBrandName = data.ruleBrandName;*/
			/*	$scope.thirdcolvalue = $scope.thirdcolumn[0];
				$scope.thirdOpervalue = $scope.thirdOperator[0];
				$scope.thirdBrandvalue=$scope.thirdBrandName[0];*/
            //$scope.resmessage = "System failed. Please try again or contact WAALOS Support";

        });


    };

    $scope.deleteHotPickBatch = function () {
        $scope.isSuccess = false;
        $scope.isFailed = false;
        $scope.isEdit = true;
        $scope.isDelete = true;
        $scope.isMianpage = true;
        $scope.isEditdataSources = false;
        $scope.isEditSlotGroup = false;
        
        var firstval = $scope.formData.firstcolvalue;

        $("#showloader").css("display", "block");

        angular.forEach($scope.gridApi.selection.getSelectedRows(), function (data, index) {
            $scope.hotPickId = data.batchId;

        });

        var payload = {
            "dcName": $scope.pagedc,
            "userName": "Test",
            "batchId": $scope.hotPickId
        }

        var res = $http.put(urlService.HOT_PICK_BATCH_DEL, payload, {
            headers: { 'x-api-key': sessionStorage.apikey }
        });



        res.success(function (data, status, headers, config) {

            $("#showloader").css("display", "none");
            if (data.errorMessage) {
                $scope.isFailed = true;
                $scope.resmessage = data.errorMessage;
            } else if (data.resMessage) {
                $scope.isSuccess = true;
                $scope.resmessage = data.resMessage;
            } else {




                $("#showloader").css("display", "none");
            }
            $scope.getHotPickBatchDtls('display');
            $('.ui-grid-pager-control input').prop("disabled", true);
        });
        res.error(function (data, status, headers, config) {
            $("#showloader").css("display", "none");
            $scope.isFailed = true;
            //	$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
            $scope.resmessage = "Unable to delete the batch:-Backend Not Integrated";
            $scope.getHotPickBatchDtls('display');

        });
        $scope.disableDeleteBatch = true;
        $scope.disableUpdateBatch = true;
		$scope.disableCreateBatch = false;


    };

    $scope.clearFile = function () {
        $scope.isFailed = false;
        $scope.isSuccess = false;
        $scope.excelErrors = false;
        document.getElementById('list').innerHTML = '';
        document.getElementById('nextStep').innerHTML = '';
        $scope.errorMessagesArray = [];
        $scope.disableDownload = true;
    };

    $scope.getHotPickBatchRulesById = function (hotPickId, hotPickBatchDescription) {
        $scope.inputs.length = 0;
        $scope.counter = 0;
        $scope.isSuccess = false;
        $scope.isFailed = false;
        $scope.isEdit = true;
        $scope.isDelete = true;
        $scope.isMianpage = true;
        $scope.isEditdataSources = false;
        $scope.isEditSlotGroup = false;
        
        $scope.firstRowUpdate = false;
        $scope.secondRowUpdate = false;
        $scope.thirdRowUpdate = false;
        $scope.firstRow = false;
        $scope.secondRow = false;
        $scope.thirdRow = false;
        $scope.inputs = [];

        $("#showloader").css("display", "block");

        var url = urlService.HOT_PICK_BATCH_GET_RULE_BY_ID.replace('dName', $scope.pagedc);
        url = url.replace('uName', sessionStorage.userName);
        url = url.replace('hpBatchId', hotPickId);
        var res = $http.get(url, { headers: { 'x-api-key': sessionStorage.apikey } });

        res.success(function (data, status, headers, config) {
            $("#showloader").css("display", "none");
            if (data.errorMessage) {
                $scope.isFailed = true;
                $scope.resmessage = data.errorMessage;
            } else if (data.resMessage) {
                $scope.hotPickBatchId = hotPickId;
                $scope.formData.hotPickBatchDescription = hotPickBatchDescription;
                $scope.isSuccess = true;
                $scope.resmessage = data.resMessage;
            } else {

                $scope.hotPickBatchId = hotPickId;
                $scope.formData.hotPickBatchDescription = data.hotPickBatchRuleDto.hotPickBatchDescription;
                $scope.firstOperator = data.hotPickBatchRuleSelectionDto.ruleOperOne;
                $scope.formData.firstOpervalue = data.hotPickBatchRuleDto.ruleOperOne;
                $scope.firstcolumn = data.hotPickBatchRuleSelectionDto.ruleColOne;
                $scope.formData.firstcolvalue = data.hotPickBatchRuleDto.ruleColOne;

                $scope.formData.firstlogvalue = data.hotPickBatchRuleDto.ruleLogicalOperOne;
                $scope.firstlogicalOperator = data.hotPickBatchRuleSelectionDto.ruleLogicalOperOne;

                $scope.secondOperator = data.hotPickBatchRuleSelectionDto.ruleOperTwo;
                $scope.formData.secondOpervalue = data.hotPickBatchRuleDto.ruleOperTwo;
                $scope.secondcolumn = data.hotPickBatchRuleSelectionDto.ruleColTwo;
                $scope.formData.secondcolvalue = data.hotPickBatchRuleDto.ruleColTwo;
                $scope.secondlogicalOperator = data.hotPickBatchRuleSelectionDto.ruleLogicalOperTwo;
                $scope.formData.secondlogValue = data.hotPickBatchRuleDto.ruleLogicalOperTwo;


                $scope.thirdOperator = data.hotPickBatchRuleSelectionDto.ruleOperThree;
                $scope.formData.thirdOpervalue = data.hotPickBatchRuleDto.ruleOperThree;
                $scope.thirdcolumn = data.hotPickBatchRuleSelectionDto.ruleColThree;
                $scope.formData.thirdcolvalue = data.hotPickBatchRuleDto.ruleColThree;
                $scope.thirdBrandName = data.hotPickBatchRuleSelectionDto.ruleBrandName;
                $scope.formData.thirdBrandvalue = data.hotPickBatchRuleDto.ruleBrandName;


                if (($scope.formData.firstOpervalue !== null) && (($scope.formData.firstOpervalue.indexOf('is null') >= 0) || ($scope.formData.firstOpervalue.indexOf('is not null') >= 0))) {
                    $scope.firstCompHide = true;
                } else {
                    $scope.firstCompHide = false;
                }
                if (($scope.formData.secondOpervalue !== null) && (($scope.formData.secondOpervalue.indexOf('is null') >= 0) || ($scope.formData.secondOpervalue.indexOf('is not null') >= 0))) {
                    $scope.secondCompHide = true;
                } else {
                    $scope.secondCompHide = false;
                }
                if (($scope.formData.thirdOpervalue !== null) && (($scope.formData.thirdOpervalue.indexOf('is null') >= 0) || ($scope.formData.thirdOpervalue.indexOf('is not null') >= 0))) {
                    $scope.thirdCompHide = true;
                } else {
                    $scope.thirdCompHide = false;
                }


                if ($scope.formData.firstcolvalue != null) {
                    $scope.counter++;
                    $scope.inputs.push({});
                    $scope.firstRow = true;
                }
                if ($scope.formData.secondcolvalue != null) {
                    $scope.counter++;
                    $scope.inputs.push({});
                    $scope.secondRow = true;

                }
                if ($scope.formData.thirdcolvalue != null) {
                    $scope.counter++;
                    $scope.inputs.push({});
                    $scope.thirdRow = true;
                }
                if ($scope.counter > 0) {
                    $scope.disableRemoveRule = false;
                }
                if ($scope.inputs.length < 3) {
                    $scope.disableAddRule = false;
                }
                if ($scope.inputs.length > 2) {
                    $scope.disableAddRule = true;
                }


                $("#showloader").css("display", "none");
            }
            $('.ui-grid-pager-control input').prop("disabled", true);
        });
        res.error(function (data, status, headers, config) {
            $("#showloader").css("display", "none");
            $scope.isFailed = true;
            //$scope.resmessage = "System failed. Please try again or contact WAALOS Support";

        });
		/*data = {
			"dcName": "Test Dc",
			"userName": "",
			"insertFlag": "",
			"hotPickBatchId": "895223",
			"hotPickBatchDescription": "Test Description",
			"ruleColOne": ["ORDERS.TC ORDER ID", "ORDERS.BILL_TO_FACILITY_NAME", "ORDERS.D_FACILITY_NAME", "ORDERS.EXT_PURCHASE_ORDER", "ITEM_CBO.PROD_TYPE"],
			"ruleOperOne": ["is less than", "is less than or equal to", "not equal to", "equals", "is greater than", "is greater than or equal to", "begins with", "contains", "ends with", "is like", "is not null", "is null"],
			"ruleCompValueOne": ["firstValue"],
			"ruleLogicalOperOne": ["and", "or"],
			"ruleColTwo": ["ORDERS.TC ORDER ID", "ORDERS.BILL_TO_FACILITY_NAME", "ORDERS.D_FACILITY_NAME", "ORDERS.EXT_PURCHASE_ORDER", "ITEM_CBO.PROD_TYPE"],
			"ruleOperTwo": ["is less than", "is less than or equal to", "not equal to", "equals", "is greater than", "is greater than or equal to", "begins with", "contains", "ends with", "is like", "is not null", "is null"],
			"ruleCompValueTwo": ["secondValue", "second string"],
			"ruleLogicalOperTwo": ["or", "and"],
			"ruleColThree": ["ORDERS.TC ORDER ID", "ORDERS.BILL_TO_FACILITY_NAME", "ORDERS.D_FACILITY_NAME", "ORDERS.EXT_PURCHASE_ORDER", "ITEM_CBO.PROD_TYPE"],
			"ruleOperThree": ["is less than", "is less than or equal to", "not equal to", "equals", "is greater than", "is greater than or equal to", "begins with", "contains", "ends with", "is like", "is not null", "is null"],
			"ruleCompValueThree": ["value three"],
			"ruleBrandName": ["Adidas", "Reebok"],
			"pageNumber": "",
			"pageSize": ""
		}
		$scope.hotPickBatchId = hotPickId;
		$scope.hotPickBatchDescription = hotPickBatchDescription;
		$scope.firstOperator = data.ruleOperOne;
		$scope.formData.firstOpervalue = data.ruleOperOne[1];
		$scope.firstcolumn = data.ruleColOne;
		$scope.formData.firstcolvalue = data.ruleColOne[1];

		$scope.formData.firstlogvalue = data.ruleLogicalOperOne[0];
		$scope.firstlogicalOperator = data.ruleLogicalOperOne;

		$scope.secondOperator = data.ruleOperTwo;
		$scope.formData.secondOpervalue = data.ruleOperTwo[1];
		$scope.secondcolumn = data.ruleColTwo;
		$scope.formData.secondcolvalue = data.ruleColTwo[2];
		$scope.secondlogicalOperator = data.ruleLogicalOperTwo;
		$scope.formData.secondlogValue = data.ruleLogicalOperTwo[1];

		$scope.thirdOperator = data.ruleOperThree;
		$scope.formData.thirdOpervalue = data.ruleOperThree[3];
		$scope.thirdcolumn = data.ruleColThree;
		$scope.formData.thirdcolvalue = data.ruleColThree[1];
		$scope.thirdBrandName = data.ruleBrandName;
		$scope.formData.thirdBrandvalue = data.ruleBrandName[1];
		/*$scope.secondcolvalue = $scope.secondcolumn[0];
		$scope.secondOpervalue = $scope.secondOperator[0];
		$scope.secondlogvalue=$scope.secondlogicalOperator[0];

		$scope.thirdOperator = data.ruleOperThree;
		$scope.formData.thirdOpervalue = data.ruleOperThree[1];
		$scope.thirdcolumn = data.ruleColThree;
		$scope.formData.thirdcolvalue = data.ruleColThree[1];
		$scope.thirdBrandName = data.ruleBrandName;
		$scope.formData.thirdBrandvalue = data.ruleBrandName[1];


		if ($scope.formData.firstcolvalue != "" || $scope.formData.firstcolvalue != undefined) {
			$scope.counter++;
			$scope.inputs.push({});
			$scope.firstRow = true;
		}
		if ($scope.formData.secondcolvalue != "" || $scope.formData.secondcolvalue != undefined) {
			$scope.counter++;
			$scope.inputs.push({});
			$scope.secondRow = true;

		}
		if ($scope.formData.thirdcolvalue != "" || $scope.formData.thirdcolvalue != undefined) {
			$scope.counter++;
			$scope.inputs.push({});
			$scope.thirdRow = true;
		}
		if ($scope.counter > 0) {
			$scope.disableRemoveRule = false;
		}
		if ($scope.inputs.length > 2) {
			$scope.disableAddRule = true;
		}*/


    };

    $scope.savePickTickets = function () {
        $scope.isSuccess = false;
        $scope.isFailed = false;
        $scope.isEdit = true;
        $scope.isDelete = true;
        $scope.isMianpage = true;
        $scope.isEditdataSources = false;
        $scope.isEditSlotGroup = false;
        
        var value = $scope.formData.firstcolvalue;

        $("#showloader").css("display", "block");
        var postRecords = [];
        angular.forEach($scope.gridOptionsTwo.data, function (data, index) {

            var payload = {
                "tcOrderId": data.tcOrderId,
                //public String batchDescription;
                "batchId": $scope.hotPickBatchId,
                "orderPr": data.orderPr,
                "batchDescription": $scope.formData.hotPickBatchDescription,
                "dcName": $scope.pagedc,
                //public String batchId;
                "dName": data.dName,
                "dFacilityName": data.dFacilityName,
                "extPurchaseOrder": data.extPurchaseOrder,
                "splInstrCode2": data.splInstrCode2,
                "totalNbrOfUnits": data.totalNbrOfUnits,
                "estLpn": data.estLpn
            };
            postRecords.push(payload);
        });

        var res = $http.post(urlService.HOT_PICK_BATCH_SAVE_PICKTICKET, postRecords, {
            headers: { 'x-api-key': sessionStorage.apikey }
        });



        res.success(function (data, status, headers, config) {
            $("#showloader").css("display", "none");
            if (data.errorMessage) {
                $scope.isFailed = true;
                $scope.resmessage = data.errorMessage;
            } else if (data.resMessage) {
                $scope.isSuccess = true;
                $scope.resmessage = data.resMessage;
                if ($scope.resmessage.indexOf('Pictickets Saved Successfully') >= 0) {
                    $scope.gridOptionsTwo.data = [];
                }
            } else {
                $scope.isFailed = true;
                $scope.resmessage = "Save failed for few picktickets:Please check Selected Inventory Tab";
                angular.forEach($scope.gridOptionsTwo.data, function (dataOne, index) {
                    var deleteFlag = true;
                    var keepGoing = true;
                    angular.forEach(data, function (dataTwo, index) {
                        if (keepGoing) {
                            if (dataOne.orderPr === dataTwo.orderPr) {
                                deleteFlag = false;
                                keepGoing = false;

                            }
                        }
                        console.log('After break');
                    });
                    if (deleteFlag) {
                        $scope.gridOptionsTwo.data.splice($scope.gridOptionsTwo.data.lastIndexOf(dataOne), 1);
                    }
                });

				/*angular.forEach(data, function (dataOne, index) {
					$scope.gridOptionsTwo.data = $scope.gridOptionsTwo.data.filter(function (dataTwo) {
						return dataTwo.orderPr === dataOne.orderPr;
					});
                    $scope.gridOptionsTwo.data ;
                });*/
                $scope.gridOptionsTwo.data;
                $("#showloader").css("display", "none");
            }
            $('.ui-grid-pager-control input').prop("disabled", true);
        });
        res.error(function (data, status, headers, config) {
            $("#showloader").css("display", "none");
            $scope.isFailed = true;
            $scope.resmessage = "Unable to save the picktickets:-Backend Not Integrated";

        });
        $scope.navigateTop();
    };
	
	//user favourites code starts
	$scope.isClicked = false;

	$scope.addToFavourate = function(isClicked){
		$("#showloader").css("display", "block");
		 if(typeof isClicked !== "boolean"){
		  commonService.postServiceResponse(urlService.GET_FAVOURITES,{"username": sessionStorage.userName})
			.then(function(response){
			  $("#showloader").css("display", "none");
				_.each(response,function(val,key){
				  if(val.funName == $scope.functionality && val.dcName == $scope.dcName){
					$scope.isClicked = true;      
				  }
				});
			},function(error){
			  $("#showloader").css("display", "none");
			  $scope.isClicked = false; 
			});
			//$scope.isClicked = ;
		 }else{
		  if(!$scope.isClicked){
			commonService.postServiceResponse(urlService.ADD_FAVOURITE,{"username": sessionStorage.userName,"dcName":$scope.dcName,"funName":$scope.functionality})
			.then(function(response){
			  $("#showloader").css("display", "none");
			  if(response.errorMessage){
				$scope.isFavouriteAdded= false; 
				$scope.isClicked = false;      
				$scope.$broadcast('showAlert',['']);
			  }else{
				$scope.isClicked = true;      
				$scope.isClicked = !isClicked;
				$scope.isFavouriteAdded= true; 
				$scope.favouriteMsg = response.resMessage;
			  $scope.$broadcast('ClickedOnFavourate',[$scope.dcName,$scope.functionality,$scope.isClicked]);
			  }
				
			},function(error){
			  $scope.isClicked = false;
			  $("#showloader").css("display", "none");
			});
			$scope.isClicked = !isClicked;
		  }else{
			$("#showloader").css("display", "none");
		  }
		 }
		
	  };

	  $scope.addToFavourate('load');
	  //user favourites code ends	


}]);