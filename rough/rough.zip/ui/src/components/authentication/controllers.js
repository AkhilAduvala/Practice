angular.module('Authentication')
 
.controller('LoginController',
    ['$scope', '$rootScope', '$http','$location', 'AuthenticationService','commonService','urlService',
    function ($scope, $rootScope, $http, $location, AuthenticationService,commonService,urlService) {
        $("#showloader").css("display", "none");
        // reset login status
        AuthenticationService.ClearCredentials();
 
        $scope.login = function () {
            //$scope.dataLoading = true;
			
            AuthenticationService.Login($scope.username, $scope.password, function(response) {
                if(response.error){
					$scope.error = response.message;
                    $scope.dataLoading = false;
				}else if(response.accessToken){
					//var resData = {};
					//resData.accessToken = response.accessToken;
					//resData.expiratinoTime = 3600*1000;
					//resData.userEmail = response.userEmail;
					//resData.userId = response.userId;
							
					//commonService.setData('userLoginData',resData.userId);
                   // commonService.setData('expiratinoTime',resData.expiratinoTime);
                  //  sessionStorage.setItem('expiratinoTime',resData.expiratinoTime);
                   // localStorage.setItem ('expiratinoTime',resData.expiratinoTime); 
                    AuthenticationService.SetCredentials($scope.username, $scope.password);
                    
                    $location.path('/home');
                    // $http.get("DCList.json").then(function (response) {
                    //                 $rootScope.DCDetails = response.data;
                    //                 $rootScope.DCList = Object.keys($scope.DCDetails);							
                    //                 $rootScope.dcName = $scope.DCList[0];
                    //                 $rootScope.functionality = $scope.DCDetails[$rootScope.dcName][0];
                    //                 $rootScope.dcFunctionalities = $scope.DCDetails[$rootScope.dcName];		
                    //             });
                } else {
                    $scope.error = response.message;
                    $scope.dataLoading = false;
                }
            });
        };
    }]);
