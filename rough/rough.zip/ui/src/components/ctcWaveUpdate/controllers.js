var app = angular.module('CTCWaveUpdate');

app.controller('CTCWaveUpdateController', ['$scope', '$http', '$q', '$interval', '$timeout', 'urlService', 'uiGridConstants', 'commonService', function ($scope, $http, $q, $interval, $timeout, urlService, uiGridConstants, commonService) {
    $scope.showDNNumbers = true;
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $scope.disable = true;
    $scope.pagefunctionality = $scope.functionality;
    $scope.pagedc = $scope.dcName;

    $scope.init = function () {
        // check if there is query in url
        // and fire search in case its value is not empty
            $scope.inputtype = "DN";
            $scope.type = "BP";

    };


    $("#dnNumbers").focus();
    $("#showloader").css("display", "none");

    /**
    This function is used to change the 'showDNNumbers' value true/false based on the selected radio button.
    Based on the selected value, The Textarea is displayed(true), otherwise hide(false).
    **/
    $scope.getDNNumbers = function (fun) {
        $scope.dnNumbers = "";
        $scope.isSuccess = false;
        $scope.isFailed = false;
            $scope.showDNNumbers = true;
            $scope.disable = true;
            //$scope.dnNumbers = "";
            $("#dnNumbers").focus();
            $scope.validateDNNumbers();
    };

    $scope.validateDNNumbers = function (dnNumbers) {
        $scope.isSuccess = false;
        $scope.isFailed = false;
        if ($scope.dnNumbers) {
            $scope.disable = false;
        } else {
            $scope.disable = true;
        }
    };

    //used to restrict '
    $scope.checkDN = function (evt) {

        if (evt.charCode === 39) {
            evt.preventDefault();
            evt.returnValue = false;
            return false;
        }
    };

    /** This function is used to update the WaveBuddy **/
    $scope.updateWaveBuddy = function (type) {
        $scope.isSuccess = false;
        $scope.isFailed = false;

        var newStr = [];
            var str_array = ($scope.dnNumbers.trim().replace(/\n/g, ",")).replace(/,+/g, ',').replace(/(^\s*,)|( ,\s*$)/g, '');
            var lastChar = str_array[str_array.length - 1];
            if (lastChar == ",") {
                newStr = str_array.substring(0, str_array.length - 1);
            } else {
                newStr = str_array;
            }
            if ((newStr.match(/,/g) || []).length > 99) {
            $scope.isFailed = true;
            $scope.resmessage = "Maximum 100 DN Numbers are allowed";
            return false;
            }
            newStr = newStr.split(",");
            newStr = newStr.filter(function (str) {//used to remove the empty spaces(like empty value)
                return /\S/.test(str);
            });
            $scope.dna = [];
            newStr.map(function (el) {//used to clear the spaces of each array element
                $scope.dna.push(el.trim());
            });
            $scope.inputtype = "DN";

        $("#showloader").css("display", "block");
        var payload = {
            "functionality": $scope.type,
            "dnNbrs": $scope.dna,
            "dcName": $scope.pagedc,
            "userName": sessionStorage.userName,
            "query": "",
            "inputType": $scope.inputtype
        };
        var res = $http.put(urlService.WAVE_BUDDY_UPDATE, payload, {
            headers: { 'x-api-key': sessionStorage.apikey }
        });
        res.success(function (data, status, headers, config) {
            $("#showloader").css("display", "none");

            $scope.type = payload.functionality + " UPDATE";
            $scope.inputtype = payload.inputType;
            $scope.type = type;

            if (data.errorMessage) {
                $scope.isFailed = true;
                $scope.resmessage = data.errorMessage;
            } else {
                $scope.isSuccess = true;
                $scope.resmessage = data.resMessage;
            }
        });
        res.error(function (data, status, headers, config) {
            $scope.type = type;
            $("#showloader").css("display", "none");
            $scope.isFailed = true;
            $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
        });
    };


    
    //user favourites code starts
    $scope.isClicked = false;
    $scope.addToFavourate = function (isClicked) {
        $("#showloader").css("display", "block");
        if (typeof isClicked !== "boolean") {
            commonService.postServiceResponse(urlService.GET_FAVOURITES, { "username": sessionStorage.userName })
                .then(function (response) {
                    $("#showloader").css("display", "none");
                    _.each(response, function (val, key) {
                        if (val.funName == $scope.functionality && val.dcName == $scope.dcName) {
                            $scope.isClicked = true;
                        }
                    });
                }, function (error) {
                    $("#showloader").css("display", "none");
                    $scope.isClicked = false;
                });
            //$scope.isClicked = ;
        } else {
            if (!$scope.isClicked) {
                commonService.postServiceResponse(urlService.ADD_FAVOURITE, { "username": sessionStorage.userName, "dcName": $scope.dcName, "funName": $scope.functionality })
                    .then(function (response) {
                        $("#showloader").css("display", "none");
                        if (response.errorMessage) {
                            $scope.isFavouriteAdded = false;
                            $scope.isClicked = false;
                            $scope.$broadcast('showAlert', ['']);
                        } else {
                            $scope.isClicked = true;
                            $scope.isClicked = !isClicked;
                            $scope.isFavouriteAdded = true;
                            $scope.favouriteMsg = response.resMessage;
                            $scope.$broadcast('ClickedOnFavourate', [$scope.dcName, $scope.functionality, $scope.isClicked]);
                        }

                    }, function (error) {
                        $scope.isClicked = false;
                        $("#showloader").css("display", "none");
                    });
                $scope.isClicked = !isClicked;
            } else {
                $("#showloader").css("display", "none");
            }
        }

    };
    $scope.addToFavourate('load');
    //user favourites code ends
}]);