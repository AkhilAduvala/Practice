var app = angular.module('InfoDcScript', ['ui.grid', 'ui.grid.selection', 'ui.grid.pagination']);

app.controller('InfoDcScriptController', ['$scope', '$http', '$q', '$interval', '$timeout','$sce','urlService','uiGridConstants','commonService', function ($scope, $http, $q, $interval, $timeout,$sce,urlService,uiGridConstants,commonService) {

  $scope.isSuccess = false;
  $scope.isFailed = false;
  $scope.disable = true;
  $scope.pagefunctionality ="InfoDC";
  $scope.gridOptionswmservers = { 
    paginationPageSizes: [15, 25, 50, 100],
    paginationPageSize: 15,
    useExternalPagination: true,
    enableSorting: true,
  };
  $scope.gridOptionswmservers.onRegisterApi = function (gridApi) {
    //set gridApi on scope
    $scope.gridApi = gridApi;

    $scope.gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
      $scope.pageNo =  newPage;
	  $scope.pageSize = pageSize;
	  $scope.searchRecords('wmservers');
	
     
   });
};


  $scope.gridOptionsscisystem = { 
    paginationPageSizes: [15, 25, 50, 100],
    paginationPageSize: 15,
    useExternalPagination: true,
    enableSorting: true,
  };
  $scope.gridOptionsscisystem.onRegisterApi = function (gridApi) {
    //set gridApi on scope
    $scope.gridApi = gridApi;

    $scope.gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
      $scope.pageNo =  newPage;
	  $scope.pageSize = pageSize;
	  $scope.sciSystems('scisystem');
     
   });
};

  $scope.gridOptionsdccodes = { 
    paginationPageSizes: [15, 25, 50, 100],
    paginationPageSize: 15,
    useExternalPagination: true,
    enableSorting: true,
  };
  $scope.gridOptionsdccodes.onRegisterApi = function (gridApi) {
    //set gridApi on scope
    $scope.gridApi = gridApi;

    $scope.gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
      $scope.pageNo =  newPage;
	  $scope.pageSize = pageSize;
$scope.dcCodes('dccodes');
	
     
   });
};

  $scope.gridOptionswaalosserver = { 
    paginationPageSizes: [15, 25, 50, 100],
    paginationPageSize: 15,
    useExternalPagination: true,
    enableSorting: true,
  };
  $scope.gridOptionswaalosserver.onRegisterApi = function (gridApi) {
    //set gridApi on scope
    $scope.gridApi = gridApi;

    $scope.gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
      $scope.pageNo =  newPage;
      $scope.pageSize = pageSize;
      $scope.waalosServer('waalosserver');
	 
     
   });
};
$scope.gridOptionsloadBalancer = { 
	paginationPageSizes: [15, 25, 50, 100, 500],
	paginationPageSize: 500,
	useExternalPagination: true,
	enableSorting: true,
	enableFiltering: true,
};
$scope.gridOptionsloadBalancer.onRegisterApi = function (gridApi) {
	//set gridApi on scope
	$scope.gridApi = gridApi;

	$scope.gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
		$scope.pageNo =  newPage;
		$scope.pageSize = pageSize;
		$scope.loadbalancerdata('loadbalancer');
 
	 
 });
};

 $scope.type = "WMservers";
 $scope.flags ={
	wmservers:true,
	scisystem:false,
	dccodes:false,
	waalosservers:false,
	Loadbalancer:false,
	isTableWmserver:false,
	isTablescisystems:false,
	isTabledccodes:false,
	isTablewaalosservers:false,
	isTableloadBalancer:false
 };
 $scope.values ={
	"anynum":"",

 };
 $scope.uidChange = function(){
	$scope.isSuccess = false;
	$scope.isFailed = false;

	var reg = /^[A-Za-z0-9\d-_]+$/;
	if($scope.values.anynum == 32 || !(reg.test($scope.values.anynum))){
		$scope.isFailed = true;
		$scope.resmessage = "Please enter valid data";
		return false;
	}
 };
	 

  $scope.getType = function(fun){
		if(fun == "WMservers"){
			$scope.flags.wmservers = true;
			$scope.flags.scisystem = false;
			$scope.flags.dccodes = false;
			$scope.flags.waalosservers = false;
			$scope.flags.Loadbalancer = false;
			$scope.pageNo =  1;
			$scope.pageSize = 15;
			$scope.flags.isTablescisystems = false;
			$scope.flags.isTabledccodes = false;
			$scope.flags.isTablewaalosservers = false;
			$scope.flags.isTableloadBalancer = false;
			$scope.values.anynum = "";
		}
		if(fun == "SCISystem"){
			$scope.flags.wmservers = false;
			$scope.flags.scisystem = true;
			$scope.flags.dccodes = false;
			$scope.flags.waalosservers = false;
			$scope.flags.Loadbalancer = false;
			$scope.pageNo =  1;
			$scope.pageSize = 15;
			$scope.sciSystems('scisystem');
		}
		if(fun == "DCCodes"){
			$scope.flags.wmservers = false;
			$scope.flags.scisystem = false;
			$scope.flags.dccodes = true;
			$scope.flags.waalosservers = false;
			$scope.flags.Loadbalancer = false;
			$scope.pageNo =  1;
			$scope.pageSize = 15;
			$scope.dcCodes('dccodes');
		}
		if(fun == "WaalosServers"){
			$scope.flags.wmservers = false;
			$scope.flags.scisystem = false;
			$scope.flags.dccodes = false;
			$scope.flags.waalosservers = true;
			$scope.flags.Loadbalancer = false;
			$scope.pageNo =  1;
			$scope.pageSize = 15;
			$scope.waalosServer('waalosserver');
		}
		if(fun == "Loadbalancer"){
			$scope.flags.wmservers = false;
			$scope.flags.scisystem = false;
			$scope.flags.dccodes = false;
			$scope.flags.waalosservers = false;
			$scope.flags.Loadbalancer = true;
			$scope.pageNo =  1;
			$scope.pageSize = 500;
			$scope.loadbalancerdata('loadbalancer');
		}
  };


	$scope.loadbalancerdata=function(type){
		$scope.isSuccess = false;
		$scope.isFailed = false;
		$scope.pageNo = $scope.pageNo ? $scope.pageNo : 1;
		$scope.pageSize = $scope.pageSize ? $scope.pageSize: $scope.gridOptionsloadBalancer.paginationPageSize;
		$("#showloader").css("display", "block");
		var url = urlService.INFO_DC_SCRIPT_GET_DATA.replace('funname',type);
			url = url.replace('uName',sessionStorage.userName);
			url = url.replace('pNumber',$scope.pageNo);
		url = url.replace('pSize',$scope.pageSize);
			var res = $http.get(url, {
			headers: {'x-api-key': sessionStorage.apikey}
		});
			res.success(function (data, status, headers, config) {
				$("#showloader").css("display", "none");
				if (data.errorMessage) {
					$scope.isTable = false;
					$scope.isFailed = true;
					$scope.resmessage = data.errorMessage;
					}
					else if(data.resMessage){
					$scope.isTable = false;
					$scope.isSuccess = true;
					$scope.resmessage = data.resMessage;
					}
					else if(data.length === 0){
					$scope.isTable = false;
					$scope.isFailed = true;
					$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
					}
				 else {
					$scope.flags.isTablescisystems = false;
					$scope.flags.isTabledccodes = false;
					$scope.flags.isTablewaalosservers = false;
					$scope.flags.isTableWmserver = false;
					$scope.flags.isTableloadBalancer = true;
					$scope.gridOptionsloadBalancer.columnDefs = [
						{ name: 'appEnv', displayName: 'App Env', cellTooltip: true, headerTooltip: true,enableCellEdit: false,sort: { direction: uiGridConstants.ASC, priority: 1 }  },
						{ name: 'destination', displayName: 'Destination',cellTooltip: true, headerTooltip: true,enableCellEdit: true },
						{ name: 'canName', displayName: 'CanName', cellTooltip: true, headerTooltip: true,enableCellEdit: true},
					];
			
					$scope.gridOptionsloadBalancer.totalItems  = data.totalNoOfRecords;  
					$scope.gridOptionsloadBalancer.data = data.pageItems;
	
					if ($scope.gridOptionsloadBalancer.data > 10) {
						$scope.gridOptionsloadBalancer.enableVerticalScrollbar = true;
					} else {
						$scope.gridOptionsloadBalancer.enableVerticalScrollbar = false;
						$scope.gridOptionsloadBalancer.enableHorizontalScrollbar = 0;
		
					}
				
				}
			});
		
			res.error(function (data, status, headers, config) {
				$("#showloader").css("display", "none");
				$scope.isTable = false;
				$scope.isFailed = true;
				$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
			});
			setTimeout(function(){  $('.ui-grid-pager-control-input').attr( "disabled", true );  }, 2000);
			
		};
  
  $scope.sciSystems=function(type){
	$scope.isSuccess = false;
	$scope.isFailed = false;
	$scope.pageNo = $scope.pageNo ? $scope.pageNo : 1;
	$scope.pageSize = $scope.pageSize ? $scope.pageSize: $scope.gridOptionsscisystem.paginationPageSize;
	$("#showloader").css("display", "block");
	var url = urlService.INFO_DC_SCRIPT_GET_DATA.replace('funname',type);
    url = url.replace('uName',sessionStorage.userName);
    url = url.replace('pNumber',$scope.pageNo);
	url = url.replace('pSize',$scope.pageSize);
	  var res = $http.get(url, {
		headers: {'x-api-key': sessionStorage.apikey}
	});
		res.success(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			if (data.errorMessage) {
				$scope.isTable = false;
				$scope.isFailed = true;
				$scope.resmessage = data.errorMessage;
			  }
			  else if(data.resMessage){
				$scope.isTable = false;
				$scope.isSuccess = true;
				$scope.resmessage = data.resMessage;
			  }
			  else if(data.length === 0){
				$scope.isTable = false;
				$scope.isFailed = true;
				$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
			  }
			 else {
				$scope.flags.isTablescisystems = true;
				$scope.flags.isTabledccodes = false;
				$scope.flags.isTablewaalosservers = false;
				$scope.flags.isTableWmserver = false;
				$scope.flags.isTableloadBalancer = false;
				$scope.gridOptionsscisystem.columnDefs = [
				  { name: 'appName', displayName: 'ENV', cellTooltip: true, headerTooltip: true,enableCellEdit: false,sort: { direction: uiGridConstants.ASC, priority: 1 }  },
				  { name: 'appEnv', displayName: 'APPENV',cellTooltip: true, headerTooltip: true,enableCellEdit: true },
				  { name: 'machineName', displayName: 'HOST', cellTooltip: true, headerTooltip: true,enableCellEdit: true},
				  { name: 'appUid', displayName: 'APPUSER', cellTooltip: true, headerTooltip: true,enableCellEdit: true},
				  { name: 'appDb', displayName: 'APPDB', cellTooltip: true, headerTooltip: true,enableCellEdit: true },
				  { name: 'appdbUid', displayName: 'APPDBUID', cellTooltip: true, headerTooltip: true,enableCellEdit: true }
				];
		
				$scope.gridOptionsscisystem.totalItems  = data.totalNoOfRecords;  
				$scope.gridOptionsscisystem.data = data.pageItems;

				if ($scope.gridOptionsscisystem.data > 10) {
					$scope.gridOptionsscisystem.enableVerticalScrollbar = true;
				} else {
					$scope.gridOptionsscisystem.enableVerticalScrollbar = false;
					$scope.gridOptionsscisystem.enableHorizontalScrollbar = 0;
	
				}
			
			}
		});
	
		res.error(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			$scope.isTable = false;
			$scope.isFailed = true;
			$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
		});
		setTimeout(function(){  $('.ui-grid-pager-control-input').attr( "disabled", true );  }, 2000);
		
  };

  $scope.dcCodes= function(type){
	$scope.isSuccess = false;
	$scope.isFailed = false;
	$scope.pageNo = $scope.pageNo ? $scope.pageNo : 1;
	$scope.pageSize = $scope.pageSize ? $scope.pageSize: $scope.gridOptionsdccodes.paginationPageSize;
		
	var url = urlService.INFO_DC_SCRIPT_GET_DATA.replace('funname',type);
    url = url.replace('uName',sessionStorage.userName);
    url = url.replace('pNumber',$scope.pageNo);
	url = url.replace('pSize',$scope.pageSize);
	$("#showloader").css("display", "block");
	  var res = $http.get(url, {
		headers: {'x-api-key': sessionStorage.apikey}
	});
		res.success(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			if (data.errorMessage) {
				$scope.isTable = false;
				$scope.isFailed = true;
				$scope.resmessage = data.errorMessage;
			  }
			  else if(data.resMessage){
				$scope.isTable = false;
				$scope.isSuccess = true;
				$scope.resmessage = data.resMessage;
			  }
			  else if(data.length === 0){
				$scope.isTable = false;
				$scope.isFailed = true;
				$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
			  }
			 else {
				$scope.flags.isTabledccodes = true;
				$scope.flags.isTablescisystems = false;
				$scope.flags.isTablewaalosservers = false;
				$scope.flags.isTableWmserver = false;
				$scope.flags.isTableloadBalancer = false;
				$scope.gridOptionsdccodes.columnDefs = [
			
				  { name: 'shortName', displayName: 'SHORT NAME', cellTooltip: true, headerTooltip: true,enableCellEdit: false,sort: { direction: uiGridConstants.ASC, priority: 1 }  },
				  { name: 'longName', displayName: 'LONG NAME',cellTooltip: true, headerTooltip: true,enableCellEdit: true },
				  { name: 'notes', displayName: 'NOTES', cellTooltip: true, headerTooltip: true,enableCellEdit: true }
				  
				];
		
				$scope.gridOptionsdccodes.totalItems  = data.totalNoOfRecords;  
				$scope.gridOptionsdccodes.data = data.pageItems;

				if ($scope.gridOptionsdccodes.data > 10) {
					$scope.gridOptionsdccodes.enableVerticalScrollbar = true;
				} else {
					$scope.gridOptionsdccodes.enableVerticalScrollbar = false;
					$scope.gridOptionsdccodes.enableHorizontalScrollbar = 0;
	
				}
			
			}
		});
	
		res.error(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			$scope.isTable = false;
			$scope.isFailed = true;
			$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
		});
		setTimeout(function(){  $('.ui-grid-pager-control-input').attr( "disabled", true );  }, 2000);
		
  };

  $scope.waalosServer = function(type){
	$scope.isSuccess = false;
	$scope.isFailed = false;
	$scope.pageNo = $scope.pageNo ? $scope.pageNo : 1;
	$scope.pageSize = $scope.pageSize ? $scope.pageSize: $scope.gridOptionswaalosserver.paginationPageSize;
	$("#showloader").css("display", "block");
	var url = urlService.INFO_DC_SCRIPT_GET_DATA.replace('funname',type);
    url = url.replace('uName',sessionStorage.userName);
    url = url.replace('pNumber',$scope.pageNo);
	url = url.replace('pSize',$scope.pageSize);
	  var res = $http.get(url, {
		headers: {'x-api-key': sessionStorage.apikey}
	});
		res.success(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			if (data.errorMessage) {
				$scope.isTable = false;
				$scope.isFailed = true;
				$scope.resmessage = data.errorMessage;
			  }
			  else if(data.resMessage){
				$scope.isTable = false;
				$scope.isSuccess = true;
				$scope.resmessage = data.resMessage;
			  }
			  else if(data.length === 0){
				$scope.isTable = false;
				$scope.isFailed = true;
				$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
			  }
			 else {
				$scope.flags.isTablewaalosservers = true;
				$scope.flags.isTabledccodes = false;
				$scope.flags.isTablescisystems = false;
				$scope.flags.isTableWmserver = false;
				$scope.flags.isTableloadBalancer = false;
				$scope.gridOptionswaalosserver.columnDefs = [
				  { name: 'appGrp',displayName: 'GROUP',cellTooltip: true, headerTooltip: true,enableCellEdit: false,sort: { direction: uiGridConstants.ASC, priority: 1 }  },
				  { name: 'appEnv', displayName: 'DCCODE', cellTooltip: true, headerTooltip: true,enableCellEdit: false  },
				  { name: 'appUid', displayName: 'UID',cellTooltip: true, headerTooltip: true,enableCellEdit: true},
				  { name: 'sysName', displayName: 'SYSTEM NAME', cellTooltip: true, headerTooltip: true,enableCellEdit: true}
				];
		
				$scope.gridOptionswaalosserver.totalItems  = data.totalNoOfRecords;  
				$scope.gridOptionswaalosserver.data = data.pageItems;


				if ($scope.gridOptionswaalosserver.data > 10) {
					$scope.gridOptionswaalosserver.enableVerticalScrollbar = true;
				} else {
					$scope.gridOptionswaalosserver.enableVerticalScrollbar = false;
					$scope.gridOptionswaalosserver.enableHorizontalScrollbar = 0;
	
				}
			
			}
		});
	
		res.error(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			$scope.isTable = false;
			$scope.isFailed = true;
			$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
		});
		setTimeout(function(){  $('.ui-grid-pager-control-input').attr( "disabled", true );  }, 2000);
		
  };
  

$scope.searchRecords = function(type){
	$scope.isSuccess = false;
	$scope.isFailed = false;
	$scope.pageNo = $scope.pageNo ? $scope.pageNo : 1;
	$scope.pageSize = $scope.pageSize ? $scope.pageSize: $scope.gridOptionswmservers.paginationPageSize;
	var searchval;
$("#showloader").css("display", "none");
	if($scope.values.anynum !=""){
	
		 searchval = 	$scope.values.anynum;
	}else{
		$scope.isFailed = true;
		$scope.resmessage = "Please enter valid data";
		return false;
	}

	var reg = /^[A-Za-z0-9\d-_]+$/;
	if(	$scope.values.anynum !=""){
		if(	$scope.values.anynum == 32 || !(reg.test(	$scope.values.anynum))){
			$scope.isFailed = true;
			$scope.resmessage = "Please enter valid data";
			return false;
		}
	}
	var openstatus,sdnNum,opsDate,restartDate;

	$("#showloader").css("display", "block");
	var url = urlService.INFO_DC_SCRIPT_GET_DATA_WMSERVER.replace('funname',type);
	//url = url.replace('searhcrit',searchcrit);
	url = url.replace('searchval',searchval);
    url = url.replace('uName',sessionStorage.userName);
    url = url.replace('pNumber',$scope.pageNo);
	url = url.replace('pSize',$scope.pageSize);
	  var res = $http.get(url, {
		headers: {'x-api-key': sessionStorage.apikey}
	});
		res.success(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			if (data.errorMessage) {
				$scope.isTable = false;
				$scope.isFailed = true;
				$scope.resmessage = data.errorMessage;
				$scope.flags.isTableWmserver = false;
			  }
			  else if(data.resMessage){
				$scope.isTable = false;
				$scope.isSuccess = true;
				$scope.resmessage = data.resMessage;
				$scope.flags.isTableWmserver = false;
			  }
			  else if(data.length === 0){
				$scope.isTable = false;
				$scope.isFailed = true;
				$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
				$scope.flags.isTableWmserver = false;
			  }
			 else {
				$scope.flags.isTableWmserver = true;
				$scope.flags.isTablescisystems = false;
				$scope.flags.isTabledccodes = false;
				$scope.flags.isTablewaalosservers = false;
				$scope.flags.isTableloadBalancer = false;
				$scope.gridOptionswmservers.columnDefs = [
				  { name: 'appName', displayName: 'APPNAME', cellTooltip: true, headerTooltip: true,enableCellEdit: false,sort: { direction: uiGridConstants.ASC, priority: 1 }  },
				  { name: 'machineName', displayName: 'HOST',cellTooltip: true, headerTooltip: true,enableCellEdit: true},
				  { name: 'appUid', displayName: 'APPUSER', cellTooltip: true, headerTooltip: true,enableCellEdit: true },
				  { name: 'appDb', displayName: 'APPDB', cellTooltip: true, headerTooltip: true,enableCellEdit: true},
				  { name: 'appdbUid', displayName: 'DBUSER', cellTooltip: true, headerTooltip: true,enableCellEdit: true}
				];
		
				$scope.gridOptionswmservers.totalItems  = data.infoWmsDto.totalNoOfRecords;  
				$scope.gridOptionswmservers.data = data.infoWmsDto.pageItems;

				if ($scope.gridOptionswmservers.data > 10) {
					$scope.gridOptionswmservers.enableVerticalScrollbar = true;
				} else {
					$scope.gridOptionswmservers.enableVerticalScrollbar = false;
					$scope.gridOptionswmservers.enableHorizontalScrollbar = 0;
	
				}
				if(data.dcName){
				if(data.dcName.length > 0){
				$scope.DCName = data.dcName;
				}else{
				$scope.DCName = "";
				}
				}else{
				$scope.DCName = "";
				}


				if(data.uiLoadBalancerDto){
				if(data.uiLoadBalancerDto .length > 0){
				$scope.uiLoadBalancerDto = data.uiLoadBalancerDto;				
				}else{
				$scope.uiLoadBalancerDto = "";
				}
				}else{
				$scope.uiLoadBalancerDto = "";
				}



				if(data.rfLoadBalancerDto){
				if(data.rfLoadBalancerDto .length > 0){
				$scope.rfLoadBalancerDto = data.rfLoadBalancerDto;
				}else{
				$scope.rfLoadBalancerDto = "";
				}
				}else{
				$scope.rfLoadBalancerDto = "";
				}


				if(data.lmLoadBalancerDto){
				if(data.lmLoadBalancerDto .length > 0){
				$scope.lmLoadBalancerDto = data.lmLoadBalancerDto;
				}else{
				$scope.lmLoadBalancerDto = "";
				}
				}else{
				$scope.lmLoadBalancerDto = "";
				}


				
				if(data.osagents){
				if(data.osagents.length > 0){
				$scope.osagents = data.osagents[0].port;
				}else{
				$scope.osagents = "";
				}

				}else{
				$scope.osagents = "";
				}


				if(data.patchopstatus){
				if(data.patchopstatus.length > 0){
				 openstatus = data.patchopstatus[0].opsStatus;
				 sdnNum = data.patchopstatus[0].sdnNum;
				 opsDate = data.patchopstatus[0].opsDate;
				}else{
				 openstatus = "";
				 sdnNum = "";
				 opsDate = "";
				}
				}else{
				 openstatus = "";
				 sdnNum = "";
				 opsDate = "";
				}


				if(data.restartdate){
				if(data.restartdate.length > 0){
				 restartDate = data.restartdate[0].restartDate;
				}else{
				 restartDate = "";
				}
				}else{
				 restartDate = "";
				}

		
			

				$scope.details = $sce.trustAsHtml(
					'<div style="margin-bottom:5px"><span style="">Last Patch Action [1=in|2=out|3=deliver]: </span> <span style="color:green;margin-left:5px">'+ 
					openstatus  +" "+ sdnNum  +" "+ opsDate +
					'</span></div><span style="margin-right:5px;">Last Restart:</span><span style="color:green;">'+restartDate);
			
			
			}
		});
	
		res.error(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			$scope.isTable = false;
			$scope.isFailed = true;
			$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
		});
		setTimeout(function(){  $('.ui-grid-pager-control-input').attr( "disabled", true );  }, 2000);
		
};
  
}]);


