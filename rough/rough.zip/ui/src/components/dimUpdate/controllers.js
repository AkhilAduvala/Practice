var app = angular.module('DimUpdate', ['ngTouch', 'ui.grid', 'ui.grid.edit', 'ui.grid.cellNav','ui.grid.selection','ui.grid.pagination','ui.grid.validate']);

app.controller('DimUpdateController', ['$scope', '$http', '$q', '$interval','$timeout','urlService', 'uiGridConstants','commonService','uiGridValidateService', function ($scope, $http, $q, $interval,$timeout,urlService,uiGridConstants,commonService,uiGridValidateService) {
 $scope.isTable = false;
 $scope.disable = true;
 $scope.isupdate = true;
 $scope.isSuccess = false;
 $scope.isFailed = false;
 $scope.isClicked = false;
 $scope.isTablecubiscan = false;
 $scope.isrefresh = false;
 $scope.hidensnc=false;
 $scope.buttondisableddc=false;
 $scope.pagefunctionality = $scope.functionality;
 $scope.pagedc = $scope.dcName;
 $("#showloader").css("display", "none");
 
 	$scope.init = function (){
		if($scope.dcName == "US1"||$scope.dcName == "US2"||$scope.dcName == "BDC"||$scope.dcName == "DTC"){
			$scope.buttondisableddc=true;
		}	
	};	

  $scope.gridOptions = { 
    paginationPageSizes: [15, 25, 50, 100],
    paginationPageSize: 100,
    useExternalPagination: true,
    enableSorting: true,
    enableColumnMenus: false,
	  multiSelect:true,
    enableRowSelection: true,//we can remove it later no use  of this
    enableSelectAll: true,//we can remove it later no use  of this             
    enableCellEdit: false, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
    enableHorizontalScrollbar:true,
    enableCellEditOnFocus: true // set any editable column to allow edit on focus

  };

  $scope.gridOptions.onRegisterApi = function(gridApi){
    //set gridApi on scope
    $scope.gridApi = gridApi; 
  
    $scope.gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
    $scope.pageNo =  newPage;
    $scope.pageSize = pageSize;
    $scope.getupdateData();
 });
    
  
    };
    
    $scope.dataValues = {
      "recsProcessed": '',
      "lastRunTime": '',
       "lastRunStatus": '',
       "isJobRunning": ''
    };

$scope.getupdateData = function (runjob) {
$("#showloader").css("display", "block");
    $scope.isSuccess = false;
    $scope.isFailed = false;
       if(runjob){
      $scope.pageNo =  1;
      $scope.pageSize = 100;
    }else{
      $scope.pageNo = $scope.pageNo ? $scope.pageNo : 1;
      $scope.pageSize = $scope.pageSize ? $scope.pageSize: $scope.gridOptions.paginationPageSize;
    }
    var region;
    if($scope.dcName == "Suzhou" || $scope.dcName == "Suzhou2" || $scope.dcName == "Tianjin"){
      region = "CHN";
    }else if($scope.dcName == "US1" || $scope.dcName == "US2" || $scope.dcName == "DTC" || $scope.dcName == "BDC" || $scope.dcName == "OneWMS-US1" ){
		  region = "NAM";
	}else if($scope.dcName == "Chile" || $scope.dcName == "Mexico" || $scope.dcName == "OneWMS-Brazil" || $scope.dcName == "OneWMS-Panama"){
		  region = "LAT";
	}
    
    var url = urlService.DIM_UPDATE_GET_DATA.replace('uName',sessionStorage.userName);
    url = url.replace('pNumber',$scope.pageNo);
    url = url.replace('pSize',$scope.pageSize);
    url = url.replace('regName',region);
 
    var res = $http.get(url, {
        headers: {'x-api-key': sessionStorage.apikey}
    });
    res.success(function (data, status, headers, config) {
      $("#showloader").css("display", "none");
	
      if (data.errorMessage) {
        $scope.isFailed = true;
        $scope.resmessage = data.errorMessage;
      }    else if (data.resMessage) {
	if(data.dimUpdateDtoPgs.totalNoOfRecords == 0){
    $scope.gridOptions.data.length = 0; 
	}

        $scope.isSuccess= true;
        $scope.resmessage = data.resMessage;
	$scope.isrefresh = true;
        $scope.dataValues.recsProcessed= data.recsProcessed;
        $scope.dataValues.lastRunTime = data.lastRunTime;
        $scope.dataValues.lastRunStatus = data.lastRunStatus;
        $scope.dataValues.isJobRunning = data.isJobRunning;

      }else {
        $scope.isrefresh = true;
        $scope.dataValues.recsProcessed= data.recsProcessed;
        $scope.dataValues.lastRunTime = data.lastRunTime;
        $scope.dataValues.lastRunStatus = data.lastRunStatus;
        $scope.dataValues.isJobRunning = data.isJobRunning;
        if(data.isJobRunning == "N"){
          $scope.isupdate = false; 
        }else{
          $scope.isupdate = true;
        }
        
        if(data.dimUpdateDtoPgs.totalNoOfRecords != 0){
          
          $scope.gridOptions.totalItems  = data.dimUpdateDtoPgs.totalNoOfRecords; 
          $scope.gridOptions.data = data.dimUpdateDtoPgs.pageItems;
		   $scope.gridOptions.columnDefs = [
      { name: 'recId',visible:false, enableCellEdit: false, sort: { direction: uiGridConstants.ASC, priority: 1 },  cellTooltip: true, headerTooltip: true,},
      { name: 'skuId', displayName: 'SKU ID',width:100,  enableCellEdit: false,cellTooltip: true, headerTooltip: true},
      { name: 'prodType', displayName: 'Prod Type',width:100,enableCellEdit: false,cellTooltip: true, headerTooltip: true },
      { name: 'unitHeight', displayName: 'Unit Height' ,width:100,enableCellEdit: false,cellTooltip: true, headerTooltip: true },
      { name: 'unitLength', displayName: 'Unit Length',width:100,enableCellEdit: false,cellTooltip: true, headerTooltip: true },
      { name: 'unitWidth', displayName: 'Unit Width',width:100,enableCellEdit: false,cellTooltip: true, headerTooltip: true },
      { name: 'unitVol', displayName: 'Unit Vol' ,width:100,enableCellEdit: false,cellTooltip: true, headerTooltip: true  },
      { name: 'unitWeight', displayName: 'Unit Weight',width:100,enableCellEdit: false,cellTooltip: true, headerTooltip: true  },
      { name: 'stdCaseWidth', displayName: 'STD Case Width',width:140,enableCellEdit: false,cellTooltip: true, headerTooltip: true  },
      { name: 'stdCaseLength', displayName: 'STD Case Length',width:140,enableCellEdit: false,cellTooltip: true, headerTooltip: true  },
      { name: 'stdCaseHeight', displayName: 'STD Case Height',width:140,enableCellEdit: false,cellTooltip: true, headerTooltip: true  },
      { name: 'stdCaseWeight', displayName: 'STD Case Weight',width:140,enableCellEdit: false,cellTooltip: true, headerTooltip: true  },
      { name: 'stdCaseVol', displayName: 'STD Case Vol',width:120,enableCellEdit: false,cellTooltip: true, headerTooltip: true  },
      { name: 'stdCaseQty', displayName: 'STD Case Qty',width:120,enableCellEdit: false,cellTooltip: true, headerTooltip: true  },
      { name: 'sourceDc', displayName: 'Source Dc',width:120,enableCellEdit: false,cellTooltip: true, headerTooltip: true  },
      { name: 'createdOn', displayName: 'Created On',width:170,enableCellEdit: false,cellTooltip: true, headerTooltip: true  },
      { name: 'status', visible:false,enableCellEdit: false,cellTooltip: true, headerTooltip: true  },
      { name: 'conveyFlag',visible:false,enableCellEdit: false,cellTooltip: true, headerTooltip: true  },
      { name: 'cartonType',visible:false,enableCellEdit: false,cellTooltip: true, headerTooltip: true  }
      ];
       
        
		
        if ($scope.gridOptions.data.length > 10) {
          $scope.gridOptions.enableVerticalScrollbar = true;

        } else {
          $scope.gridOptions.enableVerticalScrollbar = false;
         
        }
      }else{
if(runjob == 'runjob'){
$scope.isupdate = true;
}else{
  $scope.isTable = false;
$scope.isupdate = true;
$scope.isrefresh = true;
$scope.gridOptions.data.length = 0; 
        $scope.isSuccess= true;
        $scope.resmessage = "No data to process";
}

      }
        
      }
      $('.ui-grid-pager-control input').prop( "disabled", true );
    });
    res.error(function (data, status, headers, config) {
      $("#showloader").css("display", "none");
      $scope.isFailed = true;
      $scope.resmessage = data.replace(/(<([^>]+)>)/ig,"");

    });
  };
  
  $scope.getupdateData();

  $scope.runJob = function () {

	$("#showloader").css("display", "block");
    $scope.resmessage = "";
    $scope.isSuccess = false;
    $scope.isFailed = false;
    var region;

  if($scope.dcName == "Suzhou" || $scope.dcName == "Suzhou2" || $scope.dcName == "Tianjin"){
    region = "CHN";
  }else if($scope.dcName == "US1" || $scope.dcName == "US2" || $scope.dcName == "DTC" || $scope.dcName == "BDC" || $scope.dcName == "OneWMS-US1" ){
		  region = "NAM";
	}else if($scope.dcName == "Chile" || $scope.dcName == "Mexico" || $scope.dcName == "OneWMS-Brazil" || $scope.dcName == "OneWMS-Panama"){
		  region = "LAT";
	}
	
	var records = {
        "userName":sessionStorage.userName,
        "dcName": $scope.dcName,
        "region":  region
		};
    

var res = $http.put(urlService.DIM_UPDATE_RUN_JOB, records, {
    headers: {'x-api-key': sessionStorage.apikey}
});
    res.success(function (data, status, headers, config) {

      $("#showloader").css("display", "none");
      if (data.errorMessage) {
        $scope.isFailed = true;
        $scope.resmessage = data.errorMessage;
      } else {
      $scope.getupdateData('runjob');
	    $scope.isupdate = true;
	    $scope.isSuccess = true;
	    $scope.resmessage = data.resMessage;
 		 }
    });
    res.error(function (data, status, headers, config) {
      $("#showloader").css("display", "none");
      $scope.isFailed = true;
      $scope.resmessage = data.replace(/(<([^>]+)>)/ig,"");
    });
  };
 

   //user favourites code start
   $scope.addToFavourate = function(isClicked){
    $("#showloader").css("display", "block");
     if(typeof isClicked !== "boolean"){
      commonService.postServiceResponse(urlService.GET_FAVOURITES,{"username": sessionStorage.userName})
        .then(function(response){
          $("#showloader").css("display", "none");
            _.each(response,function(val,key){
              if(val.funName == $scope.functionality && val.dcName == $scope.dcName){
                $scope.isClicked = true;      
              }
            });
        },function(error){
          $("#showloader").css("display", "none");
          $scope.isClicked = false; 
        });
        
     }else{
      if(!$scope.isClicked){
        commonService.postServiceResponse(urlService.ADD_FAVOURITE,{"username": sessionStorage.userName,"dcName":$scope.dcName,"funName":$scope.functionality})
        .then(function(response){
          $("#showloader").css("display", "none");
          if(response.errorMessage){
            $scope.isFavouriteAdded= false; 
            $scope.isClicked = false;      
            $scope.$broadcast('showAlert',['']);
          }else{
            $scope.isClicked = true;      
            $scope.isClicked = !isClicked;
            $scope.isFavouriteAdded= true; 
            $scope.favouriteMsg = response.resMessage;
          $scope.$broadcast('ClickedOnFavourate',[$scope.dcName,$scope.functionality,$scope.isClicked]);
          }
            
        },function(error){
          $scope.isClicked = false;
          $("#showloader").css("display", "none");
        });
        $scope.isClicked = !isClicked;
      }else{
        $("#showloader").css("display", "none");
      }
     }
    
  };
   $scope.addToFavourate('load');
   // user favourites code end
   
  $scope.enableFirstCell = true;
  $scope.enableSecondCell = true;
  $scope.enableUpdateBtn = true;
  $scope.isFavouriteAdded = false;
  $scope.editedRowData = [];
  $scope.isChecked = ['yes', 'no'];
  
   $('[data-toggle="tooltip"]').tooltip();

  $scope.gridOptionsCubiscan = {
     enableColumnMenus: false,
     enableHorizontalScrollbar: false,
     multiSelect: true,//pradeep
     enableVerticalScrollbar: false,
     enableRowSelection: true,//we can remove it later no use  of this
     enableSelectAll: true,//we can remove it later no use  of this             
     enableCellEdit:$scope.sampleJson, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
     enableCellEditOnFocus: true // set any editable column to allow edit on focus
  };
  $scope.gridOptionsCubiscan.onRegisterApi = function (gridApi) {
       //set gridApi on scope
      $scope.gridApi = gridApi;

       gridApi.selection.on.rowSelectionChanged(null, function (row) {
        $scope.isFailed = false;
        $scope.isSuccess = false;
        $scope.rowsChecked = row.isSelected;
        $scope.editedRowData = row.entity;
         validateDataAndEnableUpdate();
        $scope.enableUpdateBtn = !$scope.rowsChecked;
       });

       gridApi.edit.on.afterCellEdit(null, function (rowEntity, colDef, newValue, oldValue) {
        $scope.isFailed = false;
        $scope.isSuccess = false;
         if (colDef.name === 'nsncFlag') {//pradeep
           if (newValue === 1) {
             rowEntity.sizeOptions =$scope.nsSizeDropdownOptions;
           } else {
             rowEntity.sizeOptions =$scope.ncSizeDropdownOptions;
           }
         }
         if (newValue != oldValue || newValue !== oldValue) {// To check old and new values same or not
           if (newValue == "") {
           } else if (+(newValue) == oldValue) {

           } else {
            $scope.gridApi.selection.selectRow(rowEntity);
           }
         }
       });
      };
     
      function validateDataAndEnableUpdate() {
        $timeout(function () {
          var found = $('.ui-grid-cell-contents');
          if (found.hasClass('invalid')) {
            $scope.$apply(function () {
             $scope.isFieldValidate = true;
             $scope.enableUpdateBtn = true;
            });
          } else if ($scope.gridApi.selection.getSelectedRows().length === 0) {
            $scope.$apply(function () {
             $scope.enableUpdateBtn = true;
            });
          } else {
            $scope.$apply(function () {
             $scope.isFieldValidate = false;
             $scope.enableUpdateBtn = false;
            });
          }
        }, 100);
      }

   uiGridValidateService.setValidator('numberChecker',
     function (argument) {
       return function (oldValue, newValue, rowEntity, colDef) {
         if (newValue == '') {
          $scope.isFieldValidate = true;
          $scope.enableUpdateBtn = true;
           $scope.$apply(function () {
            $scope.gridOptionsCubiscan.enableRowSelection = false;
           });
           validateDataAndEnableUpdate();
         }
         else if (!newValue) {
           return /^[0-9]{0,5}(\.[0-9]{1,2})?$/.test(newValue);
         } else {
           if (!(/^[0-9]{0,5}(\.[0-9]{1,2})?$/.test(newValue))) {
            $scope.isFieldValidate = true;
            $scope.enableUpdateBtn = true;
             $scope.$apply(function () {
              $scope.gridOptionsCubiscan.enableRowSelection = false;
             });
           } else {
            $scope.isFieldValidate = false;
            $scope.enableUpdateBtn = false;
            $scope.gridOptionsCubiscan.enableRowSelection = true;
             validateDataAndEnableUpdate();
           }
           return /^[0-9]{0,5}(\.[0-9]{1,2})?$/.test(newValue);
         }
       };
     },
     function (argument) {
       return 'Only numbers are allowed and max 5 digits with 2 decimal values are only a$scopeepted';
     }
   );



  $scope.changeValue = function (grid, row) {
     var a = row.entity.drpvalue;
   };
  $scope.getConfiguratorData = function () {
    $scope.isrefresh = false;
    $scope.enableUpdateBtn = true;
     $("#showloader").css("display", "block");
     var url = urlService.GET_NSNC_RULE.replace('dName', $scope.dcName);
     url = url.replace('uName', sessionStorage.userName);

 $http.get(url, {
            headers: {'x-api-key': sessionStorage.apikey}
      })
       .success(function (data) {
        $("#showloader").css("display", "none");
         if (data.errorMessage) {
          $scope.isFailed = true;
          $scope.isSuccess= false;
          $scope.resmessage = data.errorMessage;
         }else{
         for (i = 0; i < data.length; i++) {
           if (data[i].nsncFlag === 'Y') {
             data[i].nsncFlag = 1;
             data[i].size = Math.floor(Math.random() * (5 - 1)) + 1;
             data[i].sizeOptions = $scope.nsSizeDropdownOptions;
           } else {
             data[i].nsncFlag = 2;
             data[i].size = Math.floor(Math.random() * (10 - 5)) + 5;
             data[i].sizeOptions = $scope.ncSizeDropdownOptions;
           }
         }
         $scope.isTablecubiscan = true;
         $scope.isTable = false;
         $scope.gridOptionsCubiscan.columnDefs= [
          { name: 'dcName', displayName: '', cellEditableCondition: false },
          {
            name: 'unitLen', displayName: 'Length', sort: { direction: uiGridConstants.ASC }, validators: { required: true, numberChecker: true }, cellTemplate: 'ui-grid/cellTitleValidator', cellEditableCondition: function ($scope) {
              if ($scope.row.entity.dcName == 'Non-Sortable') {
                return $scope.enableFirstCell;
              } else {
                return !$scope.enableSecondCell;
              }
            }
          },
          {
            name: 'unitWidth', displayName: 'Width', sort: { direction: uiGridConstants.ASC }, validators: { required: true, numberChecker: true }, cellTemplate: 'ui-grid/cellTitleValidator', cellEditableCondition: function ($scope) {
              if ($scope.row.entity.dcName == 'Non-Sortable') {
                return $scope.enableFirstCell;
              } else {
                return !$scope.enableSecondCell;
              }
            }
          },
          {
            name: 'unitHt', displayName: 'Height', sort: { direction: uiGridConstants.ASC }, validators: { required: true, numberChecker: true }, cellTemplate: 'ui-grid/cellTitleValidator', cellEditableCondition: function ($scope) {
              if ($scope.row.entity.dcName == 'Non-Sortable') {
                return $scope.enableFirstCell;
              } else {
                return !$scope.enableSecondCell;
              }
            }
          },
          {
            name: 'unitWt', displayName: 'Weight', sort: { direction: uiGridConstants.ASC }, validators: { required: true, numberChecker: true }, cellTemplate: 'ui-grid/cellTitleValidator', cellEditableCondition: function ($scope) {
              if ($scope.row.entity.dcName == 'Non-Sortable') {
                return !$scope.enableFirstCell;
              } else {
                return $scope.enableSecondCell;
              }
            }
          },
          {
            name: 'unitVol', displayName: 'Volume', cellEditableCondition: function ($scope) {
              if ($scope.row.entity.dcName == 'Non-Sortable') {
                return $scope.enableFirstCell;
              } else {
                return $scope.enableSecondCell;
              }
            }
          },
   
          {
            name: 'nsncFlag', displayName: 'NSNC Flag', editableCellTemplate: 'ui-grid/dropdownEditor', width: '20%',
            cellFilter: 'nsncFilter', editDropdownValueLabel: 'NSNC', editDropdownOptionsArray: [
              { id: 1, NSNC: 'Y' },
              { id: 2, NSNC: 'N' }
            ]
          },
        ];
        $scope.gridOptionsCubiscan.data = data;

         _.each(data, function (value, key) {
           if (value.refDesc == 'NS') {
            $scope.gridOptionsCubiscan.data[key].dcName = 'Non-Sortable';
           } else if (value.refDesc == 'NC') {
            $scope.gridOptionsCubiscan.data[key].dcName = 'Non-Conveyable';
           }
         });
 }
         
       }).error(function (data) {
         $("#showloader").css("display", "none");
        $scope.isFailed = true;
        $scope.isSuccess = false;
         $scope.resmessage = data.replace(/(<([^>]+)>)/ig,"");
        $scope.isTable = false;
       });
   };


  $scope.fnUpdateGrid = function () {
    $scope.isrefresh = false;
    $scope.isFailed = false;
    $scope.isSuccess = false;
     $("#showloader").css("display", "block");
     var temp = [];
     var selectedRows =$scope.gridApi.selection.getSelectedRows();
     for (var i = 0; i < selectedRows.length; i++) {
       var obj = {};
       obj.dcName = $scope.dcName;
       obj.userName = sessionStorage.userName;
       obj.nsncFlag = ($scope.gridApi.selection.getSelectedRows()[i].nsncFlag === 1 ? $scope.gridApi.selection.getSelectedRows()[i].nsncFlag = 'Y' : $scope.gridApi.selection.getSelectedRows()[i].nsncFlag = 'N');
       obj.unitLen =$scope.gridApi.selection.getSelectedRows()[i].unitLen;
       obj.unitWidth =$scope.gridApi.selection.getSelectedRows()[i].unitWidth;
       obj.unitHt =$scope.gridApi.selection.getSelectedRows()[i].unitHt;
       obj.unitWt =$scope.gridApi.selection.getSelectedRows()[i].unitWt;
       obj.unitVol =$scope.gridApi.selection.getSelectedRows()[i].unitVol;
       obj.refDesc =$scope.gridApi.selection.getSelectedRows()[i].refDesc;
       temp.push(obj);
     }	

      $http.put(urlService.UPDATE_NSNC_RULE,temp, {
            headers: {'x-api-key': sessionStorage.apikey}
      })

       .success(function (data) {
         $("#showloader").css("display", "none");
         if (data.errorMessage) {
          $scope.isFailed = true;
          $scope.isSuccess= false;
          $scope.resmessage = data.errorMessage;
         } else {
          $scope.isSuccess= true;
          $scope.isFailed = false;
          $scope.resmessage = data.resMessage;
          $scope.getConfiguratorData();
         }
        
       })
       .error(function (data) {
         $("#showloader").css("display", "none");
        $scope.isFailed = true;
        $scope.isSuccess = false;
        $scope.resmessage = data.replace(/(<([^>]+)>)/ig,"");
       });

   };

   $scope.switchTo = function(switchName){
    $scope.isFailed = false;
    $scope.isSuccess = false;
    if(switchName == "cubiscan"){
     $scope.getConfiguratorData();
    }else{
      $scope.isTable = true;
      $scope.isTablecubiscan = false;
      $scope.isrefresh = true;
    }
   };


}])
.filter('nsncFilter', function () {//pradeep
  var options = {
    1: 'Y',
    2: 'N'
  };

  return function (input) {
    if (!input) {
      return '';
    } else {
      return options[input];
    }
  };
});

