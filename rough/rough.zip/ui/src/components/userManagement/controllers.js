var app = angular.module('UserManage', [ 'ui.grid.pagination','ngAnimate', 'ui.grid', 'ui.grid.selection', 'ui.bootstrap','ui.grid.autoResize' ]);

app.controller('UserManageCtrl', UserManageCtrl);
app.controller('UserManageRowEditCtrl', UserManageRowEditCtrl);
app.service('UserManageRowEditor', UserManageRowEditor);

UserManageCtrl.$inject = [ '$scope', '$http', '$uibModal', 'UserManageRowEditor', 'uiGridConstants','commonService','urlService','$timeout' ];
function UserManageCtrl($scope, $http, $uibModal, UserManageRowEditor, uiGridConstants,commonService,urlService,$timeout) {
	$scope.isTable = false;
	$scope.isDelete = true;
       $scope.isSuccess = false;
	$scope.isSearchData = true;
	var vm = this;

	$scope.disable = true;
	vm.editRow = UserManageRowEditor.editRow;
	vm.addRow = UserManageRowEditor.addRow;
		vm.serviceGrid = {

		paginationPageSizes: [15, 25, 50, 100],
		paginationPageSize: 15,
		useExternalPagination: true,
		enableColumnMenus: false,
		enableCellEditOnFocus: true,
		rowTemplate : "<div ng-dblclick=\"grid.appScope.vm.editRow(grid, row)\" ng-repeat=\"(colRenderIndex, col) in colContainer.renderedColumns track by col.colDef.name\" class=\"ui-grid-cell\" ng-class=\"{ 'ui-grid-row-header-cell': col.isRowHeader }\" ui-grid-cell></div>"
	};

		vm.serviceGrid.onRegisterApi = function (gridApi) {
		$scope.gridApi = gridApi;

		$scope.gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
      $scope.pageNo =  newPage;
      $scope.pageSize = pageSize;
      $scope.getuserdata();
	 });
	 
			gridApi.selection.on.rowSelectionChangedBatch($scope, function (rows) {
 			$scope.isSuccess = false;
  			$scope.isFailed = false;
			if ($scope.gridApi.selection.getSelectedRows().length == 0) {
				$scope.isDelete = true;
				$("#delRow").removeAttr("disabled");
			} else {
				$scope.isDelete = false;
			}
		});

		gridApi.selection.on.rowSelectionChanged($scope, function (row) {
  		$scope.isSuccess = false;
  		$scope.isFailed = false;
			if ($scope.gridApi.selection.getSelectedRows().length > 0) {
				$scope.isDelete = false;
				$("#delRow").removeAttr("disabled");
			} else {
				$scope.isDelete = true;
			}
		});
		};

	vm.serviceGrid.columnDefs = [ {
		field : 'usrId',
		displayName : 'User Login',
		enableSorting : true,
		enableCellEdit : false,
		cellTemplate: '<div class="ui-grid-cell-contents" ng-click=\"grid.appScope.vm.editRow(grid, row)\" style="cursor : pointer;"  title="{{COL_FIELD}}"><a href="javascript:void(0)">{{COL_FIELD}}</a></div>'

	}, {
		field : 'userGroup',
		displayName : 'User Group',
		enableSorting : true,
		enableCellEdit : false
	}, {
		field : 'usrFirstName',
		displayName : 'First Name',
		enableSorting : true,
		enableCellEdit : false
	}, {
		field : 'usrLastName',
		displayName : 'Last Name',
		width : 120,
		enableSorting : true,
		enableCellEdit : false
	}, {
		field : 'emailId',
		displayName : 'Email ID',
		enableSorting : true,
		enableCellEdit : false
	} ];

	// jquery click event for the sidebar panel to expand and collapse Start 
	jQuery('[data-toggle=offcanvas]').click(function () {
		
					if (jQuery('.sidebar-offcanvas').css('background-color') == 'rgb(255, 255, 255)') {
		
							jQuery('.list-group-item').attr('tabindex', '-1');
		
					} else {
		
							jQuery('.list-group-item').attr('tabindex', '');
		
					}
		
					if (jQuery("#toggling").attr('class') == "row row-offcanvas row-offcanvas-left") {
							jQuery("#toggling").addClass('row row-offcanvas row-offcanvas-left active');
							jQuery("#arrow-toggle").removeClass('arrow-toggle');
							jQuery('#arrow-toggle img').attr('src', 'img/expand.png');
							jQuery("#Form-elements").css("display", "none");
							jQuery("#back-selection").css("display", "block");
					} else {
							jQuery("#toggling").removeClass('active');
							jQuery("#arrow-toggle").addClass('arrow-toggle');
							jQuery('#arrow-toggle img').attr('src', 'img/collpase.png');
							jQuery("#Form-elements").css("display", "block");
							jQuery("#back-selection").css("display", "none");
		
					}
			});
			// jquery click event for the sidebar panel to expand and collapse end
	commonService.setData('scope',$scope);
	$scope.getuserdata = function(){
      $scope.isSuccess = false;
  		$scope.isFailed = false;

		$("#showloader").css("display", "block");
		$scope.pageNo = $scope.pageNo ? $scope.pageNo : 1;
		$scope.pageSize = $scope.pageSize ? $scope.pageSize: vm.serviceGrid.paginationPageSize;
		var dataObj = {
			"userName" : sessionStorage.userName,//$scope.userName;
			"pageNumber": $scope.pageNo,
			"pageSize": $scope.pageSize
		};
		var service_url = urlService.USER_MGMT_ALL_USER_DATA;
		var res = $http.post(service_url,dataObj);
		res.success(function (data, status, headers, config) {

			if(data.errorMessage){
			  $scope.isSuccess = true;
			 $scope.resMessage = data.errorMessage;
			 $("#showloader").css("display", "none");
			 $scope.setTopPosition={
 			 "top":"42px",
 			 "color":"red"
           		};
			}else if(data.resMessage){
 			 $scope.isSuccess = true;
 			 $scope.resMessage = data.resMessage;
			 $("#showloader").css("display", "none");
			 $scope.setTopPosition={
 			 "top":"42px",
 			 "color":"green"
			};
		       }else if (data.page) {

			$scope.isTable = true;
 			$scope.isSuccess = true;
			vm.serviceGrid.totalItems  = data.page.totalNoOfRecords;  
			vm.serviceGrid.data = data.page.pageItems;
			commonService.setData('allUserData',data);
			$("#showloader").css("display", "none");
		  }

		  
		});
		res.error(function (data, status, headers, config) {
 		$scope.isSuccess = true;
		  $scope.resMessage = "System failed. Please try again or contact WAALOS Support";
		  $("#showloader").css("display", "none");
			$scope.setTopPosition={
			  "top":"42px",
				"color":"red"
		  };
		});
		setTimeout(function(){  $('.ui-grid-pager-control-input').attr( "disabled", true );  }, 2000);
	};
	$scope.getuserdata();
	$scope.$on("CallParentMethod", function(){
           $scope.getuserdata();
	});

	$scope.reset = function(){
		$scope.UserLogin=""; 
		$scope.FirstName=""; 
		$scope.LastName="";
		$scope.resMessage="";
              $scope.isSearchData = true;
  		$scope.isSuccess = false;
  		$scope.isFailed = false;
		$scope.getuserdata();
	
	};
	$scope.addRow = function() {
        $scope.isSuccess = false;
		var newService = {
			"usrId":"",
			"userGroup":"",
			"usrFirstName":"",
			"usrLastName":"",
			"emailId":"",
		};
		var rowTmp = {};
		rowTmp.entity = newService;
		vm.addRow($scope.vm.serviceGrid, rowTmp);
	};
	$scope.validate = function(){
        $scope.isSuccess = false;
		if($scope.UserLogin || $scope.FirstName || $scope.LastName){
		$scope.isSearchData = false;
		}else{
			$scope.isSearchData = true;
		}


	};
	$scope.filter = function(){
		$("#showloader").css("display", "block");
		$scope.isSuccess = false;
		var data = { usrId: $scope.UserLogin, usrFirstName: $scope.FirstName, usrLastName: $scope.LastName};
		//console.log(data);
		var service_url = urlService.USER_MGMT_FILTER_USER;
		var res = $http.post(service_url, data);
      res.success(function (data, status, headers, config) {
		  if (data.pageItems) {
			$timeout(function () {
				$scope.isTable = true;
				vm.serviceGrid.data = data.pageItems;
				vm.serviceGrid.totalItems  = data.pageItems.length;  
    	});		 $scope.isSuccess = true;
			$scope.resMessage = data.resMessage;
			$("#showloader").css("display", "none");
			$scope.setTopPosition={
			  "top":"42px",
				"color":"green"
		  };
		  }else if(data.resMessage){
                           $scope.isSuccess = true;
				$scope.resMessage = data.resMessage;
				$scope.isTable = false;
				$("#showloader").css("display", "none");
				$scope.setTopPosition={
				  "top":"42px"
				
			  };


			} else {	 $scope.isSuccess = true;
				$scope.resMessage = data.errorMessage;
				$scope.isTable = false;
				$("#showloader").css("display", "none");
				$scope.setTopPosition={
				  "top":"42px",
					"color":"red"
			  };
		  }
		});
		res.error(function (data, status, headers, config) {
 		$scope.isSuccess = true;
		  $scope.resMessage = "System failed. Please try again or contact WAALOS Support";
		  $("#showloader").css("display", "none");
			$scope.setTopPosition={
			  "top":"42px",
				"color":"red"
		  };
		});
	};

	$scope.delRow = function(){
		var temp = [];
		angular.forEach($scope.gridApi.selection.getSelectedRows(), function (data, index) {
			var obj = {};
			obj.usrId = data.usrId;//$scope.dcName
			obj.userGroup = data.userGroup;//localStorage.getItem("userName");
			obj.usrFirstName = data.usrFirstName;
			obj.usrLastName = data.usrLastName;
			obj.emailId = data.emailId;

			temp.push(obj);
		});
		$("#showloader").css("display", "block");
		var service_url = urlService.USER_MGMT_DELETE_USER;
		var res = $http.put(service_url, temp);
		res.success(function (data, status, headers, config) {
		  if (data.errorMessage) {
 			$scope.isSuccess = true;
			 $scope.resMessage = data.errorMessage;
			 $("#showloader").css("display", "none");
			 $scope.setTopPosition={
 			  "top":"42px",
 				"color":"red"
 		  };
		  } else {
			$scope.getuserdata();
 			$scope.isSuccess = true;
			$scope.resMessage = data.resMessage;
			$("#delRow").attr("disabled",true);
			$scope.setTopPosition={
			  "top":"42px",
				"color":"green"
		  };
		  }
		});
		res.error(function (data, status, headers, config) {
 $scope.isSuccess = true;
		  $scope.resMessage = "System failed. Please try again or contact WAALOS Support";
		  $("#showloader").css("display", "none");
			$scope.setTopPosition={
			  "top":"42px",
				"color":"red"
		  };
		});
	};
}

UserManageRowEditor.$inject = [ '$http','$uibModal','urlService' ];
function UserManageRowEditor( $http,  $uibModal, urlService) {
	var service = {};
	service.editRow = editRow;
	service.addRow = addRow;
	function addRow(grid, row) {
		$uibModal.open({
			templateUrl : 'components/userManagement/views/service-add.html',
			controller : ['$http', '$uibModalInstance', 'grid', 'row', 'urlService','commonService', UserManageRowEditCtrl ],
			controllerAs : 'vm',
			resolve : {
				grid : function() {
					return grid;
				},
				row : function() {
					return row;
				}
			}
		});
	}
	function editRow(grid, row) {
		$uibModal.open({
			templateUrl : 'components/userManagement/views/service-edit.html',
			controller : ['$http', '$uibModalInstance', 'grid', 'row','urlService','commonService',UserManageRowEditCtrl ],
			controllerAs : 'vm',
			resolve : {
				grid : function() {
					return grid;
				},
				row : function() {
					return row;
				}
			}
		});
	}
	return service;
}



function UserManageRowEditCtrl($http, $uibModalInstance, grid, row,urlService,commonService) {
	var vm = this;
	vm.entity = angular.copy(row.entity);
	vm.actualValue = vm.entity.userGroup;
	vm.entity.userGroupArr = commonService.getData('allUserData').userRoles;
	if(row.entity.usrId == ""){
		vm.entity.userGroup = commonService.getData('allUserData').userRoles[0].roleName;
	}

	vm.save = save;
	function save(arg1) {
		if (row.entity.id == '0') {
			row.entity = angular.extend(row.entity, vm.entity);
			row.entity.id = Math.floor(100 + Math.random() * 1000);
			grid.data.push(row.entity);

		} else {
			row.entity = angular.extend(row.entity, vm.entity);
			if(arg1){
				row.entity.domainUserId = row.entity.usrId;//need to replace with ADFS
				addUser(row.entity);
			}else{
				modifyUser(row.entity);
			}

		}
		$uibModalInstance.close(row.entity);
	}

	vm.remove = remove;
	function remove() {


	}

	//edit operation
	function modifyUser(dataObj){
		var scope = commonService.getData('scope');
	 
		$("#showloader").css("display", "block");
		var service_url = urlService.USER_MGMT_MODIFY_USER;
		var res = $http.put(service_url,dataObj);
		res.success(function (data, status, headers, config) {
		  if (data.errorMessage) {
 scope.isSuccess = true;
			 scope.resMessage = data.errorMessage;
			 $("#showloader").css("display", "none");
			 scope.setTopPosition={
 			  "top":"42px",
 				"color":"red"
 		  };
		  } else { scope.isSuccess = true;
			scope.resMessage = data.resMessage;
			$("#showloader").css("display", "none");
			scope.setTopPosition={
			  "top":"42px",
				"color":"green"
		  };
		  }
		});
		res.error(function (data, status, headers, config) {
 scope.isSuccess = true;
		  scope.resMessage = "System failed. Please try again or contact WAALOS Support";
		  $("#showloader").css("display", "none");
			scope.setTopPosition={
			  "top":"42px",
				"color":"red"
		  };
		});
	}

	//Add operation
	function addUser(dataObj){
		var scope = commonService.getData('scope');
		$("#showloader").css("display", "block");
		var service_url = urlService.USER_MGMT_ADD_USER;
		var res = $http.post(service_url,dataObj);
		res.success(function (data, status, headers, config) {
		  if (data.errorMessage) { scope.isSuccess = true;
				 scope.resMessage = data.errorMessage;
				 $("#showloader").css("display", "none");
				 scope.setTopPosition={
	 			  "top":"42px",
	 				"color":"red"
	 		  };
		  } else {
				scope.childmethod = function() {
            scope.$emit("CallParentMethod", {});
        };
				scope.childmethod(); 
                           scope.isSuccess = true;
				scope.resMessage = data.resMessage;
				$("#showloader").css("display", "none");
				scope.setTopPosition={
				  "top":"42px",
					"color":"green"
			  };
		  }
		});
		res.error(function (data, status, headers, config) {
                scope.isSuccess = true;
		  scope.resMessage = "System failed. Please try again or contact WAALOS Support";
		  $("#showloader").css("display", "none");
			scope.setTopPosition={
			  "top":"42px",
				"color":"red"
		  };
		});
	}
}
