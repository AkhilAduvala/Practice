angular.module('Home')

.controller('HomeController', ['$scope', '$rootScope', '$http','$location','urlService',function ($scope, $rootScope, $http, $location,urlService) {

  $scope.isupdate = true;
  $scope.isSuccess = false;
  $scope.isFailed = false;
  $scope.isFailedload = false;
  $scope.isRecordFound = false;
  $("#showloader").css("display", "block");
  $scope.resmessage = "";
        var user = {
                 "username": sessionStorage.userName
             };
			
         var res = $http.post(urlService.GET_HOME_PAGE_DATA, user);
         //var res = $http.get('dclist.json');
            res.success(function (responce, status, headers, config) {
				
              $("#showloader").css("display", "none");
              if (responce.errorMessage) {
                 $scope.isFailed = true;
                $scope.resmessage = responce.errorMessage;
              } else if(responce.resMessage){
                  $scope.isSuccess = true;
                  $scope.resmessage = responce.resMessage;
                }
               else {
                $rootScope.DCDetails = responce[0];
                $rootScope.DCList = Object.keys($scope.DCDetails);
               $rootScope.dcName = $scope.DCList[0];
                $rootScope.functionality =  $scope.DCDetails[$rootScope.dcName][0].functnal_nm;//$rootScope.DCDetails[$rootScope.dcName][1].functnal_nm;
                //$rootScope.dcFunctionalities = $rootScope.DCDetails[$rootScope.dcName][0].functnal_nm;
                var temp = [];
               $rootScope.DCDetails[$rootScope.dcName].map(function(prop){
                    //$rootScope.DCDetails[prop].map(function(prop2){
                        temp.push(prop.functnal_nm);
                   // })
                });
                $rootScope.dcFunctionalities = temp;
        
              }
            });
            res.error(function (responce, status, headers, config) {
              $("#showloader").css("display", "none");
              $scope.isFailedload = true;
            });
            //user favourites code start
            $scope.$on('deletedFavourate',function(event,args){
              $scope.loadFavourites();
             });   
          $scope.loadFavourites = function(){
            $http.post(urlService.GET_FAVOURITES,{"username": sessionStorage.userName})
            .then(function(response){
                $scope.favourateList = response.data;
                if(response.data.length>0){
                  $rootScope.$broadcast('ClickedOnFavourate',['']);
                }
            },function(error){

          }); 
          };
     $scope.goToPath=function(path){
            $rootScope.$broadcast('changeDrpValues',[path.dcName,path.funName]);
            $location.path("/home/"+path.dcName+"/"+path.funName.replace(/\s/g,''));

            };

          $scope.loadFavourites();  
          //user favoourites code end
   }]);


 