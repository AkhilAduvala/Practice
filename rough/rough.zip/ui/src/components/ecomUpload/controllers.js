var myApp = angular.module('EcomUpload');
$("#showloader").css("display", "none");
myApp.directive('fileModel', ['$parse', function($parse) {
    return {
        restrict: 'A',
        link: function(scope, element, attrs) {
            var model = $parse(attrs.fileModel);
            var modelSetter = model.assign;

            element.bind('change', function() {
                scope.$apply(function() {
                    modelSetter(scope, element[0].files[0]);
                });
            });
        }
    };
}]);

app.directive('numbersOnly', function() {
    return {
        require: 'ngModel',
        link: function(scope, element, attr, ngModelCtrl) {
            function fromUser(text) {
                if (text) {
                    var transformedInput = text.replace(/[^0-9]/g, '');

                    if (transformedInput !== text) {
                        ngModelCtrl.$setViewValue(transformedInput);
                        ngModelCtrl.$render();
                    }
                    return transformedInput;
                }
                return undefined;
            }
            ngModelCtrl.$parsers.push(fromUser);
        }
    };
});


myApp.controller('EcomUploadController', ['$scope', '$rootScope', '$http', '$window', 'fileUpload3', 'urlService', 'commonService', function($scope, $rootScope, $http, $window, fileUpload3, urlService, commonService) {
    $("#showloader").css("display", "none");
    $scope.disable = true;
    $scope.disableDownload = true;
    $scope.pagefunctionality = $scope.functionality;
    $scope.pagedc = $scope.dcName;
    $scope.lotId = "";
    $scope.isFailedload = false;
    $scope.isClicked = false;
    $scope.EcmUpld = 'WaveNo';


    $scope.submitHit = function() {
        $("#showloader").css("display", "block");
        var file = $scope.myFile;
        var dcName = $rootScope.dcName;
        var userName = sessionStorage.userName;
        var uploadUrl = urlService.ECOM_UPLOAD;
        var jobCodeSg = 'EPL_SG';
        var jobCodeTh = 'EPL_TH';
        var jobCodePh = 'EPL_PH';
        var fd = new FormData();
        document.getElementById('printerror').innerHTML = "";
        fd.append('dcName', dcName);
        fd.append('userName', userName);

        var test = $scope.EcmUpld;
        if (test == 'WaveNo') {
            fd.append('selectionType', $scope.EcmUpld);
            fd.append('selectionValue', $scope.forText1);
        } else if (test == 'CartID') {
            fd.append('selectionType', $scope.EcmUpld);
            fd.append('selectionValue', $scope.forText2);
        } else if (test == 'PalletID') {
            fd.append('selectionType', $scope.EcmUpld);
            fd.append('selectionValue', $scope.forText3);
        } else {
            fd.append('selectionType', $scope.EcmUpld);
            fd.append('selectionValue', $scope.forText4);
        }
        if (dcName == "Singapore") {
            fd.append('jobCode', jobCodeSg);
        } else if (dcName == "Philippines") {
            fd.append('jobCode', jobCodePh);
        } else if (dcName == "Thailand") {
            fd.append('jobCode', jobCodeTh);
        }

        $http.post(uploadUrl, fd, {
                transformRequest: angular.identity,
                headers: {
                    'Content-Type': undefined,
                    'x-api-key': sessionStorage.apikey
                }
            })

            .success(function(response) {
                $scope.disableDownload = false;
                document.getElementById('list').innerHTML = '';
                document.getElementById('nextStep').innerHTML = '';
                document.getElementById('printerror').innerHTML = "";
                document.getElementById('list').innerHTML = response.status;
                $scope.disable = true;
                $scope.errorMessagesArray = [];
                $("#showloader").css("display", "none");
                if (response.errorMessage) {
                    $scope.uploadError = response.errorMessage;
                    document.getElementById('list').innerHTML = "";
                    document.getElementById('printerror').innerHTML = response.errorMessage;
                    $("#showloader").css("display", "none");
                }
            })

            .error(function(error) {
                $("#showloader").css("display", "none");
                $scope.isFailedload = true;
                document.getElementById('list').innerHTML = '';
                document.getElementById('nextStep').innerHTML = '';
                $scope.errorMessagesArray = [];
            });

    };

    $scope.radioClick = function() {
		$scope.isFailedload = false;
        document.getElementById('printerror').innerHTML = "";
        document.getElementById('list').innerHTML = "";
        $(document).ready(function() {
            $('.radioContainer input[name="customerRadio"]').change(function(e) {

                $(".radioContainer input[type=text]").removeAttr("disabled");
                $(".radioContainer input[type=text]").not($(this).parents('.customClass').find("input[type=text]")).prop("disabled", true).val("");
                $(this).parents('.customClass').find("input[type=text]").focus();
            });
        })

    }
    $scope.clearFile = function() {
        $scope.isFailed = false;
        $scope.excelReadErrors = false;
        $scope.excelErrors = false;
		$scope.isFailedload = false;
        document.getElementById('list').innerHTML = '';
        document.getElementById('nextStep').innerHTML = '';
        document.getElementById('printerror').innerHTML = "";
        $scope.errorMessagesArray = [];
        $scope.disableDownload = true;
        //$scope.forText1 = null; 
        $(".radioContainer input[type=text]").val("");
    };

    var fileInput = document.getElementById("uploadFile");

    //user favourites code start

    $scope.addToFavourate = function(isClicked) {
        $("#showloader").css("display", "block");
        if (typeof isClicked !== "boolean") {
            commonService.postServiceResponse(urlService.GET_FAVOURITES, {
                    "username": sessionStorage.userName
                })
                .then(function(response) {
                    $("#showloader").css("display", "none");
                    _.each(response, function(val, key) {
                        if (val.funName == $scope.functionality && val.dcName == $scope.dcName) {
                            $scope.isClicked = true;
                        }
                    })
                }, function(error) {
                    $("#showloader").css("display", "none");
                    $scope.isClicked = false;
                });
            //$scope.isClicked = ;
        } else {
            if (!$scope.isClicked) {
                commonService.postServiceResponse(urlService.ADD_FAVOURITE, {
                        "username": sessionStorage.userName,
                        "dcName": $scope.dcName,
                        "funName": $scope.functionality
                    })
                    .then(function(response) {
                        $("#showloader").css("display", "none");
                        if (response.errorMessage) {
                            $scope.isFavouriteAdded = false;
                            $scope.isClicked = false;
                            $scope.$broadcast('showAlert', ['']);
                        } else {
                            $scope.isClicked = true;
                            $scope.isClicked = !isClicked;
                            $scope.isFavouriteAdded = true;
                            $scope.favouriteMsg = response.resMessage;
                            $scope.$broadcast('ClickedOnFavourate', [$scope.dcName, $scope.functionality, $scope.isClicked]);
                        }

                    }, function(error) {
                        $scope.isClicked = false;
                        $("#showloader").css("display", "none");
                    });
                $scope.isClicked = !isClicked;
            } else {
                $("#showloader").css("display", "none");
            }
        }

    }
    $scope.addToFavourate('load');
    //user favourites code ends


    $scope.downloadExcel = function() {

        $scope.isFailed = false;
        $("#showloader").css("display", "block");
        console.log("printing lot id in download-->>" + $scope.lotId);
        var url = urlService.ECOM_DOWNLOAD_EXCEL.replace('LID', $scope.lotId);


        $http({
                method: 'GET',
                url: url,
                headers: {
                    'Content-type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                    'x-api-key': sessionStorage.apikey
                },
                responseType: 'arraybuffer'
            })
            .success(function(data, status, headers) {

                $("#showloader").css("display", "none");

                if (data.byteLength == 55) {
                    $scope.isFailed = true;
                    $('#alert-box').modal('show');


                } else if (data.byteLength == 98) {
                    $scope.isFailed = true;
                    $scope.resmessage = "Error in Downloading Excel file";
                    return;
                } else {

                    var octetStreamMime = 'application/octet-stream';
                    var success = false;

                    // Get the headers
                    headers = headers();

                    // Get the filename from the x-filename header or default to "download.bin"
                    var filename = headers['x-filename'] || 'Ecom_Upload_Excel.xlsx';

                    // Determine the content type from the header or default to "application/octet-stream"
                    var contentType = headers['content-type'] || octetStreamMime;

                    try {
                        // Try using msSaveBlob if supported
                        console.log("Trying saveBlob method ...");
                        var blob = new Blob([data], {
                            type: contentType
                        });
                        if (navigator.msSaveBlob)
                            navigator.msSaveBlob(blob, filename);
                        else {
                            // Try using other saveBlob implementations, if available
                            var saveBlob = navigator.webkitSaveBlob || navigator.mozSaveBlob || navigator.saveBlob;
                            if (saveBlob === undefined) throw "Not supported";
                            saveBlob(blob, filename);
                        }
                        console.log("saveBlob succeeded");
                        success = true;
                    } catch (ex) {
                        console.log("saveBlob method failed with the following exception:");
                        console.log(ex);
                    }

                    if (!success) {
                        // Get the blob url creator
                        var urlCreator = window.URL || window.webkitURL || window.mozURL || window.msURL;
                        if (urlCreator) {
                            // Try to use a download link
                            var link = document.createElement('a');
                            if ('download' in link) {
                                // Try to simulate a click
                                try {
                                    // Prepare a blob URL
                                    console.log("Trying download link method with simulated click ...");
                                    var blob = new Blob([data], {
                                        type: contentType
                                    });
                                    var url = urlCreator.createObjectURL(blob);
                                    link.setAttribute('href', url);

                                    // Set the download attribute (Supported in Chrome 14+ / Firefox 20+)
                                    link.setAttribute("download", filename);

                                    // Simulate clicking the download link
                                    var event = document.createEvent('MouseEvents');
                                    event.initMouseEvent('click', true, true, window, 1, 0, 0, 0, 0, false, false, false, false, 0, null);
                                    link.dispatchEvent(event);
                                    console.log("Download link method with simulated click succeeded");
                                    success = true;

                                } catch (ex) {
                                    console.log("Download link method with simulated click failed with the following exception:");
                                    console.log(ex);
                                }
                            }

                            if (!success) {
                                // Fallback to window.location method
                                try {
                                    // Prepare a blob URL
                                    // Use application/octet-stream when using window.location to force download
                                    console.log("Trying download link method with window.location ...");
                                    var blob = new Blob([data], {
                                        type: octetStreamMime
                                    });
                                    var url = urlCreator.createObjectURL(blob);
                                    window.location = url;
                                    console.log("Download link method with window.location succeeded");
                                    success = true;
                                } catch (ex) {
                                    console.log("Download link method with window.location failed with the following exception:");
                                    console.log(ex);
                                }
                            }

                        }
                    }

                    if (!success) {
                        // Fallback to window.open method
                        console.log("No methods worked for saving the arraybuffer, using last resort window.open");
                        window.open(rowData.pathName, '_blank', '');
                    }
                }
            })
            .error(function(data, status, config) {

                console.log("Request failed with status: " + status);
                $("#showloader").css("display", "none");
                // Optionally write the error out to scope
                //$scope.errorDetails = "Request failed with status: " + status;
                $scope.isFailed = true;
                $scope.resmessage = "Error in downloading Excel File";

            });
    };


}]);