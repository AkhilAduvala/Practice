var app = angular.module('AteSlotting', ['ui.bootstrap', 'ngTouch', 'ui.grid', 'ui.grid.selection', 'ui.grid.edit','ui.grid.autoResize','ui.grid.validate','ui.grid.exporter']);

app.controller('AteSlottingCtrl', ['$scope', '$http', '$q', '$interval', '$timeout', 'urlService', 'uiGridConstants','commonService', function ($scope, $http, $q, $interval, $timeout, urlService, uiGridConstants,commonService) {
	$scope.isSuccess = false;
	$scope.isFailed = false;
	$scope.isEdit = true;
	$scope.isDelete = true;
	$scope.isDeleted = false;
	$scope.isEditdataSources = false;
	$scope.isEditSlotGroup = false;
	$scope.isTablerptkrl = false;
	$scope.pagefunctionality = $scope.functionality;
	$scope.pagedc = $scope.dcName;
	$scope.isLowerGrid = false;
	$scope.reqExchangeDto = [];
	$scope.values = {
		"grpName": '',
		"forFileLocn": '',
		"orderFuture": '',
		"orderPast": '',
		"asnFuture": '',
		"asnPast": '',
		"forcastfile": '',
		"filetype": '',
		"int2remove": '',
		"openOrder": '',
		"orderStateCode": '',
		"orderMinStatCode": '',
		"asnInfoLst": '',
		"useAsns": '',
		"volOrFix": '',
		"fixedCase": '',
		"maxAllowed": '',
		"skuMovement": '',
		"skumovesvalue": '',
		"groupPriority": '',
		"slotType": '',
		"slottingType": '',
		"slotTypeReg": '',
		"kitType": '',
		"userType": '',
		"daysTillSlot": '',
		"deslotToRevVal": '',
		"intraZone": '',
		"reslotZone": '',
		'reslotZoneIndex': '',
		"releaseData": '',
		"newLogicals": '',
		"dspNumber": ''

	};

	$scope.isDatarelease = false;
	$scope.slottingsetupNameFlag = false;
	$scope.forcastFileLocationFlag = false;
	$scope.orderFutureFlag = false;
	$scope.orderPastFlag = false;
	$scope.asnFutureFlag = false;
	$scope.asnPastFlag = false;

	$scope.gridOptionsLower = {
		enableColumnMenus: false,
		exporterMenuCsv: false,
		exporterMenuPdf: false,
		enableGridMenu: true,
		exporterExcelSheetName: 'Sheet1',
		exporterExcelFilename: 'DisplaySKU_list.xlsx',
		gridMenuShowHideColumns: false,
		exporterMenuVisibleData: false,
		enableSorting: true,
	};


	$scope.gridOptionsLowerSearch = {
		enableColumnMenus: false,
		enableSorting: true,
	};



	$scope.gridOptions = {
		enableColumnMenus: false,
		enableSorting: true,
		multiSelect: false,
		enableRowSelection: true,//we can remove it later no use  of this
		enableSelectAll: true,//we can remove it later no use  of this             
		enableCellEdit: false, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
		enableCellEditOnFocus: true // set any editable column to allow edit on focus
	};

	$scope.gridOptions.onRegisterApi = function (gridApi) {
		//set gridApi on scope
		$scope.gridApi = gridApi;


		gridApi.selection.on.rowSelectionChanged($scope, function (rows) {
			$scope.isSuccess = false;
			$scope.isFailed = false;

			if ($scope.gridApi.selection.getSelectedRows().length > 0) {
				$scope.isEdit = false;
				$scope.isDelete = false;
			} else {
				$scope.isEdit = true;
				$scope.isDelete = true;

			}
		});
	};

	//sloting group

	$scope.gridOptionsSlotgroup = {
		enableColumnMenus: false,
		enableSorting: true,
		multiSelect: false,
		enableRowSelection: true,//we can remove it later no use  of this
		enableSelectAll: true,//we can remove it later no use  of this             
		enableCellEdit: false, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
		enableCellEditOnFocus: true // set any editable column to allow edit on focus
	};

	$scope.gridOptionsSlotgroup.onRegisterApi = function (gridApi) {
		//set gridApi on scope
		$scope.gridApi = gridApi;

		gridApi.selection.on.rowSelectionChanged($scope, function (row) {
			$scope.isSuccesszone = false;
			$scope.isFailedzone = false;
			$scope.selectedRowToSlotEdit = { "slotGrp": row.entity.slotGrp, "dcName": $scope.pagedc, "userName": sessionStorage.userName };

			if (row.isSelected) {
				$scope.isEdit = false;
			} else {
				$scope.isEdit = true;
			}
		});

	};


	//get data source

	$scope.gridOptionsDataSource = {
		enableColumnMenus: false,
		enableSorting: true,
		multiSelect: false,
		enableRowSelection: true,//we can remove it later no use  of this
		enableSelectAll: true,//we can remove it later no use  of this             
		enableCellEdit: false, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
		enableCellEditOnFocus: true,// set any editable column to allow edit on focus
		cellEditableCondition: function($scope) { 
			if($scope.row.entity.hasAssoc == "Y"){
				$scope.releaseTaskbutton = true;
			}else{
				$scope.releaseTaskbutton = false;
			}
			}
			  
	};


	$scope.gridOptionsDataSource.onRegisterApi = function (gridApi) {
		//set gridApi on scope
		$scope.gridApi = gridApi;
		$scope.isSuccess = false;
		$scope.isFailed = false;
		gridApi.selection.on.rowSelectionChanged($scope, function (row) {

			$scope.selectedRowSourcedata = { "grptype": row.entity.grpType, "dcName": $scope.pagedc, "userName": sessionStorage.userName };
			if (row.isSelected) {
				$scope.isEdit = false;
				$scope.isDelete = false;
			} else {
				$scope.isEdit = true;
				$scope.isDelete = true;
			}
		});
	};


	// SKU Exclusion
	$scope.gridOptionsSku = {
		enableColumnMenus: false,
		enableSorting: true,
		multiSelect: false,
		exporterMenuCsv: false,
		exporterMenuPdf: false,
		enableGridMenu: true,
		exporterExcelSheetName: 'Sheet1',
		exporterExcelFilename: 'Dsiplay_SKU.xlsx',
		gridMenuShowHideColumns: false,
		exporterMenuVisibleData: false,
		enableVerticalScrollbar: false,
		enableRowSelection: true,//we can remove it later no use  of this
		enableSelectAll: true,//we can remove it later no use  of this             
		enableCellEdit: false, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
		enableCellEditOnFocus: true // set any editable column to allow edit on focus
	};


	$scope.gridOptionsSku.onRegisterApi = function (gridApi) {
		//set gridApi on scope
		$scope.gridApi = gridApi;
		$scope.isSuccess = false;
		$scope.isFailed = false;
		gridApi.selection.on.rowSelectionChanged($scope, function (row) {

			$scope.selectedRowdspSKU = { "dspsku": row.entity.dspSku, "dcName": $scope.pagedc, "userName": sessionStorage.userName };
			if (row.isSelected) {

				$scope.isDeleted = false;
			} else {

				$scope.isDeleted = true;
			}
		});
	};


	//Zone options

	$scope.gridOptionsZone = {
		enableColumnMenus: false,
		enableSorting: true,
		multiSelect: false,
		enableHorizontalScrollbar:true,
		enableRowSelection: true,//we can remove it later no use  of this
		enableSelectAll: true,//we can remove it later no use  of this             
		enableCellEdit: false, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
		enableCellEditOnFocus: true // set any editable column to allow edit on focus
	};
	$scope.gridOptionsZone.onRegisterApi = function (gridApi) {
		//set gridApi on scope

		$scope.gridApi = gridApi;

		$scope.isSuccesszone = false;
		$scope.isFailedzone = false;


		gridApi.selection.on.rowSelectionChanged($scope, function (row) {
			$scope.isSuccesszone = false;
			$scope.isFailedzone = false;
			$scope.selectedRowToDelete = { "zoneId": row.entity.zone, "hasWorkGrpAssociation": row.entity.hasWorkGrpAssociation, "dcName": $scope.pagedc, "userName": sessionStorage.userName };
			if (row.isSelected) {
				$scope.isDeleteZone = false;
			} else {
				$scope.isDeleteZone = true;
			}
		});

	};


	//Zone prob type options zone

	$scope.gridOptionsZoneProb = {
		enableColumnMenus: false,
		enableCellEdit: true,
		enableSorting: true,
		multiSelect: true,
		enableRowSelection: true,//we can remove it later no use  of this
		enableSelectAll: true,//we can remove it later no use  of this   
		enableVerticalScrollbar: false
	};
	$scope.gridOptionsZoneProb.onRegisterApi = function (gridApi) {

		$scope.gridApi = gridApi;

		$scope.isSuccessprob = false;
		$scope.isFailedprob = false;

	gridApi.selection.on.rowSelectionChanged($scope, function (row) {
			$scope.isSuccessprob = false;
			$scope.isFailedprob = false;

			if ($scope.gridApi.selection.getSelectedRows().length > 0) {

				$scope.isSaveProb = false;
			} else {
				$scope.isSaveProb = true;
			}


		});

		gridApi.selection.on.rowSelectionChangedBatch($scope, function (rows) {
			$scope.isSuccessprob = false;
			$scope.isFailedprob = false;
			if ($scope.gridApi.selection.getSelectedRows().length > 0) {

				$scope.isSaveProb = false;
			} else {
				$scope.isSaveProb = true;
			}
		});

		gridApi.edit.on.afterCellEdit($scope, function (rowEntity, colDef, newValue, oldValue) {

			if (newValue != oldValue || newValue !== oldValue) {// To check old and new values same or not
				if (newValue == "") {

				} else if (+(newValue) == oldValue) {

				} else {
					$scope.gridApi.selection.selectRow(rowEntity);
				}
			}
		});
	};


	//Get Data Source
	$scope.dataSources = function () {
		$scope.isSuccess = false;
		$scope.isFailed = false;
		$scope.isEdit = true;
		$scope.isDelete = true;
		$scope.isMianpage = true;
		$scope.isEditdataSources = false;
		$scope.isEditSlotGroup = false;

		$("#showloader").css("display", "block");

		var url = urlService.ATE_SLOTTING_SJ.replace('dName', $scope.pagedc);
		url = url.replace('uName', sessionStorage.userName);
		var res = $http.get(url, { headers: {'x-api-key': sessionStorage.apikey} });
		
		res.success(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			if (data.errorMessage) {
				$scope.isFailed = true;
				$scope.resmessage = data.errorMessage;
			} else if (data.resMessage) {
				$scope.isSuccess = true;
				$scope.resmessage = data.resMessage;
			} else {
				
				$scope.gridOptionsDataSource.columnDefs = [
					{ name: 'grpType', displayName: 'Template ID', width: 120, enableCellEdit: false, sort: { direction: uiGridConstants.ASC, priority: 1 }, cellTooltip: true, headerTooltip: true },
					{ name: 'grpName', displayName: 'Name', width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip: true },
					{ name: 'hasAssoc', displayName: 'Has Slotting Association', width: 200, enableCellEdit: false, cellTooltip: true, headerTooltip: true },
					{ name: 'hasTask', displayName: 'Has Unreleased Tasks', width: 200, enableCellEdit: false, cellTooltip: true, headerTooltip: true },
					{ name: 'lastRun', displayName: 'Last Completion Time', width: 200, enableCellEdit: false, cellTooltip: true, headerTooltip: true },
					{ name: 'currentStatus', displayName: 'Current Status', width: 140, enableCellEdit: false, cellTooltip: true, headerTooltip: true },
					{ name: 'reportpretaskrelese', displayName: ' ', width: 180, cellTemplate: '<div class="ui-grid-cell-contents" ng-click="grid.appScope.reportPreTaskRelease(grid, row)" ><a>Report Pre Task Release</a></div>' },
					{ name: 'runaslot', displayName: ' ', width: 100, cellTemplate: '<div class="ui-grid-cell-contents" ng-click="grid.appScope.runAslot(grid, row)"><a >Run a Slot</a></div>' },
					{ name: 'releasetasks', displayName: ' ', width: 120, cellTemplate: '<div class="ui-grid-cell-contents" ng-click="grid.appScope.releaseTask(grid, row)"><a>Release Tasks</a></div>' }

				];
				$scope.isTable = true;
				$scope.isMianpage = true;
				$scope.gridOptionsDataSource.data = data;

				if ($scope.gridOptionsDataSource.data > 10) {
					$scope.gridOptionsDataSource.enableVerticalScrollbar = true;
					$scope.gridOptionsDataSource.enableHorizontalScrollbar = 1;
				} else {
					$scope.gridOptionsDataSource.enableVerticalScrollbar = false;
					$scope.gridOptionsDataSource.enableHorizontalScrollbar = 1;
				}
			}
			$('.ui-grid-pager-control input').prop("disabled", true);
		});
		res.error(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			$scope.isFailed = true;
			$scope.resmessage = "System failed. Please try again or contact WAALOS Support";

		});
	};
	$scope.dataSources();

	var asnFuture = "";
	var asnPast = "";
	var asnInfoLst = "";
	var orderFuture = "";
	var orderPast = "";
	var orderStatCode = "";
	var orderMinStatCode = "";

	//GET FORECAST SOURCE
	$scope.editDataSources = function () {
		$scope.isSave = false;
		$scope.isFailed = false;
		$scope.isSuccess = false;
		$("#showloader").css("display", "block");

		var url = urlService.ATE_SLOTTING_SJ_EDIT_GETFORECASTSOURCE.replace('dName', $scope.pagedc);
		url = url.replace('uName', sessionStorage.userName);
		url = url.replace('tempid', $scope.selectedRowSourcedata.grptype);


		var res = $http.get(url, {
			headers: {'x-api-key': sessionStorage.apikey}
		});

		res.success(function (data, status, headers, config) {
			$("#showloader").css("display", "none");

			if (data.errorMessage) {
				$scope.isFailed = true;
				$scope.resmessage = data.errorMessage;
			} else if (data.resMessage) {
				$scope.isSuccess = true;
				$scope.resmessage = data.resMessage;
			} else {
				$scope.isEditdataSources = true;
				$scope.isMianpage = false;
				$scope.isEditSlotGroup = false;

				$scope.grptype = data.grpType;
				$scope.userid = data.userId;
				$scope.orderprewave = data.orderPrewave;
				//Basic Information
				$scope.values.grpName = data.grpName;

				//Forcast File Information
				if (data.useForecastFile == 0) {
					$scope.values.forcastfile = 'Yes';
				} else {
					$scope.values.forcastfile = 'No';
				}

				$scope.values.forFileLocn = data.forFileLocn;

				if (data.forFileType == 0) {
					$scope.values.filetype = 'Americas';
				} else {
					$scope.values.filetype = 'Asia';
				}

				if (data.int2sRemoved == 0) {
					$scope.values.int2remove = 'Yes';
				} else {
					$scope.values.int2remove = 'No';
				}

				//Order Pickticket Information
				if (data.useOrders == 0) {
					$scope.values.openOrder = 'Yes';
					$scope.isOrderYes = false;
				} else {
					$scope.values.openOrder = 'No';
					$scope.isOrderYes = true;
				}

				orderFuture = data.ordersWithXFuture;
				orderPast = data.ordersWithXPast;

				$scope.values.orderFuture = data.ordersWithXFuture;
				$scope.values.orderPast = data.ordersWithXPast;

				$scope.orderList = data.orderInfoLst;

				var maxOrder = data.ordersStatCode;
				var minOrder = data.ordersMinStatCode;

				for (var i = 0; i < data.orderInfoLst.length; i++) {
					if (data.orderInfoLst[i].codeId == maxOrder) {
						$scope.values.orderStateCode = data.orderInfoLst[i];
						orderStateCode = data.orderInfoLst[i];
						break;
					}
				}

				for (var j = 0; j < data.orderInfoLst.length; j++) {
					if (data.orderInfoLst[j].codeId == maxOrder) {
						$scope.values.orderMinStatCode = data.orderInfoLst[j];
						orderMinStatCode = data.orderInfoLst[j];
						break;
					}
				}

				//ASN Information

				if (data.useAsns == 0) {
					$scope.values.useAsn = 'Yes';
					$scope.isuseAsnYes = false;
				} else {
					$scope.values.useAsn = 'No';
					$scope.isuseAsnYes = true;
					$scope.values.asnFuture = data.asnWithXFuture;
					$scope.values.asnPast = data.asnWithXPast;
				}
				asnFuture = data.asnWithXFuture;
				asnPast = data.asnWithXPast;

				$scope.values.asnFuture = data.asnWithXFuture;
				$scope.values.asnPast = data.asnWithXPast;
			}
			$scope.asnList = data.asnInfoLst;
			var maxasn = data.asnStatCode;
			for (var k = 0; k < data.asnInfoLst.length; k++) {
				if (data.asnInfoLst[k].codeId == maxasn) {
					$scope.values.asnInfoLst = data.asnInfoLst[k];
					asnInfoLst = data.asnInfoLst[k];
					break;
				}
			}

		});
		res.error(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			$scope.isFailed = true;
			$scope.resmessage = "System failed. Please try again or contact WAALOS Support";

		});
	};

	$scope.useAsnChange = function (s) {
		if (s == 'Yes') {
			$scope.useAsn = 'Yes';
			$scope.isuseAsnYes = false;
		} else {
			$scope.useAsn = 'No';
			$scope.isuseAsnYes = true;
			$scope.values.asnFuture = asnFuture;
			$scope.values.asnPast = asnPast;
			$scope.values.asnInfoLst = asnInfoLst;
		}
	};

	$scope.openOrderChange = function (s) {
		if (s == 'Yes') {
			$scope.openOrder = 'Yes';
			$scope.isOrderYes = false;
		} else {
			$scope.openOrder = 'No';
			$scope.isOrderYes = true;
			$scope.values.orderFuture = orderFuture;
			$scope.values.orderPast = orderPast;
			$scope.values.orderStateCode = orderStateCode;
			$scope.values.orderMinStatCode = orderMinStatCode;
		}
	};

	$scope.slottingsetup = function () {
		if ($scope.values.grpName == "") {
			$scope.slottingsetupNameFlag = true;
			$scope.isSave = true;
		} else {
			$scope.slottingsetupNameFlag = false;
			$scope.isSave = false;
		}
	};

	$scope.forcastFileLocation = function () {
		if ($scope.values.forFileLocn == "") {
			$scope.forcastFileLocationFlag = true;
			$scope.isSave = true;
		} else {
			$scope.forcastFileLocationFlag = false;
			$scope.isSave = false;
		}
	};

	$scope.orderFuturedata = function () {
		var numbers = /^[0-9]+$/;
		if ($scope.values.orderFuture == "" || $scope.values.orderFuture == null || !($scope.values.orderFuture.match(numbers)) ) {
			$scope.orderFutureFlag = true;
			$scope.isSave = true;
		} else {
			$scope.orderFutureFlag = false;
			$scope.isSave = false;
		}
		
	};

	$scope.orderPastdata = function () {
		var numbers = /^[0-9]+$/;
		if ($scope.values.orderPast == "" || $scope.values.orderPast == null || !($scope.values.orderPast.match(numbers)) ) {
			$scope.orderPastFlag = true;
			$scope.isSave = true;
		} else {
			$scope.orderPastFlag = false;
			$scope.isSave = false;
		}
	};

	$scope.asnFuturedata = function () {
		var numbers = /^[0-9]+$/;
		if ($scope.values.asnFuture == "" ||  $scope.values.asnFuture == null || !($scope.values.asnFuture.match(numbers)) ) {
			$scope.asnFutureFlag = true;
			$scope.isSave = true;
		} else {
			$scope.asnFutureFlag = false;
			$scope.isSave = false;
		}
	};

	$scope.asnPastdata = function () {
		var numbers = /^[0-9]+$/;
		if ($scope.values.asnPast == "" || $scope.values.asnPast == null || !($scope.values.asnPast.match(numbers)) ) {
			$scope.asnPastFlag = true;
			$scope.isSave = true;
		} else {
			$scope.asnPastFlag = false;
			$scope.isSave = false;
		}
	};

	//save Forcast Source
	$scope.saveForcastSource = function () {
		$scope.isSuccess = false;
		$scope.isFailed = false;

		if ($scope.values.forcastfile == 'Yes') {
			$scope.forcastfileValue = "0";
		} else {
			$scope.forcastfileValue = "1";
		}

		if ($scope.values.filetype == 'Americas') {
			$scope.filetypeValue = "0";
		} else {
			$scope.filetypeValue = "1";
		}

		if ($scope.values.int2remove == 'Yes') {
			$scope.int2removeValue = "0";
		} else {
			$scope.int2removeValue = "1";
		}

		if ($scope.values.openOrder == 'Yes') {
			$scope.openOrderValue = "0";
		} else {
			$scope.openOrderValue = "1";
		}

		if ($scope.useAsn == 'Yes') {
			$scope.useAsnValue = "0";
		} else {
			$scope.useAsnValue = "1";
		}

		$("#showloader").css("display", "block");
		var dataObj = {
			"dcName": $scope.pagedc,
			"userName": sessionStorage.userName,
			"grpType": $scope.grptype,
			"grpName": $scope.values.grpName,
			"createDateTime": "",
			"modDateTime": "",
			"userId": $scope.userid,
			"useForecastFile": $scope.forcastfileValue,
			"forFileLocn": $scope.values.forFileLocn,
			"forFileType": $scope.filetypeValue,
			"int2sRemoved": $scope.int2removeValue,
			"useOrders": $scope.openOrderValue,
			"ordersStatCode": $scope.values.orderStateCode.codeId,
			"ordersWithXFuture": $scope.values.orderFuture,
			"ordersWithXPast": $scope.values.orderPast,
			"orderPrewave": $scope.orderprewave,
			"useAsns": $scope.useAsnValue,
			"asnStatCode": $scope.values.asnInfoLst.codeId,
			"asnWithXFuture": $scope.values.asnFuture,
			"asnWithXPast": $scope.values.asnPast,
			"ordersMinStatCode": $scope.values.orderMinStatCode.codeId


		};

		var res = $http.put(urlService.ATE_SLOTTING_SJ_FORCAST_SOURCE_UPDATE, dataObj, {
			headers: {'x-api-key': sessionStorage.apikey}
		});

		res.success(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			if (data.errorMessage) {
				$scope.isFailed = true;
				$scope.resmessage = data.errorMessage;
				$scope.disable = true;
			} else if (data.resMessage) {
				$scope.editDataSources();
				$scope.isupdate = true;
				$scope.isSuccess = true;
				$scope.resmessage = data.resMessage;
			}

		});
		res.error(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			$scope.isFailed = true;
			$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
		});

	};

	//back to data source 

	$scope.backSource = function () {
		$scope.isEditdataSources = false;
		$scope.isMianpage = true;
		$scope.isEditSlotGroup = false;
		$scope.isSuccess = false;
		$scope.isFailed = false;
		$scope.isEdit = true;
		$scope.isDelete = true;
		$scope.isTablerptkrl = false;
		$scope.isReleseTask = false;
		$scope.dataSources();
		$scope.reqExchangeDto = [];

	};

	$scope.backSloting = function () {
		$scope.isEditdataSources = true;
		$scope.isMianpage = false;
		$scope.isEditSlotGroup = false;
		$scope.isSuccess = false;
		$scope.isFailed = false;
		$scope.isEdit = true;
		$scope.isDelete = true;
		$scope.isTablerptkrl = false;
		$scope.editDataSources();

	};


	//Reset data source

	$scope.reset = function () {
		$scope.isSuccess = false;
		$scope.isFailed = false;
		$scope.isEdit = true;
		$scope.isDelete = true;
		$scope.isMianpage = true;
		$scope.isEditdataSources = false;
		$scope.isEditSlotGroup = false;

		$("#showloader").css("display", "block");
		var dataObj = {
			"dcName": $scope.pagedc,
			"userName": sessionStorage.userName
		};

		var res = $http.put(urlService.ATE_SLOTTING_SJ_RESET_DATASOURCES, dataObj, {
			headers: {'x-api-key': sessionStorage.apikey}
		});

		res.success(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			if (data.errorMessage) {
				$scope.isFailed = true;
				$scope.resmessage = data.errorMessage;
			} else if (data.resMessage) {

				$("#resetModal").modal('show');

				$scope.resmessagereset = data.resMessage;
			}

		});
		res.error(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			$scope.isFailed = true;
			$scope.resmessage = "System failed. Please try again or contact WAALOS Support";

		});
	};

	// delete data Source
	$scope.delateDataSource = function () {
		$scope.isSuccess = false;
		$scope.isFailed = false;
		$scope.isEdit = true;
		$scope.isDelete = true;
		$scope.isMianpage = true;
		$scope.isEditdataSources = false;
		$scope.isEditSlotGroup = false;

		$("#showloader").css("display", "block");
		var dataObj = {
			"dcName": $scope.pagedc,
			"userName": sessionStorage.userName
		};


		var url = urlService.ATE_SLOTTING_SJ_DELETE.replace('dName', $scope.pagedc);
		url = url.replace('uName', sessionStorage.userName);
		url = url.replace('gType', $scope.selectedRowSourcedata.grptype);

		var res = $http.delete(url, {
			headers: {'x-api-key': sessionStorage.apikey}
		});

		res.success(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			if (data.errorMessage) {
				$scope.isFailed = true;
				$scope.resmessage = data.errorMessage;
			} else if (data.resMessage) {
				$scope.isSuccess = true;
				$scope.resmessage = data.resMessage;

			}

		});
		res.error(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			$scope.isFailed = true;
			$scope.resmessage = "System failed. Please try again or contact WAALOS Support";

		});
	};

	//Delete all tasks
	$scope.delteAllTasks = function () {
		$scope.isSuccess = false;
		$scope.isFailed = false;
		$scope.isEdit = true;
		$scope.isDelete = true;
		$scope.isMianpage = true;
		$scope.isEditdataSources = false;
		$scope.isEditSlotGroup = false;

		$("#showloader").css("display", "block");
		var url = urlService.ATE_SLOTTING_SJ_DELETE_ALL.replace('dName', $scope.pagedc);
		url = url.replace('uName', sessionStorage.userName);

		var res = $http.delete(url, {
			headers: {'x-api-key': sessionStorage.apikey}
		});

		res.success(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			if (data.errorMessage) {
				$scope.isFailed = true;
				$scope.resmessage = data.errorMessage;
			} else if (data.resMessage) {
				$scope.isSuccess = true;
				$scope.resmessage = data.resMessage;
			}

		});
		res.error(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			$scope.isFailed = true;
			$scope.resmessage = "System failed. Please try again or contact WAALOS Support";

		});
	};
	//function to seperate the keys and values from json as Object.values is not supproted in IE
function convertJsontoArray(values){
	var keyValues = {
		'keys' : [],
		'values' : []
	};

	if(values.length){
		_.each(values, function (val, key) {
			_.each(val, function (val, key) { 
					keyValues.keys.push(key);
					keyValues.values.push(val); 
			});
		});
	}else{
		_.each(values, function (val, key) {  
					keyValues.keys.push(key);
					keyValues.values.push(val); 
		});
	}
	
	return  keyValues;
}

	//Report Pre Tast Release
	$scope.reportPreTaskRelease = function (grid, row) {
		$scope.isSuccess = false;
		$scope.isFailed = false;

		$("#showloader").css("display", "block");
		var url = urlService.ATE_SLOTTING_SJ_REPORT_PRE_TASK_RELEASE.replace('dName', $scope.pagedc);
		url = url.replace('uName', sessionStorage.userName);
		url = url.replace('gType', row.entity.grpType);

		var res = $http.get(url, {
			headers: {'x-api-key': sessionStorage.apikey}
		});

		res.success(function (data, status, headers, config) {
			$("#showloader").css("display", "none");

			if (data.errorMessage) {
				$scope.isFailed = true;
				$scope.resmessage = data.errorMessage;
			} else if (data.resMessage) {
				$scope.isSuccess = true;
				$scope.resmessage = data.resMessage;
			} else {



				$scope.gridOptions.columnDefs = [
					{ name: 'grpAttr', displayName: 'Group Attribute', width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip: true },
					{ name: 'spillOrder', displayName: 'Zone Priority', width: 120, enableCellEdit: false, cellTooltip: true, headerTooltip: true },
					{ name: 'count', displayName: 'Total Locations in Zone', width: 190, enableCellEdit: false, cellTooltip: true, headerTooltip: true },
					{ name: 'profiledWithFcEmpty', displayName: 'Unforcasted Locations With No Inventory', width: 300, enableCellEdit: false, cellTooltip: true, headerTooltip: true },
					{ name: 'profiledWithoutFcEmpty', displayName: 'Locations with No Inventory (Non Profiled)', width: 330, enableCellEdit: false, cellTooltip: true, headerTooltip: true },
					{ name: 'justEmpty', displayName: 'Just Empty', width: 120, enableCellEdit: false, cellTooltip: true, headerTooltip: true },
					{ name: 'totForWInv', displayName: 'Forecasted Locations with Inventory', width: 270, enableCellEdit: false, cellTooltip: true, headerTooltip: true },
					{ name: 'totNotForWInv', displayName: 'Unforcasted Locations with Inventory', width: 300, enableCellEdit: false, cellTooltip: true, headerTooltip: true },
					{ name: 'numOfStyles', displayName: '# of Styles', width: 170, enableCellEdit: false, cellTooltip: true, headerTooltip: true },
					{ name: 'numOfKits', displayName: '# of Kits', width: 120, enableCellEdit: false, cellTooltip: true, headerTooltip: true },
					{ name: 'avgKitSize', displayName: 'Average Size of Kits', width: 170, enableCellEdit: false, cellTooltip: true, headerTooltip: true },
					{ name: 'avgStyleCount', displayName: 'Average # of SKU(s) per Style', width: 240, enableCellEdit: false, cellTooltip: true, headerTooltip: true }

				];
				$scope.isTablerptkrl = true;
				$scope.isMianpage = false;
				$scope.gridOptions.data = data;
				var datatocheck = data;

				$scope.head = [' ','Zone Priority',
					'Total Locations in Zone',
					'Forcasted Locations With No Inventory',
					'Unforcasted Locations With No Inventory',
					'Locations with No Inventory (Non Profiled)',
					'Forcasted Locations With Inventory',
					'Unforcasted Locations With Inventory',
					'Number of Styles',
					'Number  of Kits',
					'Average Size of Kits',
					'Average # of SKU(s) per Style'];
			$scope.arrayvalues = [];
			$scope.headings = [];
			_.each(datatocheck,function(val,key){ 
				
				var data = convertJsontoArray(val).values;
				var header = data[1];
				data = data.filter(function(x){ return x !=data[1];}); 
				$scope.headings.push(header);
			$scope.arrayvalues.push({key:data}); 
			});

				if ($scope.gridOptions.data > 10) {
					$scope.gridOptions.enableVerticalScrollbar = true;
					$scope.gridOptions.enableHorizontalScrollbar = 1;
				} else {
					$scope.gridOptions.enableVerticalScrollbar = false;
					$scope.gridOptions.enableHorizontalScrollbar = 1;
				}
			}

		});
		res.error(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			$scope.isFailed = true;
			$scope.resmessage = "System failed. Please try again or contact WAALOS Support";

		});
	};

	var slotgropNames = [];
	//sloting group
	$scope.slotGroups = function () {
		$scope.isSuccess = false;
		$scope.isFailed = false;
		$scope.isEdit = true;
		$("#showloader").css("display", "block");
		var url = urlService.ATE_SLOTTING_SJ_SLOTTING_GROUPS_GET.replace('dName', $scope.pagedc);
		url = url.replace('uName', sessionStorage.userName);
		url = url.replace('gType', $scope.grptype);

		var res = $http.get(url, {
			headers: {'x-api-key': sessionStorage.apikey}
		});

		res.success(function (data, status, headers, config) {

			$("#showloader").css("display", "none");
			if (data.errorMessage) {
				$scope.isFailed = true;
				$scope.resmessage = data.errorMessage;
			} else if (data.resMessage) {
				$scope.isSuccess = true;
				$scope.resmessage = data.resMessage;
			} else {


				$scope.gridOptionsSlotgroup.columnDefs = [
					{ name: 'slotGrp', displayName: 'Slot Group', width: 120, enableCellEdit: false, cellTooltip: true, headerTooltip: true },
					{ name: 'totLocnd', displayName: 'Total Location', width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip: true },
					{ name: 'distZones', displayName: 'Distinct Zones', width: 120, enableCellEdit: false, cellTooltip: true, headerTooltip: true },
					{ name: 'hasRules', displayName: 'Rules Completed', width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip: true },
					{ name: 'priority', displayName: 'Priority', width: 120, enableCellEdit: false, cellTooltip: true, headerTooltip: true },
					{ name: 'lockInPlace', displayName: 'Lock Status', width: 180, enableCellEdit: false, cellTooltip: true, headerTooltip: true },
					{ name: 'pctFull', displayName: 'Fill %', width: 120, enableCellEdit: false, cellTooltip: true, headerTooltip: true },
					{ name: 'daysTillSlot', displayName: 'Days Held in Zone', width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip: true },
					{ name: 'prodtypes', displayName: 'Prod Types', width: 120, enableCellEdit: false, cellTooltip: true, headerTooltip: true },
					{ name: 'prodGrps', displayName: 'Prod Groups', width: 180, enableCellEdit: false, cellTooltip: true, headerTooltip: true },
					{ name: 'cartonTypes', displayName: 'Carton Types', width: 120, enableCellEdit: false, cellTooltip: true, headerTooltip: true },
					{ name: 'putwyTypes', displayName: 'Putaway Types', width: 180, enableCellEdit: false, cellTooltip: true, headerTooltip: true },
					{ name: 'seasonYr', displayName: 'Season Year', width: 120, enableCellEdit: false, cellTooltip: true, headerTooltip: true },
					{ name: 'prodSubGrps', displayName: 'Prod Sub Groups', width: 140, enableCellEdit: false, cellTooltip: true, headerTooltip: true },
					{ name: 'saBusSeg', displayName: 'SA Business Segment', width: 170, enableCellEdit: false, cellTooltip: true, headerTooltip: true },
				];

				for (i = 0; i < data.length; i++) {
					slotgropNames.push(data[i].slotGrp);
				}

				$scope.gridOptionsSlotgroup.data = data;

				if ($scope.gridOptionsSlotgroup.data > 10) {
					$scope.gridOptionsSlotgroup.enableVerticalScrollbar = true;
					$scope.gridOptionsSlotgroup.enableHorizontalScrollbar = 1;
				} else {
					$scope.gridOptionsSlotgroup.enableVerticalScrollbar = false;
					$scope.gridOptionsSlotgroup.enableHorizontalScrollbar = 1;
				}
			}

		});
		res.error(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			$scope.isFailed = true;
			$scope.resmessage = "System failed. Please try again or contact WAALOS Support";

		});
	};


	$scope.zones = function () {

		$scope.Zonedata();
		$scope.zoneProbType();

	};

	//zone data
	$scope.Zonedata = function () {
		$scope.isSuccesszone = false;
		$scope.isFailedzone = false;
		$scope.isDeleteZone = true;
		$scope.isSaveProb = true;


		$("#showloader").css("display", "block");

		var url = urlService.ATE_SLOTTING_SJ_ZONE.replace('dName', $scope.pagedc);
		url = url.replace('uName', sessionStorage.userName);


		var res = $http.get(url, {
			headers: {'x-api-key': sessionStorage.apikey}
		});

		res.success(function (data, status, headers, config) {

			$("#showloader").css("display", "none");

			if (data.errorMessage) {
				$scope.isFailed = true;
				$scope.resmessagezone = data.errorMessage;
			} else if (data.resMessage) {
				$scope.isSuccesszone = true;
				$scope.resmessagezone = data.resMessage;
			} else {


				$scope.gridOptionsZone.columnDefs = [
					{ name: 'zone', displayName: 'Zone', enableCellEdit: false, cellTooltip: true, headerTooltip: true },
					{ name: 'hasWorkGrpAssociation', width: 200, displayName: 'Associated To Work Group', enableCellEdit: false, cellTooltip: true, headerTooltip: true },
					{ name: 'workGroup', displayName: 'Work Group', enableCellEdit: false, cellTooltip: true, headerTooltip: true },

				];
				$scope.isTable = true;

				$scope.gridOptionsZone.data = data;

				if ($scope.gridOptionsZone.data > 10) {
					$scope.gridOptionsZone.enableVerticalScrollbar = true;
					$scope.gridOptionsZone.enableHorizontalScrollbar = true;
				} else {
					$scope.gridOptionsZone.enableVerticalScrollbar = false;
					$scope.gridOptionsZone.enableHorizontalScrollbar = true;
				}
			}

		});
		res.error(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			$scope.isFailedzone = true;
			$scope.resmessagezone = "System failed. Please try again or contact WAALOS Support";

		});
	};


	//Delete Zone
	$scope.zoneDelete = function () {
		$scope.resmessagezone = "";
		$scope.isSuccesszone = false;
		$scope.isFailedzone = false;

		$("#showloader").css("display", "block");

		var res;
		var url = urlService.ATE_SLOTTING_SJ_ZONE_DELETE.replace('dName', $scope.pagedc);
		url = url.replace('uName', sessionStorage.userName);
		url = url.replace('zoneid', $scope.selectedRowToDelete.zoneId);
		if ($scope.selectedRowToDelete.hasWorkGrpAssociation == "N") {
			$scope.isFailedzone = true;
			$scope.resmessagezone = "No Work Group(s) to be deleted for the selected zone";
			$("#showloader").css("display", "none");
			return false;
		} else {
			  res = $http.delete(url, {
				headers: {'x-api-key': sessionStorage.apikey}
			});

			res.success(function (data, status, headers, config) {
				$("#showloader").css("display", "none");
				if (data.errorMessage) {
					$scope.isFailedzone = true;
					$scope.resmessagezone = data.errorMessage;

				} else if (data.resMessage) {
					$scope.Zonedata();
					$scope.isSuccesszone = true;
					$scope.resmessagezone = data.resMessage;
				}
			});
		}
		res.error(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			$scope.isFailedzone = true;
			$scope.resmessagezone = "System failed. Please try again or contact WAALOS Support";
		});
	};

	//Add Zone
	$scope.addZone = function () {
		$scope.resmessagezone = "";
		$scope.isSuccesszone = false;
		$scope.isFailedzone = false;

		$("#zoneModal").modal('hide');

		$("#showloader").css("display", "block");

		var postData = {
			"zone": $scope.ZoneName,
			"dcName": $scope.pagedc,
			"userName": sessionStorage.userName
		};

		var res = $http.post(urlService.ATE_SLOTTING_SJ_ZONE_ADD, postData, {
			headers: {'x-api-key': sessionStorage.apikey}
		});
		res.success(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			if (data.errorMessage) {
				$scope.isFailedzone = true;
				$scope.resmessagezone = data.errorMessage;

			} else if (data.resMessage) {
				$scope.Zonedata();
				$scope.isSuccesszone = true;
				$scope.resmessagezone = data.resMessage;
			}
		});
		res.error(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			$scope.isFailedzone = true;
			$scope.resmessagezone = "System failed. Please try again or contact WAALOS Support";
		});

		$scope.ZoneName = undefined;
		$scope.Zone_error = false;
	};


	$scope.ChangeZone = function(){
		if($scope.ZoneName == "")
		{
		$scope.Zone_error = false;
	}else{
		$scope.Zone_error = true;
	}
	};

	$scope.calcelZone = function(){
		$scope.ZoneName = undefined;
		$scope.Zone_error = false;
	};
	//Associte
	$scope.zoneAssocate = function () {
		$scope.isMultiSelect = false;
		$scope.resmessagezone = "";
		$scope.isSuccesszone = false;
		$scope.isFailedzone = false;

		$("#showloader").css("display", "block");


		var url = urlService.ATE_SLOTTING_SJ_ZONE_ASSOCATE.replace('dName', $scope.pagedc);
		url = url.replace('uName', sessionStorage.userName);
		url = url.replace('zoneid', $scope.selectedRowToDelete.zoneId);

		var res = $http.get(url, {
			headers: {'x-api-key': sessionStorage.apikey}
		});

		res.success(function (data, status, headers, config) {
	
			$("#showloader").css("display", "none");
			if (data.errorMessage) {
				$scope.isFailedzone = true;
				$scope.resmessagezone = data.errorMessage;

			} else if (data.resMessage) {
				$scope.isSuccesszone = true;
				$scope.resmessagezone = data.resMessage;
			} else {
			
				$scope.updatedDCS = [];
		
				$("#associateModel").modal('show');
				$scope.workgroups = [];
				if(data.checkedAisles.length>0){
				if(data.checkedAisles[0].workGrp == "ALL" ){
				 	$scope.all = true;
				 }else{
					$scope.all = false;
				 }
				}else{
					$scope.all = false;
				 }

				
			
				_.each(data.getAssociateZonesDtoLst, function (val, key) {
					$scope.workgroups.push(val.workGrp);
				});
				// if(data.checkedAisles.workGrp == null){
				// 	$scope.checkedVlaues = [];
				// }else{
				// 	$scope.checkedVlaues = data.checkedAisles.length > 0 ? data.checkedAisles[0].workGrp.split(',') : undefined;
				// }
				$scope.checkedVlaues = [];
				
				if(data.checkedAisles.length > 1){
				_.each(data.checkedAisles,function(val,key){
					$scope.checkedVlaues.push(val.workGrp);
				});
				}else{
				$scope.checkedVlaues = data.checkedAisles.length > 0 ? data.checkedAisles[0].workGrp.split(',') : undefined;
				}
				
				if (!$scope.checkedVlaues) {
					_.each($scope.workgroups, function (Dval, Dkey) {
						$scope.updatedDCS.push({ 'name': Dval, 'isChecked': false });

					});
					$scope.isCheck = false;
					$scope.checkedVlaues = ['All'];
				} else {
					_.each($scope.workgroups, function (Dval, Dkey) {
						if ($scope.workgroups.indexOf($scope.checkedVlaues[Dkey]) > -1) {
							$scope.updatedDCS.push({ 'name': $scope.checkedVlaues[Dkey], 'isChecked': true });
							$scope.isCheck = false;
						} else {
							var duplicateValues = [];
							_.each($scope.updatedDCS, function (val, key) {
								duplicateValues.push(val.name);
							});
							if(duplicateValues.indexOf(Dval) < 0) {
								$scope.updatedDCS.push({ 'name': Dval, 'isChecked': false });
							}

						}
					});
				}

			}
		});
		res.error(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			$scope.isFailedzone = true;
			$scope.resmessagezone = "System failed. Please try again or contact WAALOS Support";
		});
	};

	//check list
	$scope.checkedlistass = function () {

		var workgroup_list = [];
		for (var key in $scope.updatedDCS) {
			if ($scope.updatedDCS.hasOwnProperty(key)) {
				if ($scope.updatedDCS[key].isChecked == true) {
					workgroup_list.push($scope.updatedDCS[key].name);

				}
			}
		}

		if ($scope.all) {
			workgroup_list = [];
		}

		$scope.resmessagezone = "";
		$scope.isSuccesszone = false;
		$scope.isFailedzone = false;

		$("#showloader").css("display", "block");

		var postData = {

			"zone": $scope.selectedRowToDelete.zoneId,
			"hasWorkGrpAssociation": $scope.selectedRowToDelete.hasWorkGrpAssociation,
			"workGroup": workgroup_list.join(),
			"dcName": $scope.selectedRowToDelete.dcName,
			"userName": $scope.selectedRowToDelete.userName

		};

		var res = $http.put(urlService.ATE_SLOTTING_SJ_ZONE_ASSOCATE_UPDATE, postData, {
			headers: {'x-api-key': sessionStorage.apikey}
		});
		res.success(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			if (data.errorMessage) {
				$scope.isFailedzone = true;
				$scope.resmessagezone = data.errorMessage;

			} else if (data.resMessage) {
				$scope.Zonedata();
				$scope.isSuccesszone = true;
				$scope.resmessagezone = data.resMessage;
			}
		});
		res.error(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			$scope.isFailedzone = true;
			$scope.resmessagezone = "System failed. Please try again or contact WAALOS Support";
		});



	};

	$scope.assCheckedValues = function (wrkGrpAll) {
		var checkedBooleanValues = [];
		for (var key in $scope.updatedDCS) {
			if ($scope.updatedDCS.hasOwnProperty(key) && $scope.updatedDCS[key].isChecked ==true) {
				checkedBooleanValues.push($scope.updatedDCS[key].isChecked);
			}
		}
		//$scope.isMultiSelect = checkedBooleanValues.length >1?true:false;

		if (wrkGrpAll == 'check') {
			var booleanValues = [];

			for (var key in $scope.workgroupsData) {
				if ($scope.workgroupsData.hasOwnProperty(key)) {
					booleanValues.push($scope.workgroupsData[key].isChecked);
				}
			}

			$scope.isCheck = booleanValues.indexOf(true) > -1 ? true : false;
			$scope.wrkGrpAll = booleanValues.indexOf(true) > -1 ? false : true;
		} else if (typeof wrkGrpAll == "boolean") {
			$scope.wrkGrpAll = !wrkGrpAll;

			_.each($scope.workgroupsData, function (val, key) {
				val.isChecked = false;
			});

		} else if (wrkGrpAll == 'all') {

			_.each($scope.updatedDCS, function (val, key) {
				val.isChecked = false;
			});
			$scope.all = !$scope.all;
		} else {
			var booleanValues = [];

			for (var key in $scope.updatedDCS) {
				if ($scope.updatedDCS.hasOwnProperty(key)) {
					booleanValues.push($scope.updatedDCS[key].isChecked);
				}
			}

			$scope.isCheck = booleanValues.indexOf(true) > -1 ? true : false;
			$scope.all = booleanValues.indexOf(true) > -1 ? false : true;
		}
	};


	//Zone prob data
	$scope.zoneProbType = function () {
		$scope.isSuccessprob = false;
		$scope.isFailedprob = false;
		$scope.isDeleteZone = true;
		$scope.isSaveProb = true;

		$("#showloader").css("display", "block");
		var url = urlService.ATE_SLOTTING_SJ_ZONE_PROB_DATA.replace('dName', $scope.pagedc);
		url = url.replace('uName', sessionStorage.userName);


		var res = $http.get(url, {
			headers: {'x-api-key': sessionStorage.apikey}
		});

		res.success(function (data, status, headers, config) {

			$("#showloader").css("display", "none");

			if (data.errorMessage) {
				$scope.isFailedprob = true;
				$scope.resmessageprob = data.errorMessage;
			} else if (data.resMessage) {
				$scope.isSuccessprob = true;
				$scope.resmessageprob = data.resMessage;
			} else {

				$scope.isTable = true;
				$scope.gridOptionsZoneProb.columnDefs = [
					{ name: 'prodType', displayName: 'Product Type', enableCellEdit: false, cellTooltip: true, headerTooltip: true },
					{ name: 'nbrOfZones', displayName: 'Number of Zones', enableCellEdit: true, cellTooltip: true, headerTooltip: true }
				];

				$scope.gridOptionsZoneProb.data = data;

				if ($scope.gridOptionsZoneProb.data > 10) {
					$scope.gridOptionsZoneProb.enableVerticalScrollbar = true;
					$scope.gridOptionsZoneProb.enableHorizontalScrollbar = 1;
				} else {
					$scope.gridOptionsZoneProb.enableVerticalScrollbar = false;
					$scope.gridOptionsZoneProb.enableHorizontalScrollbar = 1;
				}
			}

		});
		res.error(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			$scope.isFailedprob = true;
			$scope.resmessageprob = "System failed. Please try again or contact WAALOS Support";

		});


	};


	$scope.saveProbType = function () {
		$scope.resmessageprob = "";
		$scope.isSuccessprob = false;
		$scope.isFailedprob = false;

		$("#showloader").css("display", "block");
		
		var postRecords = [];
		angular.forEach($scope.gridApi.selection.getSelectedRows(), function (data, index) {
		  var records = {
			"prodType": data.prodType,
			"nbrOfZones": data.nbrOfZones,
			"dcName": $scope.pagedc,
			"userName": sessionStorage.userName
		  };
		  postRecords.push(records);
		});
	
		var res = $http.post(urlService.ATE_SLOTTING_SJ_ZONE_PROB_DATA_UPDATE, postRecords, {
			headers: {'x-api-key': sessionStorage.apikey}
		});
		res.success(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			if (data.errorMessage) {
				$scope.isFailedprob = true;
				$scope.resmessageprob = data.errorMessage;

			} else if (data.resMessage) {
				$scope.zoneProbType();
				$scope.isSuccessprob = true;
				$scope.resmessageprob = data.resMessage;
			}
		});
		res.error(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			$scope.isFailedprob = true;
			$scope.resmessageprob = "System failed. Please try again or contact WAALOS Support";
		});
	};


	$scope.getSkuExclusion = function () {
		$scope.isSuccess = false;
		$scope.isFailed = false;
		$scope.isDeleted = true;

		$("#showloader").css("display", "block");
		var url = urlService.ATE_SLOTTING_SJ_SKU_GET.replace('dName', $scope.pagedc);
		url = url.replace('uName', sessionStorage.userName);
		url = url.replace('gType', $scope.grptype);

		var res = $http.get(url, {
			headers: {'x-api-key': sessionStorage.apikey}
		});

		res.success(function (data, status, headers, config) {
			$("#showloader").css("display", "none");

			if (data.errorMessage) {
				$scope.isFailed = true;
				$scope.resmessage = data.errorMessage;
			} else if (data.resMessage) {
				$scope.isSuccess = true;
				$scope.resmessage = data.resMessage;
			} else {


				$scope.gridOptionsSku.columnDefs = [
					{ name: 'dspSku', displayName: 'Display SKU', enableCellEdit: false, cellTooltip: true, headerTooltip: true },
				];

				$scope.gridOptionsSku.data = data;

				if ($scope.gridOptionsSku.data > 10) {
					$scope.gridOptionsSku.enableVerticalScrollbar = true;
					$scope.gridOptionsSku.enableHorizontalScrollbar = 1;
				} else {
					$scope.gridOptionsSku.enableVerticalScrollbar = false;
					$scope.gridOptionsSku.enableHorizontalScrollbar = 1;
				}
			}

		});
		res.error(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			$scope.isFailed = true;
			$scope.resmessage = "System failed. Please try again or contact WAALOS Support";

		});
	};

	//add sku
	$scope.addSku = function () {

		$scope.resmessage = "";
		$scope.isSuccess = false;
		$scope.isFailed = false;
		
		$("#addSkuModal").modal('hide');
		$("#showloader").css("display", "block");

		var postData =
			{
				"dspSku": $scope.displaySku,
				"dcName": $scope.pagedc,
				"userName": sessionStorage.userName,
				"grpType": $scope.grptype
			};

		var res = $http.post(urlService.ATE_SLOTTING_SJ_ADD_SKU, postData, {
			headers: {'x-api-key': sessionStorage.apikey}
		});

		res.success(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			if (data.errorMessage) {
				$scope.isFailed = true;
				$scope.resmessage = data.errorMessage;

			} else if (data.resMessage) {
				$scope.getSkuExclusion();
				$scope.isSuccess = true;
				$scope.resmessage = data.resMessage;
			}
		});
		res.error(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			$scope.isFailed = true;
			$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
		});
		$scope.displaySku = undefined;
		$scope.Sku_error = false;
	};
	$scope.changeSku = function(){
		if($scope.displaySku  == "")
		{
		$scope.Sku_error  = false;
	}else{
		$scope.Sku_error  = true;
	}
	};
	$scope.cancelSku = function(){
		$scope.displaySku = undefined;
		$scope.Sku_error = false;
	};
	
	// delete sku
	$scope.deleteSku = function () {

		$scope.resmessage = "";
		$scope.isSuccess = false;
		$scope.isFailed = false;
		$scope.isDeleted = true;

		$("#showloader").css("display", "block");
		var sku = $scope.selectedRowdspSKU.dspsku;
		var skuNum = sku.replace(" ", "");

		var url = urlService.ATE_SLOTTING_SJ_DELETE_SKU.replace('dName', $scope.pagedc);
		url = url.replace('uName', sessionStorage.userName);
		url = url.replace('gType', $scope.grptype);
		url = url.replace('skuid', $scope.selectedRowdspSKU.dspsku);

		var res = $http.delete(url, {
			headers: {'x-api-key': sessionStorage.apikey}
		});

		res.success(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			if (data.errorMessage) {
				$scope.isFailed = true;
				$scope.resmessage = data.errorMessage;

			} else if (data.resMessage) {
				$scope.getSkuExclusion();
				$scope.isSuccess = true;
				$scope.resmessage = data.resMessage;
				$scope.isDeleted = true;
			}
		});
		res.error(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			$scope.isFailed = true;
			$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
		});
	};

	var fixedCaseValue = "";

	//sloting grop edit
	$scope.editSlotingGroups = function () {
		$scope.isItemGroupClicked = false;
		$scope.isSave = false;
		$scope.isFailed = false;
		$scope.isSuccess = false;

		$("#showloader").css("display", "block");

		var url = urlService.ATE_SLOTTING_SJ_SLOTTING_GROUPS_EDIT.replace('dName', $scope.pagedc);
		url = url.replace('uName', sessionStorage.userName);
		url = url.replace('gType', $scope.grptype);
		url = url.replace('grpAttr', $scope.selectedRowToSlotEdit.slotGrp);

		$scope.grpAttrValue = $scope.selectedRowToSlotEdit.slotGrp;


		var res = $http.get(url, {
			headers: {'x-api-key': sessionStorage.apikey}
		});


		res.success(function (data, status, headers, config) {
		
			$("#showloader").css("display", "none");

			if (data.errorMessage) {
				$scope.isFailed = true;
				$scope.resmessage = data.errorMessage;
			} else if (data.resMessage) {
				$scope.isSuccess = true;
				$scope.resmessage = data.resMessage;
			} else {
				$scope.useridVal = data.userId;
				$scope.isEditdataSources = false;
				$scope.isMianpage = false;
				$scope.isEditSlotGroup = true;
				$scope.sataCode = data.statCode;
				$scope.needDereslot = data.needDereslot;
				//Location

				if (data.useFixAmount == 0 || data.useFixAmount == null || data.useFixAmount == 'None') {
					$scope.values.volOrFix = 'Volume';
					$scope.isFixed = true;
					$scope.values.fixedCase = "0";
				} else {
					$scope.values.volOrFix = 'Fixed';
					$scope.isFixed = false;
					$scope.values.fixedCase = data.useFixAmount;
					fixedCaseValue = data.useFixAmount;

				}
				$scope.values.maxAllowed = data.pctFull;

				$scope.values.skuMovement = data.lockInPlace;
				$scope.skumoves = ["0-SKUs Both In and Out", "1-Only SKUs Out", "2-Only SKUs In", "3-Locked-No SKUs In or Out"];

				if (data.spillOrder == "") {
					$scope.groupPriorityFlag = true;
					$scope.isSave = true;
				} else {
					$scope.values.groupPriority = data.spillOrder;
				}



				$scope.values.slotType = data.slotType;
				$scope.slottingTypes = ["Slot By Velocity", "Slot By Technical Size"];

				$scope.slotTypeRegnum = data.slotTypeRegion;
				$scope.slottingTypesReg = ["0-Americas", "1-Europe", "2-Asia"];


				//kitting
				$scope.kitTypeVal = data.kitType;
				$scope.kitted = ["100% Side By Side Kitting", "No Kitting", "User Defined Kit"];

				if (data.allowKitBreak == '0') {
					$scope.kitbreak = true;
					$scope.kitbreakVal = "0";
				} else {
					$scope.kitbreak = false;
					$scope.kitbreakVal = "1";
				}

				$scope.userTypeVal = data.kitUserType;
				$scope.usertypes = ["# of Bays - NOT WORKING", "# of Positions an article is allowed to span"];
				//slotgropNames		

				$scope.values.bayPosn = data.kitValue;

				if (data.kitType == 2) {
					$scope.isKit = false;
				} else {
					$scope.isKit = true;
				}

				if (data.deslotToReserve == '0') {
					$scope.dslotRes = true;
					$scope.isdeslot = true;
					$scope.deslotToReserve = 0;
				} else {
					$scope.dslotRes = false;
					$scope.isdeslot = false;
					$scope.deslotToReserve = 1;
				}

				if (data.deslotZero == '0') {
					$scope.dslotInv = false;
					$scope.dslotInvVal = "0";
				} else {

					$scope.dslotInv = true;
					$scope.dslotInvVal = "1";
				}
				$scope.values.daysTillSlot = data.daysTillSlot;
				$scope.values.deslotToRevVal = data.deslotToResvValue;
				if (data.reslotLimits == "") {
					$scope.values.intraZone = 0;
				} else {
					$scope.values.intraZone = data.reslotLimits;
				}
				//seasonYr prodSubGroups saBusSeg
				$scope.reslotZones = slotgropNames;
				$scope.values.reslotZoneIndex = $scope.reslotZones.indexOf(data.deslotToZone);


				$scope.prodtypes = "";
				$scope.prodgroup = "";
				$scope.carton = "";
				$scope.putwytype = "";
				$scope.seasonyr = "";
				$scope.prodsubgroups = "";
				$scope.sabusinesssegments = "";

				if (data.prodTypes == null || data.prodTypes == "") {
					$scope.prodTypes = "";
					$scope.prodtypes = " ";
				} else {

					$scope.prodTypes = data.prodTypes.replace(/['"]+/g, '').split(',');
					$scope.prodtypes = data.prodTypes;
				}

				if (data.prodGroups == null || data.prodGroups == "") {
					$scope.prodGroups = "";
					$scope.prodgroup = " ";
				} else {

					$scope.prodGroups = data.prodGroups.replace(/['"]+/g, '').split(',');
					$scope.prodgroup = data.prodGroups;
				}

				if (data.cartonTypes == null || data.cartonTypes == "") {
					$scope.cartonTypes = "";
					$scope.carton = " ";
				} else {

					$scope.cartonTypes = data.cartonTypes.replace(/['"]+/g, '').split(',');
					$scope.carton = data.cartonTypes;
				}

				if (data.putwyTypes == null || data.putwyTypes == "") {
					$scope.putwyTypes = "";
					$scope.putwytype = " ";
				} else {

					$scope.putwyTypes = data.putwyTypes.replace(/['"]+/g, '').split(',');
					$scope.putwytype = data.putwyTypes;
				}

				if (data.seasonYr == null || data.seasonYr == "") {
					$scope.seasonYr = "";
					$scope.seasonyr = " ";
				} else {

					$scope.seasonYr = data.seasonYr.replace(/['"]+/g, '').split(',');
					$scope.seasonyr = data.seasonYr;
				}

				if (data.prodSubGroups == null || data.prodSubGroups == "") {
					$scope.prodSubGroups = "";
					$scope.prodgubgroups = " ";
				} else {

					$scope.prodSubGroups = data.prodSubGroups.replace(/['"]+/g, '').split(',');
					$scope.prodgubgroups = data.prodSubGroups;
				}

				if (data.saBusinessSegments == null || data.saBusinessSegments == "") {
					$scope.saBusinessSegments = "";
					$scope.sabusinesssegments = " ";
				} else {

					$scope.saBusinessSegments = data.saBusinessSegments.replace(/['"]+/g, '').split(',');
					$scope.sabusinesssegments = data.saBusinessSegments;
				}



				$scope.saveValues = {
					"prodTypes": $scope.prodtypes,
					"prodGroups": $scope.prodgroup,
					"cartonTypes": $scope.carton,
					"putwyTypes": $scope.putwytype,
					"seasonYr": $scope.seasonyr,
					"prodSubGroups": $scope.prodsubgroups,
					"saBusinessSegments": $scope.sabusinesssegments
				};


			}
		});
		res.error(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			$scope.isFailedprob = true;
			$scope.resmessageprob = "System failed. Please try again or contact WAALOS Support";

		});
	};

	$scope.locationChange = function (s) {
		if (s == 'Volume') {
			$scope.values.volOrFix = 'Volume';
			$scope.isFixed = true;
			$scope.values.fixedCase = 0;

		} else {
			$scope.values.volOrFix = 'Fixed';
			$scope.isFixed = false;
			$scope.values.fixedCase = fixedCaseValue;


		}
	};

	$scope.fixedCaseValidation = function(){

		var numbers = /^[0-9]+$/;
		if ($scope.values.fixedCase == "" ||  $scope.values.fixedCase == null || !($scope.values.fixedCase.match(numbers)) ) {
			$scope.fixedCaseFlag = true;
			$scope.isSave = true;
		} else {
			$scope.fixedCaseFlag = false;
			$scope.isSave = false;
		}
	};

	$scope.kitBrealChange = function (kitbreak) {
		if (kitbreak == true) {
			$scope.kitbreakVal = "0";
		} else {
			$scope.kitbreakVal = "1";
		}
	};

	$scope.dslotInvChange = function (dslotInv) {
		if (dslotInv == true) {
			$scope.dslotInvVal = "1";
		} else {
			$scope.dslotInvVal = "0";
		}
	};

	$scope.maxAllowedValue = function () {

		var numbers = /^[0-9]+$/;
		if ($scope.values.maxAllowed == "" || !($scope.values.maxAllowed.match(numbers)) || $scope.values.maxAllowed == null || $scope.values.maxAllowed > 100) {
			$scope.maxValueFlag = true;
			$scope.isSave = true;
		} else {
			$scope.maxValueFlag = false;
			$scope.isSave = false;
		}

	};

	$scope.groupPriorityValue = function () {
		var numbers = /^[0-9]+$/;
		if ($scope.values.groupPriority == "" || !($scope.values.groupPriority.match(numbers))  || $scope.values.groupPriority <= 0) {
			$scope.groupPriorityFlag = true;
			$scope.isSave = true;
		} else {
			$scope.groupPriorityFlag = false;
			$scope.isSave = false;
		}
	};

	$scope.bayPosnChange = function(){
		var numbers = /^[0-9]+$/;
		if ($scope.values.bayPosn== "" || !($scope.values.bayPosn.match(numbers)) ) {
			$scope.bayPosnFlag = true;
			$scope.isSave = true;
		} else {
			$scope.bayPosnFlag = false;
			$scope.isSave = false;
		}
	};  

	$scope.changedaysTillSlot = function(){
		var numbers = /^[0-9]+$/;
		if ($scope.values.daysTillSlot== "" || !($scope.values.daysTillSlot.match(numbers)) ) {
			$scope.daysTillSlotFlag = true;
			$scope.isSave = true;
		} else {
			$scope.daysTillSlotFlag = false;
			$scope.isSave = false;
		}
	};

	$scope.changedslotToRevVal = function(){
		var numbers = /^[0-9]+$/;
		if ($scope.values.deslotToRevVal== "" || !($scope.values.deslotToRevVal.match(numbers)) ) {
			$scope.deslotToRevValFlag = true;
			$scope.isSave = true;
		} else {
			$scope.deslotToRevValFlag = false;
			$scope.isSave = false;
		}
	};

	$scope.kitChange = function (val) {
		if (val == 2) {
			$scope.isKit = false;
		} else {
			$scope.isKit = true;
		}
	};
	$scope.dSlotRes = function (dslot) {

		if (dslot == true) {
			$scope.isdeslot = true;
			$scope.deslotToReserve = 0;
		} else {
			$scope.isdeslot = false;
			$scope.deslotToReserve = 1;
		}
	};

	$scope.intraZoneChange =  function () {
		var numbers = /^[0-9]+$/;
		if ($scope.values.intraZone == "" ) {
			$scope.values.intraZone = "0";
		}
		if($scope.values.intraZone == ""  || !($scope.values.intraZone.match(numbers))){
			$scope.intraZoneFlag = true;
			$scope.isSave = true;
		}
		else{
			$scope.intraZoneFlag = false;
			$scope.isSave = false;
		}
	};




	$scope.itemGroups = function () {
		$scope.isItemGroupClicked = true;
		$scope.isSave = false;
		$scope.isFailed = false;
		$scope.isSuccess = false;

		$("#showloader").css("display", "block");

		var url = urlService.ATE_SLOTTING_SJ_ITEM_GROUP.replace('dName', $scope.pagedc);
		url = url.replace('uName', sessionStorage.userName);

		var res = $http.get(url, {
			headers: {'x-api-key': sessionStorage.apikey}
		});

		res.success(function (data, status, headers, config) {

			$("#showloader").css("display", "none");

			if (data.errorMessage) {
				$scope.isFailed = true;
				$scope.resmessage = data.errorMessage;
			} else if (data.resMessage) {
				$scope.isSuccess = true;
				$scope.resmessage = data.resMessage;
			} else {

				if (data.productTypes != null ) {
				if(data.productTypes[0].codeDesc != null || data.productTypes[0].codeId != null){
					//Product Type
					$scope.producttypes = [];
					_.each(data.productTypes, function (val, key) {
						if(val.codeId != null && val.codeDesc != null ){
						$scope.producttypes.push({ 'codeId': val.codeId, 'codeDesc': val.codeDesc, 'isChecked': false });
						}
					});
					if($scope.prodTypes[0] != " ")
					_.each($scope.prodTypes, function (val, key) {

						var arr = _.find($scope.producttypes, function (item) {
							return item.codeId == val;
						});
						arr['isChecked'] = true;
						$scope.producttypes = _.reject($scope.producttypes, function (item) {
							return item.codeId == val;

						});
						$scope.producttypes.push(arr);
						$scope.producttypes.sort(function (a, b) {
							return parseInt(a.codeId) - parseInt(b.codeId);
						});

					});
				     }
				}
				}

				//Product Groups
				if (data.productGroups != null ) {
				if(data.productGroups[0].codeDesc != null || data.productGroups[0].codeId != null){

					$scope.productgroups = [];
					_.each(data.productGroups, function (val, key) {
						if(val.codeId != null && val.codeDesc != null ){
						$scope.productgroups.push({ 'codeId': val.codeId, 'codeDesc': val.codeDesc, 'isChecked': false });
						}
					});
					if($scope.prodGroups[0] != " "){
					_.each($scope.prodGroups, function (val, key) {

						var arr = _.find($scope.productgroups, function (item) {
							return item.codeId == val;
						});
						arr['isChecked'] = true;
						$scope.productgroups = _.reject($scope.productgroups, function (item) {
							return item.codeId == val;

						});
						$scope.productgroups.push(arr);
						$scope.productgroups.sort(function (a, b) {
							return parseInt(a.codeId) - parseInt(b.codeId);
						});

					});
					}
				}
				}

				//carton Types $scope.cartonTypes 
				if (data.cartonTypes != null ) {
					if(data.cartonTypes[0].cartonType != null){
					$scope.cartontypes = [];
					_.each(data.cartonTypes, function (val, key) {
						if(val.cartonType != null ){
						$scope.cartontypes.push({ 'cartonType': val.cartonType, 'isChecked': false });
						}
					});
					if($scope.cartonTypes[0] != " "){
					_.each($scope.cartonTypes, function (val, key) {

						var arr = _.find($scope.cartontypes, function (item) {
							return item.cartonType == val;
						});
						arr['isChecked'] = true;
						$scope.cartontypes = _.reject($scope.cartontypes, function (item) {
							return item.cartonType == val;

						});
						$scope.cartontypes.push(arr);
						$scope.cartontypes.sort(function (a, b) {
							if (a.cartonType < b.cartonType) return -1;
							if (a.cartonType > b.cartonType) return 1;
							return 0;
						});

					});
					}
				}}

				//put away tyes

				if (data.putawayTypes != null) {
				if(data.putawayTypes[0].codeDesc != null || data.putawayTypes[0].codeId != null){

					$scope.putawaytypes = [];
					_.each(data.putawayTypes, function (val, key) {
						if(val.codeId != null && val.codeDesc != null ){
						$scope.putawaytypes.push({ 'codeId': val.codeId, 'codeDesc': val.codeDesc, 'isChecked': false });
						}
					});
					if($scope.putwyTypes[0] != " "){
					_.each($scope.putwyTypes, function (val, key) {

						var arr = _.find($scope.putawaytypes, function (item) {
							return item.codeId + "-" + item.codeDesc == val;
						});
						arr['isChecked'] = true;
						$scope.putawaytypes = _.reject($scope.putawaytypes, function (item) {
							return item.codeId + "-" + item.codeDesc == val;

						});
						$scope.putawaytypes.push(arr);
						$scope.putawaytypes.sort(function (a, b) {
							if (a.codeId < b.codeId) return -1;
							if (a.codeId > b.codeId) return 1;
							return 0;
						});

					});
					}
				}}
				//sub group 
				if (data.productSubGroups != null) {
				if(data.productSubGroups[0].codeDesc != null || data.productSubGroups[0].codeId != null){
					$scope.productsubgroups = [];
					_.each(data.productSubGroups, function (val, key) {
						if(val.codeId != null && val.codeDesc != null ){
						$scope.productsubgroups.push({ 'codeId': val.codeId, 'codeDesc': val.codeDesc, 'isChecked': false });
						}
					});
				if($scope.prodSubGroups[0] != " "){
					_.each($scope.prodSubGroups, function (val, key) {

						var arr = _.find($scope.productsubgroups, function (item) {
							return item.codeId == val;
						});
						arr['isChecked'] = true;
						$scope.productsubgroups = _.reject($scope.productsubgroups, function (item) {
							return item.codeId == val;

						});
						$scope.productsubgroups.push(arr);
						$scope.productsubgroups.sort(function (a, b) {
							return parseInt(a.codeId) - parseInt(b.codeId);
						});

					});
				}

				}}

				//Season year 
				if (data.seasonYrs != null) {
					$scope.seasonyears = [];
				
					
					_.each(data.seasonYrs, function (val, key) {
						if(val.miscAlpha2 !=null){
						$scope.seasonyears.push({ 'miscAlpha2': val.miscAlpha2, 'isChecked': false });
					}
					});
					if($scope.seasonYr[0] != " "){
					_.each($scope.seasonYr, function (val, key) {

						var arr = _.find($scope.seasonyears, function (item) {
							return item.miscAlpha2 == val;
						});
						arr['isChecked'] = true;
						$scope.seasonyears = _.reject($scope.seasonyears, function (item) {
							return item.miscAlpha2 == val;

						});
						$scope.seasonyears.push(arr);
						$scope.seasonyears.sort(function (a, b) {
							return parseInt(a.miscAlpha2) - parseInt(b.miscAlpha2);
						});

					});
				
					}

				}
				// Sa bussness segment
				if (data.saBusinessSegments != null) {
                                if(data.saBusinessSegments[0].codeDesc != null || data.saBusinessSegments[0].codeId != null){
					$scope.sabusinessswegments = [];
					_.each(data.saBusinessSegments, function (val, key) {
						if(val.codeId != null && val.codeDesc != null ){
						$scope.sabusinessswegments.push({ 'codeId': val.codeId, 'codeDesc': val.codeDesc, 'isChecked': false });
						}
					});
					if($scope.saBusinessSegments[0] != " "){
					_.each($scope.saBusinessSegments, function (val, key) {

						var arr = _.find($scope.sabusinessswegments, function (item) {
							return item.codeId == val;
						});
						arr['isChecked'] = true;
						$scope.sabusinessswegments = _.reject($scope.sabusinessswegments, function (item) {
							return item.codeId == val;

						});
						$scope.sabusinessswegments.push(arr);
						$scope.sabusinessswegments.sort(function (a, b) {
							return parseInt(a.codeId) - parseInt(b.codeId);
						});

					});
				}
				

			}}
		});
		res.error(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			$scope.isFailed = true;
			$scope.resmessage = "System failed. Please try again or contact WAALOS Support";

		});
	};




	$scope.saveSloting = function () {
$scope.isItemGroupClicked = true;
		$scope.resmessage = "";
		$scope.isSuccess = false;
		$scope.isFailed = false;
		$scope.isDelete = false;
		$("#showloader").css("display", "block");


		if ($scope.values.intraZone == "") {
			$scope.values.intraZone = "0";
		}
		var saveProductValues = "";
		if ($scope.producttypes) {
			_.each($scope.producttypes, function (val, key) {
				if (val.isChecked) {
					saveProductValues += "'" + val.codeId + "'" + ",";
				}
			});
			saveProductValues = saveProductValues.slice(0, -1);
		}


		var saveProductGroupValues = "";
		if ($scope.productgroups) {
			_.each($scope.productgroups, function (val, key) {
				if (val.isChecked) {
					saveProductGroupValues += "'" + val.codeId + "'" + ",";
				}
			});
			saveProductGroupValues = saveProductGroupValues.slice(0, -1);
		}

		var saveCartonTypes = "";
		if ($scope.cartontypes) {
			_.each($scope.cartontypes, function (val, key) {
				if (val.isChecked) {
					saveCartonTypes += "'" + val.cartonType + "'" + ",";
				}
			});
			saveCartonTypes = saveCartonTypes.slice(0, -1);
		}

		var savePutawayTypes = "";

		if ($scope.putawaytypes) {
			_.each($scope.putawaytypes, function (val, key) {
				if (val.isChecked) {
					savePutawayTypes += "'" + val.codeId + "-" + val.codeDesc + "'" + ",";
				}
			});
			savePutawayTypes = savePutawayTypes.slice(0, -1);
		}

		var saveProductSubGroups = "";

		if ($scope.putawaytypes) {
			_.each($scope.productsubgroups, function (val, key) {
				if (val.isChecked) {
					saveProductSubGroups += "'" + val.codeId + "'" + ",";
				}
			});
			saveProductSubGroups = saveProductSubGroups.slice(0, -1);
		}


		var saveSaBusinessSegments = "";

		if ($scope.sabusinessswegments) {
			_.each($scope.sabusinessswegments, function (val, key) {
				if (val.isChecked) {
					saveSaBusinessSegments += "'" + val.codeId + "'" + ",";
				}
			});
			saveSaBusinessSegments = saveSaBusinessSegments.slice(0, -1);
		}

		var saveSeasonYrs = "";

		if ($scope.seasonyears) {
			_.each($scope.seasonyears, function (val, key) {
				if (val.isChecked) {
					saveSeasonYrs += "'" + val.miscAlpha2 + "'" + ",";
				}
			});
			saveSeasonYrs = saveSeasonYrs.slice(0, -1);
		}

		var postData = {
			"dcName": $scope.pagedc,
			"userName": sessionStorage.userName,
			"grpType": $scope.grptype,
			"grpAttr": $scope.grpAttrValue,
			"userId": $scope.useridVal,
			"createDateTime": "",
			"modDateTime": "",
			"statCode": $scope.sataCode,
			"useFixAmount": $scope.values.fixedCase,
			"pctFull": $scope.values.maxAllowed,
			"needDereslot": $scope.needDereslot,
			"spillOrder": $scope.values.groupPriority,
			"daysTillSlot": $scope.values.daysTillSlot,
			"kitType": $scope.kitted.indexOf($scope.values.kitType).toString(),
			"kitUserType": $scope.usertypes.indexOf($scope.values.userType).toString(),
			"kitValue": $scope.values.bayPosn,
			"deslotToReserve": $scope.deslotToReserve.toString(),
			"deslotToResvValue": $scope.values.deslotToRevVal,
			"deslotToZone": $scope.values.reslotZone,
			"prodTypes": $scope.isItemGroupClicked ? saveProductValues : $scope.saveValues.prodTypes,
			"prodGroups": $scope.isItemGroupClicked ? saveProductGroupValues : $scope.saveValues.prodGroups,
			"cartonTypes": $scope.isItemGroupClicked ? saveCartonTypes : $scope.saveValues.cartonTypes,
			"putwyTypes": $scope.isItemGroupClicked ? savePutawayTypes : $scope.saveValues.putwyTypes,
			"allowKitBreak": $scope.kitbreakVal,
			"lockInPlace": $scope.skumoves.indexOf($scope.values.skumovesvalue).toString(),
			"seasonYr": $scope.isItemGroupClicked ? saveSeasonYrs : $scope.saveValues.seasonYr,
			"slotType": $scope.slottingTypes.indexOf($scope.values.slottingType).toString(),
			"slotTypeRegion": $scope.slottingTypesReg.indexOf($scope.values.slotTypeReg).toString(),
			"deslotZero": $scope.dslotInvVal,
			"prodSubGroups": $scope.isItemGroupClicked ? saveProductSubGroups : $scope.saveValues.prodSubGroups,
			"saBusSeg": $scope.isItemGroupClicked ? saveSaBusinessSegments : $scope.saveValues.saBusinessSegments,
			"reslotLimits": $scope.values.intraZone,
			"fillLocations": $scope.values.volOrFix,
			"noOfCases": $scope.values.fixedCase

		};

		var res = $http.put(urlService.ATE_SLOTTING_SJ_UPDATE_GROUP, postData, {
			headers: {'x-api-key': sessionStorage.apikey}
		});

		res.success(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			if (data.errorMessage) {
				$scope.isFailed = true;
				$scope.resmessage = data.errorMessage;

			} else if (data.resMessage) {
				$scope.editSlotingGroups();
				$scope.isSuccess = true;
				$scope.resmessage = data.resMessage;
			}
		});
		res.error(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			$scope.isFailed = true;
			$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
		});
	};

	//release task
	$scope.releaseTask = function (grid, row) {
	
		if(row.entity.hasTask == 'N'){
			$scope.isSuccess = true;
			$scope.resmessage = "Release Tasks cannot be accessed as Unreleased Tasks flag is 'N'";
			return false;
		}
		$scope.isSuccess = false;
		$scope.isFailed = false;
		$scope.isLowerGrid = false;
		$scope.gridData = grid;
		$scope.rowData = row;
		$scope.reqExchangeDto = [];
		$("#showloader").css("display", "block");
		var url = urlService.ATE_SLOTTING_SJ_RELESE_TASK.replace('dName', $scope.pagedc);
		url = url.replace('uName', sessionStorage.userName);
		url = url.replace('gType', row.entity.grpType);
		$scope.gType = row.entity.grpType;
		var res = $http.get(url, {
			headers: {'x-api-key': sessionStorage.apikey}
		});

		res.success(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			if (data.errorMessage) {
				$scope.isFailed = true;
				$scope.resmessage = data.errorMessage;
			} else if (data.resMessage) {
				$scope.isSuccess = true;
				$scope.resmessage = data.resMessage;
			} else {



				$scope.gridOptions.columnDefs = [
					{ name: 'grpAttr', displayName: 'Work Zones', enableCellEdit: false, cellTooltip: true, headerTooltip: true },
					{ name: 'deslotCntl', displayName: 'Deslot', enableCellEdit: false, cellTooltip: true, headerTooltip: true },
					{ name: 'reslotOpenCnt', displayName: 'Reslots In', enableCellEdit: false, cellTooltip: true, headerTooltip: true },
					{ name: 'reslotCnt', displayName: 'Reslots Out', enableCellEdit: false, cellTooltip: true, headerTooltip: true },
					{ name: 'newslotCnt', displayName: 'New Slots', enableCellEdit: false, cellTooltip: true, headerTooltip: true },
					{ name: 'totalCnt', displayName: 'Total Locns', enableCellEdit: false, cellTooltip: true, headerTooltip: true }
				];

				$scope.isReleseTask = true;
				$scope.isMianpage = false;
				$scope.gridOptions.data = data.getTotalReleaseCntDtoLst;

				if ($scope.gridOptions.data > 10) {
					$scope.gridOptions.enableVerticalScrollbar = true;
					$scope.gridOptions.enableHorizontalScrollbar = 1;
				} else {
					$scope.gridOptions.enableVerticalScrollbar = false;
					$scope.gridOptions.enableHorizontalScrollbar = 1;
				}

				$scope.workZoneList = data.workZonesLst;
                $scope.workZoneList.unshift({grpAttr: "*Any*"});
				$scope.values.newLogicals = $scope.workZoneList[0];

				$scope.relesedata = ["Deslot", "Reslot (Open slots)", "Reslot", "New Slots (Open slots)", "New Slots"];
				$scope.values.releaseData = $scope.relesedata[0];
			}

		});
		res.error(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			$scope.isFailed = true;
			$scope.resmessage = "System failed. Please try again or contact WAALOS Support";

		});
	};


	$scope.addWorkZones = function () {
		$scope.isSuccess = false;
		$scope.isFailed = false;
		if($scope.values.newLogicals.grpAttr == "*Any*"){var grptypeData= ' ';}else{grptypeData = $scope.values.newLogicals.grpAttr; }
		$("#showloader").css("display", "block");
		var url = urlService.ATE_SLOTTING_SJ_RELESE_TASK_ADD.replace('dName', $scope.pagedc);
		url = url.replace('uName', sessionStorage.userName);
		url = url.replace('gType', $scope.gType);
		url = url.replace('gAttr', grptypeData);


		var res = $http.get(url, {
			headers: {'x-api-key': sessionStorage.apikey}
		});

		res.success(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			if (data.errorMessage) {
				$scope.isFailed = true;
				$scope.resmessage = data.errorMessage;
			} else if (data.resMessage) {
				$scope.isSuccess = true;
				$scope.resmessage = data.resMessage;
			} else {
	                        if($scope.values.newLogicals.grpAttr == "*Any*"){$scope.wrkGrpAll = true;}else{$scope.wrkGrpAll =false;}
				
				$scope.updatedVAL = [];
				$("#releaseModel").modal('show');
				$scope.workgroupsData = [];
				_.each(data, function (Dval,Dkey) {
					$scope.workgroupsData.push({ 'name': Dval.aisles, 'isChecked': false });
				});

			}
		});
		res.error(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			$scope.isFailed = true;
			$scope.resmessage = "System failed. Please try again or contact WAALOS Support";

		});
	};

	$scope.lowerGrid = function () {

		$scope.isSuccessCancel = false;
		$scope.isFailedCancel = false;
		$scope.skubutton = true;
		$scope.values.dspNumber = " ";
		$("#showloader").css("display", "block");



		var workgroup_list = "";

		if($scope.workgroupsData.length == 0 && $scope.wrkGrpAll != true){
			$scope.isFailed = true;
			$scope.resmessage = "Please select at least one value";
			$("#showloader").css("display", "none");
			return false;
		
		}
		for (var key in $scope.workgroupsData) {
			if ($scope.workgroupsData.hasOwnProperty(key)) {
				if ($scope.workgroupsData[key].isChecked == true) {
					workgroup_list += $scope.workgroupsData[key].name + ",";

				}
			}
		}
		workgroup_list = workgroup_list.slice(0, -1);

		if ($scope.wrkGrpAll) {
			workgroup_list = "";
		}

		if (workgroup_list == "") {
			workgroup_list = "";
			
		}


		if($scope.values.newLogicals.grpAttr == "*Any*"){var grptypeData= "";}else{grptypeData = $scope.values.newLogicals.grpAttr;  }
		if($scope.reqExchangeDto == undefined){
			$scope.reqExchangeDto =[];
			$scope.reqExchangeDto.push({ "grpType": $scope.gType, "wrkZone": grptypeData, "wrkType": $scope.values.releaseData, "aisles": workgroup_list });
			
		}else{
			$scope.reqExchangeDto.push({ "grpType": $scope.gType, "wrkZone":  grptypeData, "wrkType": $scope.values.releaseData, "aisles": workgroup_list });
			//$scope.reqExchangeDto.dataValues.push({ "grpType": $scope.gType, "wrkZone":  $scope.values.newLogicals.grpAttr, "wrkType": $scope.values.releaseData, "aisles": workgroup_list });
		}

		var dataObj = 
			{
				"dcName": $scope.pagedc,
				"userName" : sessionStorage.userName,
				"reqExchangeDto" :$scope.reqExchangeDto,
				"getReleaseTasksLstDto": null,
				"getLeftGridTasksDto": null
	
	};
		var url = urlService.ATE_SLOTTING_SJ_RELESE_TASK_LOWERGRID;
		var res = $http.post(url, dataObj, {
			 headers: {'x-api-key': sessionStorage.apikey}
		});


		$scope.workgropData = workgroup_list;


		res.success(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			if (data.errorMessage) {
				$scope.isFailedCancel = true;
				$scope.resmessageCancel = data.errorMessage;
			} else if (data.resMessage) {
				$scope.isSuccessCancel = true;
				$scope.resmessageCancel = data.resMessage;
			} else {
				$scope.reqExchangeDto = data.reqExchangeDto;
						    
				
				if (data.getReleaseTasksLstDto.length == 0) {
					$scope.isLowerGrid = false;
					$scope.isSuccessCancel = true;
					$scope.resmessageCancel = "No Record(s) Found";
					$scope.releaseButton = true;
					$scope.gridOptionsLower.data = "";
					$scope.gridOptionsLower.data = [];

				} else {
					$scope.isLowerGrid = true;
					$scope.releaseButton = false;
					$scope.gridOptionsLower.data = data.getReleaseTasksLstDto;
					$scope.gridOptionsLower.columnDefs = [
						/*{ name: 'cancel', displayName: 'Cancel', width: 100, enableCellEdit: false, cellTooltip: true, headerTooltip: true, cellTemplate: '<div class="ui-grid-cell-contents" ng-click="grid.appScope.cancelTask(grid, row)"><a>Cancel</a></div>' },*/
						{ name:  'seq', field: 'name',width: 100, cellTemplate: '<div class="ui-grid-cell-contents">{{grid.renderContainers.body.visibleRowCache.indexOf(row)+1}}</div>' },
						{ name: 'fromZone', displayName: 'From Zone', width: 120, enableCellEdit: false, cellTooltip: true, headerTooltip: true },
						{ name: 'fromLocn', displayName: 'From Locn', width: 120, enableCellEdit: false, cellTooltip: true, headerTooltip: true },
						{ name: 'dispalySku', displayName: 'Display SKU', width: 130, enableCellEdit: false, cellTooltip: true, headerTooltip: true },
						{ name: 'actlInventory', displayName: 'Actl Inventory', width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip: true },
						{ name: 'toZone', displayName: 'To Zone', width: 100, enableCellEdit: false, cellTooltip: true, headerTooltip: true },
						{ name: 'toLocn', displayName: 'To Locn', width: 100, enableCellEdit: false, cellTooltip: true, headerTooltip: true },
						{ name: 'batch', displayName: 'Batch Id', width: 100, enableCellEdit: false, cellTooltip: true, headerTooltip: true },
						{ name: 'stepValue', displayName: 'Batch Step', width: 120, enableCellEdit: false, cellTooltip: true, headerTooltip: true },
						{ name: 'nullValue', displayName: 'Std Case Qty', width: 120, enableCellEdit: false, cellTooltip: true, headerTooltip: true },
						{ name: 'nullVal1', displayName: 'Tot. Cases', width: 120, enableCellEdit: false, cellTooltip: true, headerTooltip: true },
						{ name: 'prodType', displayName: 'Division', width: 100, enableCellEdit: false, cellTooltip: true, headerTooltip: true },
						{ name: 'locnPick', displayName: 'Locn Pick Seq', width: 140, enableCellEdit: false, cellTooltip: true, headerTooltip: true }
	
					]; 
				}
				$scope.isLowerGrid = true;
				$scope.isLowerGridtable = true;
				$scope.isLowerGridSearchtable = false;			
				if($scope.gridOptionsLower.data.length != 0){
					$scope.isDatarelease = true;
				}
				else{
					$scope.isDatarelease = false;
				}
						


				if($scope.values.newLogicals.grpAttr == "*Any*"){
					if($scope.values.releaseData == "Reslot (Open slots)" || $scope.values.releaseData == "Reslot"){

						var ateSzReleaseCntDtoData = [];
						_.each($scope.gridOptions.data, function (val, key) {
							var insertdata = true;
						
							for(var i = 0; i<data.resltReleaseCntDto.length; i++){
						
								if($scope.gridOptions.data[key].grpAttr == data.resltReleaseCntDto[i].grpAttr){
									ateSzReleaseCntDtoData.push({grpAttr: data.resltReleaseCntDto[i].grpAttr,slotCntl:data.resltReleaseCntDto[i].slotCntl});
									var insertdata = false;
								}
							}
							if(insertdata){
								ateSzReleaseCntDtoData.push({grpAttr:$scope.gridOptions.data[key].grpAttr,slotCntl: null});
							}
							
						});		
											var j = 0;
											
											_.each($scope.gridOptions.data, function (val, key) {
												var temp = false;
												for(var i = 0; i<ateSzReleaseCntDtoData.length; i++){
											
														if(val.grpAttr == ateSzReleaseCntDtoData[i].grpAttr){
															$scope.gridOptions.data[key].reslotOpenCnt = ateSzReleaseCntDtoData[j].slotCntl;
															i = ateSzReleaseCntDtoData.length;
															temp = true;
												}
											
													
													
												}
												if(temp){	j +=1;	}
							
											});

											var ateSzReleaseCntDtoDataout = [];
											_.each($scope.gridOptions.data, function (val, key) {
												var insertdataout = true;
											
												for(var i = 0; i<data.ateSzReleaseCntDto.length; i++){
											
													if($scope.gridOptions.data[key].grpAttr == data.ateSzReleaseCntDto[i].grpAttr){
														ateSzReleaseCntDtoDataout.push({grpAttr: data.ateSzReleaseCntDto[i].grpAttr,slotCntl:data.ateSzReleaseCntDto[i].slotCntl});
														var insertdataout = false;
													}
												}
												if(insertdataout){
													ateSzReleaseCntDtoDataout.push({grpAttr:$scope.gridOptions.data[key].grpAttr,slotCntl: null});
												}
												
											});		
																var k = 0;
																
																_.each($scope.gridOptions.data, function (val, key) {
																	var tempout = false;
																	for(var i = 0; i<ateSzReleaseCntDtoDataout.length; i++){
																
																			if(val.grpAttr == ateSzReleaseCntDtoDataout[i].grpAttr){
																				$scope.gridOptions.data[key].reslotCnt = ateSzReleaseCntDtoDataout[k].slotCntl;
																				i = ateSzReleaseCntDtoDataout.length;
																				tempout = true;
																	}
																
																		
																		
																	}
																	if(tempout){	k +=1;	}
												
																});





					}else{
					var ateSzReleaseCntDtoData = [];
					_.each($scope.gridOptions.data, function (val, key) {
						var insertdata = true;
					
						for(var i = 0; i<data.ateSzReleaseCntDto.length; i++){
					
							if($scope.gridOptions.data[key].grpAttr == data.ateSzReleaseCntDto[i].grpAttr){
								ateSzReleaseCntDtoData.push({grpAttr: data.ateSzReleaseCntDto[i].grpAttr,slotCntl:data.ateSzReleaseCntDto[i].slotCntl});
								var insertdata = false;
							}
						}
						if(insertdata){
							ateSzReleaseCntDtoData.push({grpAttr:$scope.gridOptions.data[key].grpAttr,slotCntl: null});
						}
						
					});

			if (data.ateSzReleaseCntDto.length != 0) {

				var j = 0;
				
				_.each($scope.gridOptions.data, function (val, key) {
					var temp = false;
					for(var i = 0; i<ateSzReleaseCntDtoData.length; i++){
						if ($scope.values.releaseData == "Deslot") {
							if(val.grpAttr == ateSzReleaseCntDtoData[i].grpAttr){
								$scope.gridOptions.data[key].deslotCntl = ateSzReleaseCntDtoData[j].slotCntl;
								i = ateSzReleaseCntDtoData.length;
								temp = true;
							}
						}else if($scope.values.releaseData == "Reslot (Open slots)"){
							if(val.grpAttr == ateSzReleaseCntDtoData[i].grpAttr){
								$scope.gridOptions.data[key].reslotCnt = ateSzReleaseCntDtoData[j].slotCntl;
								i = ateSzReleaseCntDtoData.length;
								temp = true;
							}
							}else if($scope.values.releaseData == "Reslot"){
								if(val.grpAttr == ateSzReleaseCntDtoData[i].grpAttr){
								$scope.gridOptions.data[key].reslotOpenCnt = ateSzReleaseCntDtoData[j].slotCntl;
								i = ateSzReleaseCntDtoData.length;
								temp = true;
								}
							}else if($scope.values.releaseData == "New Slots (Open slots)" || $scope.values.releaseData == "New Slots"){
								if(val.grpAttr == ateSzReleaseCntDtoData[i].grpAttr){
								$scope.gridOptions.data[key].newslotCnt = ateSzReleaseCntDtoData[j].slotCntl;
								i = ateSzReleaseCntDtoData.length;
								temp = true;
								}
							}
						
						
					}
					if(temp){	j +=1;	}

				});
			}
		}
				}
				
				else if(data.resltReleaseCntDto !=null){
					
					var ateSzReleaseCntDtoData = [];
					_.each($scope.gridOptions.data, function (val, key) {
						var insertdata = true;
					
						for(var i = 0; i<data.resltReleaseCntDto.length; i++){
					
							if($scope.gridOptions.data[key].grpAttr == data.resltReleaseCntDto[i].grpAttr){
								ateSzReleaseCntDtoData.push({grpAttr: data.resltReleaseCntDto[i].grpAttr,slotCntl:data.resltReleaseCntDto[i].slotCntl});
								var insertdata = false;
							}
						}
						if(insertdata){
							ateSzReleaseCntDtoData.push({grpAttr:$scope.gridOptions.data[key].grpAttr,slotCntl: null});
						}
						
					});		
										var j = 0;
										
										_.each($scope.gridOptions.data, function (val, key) {
											var temp = false;
											for(var i = 0; i<ateSzReleaseCntDtoData.length; i++){
										
													if(val.grpAttr == ateSzReleaseCntDtoData[i].grpAttr){
														$scope.gridOptions.data[key].reslotOpenCnt = ateSzReleaseCntDtoData[j].slotCntl;
														i = ateSzReleaseCntDtoData.length;
														temp = true;
											}
										
												
												
											}
											if(temp){	j +=1;	}
						
										});

					_.each($scope.gridOptions.data, function (val, key) {
						for(var i = 0; i<data.ateSzReleaseCntDto.length; i++){
							if (data.ateSzReleaseCntDto[i].grpAttr == val.grpAttr) {
								
								if($scope.values.releaseData == "Reslot" || $scope.values.releaseData == "Reslot (Open slots)"){
									$scope.gridOptions.data[key].reslotCnt = data.ateSzReleaseCntDto[i].slotCntl;
								}
						}
						}

					});

									

				}else{

					if (data.ateSzReleaseCntDto.length != 0) {
						_.each($scope.gridOptions.data, function (val, key) {
							for(var i = 0; i<data.ateSzReleaseCntDto.length; i++){
								if (data.ateSzReleaseCntDto[i].grpAttr == val.grpAttr) {
									if($scope.values.releaseData == "Deslot"){
										$scope.gridOptions.data[key].deslotCntl = data.ateSzReleaseCntDto[i].slotCntl;
									}
									if($scope.values.releaseData == "Reslot (Open slots"){
										$scope.gridOptions.data[key].reslotOpenCnt = data.ateSzReleaseCntDto[i].slotCntl;
									}
									if($scope.values.releaseData == "Reslot"){
										$scope.gridOptions.data[key].reslotCnt = data.ateSzReleaseCntDto[i].slotCntl;
									}
									if($scope.values.releaseData == "New Slots (Open slots)" || $scope.values.releaseData == "New Slots"){
										$scope.gridOptions.data[key].newslotCnt = data.ateSzReleaseCntDto[i].slotCntl;
									}
									
									
									
								
								}
		
							}
							
		
						});
					}
		
				}				



				if ($scope.gridOptionsLower.data > 10) {
					$scope.gridOptionsLower.enableVerticalScrollbar = true;
					$scope.gridOptionsLower.enableHorizontalScrollbar = 1;
				} else {
					$scope.gridOptionsLower.enableVerticalScrollbar = false;
					$scope.gridOptionsLower.enableHorizontalScrollbar = 1;
				}
			}

		});
		res.error(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			$scope.isFailedCancel = true;
			$scope.resmessageCancel = "System failed. Please try again or contact WAALOS Support";

		});

	};

	$scope.backtorelease = function(){
		$scope.isLowerGrid = true;
		$scope.isLowerGridtable = true;
		$scope.isLowerGridSearchtable = false;	
	};

	

	$scope.updateLowergrid = function (noRecords) {
		$scope.isFailedCancel = false;
		$scope.isSuccessCancel = false;
		$scope.isLowerGridtable = false;
		$("#showloader").css("display", "block");

		$scope.gridOptionsLowerSearch.data = "";

		var url = urlService.ATE_SLOTTING_SJ_RELESE_TASK_LOWERGRID_SEARCH.replace('dName', $scope.pagedc);
		url = url.replace('uName', sessionStorage.userName);
		url = url.replace('gType', $scope.gType);
		url = url.replace('gAttr', $scope.values.newLogicals.grpAttr);
		url = url.replace('WTypr', $scope.values.releaseData);
		url = url.replace('ailas', $scope.workgropData);
		url = url.replace('dspNum', $scope.values.dspNumber);
		url = decodeURI(url);


		var res = $http.get(url, {
			headers: {'x-api-key': sessionStorage.apikey}
		});

		res.success(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			if (data.errorMessage) {
				$scope.isFailedCancel = true;
				$scope.resmessageCancel = data.errorMessage;
			} else if (data.resMessage) {
				$scope.isSuccessCancel = true;
				$scope.resmessageCancel = data.resMessage;
			} else {
				
				$scope.gridOptionsLowerSearch.columnDefs = [
					/*{ name: 'cancel', displayName: 'Cancel', width: 100, enableCellEdit: false, cellTooltip: true, headerTooltip: true, cellTemplate: '<div class="ui-grid-cell-contents" ng-click="grid.appScope.cancelTask(grid, row)"><a>Cancel</a></div>' },*/
					
					{ name: 'fromZone', displayName: 'From Zone', width: 100, enableCellEdit: false, cellTooltip: true, headerTooltip: true },
					{ name: 'fromLocn', displayName: 'From Locn', width: 100, enableCellEdit: false, cellTooltip: true, headerTooltip: true },
					{ name: 'dispalySku', displayName: 'Display SKU', width: 130, enableCellEdit: false, cellTooltip: true, headerTooltip: true },
					{ name: 'actlInventory', displayName: 'Actl Inventory', width: 100, enableCellEdit: false, cellTooltip: true, headerTooltip: true },
					{ name: 'toZone', displayName: 'To Zone', width: 100, enableCellEdit: false, cellTooltip: true, headerTooltip: true },
					{ name: 'toLocn', displayName: 'To Locn', width: 100, enableCellEdit: false, cellTooltip: true, headerTooltip: true },
					{ name: 'batch', displayName: 'Batch', width: 100, enableCellEdit: false, cellTooltip: true, headerTooltip: true },
					{ name: 'stepValue', displayName: 'Step Value', width: 100, enableCellEdit: false, cellTooltip: true, headerTooltip: true },
					{ name: 'nullValue', displayName: 'Null Value', width: 100, enableCellEdit: false, cellTooltip: true, headerTooltip: true },
					{ name: 'nullVal1', displayName: 'Null Val1', width: 100, enableCellEdit: false, cellTooltip: true, headerTooltip: true },
					{ name: 'prodType', displayName: 'Prod Type', width: 100, enableCellEdit: false, cellTooltip: true, headerTooltip: true },
					{ name: 'locnPick', displayName: 'Locn Pick', width: 100, enableCellEdit: false, cellTooltip: true, headerTooltip: true }

				];
				$scope.isLowerGridSearchtable = true;

				$scope.gridOptionsLowerSearch.data = data;


				if ($scope.gridOptionsLowerSearch.data > 10) {
					$scope.gridOptionsLowerSearch.enableVerticalScrollbar = true;
					$scope.gridOptionsLowerSearch.enableHorizontalScrollbar = 1;
				} else {
					$scope.gridOptionsLowerSearch.enableVerticalScrollbar = false;
					$scope.gridOptionsLowerSearch.enableHorizontalScrollbar = 1;
				}


			}

		});
		res.error(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			$scope.isFailedCancel = true;
			$scope.resmessageCancel = "System failed. Please try again or contact WAALOS Support";

		});


	};


	$scope.skubutton = true;
	$scope.displaySkuValidation= function(){
	if($scope.values.dspNumber == null || $scope.values.dspNumber == undefined || $scope.values.dspNumber.length == 0){
	$scope.skubutton = true;
	}else{
	$scope.skubutton = false;
	}
	};

	$scope.cancelTask = function (grid, row) {
		$scope.isFailedCancel = false;
		$scope.isSuccessCancel = false;

		if (grid) {
			$("#CancelModal").modal('show');
			$scope.cancellingData = row;
		} else {
			$("#showloader").css("display", "block");
			var postData = {
				"dcName": $scope.pagedc,
				"userName": sessionStorage.userName,
				"fromZone": $scope.cancellingData.entity.fromZone,
				"fromLocn": $scope.cancellingData.entity.fromLocn,
				"dispalySku": $scope.cancellingData.entity.dispalySku,
				"actlInventory": $scope.cancellingData.entity.actlInventory,
				"toZone": $scope.cancellingData.entity.toZone,
				"toLocn": $scope.cancellingData.entity.toLocn,
				"batch": $scope.cancellingData.entity.batch,
				"stepValue": $scope.cancellingData.entity.stepValue,
				"nullValue": $scope.cancellingData.entity.nullValue,
				"nullVal1": $scope.cancellingData.entity.nullVal1,
				"prodType": $scope.cancellingData.entity.prodType,
				"locnPick": $scope.cancellingData.entity.locnPick

			};
			var res = $http.put(urlService.ATE_SLOTTING_SJ_RELESE_TASK_CANCEL, postData, {
				headers: {'x-api-key': sessionStorage.apikey}
			});

			res.success(function (data, status, headers, config) {
				$("#showloader").css("display", "none");

				if (data.errorMessage) {
					$scope.isFailedCancel = true;
					$scope.resmessageCancel = data.errorMessage;

				} else if (data.resMessage) {
					$scope.isSuccessCancel = true;
					$scope.resmessageCancel = data.resMessage;

				}
			});
			res.error(function (data, status, headers, config) {
				$("#showloader").css("display", "none");
				$scope.isFailedCancel = true;
				$scope.resmessageCancel = "System failed. Please try again or contact WAALOS Support";

			});

		}

	};



	

	$scope.runAslot = function (grid, row) {
		$scope.isFailed = false;
		$scope.isFailed = false;
		if (grid) {
			$("#runaslotModel").modal('show');

			$scope.runASlot = row;
		} else {
			$("#showloader").css("display", "block");
			var url = urlService.ATE_SLOTTING_SJ_RUN_A_SLOT.replace('dName', $scope.pagedc);
			url = url.replace('gType', $scope.runASlot.entity.grpType);

			var res = $http.get(url, {
				headers: {'x-api-key': sessionStorage.apikey}
			});

			res.success(function (data, status, headers, config) {
				$("#showloader").css("display", "none");

				if (data.errorMessage) {
					$scope.isFailed = true;
					$scope.resmessage = data.errorMessage;

				} else if (data.resMessage) {
					$("#showloader").css("display", "block");
					setTimeout(function(){ 
					$("#showloader").css("display", "none");
					$scope.dataSources();
					$scope.isSuccess = true;
					$scope.resmessage = data.resMessage;
					}, 10000);
					
					

				}
			});
			res.error(function (data, status, headers, config) {
				$("#showloader").css("display", "none");
				$scope.isFailed = true;
				$scope.resmessage = "System failed. Please try again or contact WAALOS Support";

			});


		}
	};

	$scope.release = function () {

		$scope.isFailed = false;
		$scope.isFailed = false;
		$("#showloader").css("display", "block");

		var postData = {
			"dcName": $scope.pagedc,
			"username": sessionStorage.userName,
			"grpType": $scope.gType,
			"wrkType": $scope.values.releaseData,
			"wrkZone": $scope.values.newLogicals.grpAttr,
			"aisles": $scope.workgropData
		};

		var res = $http.put(urlService.ATE_SLOTTING_SJ_RELESE, postData, {
			headers: {'x-api-key': sessionStorage.apikey}
		});

		res.success(function (data, status, headers, config) {
			$("#showloader").css("display", "none");

			if (data.errorMessage) {
				$scope.isFailed = true;
				$scope.resmessage = data.errorMessage;

			} else if (data.resMessage) {
				
				$scope.backSource();
			$timeout(function(){
					$scope.isSuccess = true;
				$scope.resmessage = data.resMessage;
							},2000);
				



			}
		});
		res.error(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			$scope.isFailed = true;
			$scope.resmessage = "System failed. Please try again or contact WAALOS Support";

		});
	};

   //user favourites code start
$scope.isClicked = false;
   $scope.addToFavourate = function(isClicked){
    $("#showloader").css("display", "block");
     if(typeof isClicked !== "boolean"){
      commonService.postServiceResponse(urlService.GET_FAVOURITES,{"username": sessionStorage.userName})
        .then(function(response){
          $("#showloader").css("display", "none");
            _.each(response,function(val,key){
              if(val.funName == $scope.functionality && val.dcName == $scope.dcName){
                $scope.isClicked = true;      
              }
            });
        },function(error){
          $("#showloader").css("display", "none");
          $scope.isClicked = false; 
        });
        //$scope.isClicked = ;
     }else{
      if(!$scope.isClicked){
        commonService.postServiceResponse(urlService.ADD_FAVOURITE,{"username": sessionStorage.userName,"dcName":$scope.dcName,"funName":$scope.functionality})
        .then(function(response){
          $("#showloader").css("display", "none");
          if(response.errorMessage){
            $scope.isFavouriteAdded= false; 
            $scope.isClicked = false;      
            $scope.$broadcast('showAlert',['']);
          }else{
            $scope.isClicked = true;      
            $scope.isClicked = !isClicked;
            $scope.isFavouriteAdded= true; 
            $scope.favouriteMsg = response.resMessage;
          $scope.$broadcast('ClickedOnFavourate',[$scope.dcName,$scope.functionality,$scope.isClicked]);
          }
            
        },function(error){
          $scope.isClicked = false;
          $("#showloader").css("display", "none");
        });
        $scope.isClicked = !isClicked;
      }else{
        $("#showloader").css("display", "none");
      }
     }
    
  };
   $scope.addToFavourate('load');
   // user favourites code end





  $scope.downloadExcel = function() {
	$scope.isFailed = false;
	$("#showloader").css("display", "block");
	var url;
	 url = urlService.ATE_SLOTTING_SJ_ZONE_DOWNLOAD;


$http({
		method: 'POST',
		url: url,
		data: {"jobcode":"ASR","getReleaseTasksLstDto":$scope.gridOptionsLower.data},
		headers: {				
			'Content-type': 'application/json', 'x-api-key': sessionStorage.apikey
		},
		responseType: 'arraybuffer'
	
	})
.success( function(data, status, headers) {

$("#showloader").css("display", "none");

	if(data.byteLength == 55){
			$scope.isFailed = true;
			  $('#alert-box').modal('show');


			  }else if(data.byteLength == 98){
		$scope.isFailed = true;
		$scope.resmessage = "Error in Downloading Excel file";
		return;
	}else{
		
		var octetStreamMime = 'application/octet-stream';
		var success = false;

		// Get the headers
		headers = headers();
		var blob;
		// Get the filename from the x-filename header or default to "download.bin"
		var filename = headers['x-filename'] || 'Rleasedata.xlsx';

		// Determine the content type from the header or default to "application/octet-stream"
		var contentType = headers['content-type'] || octetStreamMime;

		try
		{
			// Try using msSaveBlob if supported
			console.log("Trying saveBlob method ...");
			 blob = new Blob([data], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
			if(navigator.msSaveBlob)
				navigator.msSaveBlob(blob, filename);
			else {
				// Try using other saveBlob implementations, if available
				var saveBlob = navigator.webkitSaveBlob || navigator.mozSaveBlob || navigator.saveBlob;
				if(saveBlob === undefined) throw "Not supported";
				saveBlob(blob, filename);
			}
			console.log("saveBlob succeeded");
			success = true;
		} catch(ex)
		{
			console.log("saveBlob method failed with the following exception:");
			console.log(ex);
		}

		if(!success)
		{
			// Get the blob url creator
			var urlCreator = window.URL || window.webkitURL || window.mozURL || window.msURL;
			if(urlCreator)
			{
				// Try to use a download link
				var link = document.createElement('a');
				if('download' in link)
				{
					// Try to simulate a click
					try
					{
						// Prepare a blob URL
						console.log("Trying download link method with simulated click ...");
						 blob = new Blob([data], { type: contentType });
						 url = urlCreator.createObjectURL(blob);
						link.setAttribute('href', url);

						// Set the download attribute (Supported in Chrome 14+ / Firefox 20+)
						link.setAttribute("download", filename);

						// Simulate clicking the download link
						var event = document.createEvent('MouseEvents');
						event.initMouseEvent('click', true, true, window, 1, 0, 0, 0, 0, false, false, false, false, 0, null);
						link.dispatchEvent(event);
						console.log("Download link method with simulated click succeeded");
						success = true;

					} catch(ex) {
						console.log("Download link method with simulated click failed with the following exception:");
						console.log(ex);
					}
				}

				if(!success)
				{
					// Fallback to window.location method
					try
					{
						// Prepare a blob URL
						// Use application/octet-stream when using window.location to force download
						console.log("Trying download link method with window.location ...");
						 blob = new Blob([data], { type: octetStreamMime });
						 url = urlCreator.createObjectURL(blob);
						window.location = url;
						console.log("Download link method with window.location succeeded");
						success = true;
					} catch(ex) {
						console.log("Download link method with window.location failed with the following exception:");
						console.log(ex);
					}
				}

			}
		}

		if(!success)
		{
			// Fallback to window.open method
			console.log("No methods worked for saving the arraybuffer, using last resort window.open");
			window.open(rowData.pathName, '_blank', '');
		}
	}
})
.error(function(data, status, config) {

	console.log("Request failed with status: " + status);
$("#showloader").css("display", "none");
	// Optionally write the error out to scope
	//$scope.errorDetails = "Request failed with status: " + status;
$scope.isFailed = true;
		$scope.resmessage = "Error in downloading Excel File";

});
};






}]);