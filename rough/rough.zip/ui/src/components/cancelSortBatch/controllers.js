
var app = angular.module('CancelSortBatch', ['ngTouch', 'ui.grid.autoResize', 'ui.grid', 'ui.grid.selection', 'ui.grid.resizeColumns', 'ui.grid.pagination']);

app.controller('CancelSortBatchCtrl', ['$scope', '$http', '$q', '$interval', '$timeout', 'urlService', 'uiGridConstants', 'commonService', function ($scope, $http, $q, $interval, $timeout, urlService, uiGridConstants, commonService){
 
	$scope.isTable = false;
	$scope.disable = true;
	$scope.isUpdate = true;
	$scope.isSuccess = false;
	$scope.isClicked = false;
	$scope.isFailed = false;
	$scope.pagefunctionality = $scope.functionality;
	$scope.pagedc = $scope.dcName;
	$("#showloader").css("display", "none");

	$scope.inputValid = function () {
		$scope.isSuccess = false;
		$scope.isFailed = false;
		if (($scope.batchnumber == '' || $scope.batchnumber == null || $scope.batchnumber == undefined || $scope.batchnumber == 32) &&( $scope.asnnumber == '' || $scope.asnnumber == null || $scope.asnnumber == undefined || $scope.asnnumber == 32)) {  
			$scope.disable = true;
		} else {
			$scope.disable = false;
		}
	};



		$scope.gridOptions = {
		paginationPageSizes: [10, 25, 50, 100],
		paginationPageSize: 10,
		useExternalPagination: true,
		enableColumnMenus: false,
		enableSorting: true,
		enableRowSelection: true,//we can remove it later no use  of this
		enableSelectAll: true,//we can remove it later no use  of this             
		enableCellEdit: false, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
		//enableCellEditOnFocus: true, // set any editable column to allow edit on focus
		enableColumnResizing: true,
		enableHorizontalScrollbar: true
	};

	$scope.gridOptions.onRegisterApi = function (gridApi) {
		$scope.gridApi = gridApi;

		gridApi.selection.on.rowSelectionChangedBatch($scope, function (rows) {
			$scope.isSuccess = false;
			$scope.isFailed = false;
			if ($scope.gridApi.selection.getSelectedRows().length == 0) {
				$scope.isUpdate = true;
			} else {
				$scope.isUpdate = false;
			}
		});

		gridApi.selection.on.rowSelectionChanged($scope, function (row) {
			$scope.isSuccess = false;
			$scope.isFailed = false;
			if ($scope.gridApi.selection.getSelectedRows().length > 0) {
				$scope.isUpdate = false;
			} else {
				$scope.isUpdate = true;
			}
		});

		$scope.gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
			$scope.pageNo = newPage;
			$scope.pageSize = pageSize;
			$scope.getBarCodeData();
		});
	};


	$scope.getSortBatchData = function (chk) {
		$scope.isSuccess = false;
		$scope.isFailed = false;
		$scope.isTable = false;
		$scope.resmessage = "";
		$scope.pageNo = $scope.pageNo ? $scope.pageNo : 1;
		$scope.pageSize = $scope.pageSize ? $scope.pageSize : $scope.gridOptions.paginationPageSize;
		$scope.check = arguments[0];
	if($scope.batchnumber != '' && $scope.batchnumber != null && $scope.batchnumber != undefined){
		var str_array = ($scope.batchnumber.trim().replace(/\n/g, ",")).replace(/,+/g, ',').replace(/(^\s*,)|( ,\s*$)/g, '');
		var lastChar = str_array[str_array.length - 1];
		if (lastChar == ",") {
			newStr = str_array.substring(0, str_array.length - 1);
		} else {
			newStr = str_array;
		}
		if ((newStr.match(/,/g) || []).length > 99) {
			$scope.isFailed = true;
			$scope.resmessage = "Maximum 100 Batch Numbers are allowed";
			return false;
		}
		newStr = newStr.split(",");
		newStr = newStr.filter(function (str) {//used to remove the empty spaces(like empty value)
			str = str.trim();
			if (str) {
				return /\S/.test(str);
			}
		});
		newStr = newStr.map(function (el) {//used to clear the spaces of each array element
			return el.trim();
		});
	}else{newStr = "";
	var str_array ="";
	}
	if($scope.asnnumber != '' && $scope.asnnumber != null && $scope.asnnumber != undefined){
		var str_arra = ($scope.asnnumber.trim().replace(/\n/g, ",")).replace(/,+/g, ',').replace(/(^\s*,)|( ,\s*$)/g, '');
		var lastCha = str_arra[str_arra.length - 1];
		if (lastCha == ",") {
			newSt = str_arra.substring(0, str_arra.length - 1);
		} else {
			newSt = str_arra;
		}
		if ((newSt.match(/,/g) || []).length > 99) {
			$scope.isFailed = true;
			$scope.resmessage = "Maximum 100 ASN Numbers are allowed";
			return false;
		}
		newSt = newSt.split(",");
		newSt = newSt.filter(function (st) {//used to remove the empty spaces(like empty value)
			st = st.trim();
			if (st) {
				return /\S/.test(st);
			}
		});
		newSt = newSt.map(function (el) {//used to clear the spaces of each array element
			return el.trim();
		});		
	}else{newSt = "";
	//str_arra ="";
	}
		var payload = {
			"batchnumber": newStr,
			"asnnumber": newSt
		};

		$("#showloader").css("display", "block");
		var url = urlService.GET_SORT_DETAILS;
		url = url.replace('dName', $scope.pagedc);
		url = url.replace('uName', sessionStorage.userName);
		url = url.replace('pNumber', $scope.pageNo);
		url = url.replace('pSize', $scope.pageSize);
		url = url.replace('batchnumber', str_array);
		url = url.replace('asnnumber', str_arra);
		if($scope.check===0){
			url+='&isSearch=true';
		}
		var headers = { headers: { 'x-api-key': sessionStorage.apikey } };
		commonService.getServiceResponse(url, headers)
			.then(
			function (d) {
				if (d.pageItems) {
					if (d.pageItems.length > 0) {
						$("#showloader").css("display", "none");
						$scope.isTable = true;
						$scope.isUpdate = true;
						$scope.gridOptions.data = d.pageItems;
						$scope.gridOptions.totalItems = d.totalNoOfRecords;

						$scope.gridOptions.columnDefs = [
							{ name: 'batchNbr', displayName: 'Batch Number', enableCellEdit: false,sort: { direction: uiGridConstants.ASC, priority: 1 } },
							{ name: 'statCode', displayName: 'Stat Code', enableCellEdit: false, cellTooltip: true, headerTooltip: true},
							{ name: 'asnNbr', displayName: 'ASN Number', enableCellEdit: false, cellTooltip: true, headerTooltip: true },							
							{ name: 'createdDateTime', displayName: 'Created Date Time', enableCellEdit: false, cellTooltip: true, headerTooltip: true},
							{ name: 'modifiedDataTime', displayName: 'Modified Date Time', enableCellEdit: false, cellTooltip: true, headerTooltip: true},
							{ name: 'userId', displayName: 'User ID', enableCellEdit: false, cellTooltip: true, headerTooltip: true}
						];
					}
					if(d.pageItems.length === 0){
					$scope.isSuccess = true;
					$scope.isFailed = false;
					$("#showloader").css("display", "none");
					$("#showloader").css("display", "none");
					$scope.resmessage="No data available";
					
				}
					if ($scope.gridOptions.data > 10) {
						$scope.gridOptions.enableVerticalScrollbar = true;

					} else {
						$scope.gridOptions.enableVerticalScrollbar = false;
						$scope.gridOptions.enableHorizontalScrollbar = 1;
					}
				}else if (d.resMessage) {
					$scope.isSuccess = true;
					$scope.isUpdate = true;
					$scope.resmessage = d.resMessage;
					
				}else {
					$scope.isFailed = true;
					$scope.isUpdate = true;
					if($scope.check == 1 && d.errorMessage.indexOf("No data found") >= 0){
					$scope.isSuccess = true;
					$scope.isFailed = false;
					$scope.resmessage="Batch[s] cancelled successfully";
					} else{
					$scope.resmessage = d.errorMessage;
					}
					$("#showloader").css("display", "none");
				}
			},
			function (errResponse) {

				$scope.isFailed = true;
				$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
				$("#showloader").css("display", "none");
			}
			);
	};
	
	$scope.getSortBatchData();

	
	
		$scope.updateSortBatchDetails = function (args) {
			$("#showloader").css("display", "block");
		$scope.resmessage = "";
		$scope.isSuccess = false;
		$scope.isFailed = false;

		angular.forEach($scope.gridApi.selection.getSelectedRows(), function (data, index) {
			data.dcName = $scope.dcName;
			data.userName = sessionStorage.userName;

		});

		var req, service_url;
					service_url = urlService.CANCEL_SORT_DETAILS;
			  req = $http.put(service_url, $scope.gridApi.selection.getSelectedRows(), {
    			headers: {'x-api-key': sessionStorage.apikey}
			});
			req.success(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			if (data.errorMessage) {
				$scope.isFailed = true;
				$scope.resmessage = data.errorMessage;

			} else {
				$scope.getSortBatchData(1);
				$scope.isSuccess = true;
				$scope.resmessage = data.resMessage;

			}
		});
		req.error(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			$scope.isFailed = true;
			$scope.resmessage = "System failed. Please try again or contact WAALOS Support";

		});
	};
	
	
	
	
	//user favourites code starts
	$scope.addToFavourate = function (isClicked) {
		$("#showloader").css("display", "block");
		if (typeof isClicked !== "boolean") {
			commonService.postServiceResponse(urlService.GET_FAVOURITES, { "username": sessionStorage.userName })
				.then(function (response) {
					$("#showloader").css("display", "none");
					_.each(response, function (val, key) {
						if (val.funName == $scope.functionality && val.dcName == $scope.dcName) {
							$scope.isClicked = true;
						}
					});
				}, function (error) {
					$("#showloader").css("display", "none");
					$scope.isClicked = false;
				});
			//$scope.isClicked = ;
		} else {
			if (!$scope.isClicked) {
				commonService.postServiceResponse(urlService.ADD_FAVOURITE, { "username": sessionStorage.userName, "dcName": $scope.dcName, "funName": $scope.functionality })
					.then(function (response) {
						$("#showloader").css("display", "none");
						if (response.errorMessage) {
							$scope.isFavouriteAdded = false;
							$scope.isClicked = false;
							$scope.$broadcast('showAlert', ['']);
						} else {
							$scope.isClicked = true;
							$scope.isClicked = !isClicked;
							$scope.isFavouriteAdded = true;
							$scope.favouriteMsg = response.resMessage;
							$scope.$broadcast('ClickedOnFavourate', [$scope.dcName, $scope.functionality, $scope.isClicked]);
						}

					}, function (error) {
						$scope.isClicked = false;
						$("#showloader").css("display", "none");
					});
				$scope.isClicked = !isClicked;
			} else {
				$("#showloader").css("display", "none");
			}
		}

	};
	$scope.addToFavourate('load');
	//user favourites code ends
}]);
