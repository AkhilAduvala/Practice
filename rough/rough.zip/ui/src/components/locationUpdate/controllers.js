var app = angular.module('LocationUpdate', ['ngAnimate', 'ui.grid', 'ui.grid.selection', 'ui.grid.pagination', 'ui.grid.autoResize', 'ui.grid.exporter']);
app.controller('LocationUpdateController', ['$scope', '$http', '$q', '$interval', '$timeout', 'urlService', 'uiGridConstants', 'commonService', function ($scope, $http, $q, $interval, $timeout, urlService, uiGridConstants, commonService) {

  $scope.isSuccess = false;
  $scope.isFailed = false;
  $scope.disable = true;
  $scope.pagefunctionality = $scope.functionality;
  $scope.pagedc = $scope.dcName;
  $scope.isTablebarcode = false;
  $scope.isTablebarcodeByFilter = false;
  $scope.isEnable = true;
  $scope.isDisable = true;
  $scope.isDisableLoc = true;
  $scope.enabledisableFun = false;
  $scope.updatelocFun = false;


  /* Intial dropdown values */
  $scope.area = true;
  $scope.zone = true;
  $scope.workarea = true;
  $scope.aisle = true;
  $scope.bay = true;
  $scope.lvl = true;
  $scope.position = true;

  $("#showloader").css("display", "none");

  $scope.gridOptions = {
    enableColumnMenus: false,
    enableSorting: true,
    exporterMenuCsv: false,
    exporterMenuPdf: false,
    enableGridMenu: true,
    exporterExcelSheetName: 'Sheet1',
    exporterExcelFilename: 'Location_Barcode.xlsx',
    multiSelect: true,
    gridMenuShowHideColumns: false,
    exporterMenuVisibleData: false,
    enableRowSelection: false,//we can remove it later no use  of this
    enableSelectAll: false,//we can remove it later no use  of this             
    enableCellEdit: false, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
    enableCellEditOnFocus: true // set any editable column to allow edit on focus

  };


  $scope.gridOptions.onRegisterApi = function (gridApi) {
    //set gridApi on scope
    $scope.gridApi = gridApi;
    gridApi.selection.on.rowSelectionChanged($scope, function (row) {
      $scope.isSuccess = false;
      $scope.isFailed = false;
      if ($scope.gridApi.selection.getSelectedRows().length > 0) {
        $scope.isEnable = false;
        $scope.isDisable = false;
        $scope.isDisableLoc = false;
      } else {
        $scope.isEnable = true;
        $scope.isDisable = true;
        $scope.isDisableLoc = true;
      }
    });
  };

  $scope.gridOptionsLocByFillter = {
    paginationPageSizes: [15, 25, 50, 100, 300],
    paginationPageSize: 15,
    enableSorting: true,
    useExternalPagination: true,
    enableColumnMenus: false,
    exporterMenuCsv: false,
    exporterMenuPdf: false,
    enableGridMenu: true,
    exporterExcelSheetName: 'Sheet1',
    exporterExcelFilename: 'Location_Barcode.xlsx',
    multiSelect: true,
    gridMenuShowHideColumns: false,
    exporterMenuVisibleData: false,
    enableCellEdit: false, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
    enableCellEditOnFocus: true // set any editable column to allow edit on focus
  };

  $scope.gridOptionsLocByFillter.onRegisterApi = function (gridApi) {
    //set gridApi on scope
    $scope.gridApi = gridApi;
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $scope.gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
	if(isNaN(newPage)){
	newPage = 1;
	}
      $scope.pageNo = newPage;
      $scope.pageSize = pageSize;
      if ($scope.funtype == "enableDisable" && $scope.searchtype == "searchFilter" && $scope.pagedc == 'Scheinfeld-2') {
        $scope.getlocationsBarcodes();
      }
      if ($scope.funtype == "enableDisable" && $scope.searchtype == "searchFilter" && $scope.pagedc == 'Scheinfeld-1') {
        $scope.getlocationsDataSef1();
      }
      if ($scope.funtype == "update" && $scope.searchtype == "searchFilter" && $scope.pagedc == 'Scheinfeld-2') {
        $scope.getlocationsBarcodes();
      }
    });

    gridApi.selection.on.rowSelectionChangedBatch($scope, function (rows) {
      $scope.isSuccess = false;
      $scope.isFailed = false;
      if ($scope.gridApi.selection.getSelectedRows().length == 0) {
        $scope.isEnable = true;
        $scope.isDisable = true;
        $scope.isDisableLoc = true;
      } else {
        $scope.isEnable = false;
        $scope.isDisable = false;
        $scope.isDisableLoc = false;
      }
    });

    gridApi.selection.on.rowSelectionChanged($scope, function (row) {
      $scope.isSuccess = false;
      $scope.isFailed = false;
      if ($scope.gridApi.selection.getSelectedRows().length > 0) {
        $scope.isEnable = false;
        $scope.isDisable = false;
        $scope.isDisableLoc = false;
      } else {
        $scope.isEnable = true;
        $scope.isDisable = true;
        $scope.isDisableLoc = true;
      }
    });

  };

  // Disable update functionality for Scheinfeld-1
  if ($scope.pagedc == 'Scheinfeld-1') {
    $scope.shf1 = false;
  } else {
    $scope.shf1 = true;
  }

  // Intial default values for functionality type and search type
  $scope.funtype = "enableDisable";
  $scope.searchtype = "searchBarcode";


  if ($scope.searchtype == "searchBarcode" && $scope.pagedc == 'Scheinfeld-2') {
    $scope.barcode = true;
    $scope.filters = false;
   
    $scope.filtersSef1 = false;
  }

  if ($scope.searchtype == "searchBarcode" && $scope.pagedc == 'Scheinfeld-1') {
    $scope.barcode = true;
    $scope.filters = false;
  
    $scope.filtersSef1 = false;
  }

  // get select funactionality name 
  $scope.getFuntionality = function (funtype) {
    $scope.funtype = funtype;

    if ($scope.funtype == "enableDisable" && $scope.searchtype == "searchBarcode" && $scope.pagedc == 'Scheinfeld-2') {
      $scope.barcode = true;
      $scope.filters = false;
    
      $scope.filtersSef1 = false;
      $scope.isTablebarcode = false;
      $scope.isTablebarcodeByFilter = false;
      $scope.enabledisableFun = false;
      $scope.updatelocFun = false;
      $scope.isSuccess = false;
      $scope.isFailed = false;
    }

    if ($scope.funtype == "enableDisable" && $scope.searchtype == "searchBarcode" && $scope.pagedc == 'Scheinfeld-1') {
      $scope.barcode = true;
      $scope.filters = false;
     
      $scope.filtersSef1 = false;
      $scope.isTablebarcode = false;
      $scope.isTablebarcodeByFilter = false;
      $scope.enabledisableFun = false;
      $scope.updatelocFun = false;
      $scope.isSuccess = false;
      $scope.isFailed = false;
    }

    if ($scope.funtype == "enableDisable" && $scope.searchtype == "searchFilter" && $scope.pagedc == 'Scheinfeld-2') {
      $scope.searchbyfilter();
    }

    if ($scope.funtype == "enableDisable" && $scope.searchtype == "searchFilter" && $scope.pagedc == 'Scheinfeld-1') {
      $scope.searchbyfilterSef1();
    }

    if ($scope.funtype == "update" && $scope.searchtype == "searchBarcode" && $scope.pagedc == 'Scheinfeld-2') {
      $scope.barcode = true;
      $scope.filters = false;
     
      $scope.filtersSef1 = false;
      $scope.isTablebarcode = false;
      $scope.isTablebarcodeByFilter = false;
      $scope.enabledisableFun = false;
      $scope.updatelocFun = false;
      $scope.isSuccess = false;
      $scope.isFailed = false;
    }

    if ($scope.funtype == "update" && $scope.searchtype == "searchFilter" && $scope.pagedc == 'Scheinfeld-2') {
      $scope.searchbyfilter();
    }
  };

  // get select search type
  $scope.setSearch = function (searchtype) {
    $scope.searchtype = searchtype;

    if ($scope.searchtype == "searchBarcode" && $scope.pagedc == 'Scheinfeld-2') {
      $scope.barcode = true;
      $scope.filters = false;
     
      $scope.filtersSef1 = false;
      $scope.isTablebarcode = false;
      $scope.isTablebarcodeByFilter = false;
      $scope.isSuccess = false;
      $scope.isFailed = false;
      $scope.enabledisableFun = false;
      $scope.updatelocFun = false;
    } else if ($scope.searchtype == "searchBarcode" && $scope.pagedc == 'Scheinfeld-1') {
      $scope.filters = false;
     
      $scope.filtersSef1 = false;
      $scope.barcode = true;
      $scope.isTablebarcode = false;
      $scope.isTablebarcodeByFilter = false;
      $scope.isSuccess = false;
      $scope.isFailed = false;
    } else if ($scope.searchtype == "searchFilter" && $scope.pagedc == 'Scheinfeld-1') {

      $scope.searchbyfilterSef1();
    } else if ($scope.searchtype == "searchFilter" && $scope.pagedc == 'Scheinfeld-2') {
      $scope.searchbyfilter();
    }
    if ($scope.funtype == "enableDisable" && $scope.searchtype == "searchBarcode" && $scope.pagedc == 'Scheinfeld-1') {
      $scope.barcode = true;
      $scope.filters = false;
    
      $scope.filtersSef1 = false;
      $scope.isTablebarcode = false;
      $scope.isTablebarcodeByFilter = false;
      $scope.enabledisableFun = false;
      $scope.updatelocFun = false;
      $scope.isSuccess = false;
      $scope.isFailed = false;
    }
  };


  $scope.searchbyfilterSef1 = function () {
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $("#showloader").css("display", "block");
    $scope.filters = false;
    $scope.enableDisableFilters= false;
    $scope.filtersSef1 = true;
    $scope.barcode = false;
    $scope.isTablebarcode = false;
    $scope.isTablebarcodeByFilter = false;
    $scope.enabledisableFun = false;
    $scope.updatelocFun = false;

    $scope.locationval= "";
    $scope.Area = "";
    $scope.zoneval= "";
    $scope.aisleval= "";
    $scope.bayval= "";
    $scope.lvlval= "";
    $scope.Position = "";

    $scope.LocType = "LOCCLASS";
    $scope.LocationClass = "";
    $scope.Area = "";
    $scope.Zone = "";
    $scope.Aisle = "";
    $scope.Bay = "";
    $scope.Level = "";
    $scope.Action = $scope.funtype;

    var url = urlService.LOCATION_UPDATE_GET_lOCATIONCLASS.replace('dName', $scope.pagedc);
    url = url.replace('uName', sessionStorage.userName);
    url = url.replace('LocType', $scope.LocType);
    url = url.replace('LocationClass', $scope.LocationClass);
    url = url.replace('Area', $scope.Area);
    url = url.replace('Zone', $scope.Zone);
    url = url.replace('Aisle', $scope.Aisle);
    url = url.replace('Bay', $scope.Bay);
    url = url.replace('Level', $scope.Level);
    url = url.replace('Action', $scope.Action);


    var res = $http.get(url, {
      headers: { 'x-api-key': sessionStorage.apikey }
    });

    res.success(function (data, status, headers, config) {
      $("#showloader").css("display", "none");
      if (data.errorMessage) {
        $scope.isFailed = true;
        $scope.resmessage = data.errorMessage;
      } else if (data.resMessage) {
        $scope.isSuccess = true;
        $scope.resmessage = data.resMessage;
      } else {
        $scope.filters = false;

        $scope.filtersSef1 = true;
        $scope.barcode = false;
        $scope.locationsSef1 = data;
        $scope.area = false;

        $scope.locationDataSef1 = "";
        $scope.areaDataSef1 = "";
        $scope.zoneDateSef1 = "";
        $scope.aisleDataSef1 = "";
        $scope.bayDataSef1 = "";
        $scope.lvlDataSef1 = "";


        $scope.areasSef1 = [];
        $scope.zonesSef1 = [];
        $scope.aislesSef1 = [];
        $scope.baysSef1 = [];
        $scope.levelsSef1 = [];

      }

    });
    res.error(function (data, status, headers, config) {
      $("#showloader").css("display", "none");
      $scope.isFailed = true;
      $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
    });
  };


  $scope.changeLocationClassSef1 = function () {
    $scope.locationval = $scope.locationDataSef1;
    $scope.isTablebarcodeByFilter = false;
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $scope.isEnable = true;
    $scope.isDisable = true;
    $scope.isDisableLoc = true;
    $scope.enabledisableFun = false;
    $scope.updatelocFun = false;

    $scope.Area = "";
    $scope.zoneval= "";
    $scope.aisleval= "";
    $scope.bayval= "";
    $scope.lvlval= "";
    $scope.Position = "";


    if ($scope.locationval != null) {
      $("#showloader").css("display", "block");
      $scope.LocType = "ZONE";
      $scope.LocationClass = $scope.locationval;
      $scope.Area = "";
      $scope.Zone = "";
      $scope.Aisle = "";
      $scope.Bay = "";
      $scope.Level = "";
      $scope.Action = $scope.funtype;

      var url = urlService.LOCATION_UPDATE_GET_lOCATIONCLASS.replace('dName', $scope.pagedc);
      url = url.replace('uName', sessionStorage.userName);
      url = url.replace('LocType', $scope.LocType);
      url = url.replace('LocationClass', $scope.LocationClass);
      url = url.replace('Area', $scope.Area);
      url = url.replace('Zone', $scope.Zone);
      url = url.replace('Aisle', $scope.Aisle);
      url = url.replace('Bay', $scope.Bay);
      url = url.replace('Level', $scope.Level);
      url = url.replace('Action', $scope.Action);

      var res = $http.get(url, {
        headers: { 'x-api-key': sessionStorage.apikey }
      });

      res.success(function (data, status, headers, config) {
        $("#showloader").css("display", "none");

        if (data.errorMessage) {
          $scope.isFailed = true;
          $scope.resmessage = data.errorMessage;
        } else if (data.resMessage) {
          $scope.isSuccess = true;
          $scope.resmessage = data.resMessage;
        } else {

          $scope.zoneDateSef1 = "";
          $scope.aisleDataSef1 = "";
          $scope.bayDataSef1 = "";
          $scope.lvlDataSef1 = "";

          $scope.zonesSef1 = data;
          $scope.aislesSef1 = [];
          $scope.baysSef1 = [];
          $scope.levelsSef1 = [];

        }

      });
      res.error(function (data, status, headers, config) {
        $("#showloader").css("display", "none");
        $scope.isFailed = true;
        $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
      });

    } else {
      $("#showloader").css("display", "none");
      $scope.areaDataSef1 = "";
      $scope.zoneDateSef1 = "";
      $scope.aisleDataSef1 = "";
      $scope.bayDataSef1 = "";
      $scope.lvlDataSef1 = "";
      $scope.positionDataSef1 = "";

      $scope.areasSef1 = [];
      $scope.zonesSef1 = [];
      $scope.aislesSef1 = [];
      $scope.baysSef1 = [];
      $scope.levelsSef1 = [];
      $scope.positionsSef1 = [];
    }
  };

  $scope.changeZoneSef1 = function () {
    $scope.zoneval = $scope.zoneDataSef1;
    $scope.isTablebarcodeByFilter = false;
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $scope.isEnable = true;
    $scope.isDisable = true;
    $scope.isDisableLoc = true;
    $scope.enabledisableFun = false;
    $scope.updatelocFun = false;
   
    $scope.aisleval= "";
    $scope.bayval= "";
    $scope.lvlval= "";
    $scope.Position = "";

    if ($scope.zoneval != null) {
      $("#showloader").css("display", "block");
      $scope.LocType = "AISLE";
      $scope.LocationClass = $scope.locationval;
      $scope.Area = "";
      $scope.Zone = $scope.zoneval;
      $scope.Aisle = "";
      $scope.Bay = "";
      $scope.Level = "";
      $scope.Action = $scope.funtype;

      var url = urlService.LOCATION_UPDATE_GET_lOCATIONCLASS.replace('dName', $scope.pagedc);
      url = url.replace('uName', sessionStorage.userName);
      url = url.replace('LocType', $scope.LocType);
      url = url.replace('LocationClass', $scope.LocationClass);
      url = url.replace('Area', $scope.Area);
      url = url.replace('Zone', $scope.Zone);
      url = url.replace('Aisle', $scope.Aisle);
      url = url.replace('Bay', $scope.Bay);
      url = url.replace('Level', $scope.Level);
      url = url.replace('Action', $scope.Action);

      var res = $http.get(url, {
        headers: { 'x-api-key': sessionStorage.apikey }
      });

      res.success(function (data, status, headers, config) {
        $("#showloader").css("display", "none");

        if (data.errorMessage) {
          $scope.isFailed = true;
          $scope.resmessage = data.errorMessage;
        } else if (data.resMessage) {
          $scope.isSuccess = true;
          $scope.resmessage = data.resMessage;
        } else {
          $scope.aisleDataSef1 = "";
          $scope.bayDataSef1 = "";
          $scope.lvlDataSef1 = "";

          $scope.aislesSef1 = data;
          $scope.baysSef1 = [];
          $scope.levelsSef1 = [];
        }

      });
      res.error(function (data, status, headers, config) {
        $("#showloader").css("display", "none");
        $scope.isFailed = true;
        $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
      });

    } else {
      $("#showloader").css("display", "none");
      $scope.aisleDataSef1 = "";
      $scope.bayDataSef1 = "";
      $scope.lvlDataSef1 = "";
      $scope.positionDataSef1 = "";

      $scope.aislesSef1 = [];
      $scope.baysSef1 = [];
      $scope.levelsSef1 = [];
      $scope.positionsSef1 = [];
    }
  };


  $scope.changeAisleSef1 = function () {
    $scope.aisleval = $scope.aisleDataSef1;
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $scope.isTablebarcodeByFilter = false;
    $scope.isEnable = true;
    $scope.isDisable = true;
    $scope.isDisableLoc = true;
    $scope.enabledisableFun = false;
    $scope.updatelocFun = false;

    $scope.bayval= "";
    $scope.lvlval= "";
    $scope.Position = "";

    if ($scope.aisleval != null) {
      $("#showloader").css("display", "block");
      $scope.LocType = "BAY";
      $scope.LocationClass = $scope.locationval;
      $scope.Area = "";
      $scope.Zone = $scope.zoneval;
      $scope.Aisle = $scope.aisleval;
      $scope.Bay = "";
      $scope.Level = "";
      $scope.Action = $scope.funtype;

      var url = urlService.LOCATION_UPDATE_GET_lOCATIONCLASS.replace('dName', $scope.pagedc);
      url = url.replace('uName', sessionStorage.userName);
      url = url.replace('LocType', $scope.LocType);
      url = url.replace('LocationClass', $scope.LocationClass);
      url = url.replace('Area', $scope.Area);
      url = url.replace('Zone', $scope.Zone);
      url = url.replace('Aisle', $scope.Aisle);
      url = url.replace('Bay', $scope.Bay);
      url = url.replace('Level', $scope.Level);
      url = url.replace('Action', $scope.Action);


      var res = $http.get(url, {
        headers: { 'x-api-key': sessionStorage.apikey }
      });

      res.success(function (data, status, headers, config) {
        $("#showloader").css("display", "none");

        if (data.errorMessage) {
          $scope.isFailed = true;
          $scope.resmessage = data.errorMessage;
        } else if (data.resMessage) {
          $scope.isSuccess = true;
          $scope.resmessage = data.resMessage;
        } else {
          $scope.bayDataSef1 = "";
          $scope.lvlDataSef1 = "";

          $scope.baysSef1 = data;
          $scope.levelsSef1 = [];

        }

      });
      res.error(function (data, status, headers, config) {
        $("#showloader").css("display", "none");
        $scope.isFailed = true;
        $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
      });

    } else {
      $("#showloader").css("display", "none");

      $scope.bayDataSef1 = "";
      $scope.lvlDataSef1 = "";
      $scope.positionDataSef1 = "";

      $scope.baysSef1 = [];
      $scope.levelsSef1 = [];
      $scope.positionsSef1 = [];
    }
  };



  $scope.changeBaySef1 = function () {
    $scope.bayval = $scope.bayDataSef1;
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $scope.isTablebarcodeByFilter = false;
    $scope.isEnable = true;
    $scope.isDisable = true;
    $scope.isDisableLoc = true;
    $scope.enabledisableFun = false;
    $scope.updatelocFun = false;
    
    $scope.lvlval= "";
    $scope.Position = "";

    if ($scope.bayval != null) {
      $("#showloader").css("display", "block");
      $scope.LocType = "LEVEL";
      $scope.LocationClass = $scope.locationval;
      $scope.Area = "";
      $scope.Zone = $scope.zoneval;
      $scope.Aisle = $scope.aisleval;
      $scope.Bay = $scope.bayval;
      $scope.Level = "";
      $scope.Action = $scope.funtype;

      var url = urlService.LOCATION_UPDATE_GET_lOCATIONCLASS.replace('dName', $scope.pagedc);
      url = url.replace('uName', sessionStorage.userName);
      url = url.replace('LocType', $scope.LocType);
      url = url.replace('LocationClass', $scope.LocationClass);
      url = url.replace('Area', $scope.Area);
      url = url.replace('Zone', $scope.Zone);
      url = url.replace('Aisle', $scope.Aisle);
      url = url.replace('Bay', $scope.Bay);
      url = url.replace('Level', $scope.Level);
      url = url.replace('Action', $scope.Action);


      var res = $http.get(url, {
        headers: { 'x-api-key': sessionStorage.apikey }
      });

      res.success(function (data, status, headers, config) {
        $("#showloader").css("display", "none");

        if (data.errorMessage) {
          $scope.isFailed = true;
          $scope.resmessage = data.errorMessage;
        } else if (data.resMessage) {
          $scope.isSuccess = true;
          $scope.resmessage = data.resMessage;
        } else {
          $scope.lvlDataSef1 = "";

          $scope.levelsSef1 = data;
        }

      });
      res.error(function (data, status, headers, config) {
        $("#showloader").css("display", "none");
        $scope.isFailed = true;
        $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
      });

    } else {
      $("#showloader").css("display", "none");
      $scope.lvlData = "";
      $scope.positionDataSef1 = "";

      $scope.levelsSef1 = [];
      $scope.positionsSef1 = [];
    }
  };

  $scope.changeLevelSef1 = function () {
  
    $scope.lvlval = $scope.lvlDataSef1;
    $scope.isTablebarcodeByFilter = false;
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $scope.isEnable = true;
    $scope.isDisable = true;
    $scope.isDisableLoc = true;
    $scope.enabledisableFun = false;
    $scope.updatelocFun = false;
  };

  $scope.getlocationsDataSef1 = function (val) {
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $scope.enabledisableFun = false;
    $scope.updatelocFun = false;
    $("#showloader").css("display", "block");
     if(val == 'clicked'){
	$scope.pageNo = 1;
	}else{
	$scope.pageNo = $scope.pageNo ? $scope.pageNo : 1;
	}
    $scope.pageSize = $scope.pageSize ? $scope.pageSize : $scope.gridOptionsLocByFillter.paginationPageSize;

    $scope.LocationClass = $scope.locationval;
    $scope.Area = "";
    $scope.Zone = $scope.zoneval;
    $scope.Aisle = $scope.aisleval;
    $scope.Bay = $scope.bayval;
    $scope.Level = $scope.lvlval;
    $scope.Position = "";
    $scope.Action = $scope.funtype;

    if ($scope.LocationClass) { $scope.LocationClass = $scope.locationval; } else { $scope.LocationClass = ""; }
    if ($scope.Area) { $scope.Area = $scope.areaval; } else { $scope.Area = ""; }
    if ($scope.Zone) { $scope.Zone = $scope.zoneval; } else { $scope.Zone = ""; }
    if ($scope.Aisle) { $scope.Aisle = $scope.aisleval; } else { $scope.Aisle = ""; }
    if ($scope.Bay) { $scope.Bay = $scope.bayval; } else { $scope.Bay = ""; }
    if ($scope.Level) { $scope.Level = $scope.lvlval; } else { $scope.Level = ""; }
    if ($scope.Position) { $scope.Position = $scope.positionval; } else { $scope.Position = ""; }

    var url = urlService.LOCATION_UPDATE_GET_FINAL_GRID.replace('dName', $scope.pagedc);
    url = url.replace('uName', sessionStorage.userName);
    url = url.replace('LocationClass', $scope.LocationClass);
    url = url.replace('Area', $scope.Area);
    url = url.replace('Zone', $scope.Zone);
    url = url.replace('Aisle', $scope.Aisle);
    url = url.replace('Bay', $scope.Bay);
    url = url.replace('Level', $scope.Level);
    url = url.replace('Action', $scope.Action);
    url = url.replace('Position', $scope.Position);
    url = url.replace('pNumber', $scope.pageNo);
    url = url.replace('pSize', $scope.pageSize);

    var res = $http.get(url, {
      headers: { 'x-api-key': sessionStorage.apikey }
    });

    res.success(function (data, status, headers, config) {
      $("#showloader").css("display", "none");

      if (data.errorMessage) {
        $scope.isFailed = true;
        $scope.resmessage = data.errorMessage;
      } else if (data.resMessage) {
        $scope.isSuccess = true;
        $scope.resmessage = data.resMessage;
      } else {
        $scope.gridOptionsLocByFillter.data = "";
        $scope.isTablebarcodeByFilter = true;
        $scope.updatelocFun = false;
        $scope.enabledisableFun = true;
        $scope.gridOptionsLocByFillter.columnDefs = [
          { name: 'locationBrcd', displayName: 'Location Barcode', enableCellEdit: false, cellTooltip: true, headerTooltip: true },
          { name: 'locClass', visible: false, displayName: 'Location Class', cellTooltip: true, headerTooltip: true, enableCellEdit: false },
          { name: 'area', visible: false, displayName: 'Area', cellTooltip: true, headerTooltip: true, enableCellEdit: false },
          { name: 'pickLocAssignZone', visible: false, displayName: 'Pick Location Assign Zone', cellTooltip: true, headerTooltip: true, enableCellEdit: false },
          { name: 'enabled', displayName: 'Enable Flag', cellTooltip: true, headerTooltip: true, enableCellEdit: false },
        ];

        $scope.gridOptionsLocByFillter.totalItems = data.totalNoOfRecords;
        $scope.gridOptionsLocByFillter.data = data.pageItems;

        if ($scope.gridOptionsLocByFillter.data.length > 10) {
          $scope.gridOptionsLocByFillter.enableVerticalScrollbar = true;
          $scope.gridOptionsLocByFillter.enableHorizontalScrollbar = 0;
        } else {
          $scope.gridOptionsLocByFillter.enableVerticalScrollbar = false;
          $scope.gridOptionsLocByFillter.enableHorizontalScrollbar = 0;
        }
      }
      if(val == "clicked"){$scope.gridOptionsLocByFillter.paginationCurrentPage  = 1;}
      setTimeout(function(){  $('.ui-grid-pager-control-input').attr( "disabled", true );  }, 2000);

    });
    res.error(function (data, status, headers, config) {
      $("#showloader").css("display", "none");
      $scope.isFailed = true;
      $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
    });
  };


  // Validation airticle number
  $scope.locationbarcodevalid = function () {
    $scope.isSuccess = false;
    $scope.isFailed = false;
    var reg = /^[0-9a-zA-Z\_ ]+$/;
    if ($scope.locationBarcode == undefined || $scope.locationBarcode == "" || $scope.locationBarcode.length < 3) {
      $scope.disable = true;
    } else if ($scope.locationBarcode == undefined || $scope.locationBarcode == 32 || !(reg.test($scope.locationBarcode))) {
      $scope.disable = true;
      $scope.isFailed = true;
      $scope.resmessage = "Please enter a valid data";
    } else {
      $scope.disable = false;
    }
  };


  // onenter Validation airticle number
  $scope.locationbarcodekeyup = function ($event) {
    var keyCode = $event.which || $event.keyCode;
    var reg = /^[0-9a-zA-Z\_ ]+$/;
    if($event.currentTarget.value.length > 3 && keyCode === 13 && $event.currentTarget.value != undefined && $event.currentTarget.value != "" &&  $event.currentTarget.value != 32 && (reg.test($event.currentTarget.value))){
      $scope.disable = false;
      $scope.getLocationsdata();
    }

    if(keyCode === 13){
    if($event.currentTarget.value == "" || $event.currentTarget.value.length < 3 || $event.currentTarget.value == undefined || $event.currentTarget.value == 32 || !(reg.test($event.currentTarget.value))){
       $scope.disable = true;
       $scope.isFailed = true;
       $scope.resmessage = "Please enter a valid data";
     }
    }
  };

  /* Search by location barcode */
  $scope.getLocationsdata = function () {
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $scope.isEnable = true;
    $scope.isDisable = true;
    var url = urlService.LOCATION_UPDATE_GET_LOCATIONBARCODE.replace('dName', $scope.pagedc);
    url = url.replace('uName', sessionStorage.userName);
    url = url.replace('locBarcode', $scope.locationBarcode);
    url = url.replace('Action', $scope.funtype);
    var res = $http.get(url, {
      headers: { 'x-api-key': sessionStorage.apikey }
    });

    // based on functionality type
    if ($scope.funtype == "update") {
      res.success(function (data, status, headers, config) {
        $("#showloader").css("display", "none");
        if (data.errorMessage) {
          $scope.isFailed = true;
          $scope.resmessage = data.errorMessage;
          $scope.isTablebarcode = false;
          $scope.isTablebarcodeByFilter = false;
          $scope.enabledisableFun = false;
          $scope.updatelocFun = false;
        } else if (data.resMessage) {
          $scope.isSuccess = true;
          $scope.resmessage = data.resMessage;
          $scope.isTablebarcode = false;
          $scope.isTablebarcodeByFilter = false;
          $scope.enabledisableFun = false;
          $scope.updatelocFun = false;
        } else {

          $scope.isTablebarcode = true;
          $scope.isTablebarcodeByFilter = false;
      
          $scope.isDisableLoc = true;
          $scope.enabledisableFun = false;
          $scope.updatelocFun = true;

          $scope.gridOptions.columnDefs = [
            { name: 'locationBrcd', displayName: 'Location Barcode', enableCellEdit: false, cellTooltip: true, headerTooltip: true },
            { name: 'pickLocAssignZone', displayName: 'Pick Location Assign Zone', cellTooltip: true, headerTooltip: true, enableCellEdit: false },
           
          ];
          var finaldata = [data];
          $scope.gridOptions.data = finaldata;

          if ($scope.gridOptions.data.length > 10) {
            $scope.gridOptions.enableVerticalScrollbar = true;
            $scope.gridOptions.enableHorizontalScrollbar = 0;
          } else {
            $scope.gridOptions.enableVerticalScrollbar = false;
            $scope.gridOptions.enableHorizontalScrollbar = 0;
          }
        }

      });
      res.error(function (data, status, headers, config) {
        $("#showloader").css("display", "none");
        $scope.isFailed = true;
        $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
      });
    } else {
      res.success(function (data, status, headers, config) {
        $("#showloader").css("display", "none");
        if (data.errorMessage) {
          $scope.isFailed = true;
          $scope.resmessage = data.errorMessage;
          $scope.isTablebarcode = false;
          $scope.isTablebarcodeByFilter = false;
          $scope.enabledisableFun = false;
          $scope.updatelocFun = false;
        } else if (data.resMessage) {
          $scope.isSuccess = true;
          $scope.resmessage = data.resMessage;
          $scope.isTablebarcode = false;
          $scope.isTablebarcodeByFilter = false;
          $scope.enabledisableFun = false;
          $scope.updatelocFun = false;
        } else {

          $scope.isTablebarcode = true;
          $scope.isTablebarcodeByFilter = false;
          $scope.enabledisableFun = true;
          $scope.updatelocFun = false;

          $scope.gridOptions.columnDefs = [
            { name: 'locationBrcd', displayName: 'Location Barcode', enableCellEdit: false, cellTooltip: true, headerTooltip: true },
            { name: 'enabled', displayName: 'Enable Flag', cellTooltip: true, headerTooltip: true, enableCellEdit: false },
          

          ];
          var finaldata = [data];
          $scope.gridOptions.data = finaldata;

          if ($scope.gridOptions.data.length > 10) {
            $scope.gridOptions.enableVerticalScrollbar = true;
            $scope.gridOptions.enableHorizontalScrollbar = 0;
          } else {
            $scope.gridOptions.enableVerticalScrollbar = false;
            $scope.gridOptions.enableHorizontalScrollbar = 0;
          }
        }

      });
      res.error(function (data, status, headers, config) {
        $("#showloader").css("display", "none");
        $scope.isFailed = true;
        $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
      });
    }


  };


  $scope.searchbyfilter = function () {
    $scope.isSuccess = false;
    $scope.isFailed = false;

    $("#showloader").css("display", "block");
    $scope.isTablebarcode = false;
    $scope.isTablebarcodeByFilter = false;
    $scope.enabledisableFun = false;
    $scope.updatelocFun = false;
    $scope.LocType = "LOCCLASS";
    $scope.LocationClass = "";
    $scope.Area = "";
    $scope.Zone = "";
    $scope.WorkArea = "";
    $scope.Aisle = "";
    $scope.Bay = "";
    $scope.Level = "";
    $scope.Action = $scope.funtype;

  $scope.locationval= "";
  $scope.areaval= "";
  $scope.zoneval= "";
  $scope.workareaval ="";
  $scope.aisleval= "";
  $scope.bayval= "";
  $scope.lvlval= "";
  $scope.positionval= "";

    var url = urlService.LOCATION_UPDATE_GET_lOCATIONCLASS.replace('dName', $scope.pagedc);
    url = url.replace('uName', sessionStorage.userName);
    url = url.replace('LocType', $scope.LocType);
    url = url.replace('LocationClass', $scope.LocationClass);
    url = url.replace('workarea', $scope.WorkArea);
    url = url.replace('Area', $scope.Area);
    url = url.replace('Zone', $scope.Zone);
    
    url = url.replace('Aisle', $scope.Aisle);
    url = url.replace('Bay', $scope.Bay);
    url = url.replace('Level', $scope.Level);
    url = url.replace('Action', $scope.Action);

    var res = $http.get(url, {
      headers: { 'x-api-key': sessionStorage.apikey }
    });

    res.success(function (data, status, headers, config) {
      $("#showloader").css("display", "none");
      if (data.errorMessage) {
        $scope.isFailed = true;
        $scope.resmessage = data.errorMessage;
      } else if (data.resMessage) {
        $scope.isSuccess = true;
        $scope.resmessage = data.resMessage;
   
      } else {
        $scope.filters = true;
        $scope.filtersSef1 = false;
        $scope.barcode = false;
        $scope.locations = data;
        $scope.area = false;

        $scope.locationData = "";
        $scope.areaData = "";
        $scope.zoneDate = "";
        $scope.WorkAreaData = "";
        $scope.aisleData = "";
        $scope.bayData = "";
        $scope.lvlData = "";
        $scope.positionData = "";

        $scope.areas = [];
        $scope.zones = [];
        $scope.workareas=[];
        $scope.aisles = [];
        $scope.bays = [];
        $scope.levels = [];
        $scope.positions = [];
      }

    });
    res.error(function (data, status, headers, config) {
      $("#showloader").css("display", "none");
      $scope.isFailed = true;
      $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
    });
  };



  $scope.changeLocationClassSef2 = function () {
    $scope.locationval = $scope.locationData;
    $scope.isTablebarcodeByFilter = false;
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $scope.isEnable = true;
    $scope.isDisable = true;
    $scope.isDisableLoc = true;
    $scope.enabledisableFun = false;
    $scope.updatelocFun = false;

  $scope.workareaval =""; 
  $scope.areaval= "";
  $scope.zoneval= "";
  $scope.aisleval= "";
  $scope.bayval= "";
  $scope.lvlval= "";
  $scope.positionval= "";

    if ($scope.locationval != null) {
      $("#showloader").css("display", "block");
      $scope.LocType = "WORKAREA";
      $scope.LocationClass = $scope.locationval;
      $scope.WorkArea = "";
      $scope.Area = "";
      $scope.Zone = "";
      $scope.Aisle = "";
      $scope.Bay = "";
      $scope.Level = "";
      $scope.Action = $scope.funtype;

      var url = urlService.LOCATION_UPDATE_GET_lOCATIONCLASS.replace('dName', $scope.pagedc);
      url = url.replace('uName', sessionStorage.userName);
      url = url.replace('LocType', $scope.LocType);
      url = url.replace('LocationClass', $scope.LocationClass);
      url = url.replace('workarea', $scope.WorkArea);
      url = url.replace('Area', $scope.Area);
      url = url.replace('Zone', $scope.Zone);
      url = url.replace('Aisle', $scope.Aisle);
      url = url.replace('Bay', $scope.Bay);
      url = url.replace('Level', $scope.Level);
      url = url.replace('Action', $scope.Action);

    $scope.LocationClass = $scope.locationval;
    

      var res = $http.get(url, {
        headers: { 'x-api-key': sessionStorage.apikey }
      });

      res.success(function (data, status, headers, config) {
        $("#showloader").css("display", "none");

        if (data.errorMessage) {
          $scope.isFailed = true;
          $scope.resmessage = data.errorMessage;
        } else if (data.resMessage) {
          $scope.isSuccess = true;
          $scope.resmessage = data.resMessage;
        } else {
          $scope.WorkAreaData = "";
          $scope.areaData = "";
          $scope.zoneDate = "";
          $scope.aisleData = "";
          $scope.bayData = "";
          $scope.lvlData = "";
          $scope.positionData = "";

          $scope.workareas=data;
          $scope.areas = [];
          $scope.zones = [];
          $scope.aisles = [];
          $scope.bays = [];
          $scope.levels = [];
          $scope.positions = [];
        }

      });
      res.error(function (data, status, headers, config) {
        $("#showloader").css("display", "none");
        $scope.isFailed = true;
        $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
      });

    } else {
      $("#showloader").css("display", "none");
      $scope.WorkAreaData = "";
      $scope.areaData = "";
      $scope.zoneDate = "";
      $scope.aisleData = "";
      $scope.bayData = "";
      $scope.lvlData = "";
      $scope.positionData = "";

      $scope.workareas=[];
      $scope.areas = [];
      $scope.zones = [];
      $scope.aisles = [];
      $scope.bays = [];
      $scope.levels = [];
      $scope.positions = [];
    }

  };


  $scope.changeWorkAreaSef2= function () {
    $scope.workareaval = $scope.WorkAreaData;
    $scope.isTablebarcodeByFilter = false;
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $scope.isEnable = true;
    $scope.isDisable = true;
    $scope.isDisableLoc = true;
    $scope.enabledisableFun = false;
    $scope.updatelocFun = false;
   
    $scope.areaval= "";
    $scope.zoneval= "";
    $scope.aisleval= "";
    $scope.bayval= "";
    $scope.lvlval= "";
    $scope.positionval= "";

    if ($scope.zoneval != null) {
      $("#showloader").css("display", "block");
      $scope.LocType = "AREA";
      $scope.LocationClass = $scope.locationval;
      $scope.WorkArea = $scope.workareaval;
      $scope.Area = "";
      $scope.Zone = "";
      $scope.Aisle = "";
      $scope.Bay = "";
      $scope.Level = "";
      $scope.Action = $scope.funtype;

      var url = urlService.LOCATION_UPDATE_GET_lOCATIONCLASS.replace('dName', $scope.pagedc);
      url = url.replace('uName', sessionStorage.userName);
      url = url.replace('LocType', $scope.LocType);
      url = url.replace('LocationClass', $scope.LocationClass);
      url = url.replace('workarea', $scope.WorkArea);
      url = url.replace('Area', $scope.Area);
      url = url.replace('Zone', $scope.Zone);
      url = url.replace('Aisle', $scope.Aisle);
      url = url.replace('Bay', $scope.Bay);
      url = url.replace('Level', $scope.Level);
      url = url.replace('Action', $scope.Action);


      var res = $http.get(url, {
        headers: { 'x-api-key': sessionStorage.apikey }
      });

      res.success(function (data, status, headers, config) {
        $("#showloader").css("display", "none");
        
        if (data.errorMessage) {
          $scope.isFailed = true;
          $scope.resmessage = data.errorMessage;
        } else if (data.resMessage) {
          $scope.isSuccess = true;
          $scope.resmessage = data.resMessage;
        } else {
         
          $scope.areaData = "";
          $scope.zoneDate = "";
          $scope.aisleData = "";
          $scope.bayData = "";
          $scope.lvlData = "";
          $scope.positionData = "";

         
          $scope.areas = data;
          $scope.zones = [];
          $scope.aisles = [];
          $scope.bays = [];
          $scope.levels = [];
          $scope.positions = [];
        }

      });
      res.error(function (data, status, headers, config) {
        $("#showloader").css("display", "none");
        $scope.isFailed = true;
        $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
      });

    } else {
      $("#showloader").css("display", "none");
     
      $scope.areaData = "";
      $scope.zoneDate = "";
      $scope.aisleData = "";
      $scope.bayData = "";
      $scope.lvlData = "";
      $scope.positionData = "";

      $scope.areas = [];
      $scope.zones = [];
      $scope.aisles = [];
      $scope.bays = [];
      $scope.levels = [];
      $scope.positions = [];
    }

  };


  $scope.changeAreaSef2 = function () {
    $scope.areaval = $scope.areaData;
    $scope.isTablebarcodeByFilter = false;
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $scope.isEnable = true;
    $scope.isDisable = true;
    $scope.isDisableLoc = true;
    $scope.enabledisableFun = false;
    $scope.updatelocFun = false;

    $scope.zoneval= "";
    $scope.aisleval= "";
    $scope.bayval= "";
    $scope.lvlval= "";
    $scope.positionval= "";

    if ($scope.areaval != null) {
      $("#showloader").css("display", "block");
      $scope.LocType = "ZONE";
      $scope.LocationClass = $scope.locationval;
      $scope.WorkArea = $scope.workareaval;
      $scope.Area = $scope.areaval;
      $scope.Zone = "";
      $scope.Aisle = "";
      $scope.Bay = "";
      $scope.Level = "";
      $scope.Action = $scope.funtype;

      var url = urlService.LOCATION_UPDATE_GET_lOCATIONCLASS.replace('dName', $scope.pagedc);
      url = url.replace('uName', sessionStorage.userName);
      url = url.replace('LocType', $scope.LocType);
      url = url.replace('LocationClass', $scope.LocationClass);
      url = url.replace('workarea', $scope.WorkArea);
      url = url.replace('Area', $scope.Area);
      url = url.replace('Zone', $scope.Zone);
      url = url.replace('Aisle', $scope.Aisle);
      url = url.replace('Bay', $scope.Bay);
      url = url.replace('Level', $scope.Level);
      url = url.replace('Action', $scope.Action);
      

      var res = $http.get(url, {
        headers: { 'x-api-key': sessionStorage.apikey }
      });

      res.success(function (data, status, headers, config) {
        $("#showloader").css("display", "none");

        if (data.errorMessage) {
          $scope.isFailed = true;
          $scope.resmessage = data.errorMessage;
        } else if (data.resMessage) {
          $scope.isSuccess = true;
          $scope.resmessage = data.resMessage;
        } else {
          $scope.zoneData = "";
          $scope.aisleData = "";
          $scope.bayData = "";
          $scope.lvlData = "";
          $scope.positionData = "";

          $scope.zones = data;
          $scope.aisles = [];
          $scope.bays = [];
          $scope.levels = [];
          $scope.positions = [];
        }

      });
      res.error(function (data, status, headers, config) {
        $("#showloader").css("display", "none");
        $scope.isFailed = true;
        $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
      });

    } else {
      $("#showloader").css("display", "none");
      $scope.zoneData = "";
      $scope.aisleData = "";
      $scope.bayData = "";
      $scope.lvlData = "";
      $scope.positionData = "";

      $scope.zones = [];
      $scope.aisles = [];
      $scope.bays = [];
      $scope.levels = [];
      $scope.positions = [];
    }
  };

  $scope.changeZoneSef2 = function () {
    $scope.zoneval = $scope.zoneData;
    $scope.isTablebarcodeByFilter = false;
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $scope.isEnable = true;
    $scope.isDisable = true;
    $scope.isDisableLoc = true;
    $scope.enabledisableFun = false;
    $scope.updatelocFun = false;

    $scope.aisleval= "";
    $scope.bayval= "";
    $scope.lvlval= "";
    $scope.positionval= "";

    if ($scope.zoneval != null) {
      $("#showloader").css("display", "block");
 
      $scope.LocType = "AISLE";
      $scope.LocationClass = $scope.locationval;
      $scope.WorkArea = $scope.workareaval;
      $scope.Area = $scope.areaval;
      $scope.Zone = $scope.zoneval;
      $scope.Aisle = "";
      $scope.Bay = "";
      $scope.Level = "";
      $scope.Action = $scope.funtype;

      var url = urlService.LOCATION_UPDATE_GET_lOCATIONCLASS.replace('dName', $scope.pagedc);
      url = url.replace('uName', sessionStorage.userName);
      url = url.replace('LocType', $scope.LocType);
      url = url.replace('LocationClass', $scope.LocationClass);
      url = url.replace('workarea', $scope.WorkArea);
      url = url.replace('Area', $scope.Area);
      url = url.replace('Zone', $scope.Zone);
      url = url.replace('Aisle', $scope.Aisle);
      url = url.replace('Bay', $scope.Bay);
      url = url.replace('Level', $scope.Level);
      url = url.replace('Action', $scope.Action);


      var res = $http.get(url, {
        headers: { 'x-api-key': sessionStorage.apikey }
      });

      res.success(function (data, status, headers, config) {
        $("#showloader").css("display", "none");
        
        if (data.errorMessage) {
          $scope.isFailed = true;
          $scope.resmessage = data.errorMessage;
        } else if (data.resMessage) {
          $scope.isSuccess = true;
          $scope.resmessage = data.resMessage;
        } else {
         
          $scope.aisleData = "";
          $scope.bayData = "";
          $scope.lvlData = "";
          $scope.positionData = "";
                  

          $scope.aisles = data;
          $scope.bays = [];
          $scope.levels = [];
          $scope.positions = [];
        }

      });
      res.error(function (data, status, headers, config) {
        $("#showloader").css("display", "none");
        $scope.isFailed = true;
        $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
      });

    } else {
      $("#showloader").css("display", "none");

      $scope.aisleData = "";
      $scope.bayData = "";
      $scope.lvlData = "";
      $scope.positionData = "";

      $scope.aisles = [];
      $scope.bays = [];
      $scope.levels = [];
      $scope.positions = [];
    }

  };






  $scope.changeAisleSef2 = function () {
    $scope.aisleval = $scope.aisleData;
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $scope.isTablebarcodeByFilter = false;
    $scope.isEnable = true;
    $scope.isDisable = true;
    $scope.isDisableLoc = true;
    $scope.enabledisableFun = false;
    $scope.updatelocFun = false;
    $scope.bayval= "";
    $scope.lvlval= "";
    $scope.positionval= "";

    if ($scope.aisleval != null) {
      $("#showloader").css("display", "block");
      $scope.LocType = "BAY";
      $scope.LocationClass = $scope.locationval;
      $scope.WorkArea = $scope.workareaval;  
      $scope.Area = $scope.areaval;
      $scope.Zone = $scope.zoneval;
      $scope.Aisle = $scope.aisleval;
      $scope.Bay = "";
      $scope.Level = "";
      $scope.Action = $scope.funtype;

      var url = urlService.LOCATION_UPDATE_GET_lOCATIONCLASS.replace('dName', $scope.pagedc);
      url = url.replace('uName', sessionStorage.userName);
      url = url.replace('LocType', $scope.LocType);
      url = url.replace('LocationClass', $scope.LocationClass);
      url = url.replace('workarea', $scope.WorkArea);
      url = url.replace('Area', $scope.Area);
      url = url.replace('Zone', $scope.Zone);
      url = url.replace('Aisle', $scope.Aisle);
      url = url.replace('Bay', $scope.Bay);
      url = url.replace('Level', $scope.Level);
      url = url.replace('Action', $scope.Action);


      var res = $http.get(url, {
        headers: { 'x-api-key': sessionStorage.apikey }
      });

      res.success(function (data, status, headers, config) {
        $("#showloader").css("display", "none");

        if (data.errorMessage) {
          $scope.isFailed = true;
          $scope.resmessage = data.errorMessage;
        } else if (data.resMessage) {
          $scope.isSuccess = true;
          $scope.resmessage = data.resMessage;
        } else {
          $scope.bayData = "";
          $scope.lvlData = "";
          $scope.positionData = "";

          $scope.bays = data;
          $scope.levels = [];
          $scope.positions = [];
        }

      });
      res.error(function (data, status, headers, config) {
        $("#showloader").css("display", "none");
        $scope.isFailed = true;
        $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
      });

    } else {
      $("#showloader").css("display", "none");

      $scope.bayData = "";
      $scope.lvlData = "";
      $scope.positionData = "";

      $scope.bays = [];
      $scope.levels = [];
      $scope.positions = [];
    }
  };

  $scope.changeBaySef2 = function () {
    $scope.bayval = $scope.bayData;
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $scope.isTablebarcodeByFilter = false;
    $scope.isEnable = true;
    $scope.isDisable = true;
    $scope.isDisableLoc = true;
    $scope.enabledisableFun = false;
    $scope.updatelocFun = false;
    $scope.lvlval= "";
    $scope.positionval= "";
    if ($scope.bayval != null) {
      $("#showloader").css("display", "block");
      $scope.LocType = "LEVEL";
      $scope.LocationClass = $scope.locationval;
      $scope.WorkArea = $scope.workareaval; 
      $scope.Area = $scope.areaval;
      $scope.Zone = $scope.zoneval;
      $scope.Aisle = $scope.aisleval;
      $scope.Bay = $scope.bayval;
      $scope.Level = "";
      $scope.Action = $scope.funtype;

      var url = urlService.LOCATION_UPDATE_GET_lOCATIONCLASS.replace('dName', $scope.pagedc);
      url = url.replace('uName', sessionStorage.userName);
      url = url.replace('LocType', $scope.LocType);
      url = url.replace('LocationClass', $scope.LocationClass);
      url = url.replace('workarea', $scope.WorkArea);
      url = url.replace('Area', $scope.Area);
      url = url.replace('Zone', $scope.Zone);
      url = url.replace('Aisle', $scope.Aisle);
      url = url.replace('Bay', $scope.Bay);
      url = url.replace('Level', $scope.Level);
      url = url.replace('Action', $scope.Action);


      var res = $http.get(url, {
        headers: { 'x-api-key': sessionStorage.apikey }
      });

      res.success(function (data, status, headers, config) {
        $("#showloader").css("display", "none");
        
        if (data.errorMessage) {
          $scope.isFailed = true;
          $scope.resmessage = data.errorMessage;
        } else if (data.resMessage) {
          $scope.isSuccess = true;
          $scope.resmessage = data.resMessage;
        } else {
          $scope.lvlData = "";
          $scope.positionData = "";

          $scope.levels = data;
          $scope.positions = [];
        }

      });
      res.error(function (data, status, headers, config) {
        $("#showloader").css("display", "none");
        $scope.isFailed = true;
        $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
      });

    } else {
      $("#showloader").css("display", "none");
      $scope.lvlData = "";
      $scope.positionData = "";

      $scope.levels = [];
      $scope.positions = [];
    }
  };

  $scope.changeLevelSef2 = function () {
    $scope.lvlval = $scope.lvlData;
    $scope.isTablebarcodeByFilter = false;
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $scope.isEnable = true;
    $scope.isDisable = true;
    $scope.isDisableLoc = true;
    $scope.enabledisableFun = false;
    $scope.updatelocFun = false;
    $scope.positionval= "";

    if ($scope.lvlval != null) {
      $("#showloader").css("display", "block");
      $scope.LocType = "POSITION";
      $scope.LocationClass = $scope.locationval;
      $scope.WorkArea = $scope.workareaval; 
      $scope.Area = $scope.areaval;
      $scope.Zone = $scope.zoneval;
      $scope.Aisle = $scope.aisleval;
      $scope.Bay = $scope.bayval;
      $scope.Level = $scope.lvlval;
      $scope.Action = $scope.funtype;

      var url = urlService.LOCATION_UPDATE_GET_lOCATIONCLASS.replace('dName', $scope.pagedc);
      url = url.replace('uName', sessionStorage.userName);
      url = url.replace('LocType', $scope.LocType);
      url = url.replace('LocationClass', $scope.LocationClass);
      url = url.replace('workarea', $scope.WorkArea);
      url = url.replace('Area', $scope.Area);
      url = url.replace('Zone', $scope.Zone);
      url = url.replace('Aisle', $scope.Aisle);
      url = url.replace('Bay', $scope.Bay);
      url = url.replace('Level', $scope.Level);
      url = url.replace('Action', $scope.Action);


      var res = $http.get(url, {
        headers: { 'x-api-key': sessionStorage.apikey }
      });

      res.success(function (data, status, headers, config) {
        $("#showloader").css("display", "none");
        
        if (data.errorMessage) {
          $scope.isFailed = true;
          $scope.resmessage = data.errorMessage;
        } else if (data.resMessage) {
          $scope.isSuccess = true;
          $scope.resmessage = data.resMessage;
        } else {
          $scope.positionData = "";
          $scope.positions = data;
        }

      });
      res.error(function (data, status, headers, config) {
        $("#showloader").css("display", "none");
        $scope.isFailed = true;
        $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
      });

    } else {
      $("#showloader").css("display", "none");
      $scope.positionData = "";
      $scope.positions = [];
    }

  };

  $scope.changePositionSef2 = function () {
    $scope.positionval = $scope.positionData;
    $scope.Position = $scope.positionval;
    $scope.isTablebarcodeByFilter = false;
    $scope.isEnable = true;
    $scope.isDisable = true;
    $scope.isDisableLoc = true;
    $scope.enabledisableFun = false;
    $scope.updatelocFun = false;
  };


  $scope.getlocationsBarcodes = function(val) {


    $scope.isSuccess = false;
    $scope.isFailed = false;
    $scope.enabledisableFun = false;
    $scope.updatelocFun = false;
    var res,url;

    $("#showloader").css("display", "block");
    if(val == 'clicked'){
	$scope.pageNo = 1;
	}else{
	$scope.pageNo = $scope.pageNo ? $scope.pageNo : 1;
	}
    
    $scope.pageSize = $scope.pageSize ? $scope.pageSize : $scope.gridOptionsLocByFillter.paginationPageSize;

    $scope.LocationClass = $scope.locationval;
    $scope.WorkArea = $scope.workareaval;
    $scope.Area = $scope.areaval;
    $scope.Zone = $scope.zoneval;
    $scope.Aisle = $scope.aisleval;
    $scope.Bay = $scope.bayval;
    $scope.Level = $scope.lvlval;
    $scope.Position = $scope.positionval;
    $scope.Action = $scope.funtype;

    if ($scope.LocationClass) { $scope.LocationClass = $scope.locationval; } else { $scope.LocationClass = ""; }
    if ($scope.WorkArea) { $scope.WorkArea= $scope.workareaval; } else { $scope.WorkArea= ""; }
    if ($scope.Area) { $scope.Area = $scope.areaval; } else { $scope.Area = ""; }
    if ($scope.Zone) { $scope.Zone = $scope.zoneval; } else { $scope.Zone = ""; }
    if ($scope.Aisle) { $scope.Aisle = $scope.aisleval; } else { $scope.Aisle = ""; }
    if ($scope.Bay) { $scope.Bay = $scope.bayval; } else { $scope.Bay = ""; }
    if ($scope.Level) { $scope.Level = $scope.lvlval; } else { $scope.Level = ""; }
    if ($scope.Position) { $scope.Position = $scope.positionval; } else { $scope.Position = ""; }

    if ($scope.Action == "update") {
       url = urlService.LOCATION_UPDATE_GET_FINAL_GRID.replace('dName', $scope.pagedc);
      url = url.replace('uName', sessionStorage.userName);
      url = url.replace('LocationClass', $scope.LocationClass);
      url = url.replace('workarea', $scope.WorkArea); 
      url = url.replace('Area', $scope.Area);
      url = url.replace('Zone', $scope.Zone);
      url = url.replace('Aisle', $scope.Aisle);
      url = url.replace('Bay', $scope.Bay);
      url = url.replace('Level', $scope.Level);
      url = url.replace('Action', $scope.Action);
      url = url.replace('Position', $scope.Position);
      url = url.replace('pNumber', $scope.pageNo);
      url = url.replace('pSize', $scope.pageSize);


       res = $http.get(url, {
        headers: { 'x-api-key': sessionStorage.apikey }
      });

      res.success(function (data, status, headers, config) {
        $("#showloader").css("display", "none");
        
        if (data.errorMessage) {
          $scope.isFailed = true;
          $scope.resmessage = data.errorMessage;
        } else if (data.resMessage) {
          $scope.isSuccess = true;
          $scope.resmessage = data.resMessage;
        } else {

          $scope.gridOptionsLocByFillter.data = "";
          $scope.isTablebarcodeByFilter = true;
          $scope.enabledisableFun = false;
          $scope.updatelocFun = true;
          $scope.gridOptionsLocByFillter.columnDefs = [
            { name: 'locationBrcd', displayName: 'Location Barcode', enableCellEdit: false, cellTooltip: true, headerTooltip: true },
            { name: 'locClass', visible: false, displayName: 'Location Class', cellTooltip: true, headerTooltip: true, enableCellEdit: false },
            { name: 'area', visible: false, displayName: 'Area', cellTooltip: true, headerTooltip: true, enableCellEdit: false },
            { name: 'pickLocAssignZone', displayName: 'Pick Location Assign Zone', cellTooltip: true, headerTooltip: true, enableCellEdit: false },
            { name: 'enabled', displayName: 'Enable Flag', visible: false, cellTooltip: true, headerTooltip: true, enableCellEdit: false },

          ];

          $scope.gridOptionsLocByFillter.totalItems = data.totalNoOfRecords;
          $scope.gridOptionsLocByFillter.data = data.pageItems;

          if ($scope.gridOptionsLocByFillter.data.length > 10) {
            $scope.gridOptionsLocByFillter.enableVerticalScrollbar = true;
            $scope.gridOptionsLocByFillter.enableHorizontalScrollbar = 0;
          } else {
            $scope.gridOptionsLocByFillter.enableVerticalScrollbar = false;
            $scope.gridOptionsLocByFillter.enableHorizontalScrollbar = 0;
          }
        }
	if(val == "clicked"){$scope.gridOptionsLocByFillter.paginationCurrentPage  = 1;}
	setTimeout(function(){  $('.ui-grid-pager-control-input').attr( "disabled", true );  }, 2000);

      });
      res.error(function (data, status, headers, config) {
        $("#showloader").css("display", "none");
        $scope.isFailed = true;
        $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
      });
    } else {
       url = urlService.LOCATION_UPDATE_GET_FINAL_GRID.replace('dName', $scope.pagedc);
      url = url.replace('uName', sessionStorage.userName);
      url = url.replace('LocationClass', $scope.LocationClass);
      url = url.replace('workarea', $scope.WorkArea);
      url = url.replace('Area', $scope.Area);
      url = url.replace('Zone', $scope.Zone);
      url = url.replace('Aisle', $scope.Aisle);
      url = url.replace('Bay', $scope.Bay);
      url = url.replace('Level', $scope.Level);
      url = url.replace('Action', $scope.Action);
      url = url.replace('Position', $scope.Position);
      url = url.replace('pNumber', $scope.pageNo);
      url = url.replace('pSize', $scope.pageSize);


       res = $http.get(url, {
        headers: { 'x-api-key': sessionStorage.apikey }
      });

      res.success(function (data, status, headers, config) {
        $("#showloader").css("display", "none");

        if (data.errorMessage) {
          $scope.isFailed = true;
          $scope.resmessage = data.errorMessage;
        } else if (data.resMessage) {
          $scope.isSuccess = true;
          $scope.resmessage = data.resMessage;
        } else {

          $scope.isTablebarcodeByFilter = true;
          $scope.updatelocFun = false;
          $scope.enabledisableFun = true;
          $scope.gridOptionsLocByFillter.columnDefs = [
            { name: 'locationBrcd', displayName: 'Location Barcode', enableCellEdit: false, cellTooltip: true, headerTooltip: true },
            { name: 'locClass', visible: false, displayName: 'Location Class', cellTooltip: true, headerTooltip: true, enableCellEdit: false },
            { name: 'area', visible: false, displayName: 'Area', cellTooltip: true, headerTooltip: true, enableCellEdit: false },
            { name: 'pickLocAssignZone', visible: false, displayName: 'Pick Location Assign Zone', cellTooltip: true, headerTooltip: true, enableCellEdit: false },
            { name: 'enabled', displayName: 'Enable Flag', cellTooltip: true, headerTooltip: true, enableCellEdit: false },

          ];

          $scope.gridOptionsLocByFillter.totalItems = data.totalNoOfRecords;
          $scope.gridOptionsLocByFillter.data = data.pageItems;

          if ($scope.gridOptionsLocByFillter.data.length > 10) {
            $scope.gridOptionsLocByFillter.enableVerticalScrollbar = true;
            $scope.gridOptionsLocByFillter.enableHorizontalScrollbar = 0;
          } else {
            $scope.gridOptionsLocByFillter.enableVerticalScrollbar = false;
            $scope.gridOptionsLocByFillter.enableHorizontalScrollbar = 0;
          }
        }
	if(val == "clicked"){$scope.gridOptionsLocByFillter.paginationCurrentPage  = 1;}
	setTimeout(function(){  $('.ui-grid-pager-control-input').attr( "disabled", true );  }, 2000);
      });
      res.error(function (data, status, headers, config) {
        $("#showloader").css("display", "none");
        $scope.isFailed = true;
        $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
      });
    }
  };

  //popup dropdown data
  $scope.pickLocationsDropDown = function () {
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $scope.WorkArea= $scope.workareaval;
    $("#showloader").css("display", "block");
    var url = urlService.UPDATE_LOCATIONS_GET_PICKLOCATIONS.replace('uName', sessionStorage.userName);
    url = url.replace('dName', $scope.pagedc);
    url = url.replace('workarea', $scope.WorkArea);
    var res = $http.get(url, {
      headers: { 'x-api-key': sessionStorage.apikey }
    });
    res.success(function (data, status, headers, config) {
      $("#showloader").css("display", "none");
      if (data.errorMessage) {
        $scope.isFailed = true;
        $scope.resmessage = data.errorMessage;
      } else if (data.resMessage) {
        $scope.isSuccess = true;
        $scope.resmessage = data.resMessage;
      } else {
        $("#pickLocUpdateModel").modal('show');
        $scope.pickloczones = data;
        $scope.pickLocationVal = data[0];
      }
    });

    res.error(function (data, status, headers, config) {
      $("#showloader").css("display", "none");
      $scope.isFailed = true;
      $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
    });
  };

  //Update pick locations ass zones
  $scope.locationSelectionUpdate = function (forceupdate) {
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $("#showloader").css("display", "block");

    var barcodes = [];
    var pickLocAssignZones = [];
    angular.forEach($scope.gridApi.selection.getSelectedRows(), function (data, index) {
      barcodes.push(data.locationBrcd);
      pickLocAssignZones.push(data.pickLocAssignZone);
    });
    var forceupdateboolen;
    if(forceupdate){
      forceupdateboolen = true;
    }else{
      forceupdateboolen = false;
    }

    var records = {
      "dcName": $scope.pagedc,
      "userName": sessionStorage.userName,
      "pickLocAssignZone": $scope.pickLocationVal,
      "locBrcdLst": barcodes,
      "pickLocAssignZoneLst":pickLocAssignZones,
      "forceUpdate": forceupdateboolen
      
    };

    var res = $http.put(urlService.UPDATE_LOCATIONS_PUT_LOCATIONBARCODE, records, {
      headers: { 'x-api-key': sessionStorage.apikey }
    });
    res.success(function (data, status, headers, config) {
      $("#showloader").css("display", "none");
      if (data.errorMessage) {
        $scope.isFailed = true;
        $scope.resmessage = data.errorMessage;
        $scope.isEnable = true;
        $scope.isDisable = true;

      } else if (data.resMessage) {
        $scope.isDisableLoc = true;
        $scope.isEnable = true;
        $scope.isDisable = true;
     
        if(data.resCode != "Success"){
          $('#pickLocProccedModel').modal('show');
        $scope.WarningMsg = data.resMessage;
        }else{
          if ($scope.searchtype == "searchFilter") {
            $scope.getlocationsBarcodes();
          } else {
            $scope.getLocationsdata();
          }
          $scope.isSuccess = true;
          $scope.resmessage = data.resMessage;
        }
       
      }
    });

    res.error(function (data, status, headers, config) {
      $("#showloader").css("display", "none");
      $scope.isFailed = true;
      $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
    });
  };


  //Enable Functionality

  $scope.enableFalg = function () {
    $scope.isSuccess = false;

    $scope.isFailed = false;
    $("#showloader").css("display", "block");

    if ($scope.pagedc == "Scheinfeld-2") {

      if ($scope.searchtype == "searchFilter") {
        var barcodes = [];

        angular.forEach($scope.gridApi.selection.getSelectedRows(), function (data, index) {

          barcodes.push(data.locationBrcd);

        });

        var records = {
          "dcName": $scope.pagedc,
          "userName": sessionStorage.userName,
          "action": "ENABLE",
		  "workArea":$scope.WorkArea,
          "area": $scope.Area,
          "locClass": $scope.LocationClass,
          "locBrcdLst": barcodes
        };
      } else {
        var barcodes = [];
        var locationClass;
        var areadata;
        angular.forEach($scope.gridApi.selection.getSelectedRows(), function (data, index) {

          locationClass = data.locClass;
		  workareadata=data.workArea;
          areadata = data.area;
          barcodes.push(data.locationBrcd);

        });

        var records = {
          "dcName": $scope.pagedc,
          "userName": sessionStorage.userName,
          "action": "ENABLE",
		  "workArea":workareadata,
          "area": areadata,
          "locClass": locationClass,
          "locBrcdLst": barcodes
        };
      }




      var res = $http.put(urlService.UPDATE_LOCATIONS_PUT_ENABLE_DISABLE, records, {
        headers: { 'x-api-key': sessionStorage.apikey }
      });
      res.success(function (data, status, headers, config) {
        $("#showloader").css("display", "none");
        if (data.errorMessage) {
          $scope.isFailed = true;
          $scope.resmessage = data.errorMessage;
          $scope.isDisableLoc = true;

        } else if (data.resMessage) {
          $scope.isDisableLoc = true;
          $scope.isEnable = true;
          $scope.isDisable = true;
          $scope.isDisableLoc = true;
          if ($scope.searchtype == "searchFilter") {
            $scope.getlocationsBarcodes();
          } else {
            $scope.getLocationsdata();
          }

          $scope.isSuccess = true;
          $scope.resmessage = data.resMessage;
        }
      });

      res.error(function (data, status, headers, config) {
        $("#showloader").css("display", "none");
        $scope.isFailed = true;
        $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
      });

    } else {
      if ($scope.searchtype == "searchFilter") {
        var barcodes = [];

        angular.forEach($scope.gridApi.selection.getSelectedRows(), function (data, index) {

          barcodes.push(data.locationBrcd);

        });

        var records = {
          "dcName": $scope.pagedc,
          "userName": sessionStorage.userName,
          "action": "ENABLE",
          "area": "",
          "locClass": $scope.LocationClass,
          "locBrcdLst": barcodes
        };
      } else {
        var barcodes = [];
        var locationClass;

        angular.forEach($scope.gridApi.selection.getSelectedRows(), function (data, index) {

          locationClass = data.locClass;
          barcodes.push(data.locationBrcd);

        });

        var records = {
          "dcName": $scope.pagedc,
          "userName": sessionStorage.userName,
          "action": "ENABLE",
          "area": "",
          "locClass": locationClass,
          "locBrcdLst": barcodes
        };
      }



      var res = $http.put(urlService.UPDATE_LOCATIONS_PUT_ENABLE_DISABLE, records, {
        headers: { 'x-api-key': sessionStorage.apikey }
      });
      res.success(function (data, status, headers, config) {
        $("#showloader").css("display", "none");
        if (data.errorMessage) {
          $scope.isFailed = true;
          $scope.resmessage = data.errorMessage;
          $scope.isDisableLoc = true;

        } else if (data.resMessage) {
          $scope.isDisableLoc = true;
          $scope.isEnable = true;
          $scope.isDisable = true;
          $scope.isDisableLoc = true;
          if ($scope.searchtype == "searchFilter") {
            $scope.getlocationsDataSef1();
          } else {
            $scope.getLocationsdata();
          }

          $scope.isSuccess = true;
          $scope.resmessage = data.resMessage;
        }
      });

      res.error(function (data, status, headers, config) {
        $("#showloader").css("display", "none");
        $scope.isFailed = true;
        $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
      });

    }
  };

  //Disable Functionality
  $scope.disableFalg = function () {
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $("#showloader").css("display", "block");
    if ($scope.pagedc == "Scheinfeld-2") {
      if ($scope.searchtype == "searchFilter") {
        var barcodes = [];

        angular.forEach($scope.gridApi.selection.getSelectedRows(), function (data, index) {

          barcodes.push(data.locationBrcd);

        });

        var records = {
          "dcName": $scope.pagedc,
          "userName": sessionStorage.userName,
          "action": "DISABLE",
		  "workArea":$scope.WorkArea,
          "area": "$scope.Area",
          "locClass": $scope.LocationClass,
          "locBrcdLst": barcodes
        };
      } else {
        var barcodes = [];
        var locationClass;
        var areadata;
        angular.forEach($scope.gridApi.selection.getSelectedRows(), function (data, index) {

          locationClass = data.locClass;
		  workareadata=data.workArea;
          areadata = data.area;
          barcodes.push(data.locationBrcd);

        });

        var records = {
          "dcName": $scope.pagedc,
          "userName": sessionStorage.userName,
          "action": "DISABLE",
		  "workArea":workareadata,
          "area": areadata,
          "locClass": locationClass,
          "locBrcdLst": barcodes
        };

      }


      var res = $http.put(urlService.UPDATE_LOCATIONS_PUT_ENABLE_DISABLE, records, {
        headers: { 'x-api-key': sessionStorage.apikey }
      });
      res.success(function (data, status, headers, config) {
        $("#showloader").css("display", "none");
        if (data.errorMessage) {
          $scope.isFailed = true;
          $scope.resmessage = data.errorMessage;
          $scope.isDisableLoc = true;

        } else if (data.resMessage) {

          $scope.isEnable = true;
          $scope.isDisable = true;
          $scope.isDisableLoc = true;
          if ($scope.searchtype == "searchFilter") {
            $scope.getlocationsBarcodes();
          } else {
            $scope.getLocationsdata();
          }

          $scope.isSuccess = true;
          $scope.resmessage = data.resMessage;
        }
      });

      res.error(function (data, status, headers, config) {
        $("#showloader").css("display", "none");
        $scope.isFailed = true;
        $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
      });
    } else {
      if ($scope.searchtype == "searchFilter") {
        var barcodes = [];

        angular.forEach($scope.gridApi.selection.getSelectedRows(), function (data, index) {

          barcodes.push(data.locationBrcd);

        });

        var records = {
          "dcName": $scope.pagedc,
          "userName": sessionStorage.userName,
          "action": "DISABLE",
          "area": "",
          "locClass": $scope.LocationClass,
          "locBrcdLst": barcodes
        };
      } else {
        var barcodes = [];
        var locationClass;

        angular.forEach($scope.gridApi.selection.getSelectedRows(), function (data, index) {
          locationClass = data.locClass;
          barcodes.push(data.locationBrcd);

        });

        var records = {
          "dcName": $scope.pagedc,
          "userName": sessionStorage.userName,
          "action": "DISABLE",
          "area": "",
          "locClass": locationClass,
          "locBrcdLst": barcodes
        };

      }


      var res = $http.put(urlService.UPDATE_LOCATIONS_PUT_ENABLE_DISABLE, records, {
        headers: { 'x-api-key': sessionStorage.apikey }
      });
      res.success(function (data, status, headers, config) {
        $("#showloader").css("display", "none");
        if (data.errorMessage) {
          $scope.isFailed = true;
          $scope.resmessage = data.errorMessage;
          $scope.isDisableLoc = true;

        } else if (data.resMessage) {

          $scope.isEnable = true;
          $scope.isDisable = true;
          $scope.isDisableLoc = true;
          if ($scope.searchtype == "searchFilter") {
            $scope.getlocationsDataSef1();
          } else {
            $scope.getLocationsdata();
          }

          $scope.isSuccess = true;
          $scope.resmessage = data.resMessage;
        }
      });

      res.error(function (data, status, headers, config) {
        $("#showloader").css("display", "none");
        $scope.isFailed = true;
        $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
      });
    }

  };




  $scope.downloadExcel = function() {
	$scope.isFailed = false;
	$("#showloader").css("display", "block");

	
    $scope.LocationClass = $scope.locationval;
    $scope.Area = $scope.areaval;
    $scope.Zone = $scope.zoneval;
    $scope.WorkArea= $scope.workareaval;
    $scope.Aisle = $scope.aisleval;
    $scope.Bay = $scope.bayval;
    $scope.Level = $scope.lvlval;
    $scope.Position = $scope.positionval;
    $scope.Action = $scope.funtype;

    if ($scope.LocationClass) { $scope.LocationClass = $scope.locationval; } else { $scope.LocationClass = ""; }
    if ($scope.Area) { $scope.Area = $scope.areaval; } else { $scope.Area = ""; }
    if ($scope.Zone) { $scope.Zone = $scope.zoneval; } else { $scope.Zone = ""; }
    if ($scope.WorkArea) { $scope.WorkArea= $scope.workareaval; } else { $scope.WorkArea= ""; }
    if ($scope.Aisle) { $scope.Aisle = $scope.aisleval; } else { $scope.Aisle = ""; }
    if ($scope.Bay) { $scope.Bay = $scope.bayval; } else { $scope.Bay = ""; }
    if ($scope.Level) { $scope.Level = $scope.lvlval; } else { $scope.Level = ""; }
    if ($scope.Position) { $scope.Position = $scope.positionval; } else { $scope.Position = ""; }
    var url;
    if ($scope.Action == "update") {
      url = urlService.LOCATION_UPDATE_DOWNLOAD_ERRORS.replace('dName', $scope.pagedc);
      url = url.replace('uName', sessionStorage.userName);
      url = url.replace('LocationClass', $scope.LocationClass);
      url = url.replace('Area', $scope.Area);
      url = url.replace('Zone', $scope.Zone);
 	if($scope.funtype == "update" && $scope.searchtype == "searchFilter"){
         url = url.replace('workarea', $scope.WorkArea);
	 }else{
	 url = url.replace('workarea', $scope.WorkArea);
         }
      url = url.replace('Aisle', $scope.Aisle);
      url = url.replace('Bay', $scope.Bay);
      url = url.replace('Level', $scope.Level);
      url = url.replace('Action', $scope.Action);
      url = url.replace('Position', $scope.Position);
      url = url.replace('jcodeId',"LUU");
} else {
       url = urlService.LOCATION_ENABLE_DISABLE_DOWNLOAD_ERRORS.replace('dName', $scope.pagedc);
      url = url.replace('uName', sessionStorage.userName);
      url = url.replace('LocationClass', $scope.LocationClass);
      url = url.replace('Area', $scope.Area);
      url = url.replace('Zone', $scope.Zone);
      if($scope.funtype == "update" && $scope.searchtype == "searchFilter"){
         url = url.replace('workarea', $scope.WorkArea);
	 }else{
	 url = url.replace('workarea', $scope.WorkArea);
         }
      url = url.replace('Aisle', $scope.Aisle);
      url = url.replace('Bay', $scope.Bay);
      url = url.replace('Level', $scope.Level);
      url = url.replace('Action', $scope.Action);
      url = url.replace('Position', $scope.Position);
      url = url.replace('jcodeId',"LUE");
}

$http({
		method: 'GET',
		url: url,
		headers: {				
			'Content-type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'x-api-key': sessionStorage.apikey
		},
		responseType: 'arraybuffer'
	})
.success( function(data, status, headers) {

$("#showloader").css("display", "none");

	if(data.byteLength == 55){
			$scope.isFailed = true;
			  $('#alert-box').modal('show');


			  }else if(data.byteLength == 98){
		$scope.isFailed = true;
		$scope.resmessage = "Error in Downloading Excel file";
		return;
	}else{
		
		var octetStreamMime = 'application/octet-stream';
		var success = false;

		// Get the headers
		headers = headers();
    var blob,filename;
		// Get the filename from the x-filename header or default to "download.bin"
                if ($scope.Action == "update") {
                   filename = headers['x-filename'] || 'Location_Barcode.xlsx';
                }
                else{
                   filename = headers['x-filename'] || 'Location_Barcode.xlsx';
                }
		

		// Determine the content type from the header or default to "application/octet-stream"
		var contentType = headers['content-type'] || octetStreamMime;

		try
		{
			// Try using msSaveBlob if supported
			console.log("Trying saveBlob method ...");
			 blob = new Blob([data], { type: contentType });
			if(navigator.msSaveBlob)
				navigator.msSaveBlob(blob, filename);
			else {
				// Try using other saveBlob implementations, if available
				var saveBlob = navigator.webkitSaveBlob || navigator.mozSaveBlob || navigator.saveBlob;
				if(saveBlob === undefined) throw "Not supported";
				saveBlob(blob, filename);
			}
			console.log("saveBlob succeeded");
			success = true;
		} catch(ex)
		{
			console.log("saveBlob method failed with the following exception:");
			console.log(ex);
		}

		if(!success)
		{
			// Get the blob url creator
			var urlCreator = window.URL || window.webkitURL || window.mozURL || window.msURL;
			if(urlCreator)
			{
				// Try to use a download link
				var link = document.createElement('a');
				if('download' in link)
				{
					// Try to simulate a click
					try
					{
						// Prepare a blob URL
						console.log("Trying download link method with simulated click ...");
						 blob = new Blob([data], { type: contentType });
						 url = urlCreator.createObjectURL(blob);
						link.setAttribute('href', url);

						// Set the download attribute (Supported in Chrome 14+ / Firefox 20+)
						link.setAttribute("download", filename);

						// Simulate clicking the download link
						var event = document.createEvent('MouseEvents');
						event.initMouseEvent('click', true, true, window, 1, 0, 0, 0, 0, false, false, false, false, 0, null);
						link.dispatchEvent(event);
						console.log("Download link method with simulated click succeeded");
						success = true;

					} catch(ex) {
						console.log("Download link method with simulated click failed with the following exception:");
						console.log(ex);
					}
				}

				if(!success)
				{
					// Fallback to window.location method
					try
					{
						// Prepare a blob URL
						// Use application/octet-stream when using window.location to force download
						console.log("Trying download link method with window.location ...");
						 blob = new Blob([data], { type: octetStreamMime });
						 url = urlCreator.createObjectURL(blob);
						window.location = url;
						console.log("Download link method with window.location succeeded");
						success = true;
					} catch(ex) {
						console.log("Download link method with window.location failed with the following exception:");
						console.log(ex);
					}
				}

			}
		}

		if(!success)
		{
			// Fallback to window.open method
			console.log("No methods worked for saving the arraybuffer, using last resort window.open");
			window.open(rowData.pathName, '_blank', '');
		}
	}
})
.error(function(data, status, config) {

	console.log("Request failed with status: " + status);
$("#showloader").css("display", "none");
	// Optionally write the error out to scope
	//$scope.errorDetails = "Request failed with status: " + status;
$scope.isFailed = true;
		$scope.resmessage = "Error in downloading Excel File";

});
};





  //user favourites code starts
  $scope.isClicked = false;
  $scope.addToFavourate = function (isClicked) {
    $("#showloader").css("display", "block");
    if (typeof isClicked !== "boolean") {
      commonService.postServiceResponse(urlService.GET_FAVOURITES, { "username": sessionStorage.userName })
        .then(function (response) {
          $("#showloader").css("display", "none");
          _.each(response, function (val, key) {
            if (val.funName == $scope.functionality && val.dcName == $scope.dcName) {
              $scope.isClicked = true;
            }
          });
        }, function (error) {
          $("#showloader").css("display", "none");
          $scope.isClicked = false;
        });
      //$scope.isClicked = ;
    } else {
      if (!$scope.isClicked) {
        commonService.postServiceResponse(urlService.ADD_FAVOURITE, { "username": sessionStorage.userName, "dcName": $scope.dcName, "funName": $scope.functionality })
          .then(function (response) {
            $("#showloader").css("display", "none");
            if (response.errorMessage) {
              $scope.isFavouriteAdded = false;
              $scope.isClicked = false;
              $scope.$broadcast('showAlert', ['']);
            } else {
              $scope.isClicked = true;
              $scope.isClicked = !isClicked;
              $scope.isFavouriteAdded = true;
              $scope.favouriteMsg = response.resMessage;
              $scope.$broadcast('ClickedOnFavourate', [$scope.dcName, $scope.functionality, $scope.isClicked]);
            }

          }, function (error) {
            $scope.isClicked = false;
            $("#showloader").css("display", "none");
          });
        $scope.isClicked = !isClicked;
      } else {
        $("#showloader").css("display", "none");
      }
    }

  };
  $scope.addToFavourate('load');
  //user favourites code ends
}]);


