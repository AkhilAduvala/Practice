var app = angular.module('HolidayExclusion', ['ngTouch', 'ngAnimate', 'ngSanitize', 'ui.bootstrap',  'ui.grid.autoResize', 'ui.grid', 'ui.grid.edit', 'ui.grid.selection', 'ui.grid.pagination', 'ui.grid.validate']);
app.controller('HolidayExclusionCtrl', ['$scope', '$http', '$q', '$templateCache', '$interval', 'uiGridValidateService', '$timeout','urlService','uiGridConstants','commonService', function ($scope, $http, $q, $templateCache, $interval, uiGridValidateService, $timeout,urlService,uiGridConstants,commonService) {

  $scope.isTable = false;
  $scope.disable = true;
  $scope.isupdate = true;
  $scope.isSuccess = false;
  $scope.isFailed = false;
  $scope.isFailedload = false;
  $scope.isRecordFound = false;
  $scope.isClicked = false;  
  $scope.pagefunctionality = $scope.functionality;
  $scope.pagedc = $scope.dcName;
  $("#showloader").css("display", "none");
  $scope.isFieldValidate = false;

  $scope.today = function () {
    $scope.dt = new Date();
  };
  $scope.today();

  $scope.clear = function () {
    $scope.dt = null;
  };

  $scope.inlineOptions = {
    customClass: getDayClass,
    minDate: new Date(),
    showWeeks: true
  };
  $scope.dateOptions = {
    formatYear: 'yy',
    startingDay: 1
  };


  $scope.open1 = function () {
    $scope.popup1.opened = true;
  };


  $scope.setDate = function (year, month, day) {
    $scope.dt = new Date(year, month, day);
  };

  $scope.formats = ['dd-MMMM-yyyy', 'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate'];
  $scope.format = $scope.formats[0];
  $scope.altInputFormats = ['M!/d!/yyyy'];

  $scope.popup1 = {
    opened: false
  };


  var tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  var afterTomorrow = new Date();
  afterTomorrow.setDate(tomorrow.getDate() + 1);
  $scope.events = [{
    date: tomorrow,
    status: 'full'
  }, {
    date: afterTomorrow,
    status: 'partially'
  }];

  function getDayClass(data) {
    var date = data.date,
      mode = data.mode;
    if (mode === 'day') {
      var dayToCheck = new Date(date).setHours(0, 0, 0, 0);

      for (var i = 0; i < $scope.events.length; i++) {
        var currentDay = new Date($scope.events[i].date).setHours(0, 0, 0, 0);

        if (dayToCheck === currentDay) {
          return $scope.events[i].status;
        }
      }
    }

    return '';
  }

  $scope.gridOptions = {
    paginationPageSizes: [15, 25, 50, 100],
    paginationPageSize: 15,
    useExternalPagination: true,
    enableSorting: true,
    enableColumnMenus: false,
    columnDefs: [
      { field: 'holidayName', displayName: 'Holiday Name', enableCellEdit: true, sort: { direction: uiGridConstants.ASC, priority: 1 },  cellTooltip: true, headerTooltip: true, validators: { required: true, minLength: 1, maxLength: 50 }, cellTemplate: 'ui-grid/cellTitleValidator' },
      { name: 'holidayDt', displayName: 'Holiday Date', enableCellEdit: false }
    ]
  };


  $scope.gridOptions.onRegisterApi = function (gridApi) {

    //set gridApi on scope
    $scope.gridApi = gridApi;

    $scope.gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
      $scope.pageNo =  newPage;
      $scope.pageSize = pageSize;
      $scope.getHolidaysData();
   });

    gridApi.selection.on.rowSelectionChangedBatch($scope, function (rows) {
      $scope.isSuccess = false;
      $scope.isFailed = false;
      if ($scope.gridApi.selection.getSelectedRows().length == 0) {
        $scope.isupdate = true;
      } else {
        $scope.isupdate = false;
      }

    });

    gridApi.selection.on.rowSelectionChanged($scope, function (row) {
      $scope.isSuccess = false;
      $scope.isFailed = false;
      if ($scope.gridApi.selection.getSelectedRows().length > 0) {
        $scope.isupdate = false;
      } else {
        $scope.isupdate = true;
      }
    });


    // Just disabling update button while entering data on row input control.
    gridApi.edit.on.beginCellEdit($scope, function (rowEntity, colDef) {
      $scope.isSuccess = false;
      $scope.isFailed = false;
      $scope.$apply(function () {
        $scope.isupdate = true;
      });
    });


    gridApi.edit.on.afterCellEdit($scope, function (rowEntity, colDef, newValue, oldValue) {
      //$scope.msg.lastCellEdited = 'edited row id:' + rowEntity.id + ' Column:' + colDef.name + ' newValue:' + newValue + ' oldValue:' + oldValue ;
      $scope.isSuccess = false;
      $scope.isFailed = false;
      $scope.isFailedload = false;
      $scope.isRecordFound = false;
      if (newValue != oldValue || newValue !== oldValue) {// To check old and new values same or not
        if (newValue == "") {
          //alert(colDef.name+" should not be Empty");

          //rowEntity[colDef.name] = oldValue;
          //  return;
        } else if (+(newValue) == oldValue) {

        } else {
          $scope.gridApi.selection.selectRow(rowEntity);
        }

      }


      $timeout(function () {
        var found = $('.ui-grid-cell-contents');
        if (found.hasClass('invalid')) {
          $scope.$apply(function () {

            $scope.isFieldValidate = true;
            $scope.isupdate = true;
          });
        } else if (found.hasClass('ui-grid-cell-contents-hidden')) {
          $scope.isupdate = true;

        } else if (newValue != oldValue || newValue !== oldValue) {
          $scope.$apply(function () {
            $scope.isFieldValidate = false;
            $scope.isupdate = false;
          });
        } else if ($scope.gridApi.selection.getSelectedRows().length !== 0) {
          $scope.$apply(function () {
            $scope.isupdate = false;
            $scope.isFieldValidate = false;
          });
        }

      }, 100);
      $scope.$apply();
    });
  };


  $scope.getHolidaysData = function () {
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $scope.isFailedload = false;
    $scope.isupdate = true;
    $scope.isRecordFound = false;
    $scope.resmessage = "";
    $("#showloader").css("display", "block");
    $scope.pageNo = $scope.pageNo ? $scope.pageNo : 1;
    $scope.pageSize = $scope.pageSize ? $scope.pageSize: $scope.gridOptions.paginationPageSize;
   /* var obj =
      {
        "dcName": $scope.pagedc,
        "userLoggedIn": sessionStorage.userName,
        "pageNumber": $scope.pageNo,
        "pageSize": $scope.pageSize
      };
     
    var res = $http.post(urlService.GET_HOLIDAYS_DATA, obj);*/

    var url = urlService.GET_HOLIDAYS_DATA.replace('dName',$scope.pagedc);
    url = url.replace('uName',sessionStorage.userName);
    url = url.replace('pNumber',$scope.pageNo);
    url = url.replace('pSize',$scope.pageSize);
    //var res = $http.get(url);
    var res = $http.get(url, {
    headers: {'x-api-key': sessionStorage.apikey}
    });
    res.success(function (data, status, headers, config) {
    
      $("#showloader").css("display", "none");
      
      if (data.errorMessage) {
        $scope.isFailedload = true;
        $scope.resmessage  = data.errorMessage;
      } else if (data.resMessage) {
        $scope.isTable = false;
        $scope.resmessage  = data.resMessage;

      }
      else {

        $scope.isTable = true;
        $scope.gridOptions.totalItems  = data.totalNoOfRecords;  
        $scope.gridOptions.data = data.pageItems;
        if ($scope.gridOptions.data > 10) {
          $scope.gridOptions.enableVerticalScrollbar = true;
        } else {
          $scope.gridOptions.enableVerticalScrollbar = false;
          $scope.gridOptions.enableHorizontalScrollbar = 0;

        }
      }
    });
    res.error(function (data, status, headers, config) {
      $("#showloader").css("display", "none");
      $scope.isFailed = true;
      $scope.resmessage = "System failed. Please try again or contact WAALOS Support";

    });
    setTimeout(function(){  $('.ui-grid-pager-control-input').attr( "disabled", true );  }, 2000);
  };
  $scope.add = function(){
    $scope.dt = "";
    $scope.holidayName = "";
  };
  $scope.getHolidaysData();

 
  $scope.addHoliday = function () {
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $scope.isFailedload = false;
    $scope.isupdate = true;
    $scope.isRecordFound = false;
    $scope.resmessage = "";
    $("#myModal").modal('hide');
    
    $("#showloader").css("display", "block");
    var date = $scope.dt.getFullYear() + '-' + ('0' + ($scope.dt.getMonth() + 1)).slice(-2) + '-' + ('0' + $scope.dt.getDate()).slice(-2);
    var obj =

      {
        "holidayName": $scope.holidayName,
        "holidayDt": date,
        "operateFlag": "",
        "dcName": $scope.pagedc,
        "userLoggedIn": sessionStorage.userName
      };
	
    //var res = $http.post(urlService.ADD_HOLIDAY, obj);
    var res = $http.post(urlService.ADD_HOLIDAY, obj, {
    headers: {'x-api-key': sessionStorage.apikey}
    });
    res.success(function (data, status, headers, config) {
      $("#showloader").css("display", "none");
      if (data.errorMessage) {
        $scope.isFailed = true;
        $scope.resmessage = data.errorMessage;

      } else if (data.resMessage) {
        $scope.getHolidaysData();
        $scope.isTable = false;
        $scope.isSuccess = true;
        $scope.resmessage = data.resMessage;

      }
      else {
        $scope.getHolidaysData();
        $scope.resmessage ="";
        $scope.isSuccess = true;
        $scope.resmessage = data.resMessage;

      }
    });
    res.error(function (data, status, headers, config) {
      $("#showloader").css("display", "none");
      $scope.isFailed = true;
      $scope.resmessage = "System failed. Please try again or contact WAALOS Support";

    });

  };

  $scope.update = function () {
    $scope.resmessage = "";
    $scope.isTable = false;
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $scope.isFailedload = false;
    $scope.isRecordFound = false;
    $scope.isupdate = true;
    $("#showloader").css("display", "block");
    var temp = [];
    angular.forEach($scope.gridApi.selection.getSelectedRows(), function (data, index) {
      var obj = {
        "holidayName": data.holidayName,
        "holidayDt": data.holidayDt,
        "operateFlag": "update",
        "dcName": $scope.pagedc,
        "userLoggedIn": sessionStorage.userName

      };
      temp.push(obj);
    });
    $scope.operation(temp);
  };

  $scope.delete = function () {
    $scope.resmessage = "";
    $scope.isTable = false;
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $scope.isFailedload = false;
    $scope.isRecordFound = false;
    $scope.isupdate = true;
    $("#deleteModal").modal('hide');
    $("#showloader").css("display", "block");
    var temp = [];
    angular.forEach($scope.gridApi.selection.getSelectedRows(), function (data, index) {
      var obj = {
        "holidayName": data.holidayName,
        "holidayDt": data.holidayDt,
        "operateFlag": "delete",
        "dcName": $scope.pagedc,
        "userLoggedIn": sessionStorage.userName
      };
      temp.push(obj);
    });

    $scope.operation(temp);
  };

  $scope.operation = function (temp, rowEntity) {
    $scope.resmessage = "";
    $scope.isTable = false;
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $scope.isFailedload = false;
    $scope.isupdate = true;
    $scope.isRecordFound = false;
    //var res = $http.put(urlService.MANAGE_HOLIDAYS, temp);
    var res = $http.put(urlService.MANAGE_HOLIDAYS, temp, {
    headers: {'x-api-key': sessionStorage.apikey}
    });
    res.success(function (data, status, headers, config) {
      $("#showloader").css("display", "none");
      if (data.errMessage) {
        $scope.isFailedload = true;
        $scope.resmessage = data.errMessage;

      } else {
        $scope.getHolidaysData();
        $scope.isSuccess = true;
        $scope.resmessage = data.resMessage;

      }
    });
    res.error(function (data, status, headers, config) {
      $("#showloader").css("display", "none");
      $scope.isFailed = true;
      $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
    });
  };
//user favourites code start

$scope.addToFavourate = function(isClicked){
  $("#showloader").css("display", "block");
   if(typeof isClicked !== "boolean"){
    commonService.postServiceResponse(urlService.GET_FAVOURITES,{"username": sessionStorage.userName})
      .then(function(response){
    $("#showloader").css("display", "none");
          _.each(response,function(val,key){
            if(val.funName == $scope.functionality && val.dcName == $scope.dcName){
              $scope.isClicked = true;      
            }
          });
      },function(error){
    $("#showloader").css("display", "none");
    $scope.isClicked = false;  
      });
      //$scope.isClicked = ;
   }else{
    if(!$scope.isClicked){
      commonService.postServiceResponse(urlService.ADD_FAVOURITE,{"username": sessionStorage.userName,"dcName":$scope.dcName,"funName":$scope.functionality})
      .then(function(response){
    $("#showloader").css("display", "none");
    if(response.errorMessage){
      $scope.isClicked = isClicked;
      $scope.isFavouriteAdded= false; 
     $scope.$broadcast('showAlert',['']);
    }else{
      $scope.isClicked = !isClicked;
      $scope.isFavouriteAdded= true; 
      $scope.favouriteMsg = response.resMessage;
      $scope.$broadcast('ClickedOnFavourate',[$scope.dcName,$scope.functionality,$scope.isClicked]);
    } 
      },function(error){
    $("#showloader").css("display", "none");
      });
      
    }
   }
  
};
 
$scope.addToFavourate('load');
//user favourites code ends

}]);

