var app = angular.module('UserGroupManage', ['ui.bootstrap','ngTouch', 'ui.grid.autoResize', 'ui.grid', 'ui.grid.edit', 'ui.grid.cellNav', 'ui.grid.selection', 'ui.grid.validate']);
app.controller('UserManageGroupRowEditCtrl', UserManageGroupRowEditCtrl);
app.service('UserGroupManageRowEditor', UserGroupManageRowEditor);
app.controller('UserGroupManageController', ['$scope', '$http', '$q', '$interval', '$timeout','urlService','UserGroupManageRowEditor','commonService', function ($scope, $http, $q, $interval, $timeout,urlService,UserGroupManageRowEditor,commonService) {
  $scope.isTable = false;
  $scope.disable = true;
  $scope.isUnlock = true;
  $scope.isSuccess = false;	
	$scope.isFailed = false;
 
	$scope.editRow = UserGroupManageRowEditor.editRow;
	$scope.addRow = UserGroupManageRowEditor.addRow;
  $scope.pagefunctionality = $scope.functionality;
	$scope.pagedc = $scope.dcName;
  $("#showloader").css("display", "none");


  $scope.gridOptions = {
    enableColumnMenus: false,
	enableHorizontalScrollbar: false,
	multiSelect:false,
    enableRowSelection: true,//we can remove it later no use  of this
    enableSelectAll: true,//we can remove it later no use  of this             
    enableCellEdit: false, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
    enableCellEditOnFocus: true, // set any editable column to allow edit on focus
	rowTemplate : "<div ng-dblclick=\"grid.appScope.editRow(grid, row)\" ng-repeat=\"(colRenderIndex, col) in colContainer.renderedColumns track by col.colDef.name\" class=\"ui-grid-cell\" ng-class=\"{ 'ui-grid-row-header-cell': col.isRowHeader }\" ui-grid-cell></div>"
  };

  $scope.gridOptions.onRegisterApi = function (gridApi) {
    //set gridApi on scope
    $scope.gridApi = gridApi;

    gridApi.selection.on.rowSelectionChangedBatch($scope, function (rows) {
      $scope.isSuccess = false;
      $scope.isFailed = false;
      if ($scope.gridApi.selection.getSelectedRows().length == 0) {
        $scope.isUnlock = true;
      } else {
        $scope.isUnlock = false;
    
      }


    });

    gridApi.selection.on.rowSelectionChanged($scope, function (row) {
			$scope.rowToDelete = row.entity.name;
			if($scope.rowToDelete === 'Administrator'){
				$scope.disable = true;
			}else if(row.isSelected){
				$scope.disable = false;
			}else{
				$scope.disable = true;
			}
      $scope.isSuccess = false;
      $scope.isFailed = false;
      if ($scope.gridApi.selection.getSelectedRows().length > 0) {
        $scope.isUnlock = false;
        
      } else {
        $scope.isUnlock = true;
       
      }
    });
		
		$scope.removeRow = function(){
			$("#showloader").css("display", "block");			 		 
			if($scope.rowToDelete !== 'Administrator'){
			var res = $http.post(urlService.DELETE_USER_GROUP_GRID_ROW,{"ugName": $scope.rowToDelete});
			res.success(function (data, status, headers, config) {
				$("#showloader").css("display", "none");
				if(data.errorMessage){
					$scope.isSuccess = false;
					$scope.isFailed = true;
					$scope.resmessage = data.errorMessage;
				}else if(data.resMessage){
					commonService.setData('addResMessage',data);
					//$scope.resmessage = data.resMessage;
					$scope.getPickCartData('delete');
				} 
				$scope.disable = true;
			});
		}
	}; 
 
  };
	
	jQuery('[data-toggle=offcanvas]').click(function () {

			if (jQuery('.sidebar-offcanvas').css('background-color') == 'rgb(255, 255, 255)') {

					jQuery('.list-group-item').attr('tabindex', '-1');

			} else {

					jQuery('.list-group-item').attr('tabindex', '');

			}

			if (jQuery("#toggling").attr('class') == "row row-offcanvas row-offcanvas-left") {
					jQuery("#toggling").addClass('row row-offcanvas row-offcanvas-left active');
					jQuery("#arrow-toggle").removeClass('arrow-toggle');
					jQuery('#arrow-toggle img').attr('src', 'img/expand.png');
					jQuery("#Form-elements").css("display", "none");
					jQuery("#back-selection").css("display", "block");
			} else {
					jQuery("#toggling").removeClass('active');
					jQuery("#arrow-toggle").addClass('arrow-toggle');
					jQuery('#arrow-toggle img').attr('src', 'img/collpase.png');
					jQuery("#Form-elements").css("display", "block");
					jQuery("#back-selection").css("display", "none");

			}



	});
	
  $scope.getPickCartData = function (callType,isSearched) {
		$scope.isSuccess = false;
		$scope.isFailed = false;
		
		$scope.gridOptions.data = '';
    $scope.resmessage = "";
    $scope.isTable = false;
    $scope.isUnlock = true;
    $scope.isFailedload = false;
    $scope.isRecordFound = false;
   

 var data = { username: 'test'};
 var ugName='';
  	if(!callType && isSearched){
			$scope.isTable = true;
			return;
		}else if(callType && isSearched){
			ugName =  callType;
			$scope.resmessage = "";
		}else if(!isSearched){
			ugName = 'Administrator';
		}
		var url  = isSearched ? 	urlService.SEARCH_UGS	: urlService.USER_GROUP_MGMT_DASHBOARD_DATA;
		$("#showloader").css("display", "block");
		var res = $http.post(url,{"ugName":ugName,"username": sessionStorage.userName});
		
	  res.success(function (data, status, headers, config) {
		
      $("#showloader").css("display", "none");
        if (data.errorMessage) {
			$scope.isFailed = true;
			$scope.isSuccess = false;
         
        $scope.resmessage = data.errorMessage;
      }else if(data.resMessage){
		$scope.isTable = false;
		$scope.isFailed = false;
		$scope.isSuccess = true;
        $scope.resmessage = data.resMessage;
      }
      else {
     
        $scope.isTable = true;
        $scope.isupdate = false;
        $scope.gridOptions.columnDefs = [
          {name: 'name', displayName: 'User Group(s)', enableCellEdit: false,cellTemplate: '<div class="ui-grid-cell-contents" style="margin-left:15px;">{{COL_FIELD}}</div>'},
			{ name: 'functionality', displayName: 'User Group Details', enableCellEdit: false,//uib-popover="{{COL_FIELD}}"
            cellTemplate: '<div class="ui-grid-cell-contents"><a class="test" style="margin-left: 5px;" ng-click=\"grid.appScope.editRow(grid, row)\"   popover-placement="bottom"  popover-trigger="focus" ><i class="fa fa-users" style="color:black;" aria-hidden="true"></i></a></div>' },
               ];
        $scope.gridOptions.cellEditableCondition = function ($scope) {
          //console.log($scope.row.entity);
          // put your enable-edit code here, using values from $scope.row.entity and/or $scope.col.colDef as you desire
          if ($scope.row.entity.editable == "Y") {
            return $scope.row.entity.editable;
          } // in this example, we'll only allow active rows to be edited
    
        }; 		
		var ugNames = [];
		 for (var i = 0; i < data.ugNames.length; i++) {  
				 ugNames.push({'name':data.ugNames[i]});
		}
		$scope.gridOptions.data = ugNames;				
        if ($scope.gridOptions.data > 10) {
          $scope.gridOptions.enableVerticalScrollbar = true;
        } else {
          $scope.gridOptions.enableVerticalScrollbar = false;
          $scope.gridOptions.enableHorizontalScrollbar = 0;

        }
      }
    });
    res.error(function (data, status, headers, config) {
      $("#showloader").css("display", "none");
      $scope.isFailedload = true;
		});
		if(callType && commonService.getData('addResMessage')){
			
		 if(commonService.getData('addResMessage').errorMessage){
			 $scope.isFailed = true;
			 $scope.isSuccess = false;
			 $scope.resmessage = commonService.getData('addResMessage').errorMessage;
		 }else if(commonService.getData('addResMessage').resMessage){
			 $scope.isFailed = false;
			 $scope.isSuccess = true;
			 $scope.resmessage = commonService.getData('addResMessage').resMessage;
		 }
		 if(isSearched){
			$scope.resmessage = '';
		 }
	 }
	};

	$scope.reset = function(){
		$scope.pickCartNbr=""; 
		$scope.getPickCartData();
	
	};


	commonService.setData('getPickCartData',$scope.getPickCartData);
	var newService = {
		"usrId":"",
		"userGroup":"",
		"usrFirstName":"",
		"usrLastName":"",
		"emailId":"",
		
	};
	var rowTmp = {};
	rowTmp.entity = newService;
	$scope.getPickCartData('','');
}]);



UserGroupManageRowEditor.$inject = [ '$http', '$rootScope', '$uibModal','commonService' ];
function UserGroupManageRowEditor($http, $rootScope, $uibModal,commonService) {
	var service = {};
	service.editRow = editRow;
	service.addRow = addRow;
	function addRow(grid, row) {
		$uibModal.open({
			templateUrl : 'components/userGroupManagement/views/service-add.html',
			controller : [ '$http', '$uibModalInstance', 'grid', 'row','urlService','commonService', UserManageGroupRowEditCtrl ],
			controllerAs : 'vm',
			windowClass: 'userFileWindow',
			resolve : {
				grid : function() {
					return grid;
				},
				row : function() {
					return row;
				}
			}
		}).closed.then(function(){
			if(commonService.getData('changedDone')){
				var getPickCartData = commonService.getData('getPickCartData');
				getPickCartData('addCall');
				commonService.setData('changedDone',false);
			}
		});
	} 
	function editRow(grid, row) {
		$("#showloader").css("display", "block");
		$uibModal.open({
			templateUrl : 'components/userGroupManagement/views/service-edit.html',
			controller : [ '$http', '$uibModalInstance', 'grid', 'row','urlService','commonService', UserManageGroupRowEditCtrl ],
			controllerAs : 'vm',
			windowClass: 'userFileWindow',
			resolve : {
				grid : function() {
					return grid;
				},
				row : function() {
					return row;
				}
			}
			
		}).closed.then(function(){
			if(commonService.getData('changedDone')){
				var getPickCartData = commonService.getData('getPickCartData');
				getPickCartData('editCall');
				commonService.setData('changedDone',false);
			}
		});
	}
	
	return service;
}
 
function UserManageGroupRowEditCtrl($http, $uibModalInstance, grid, row,urlService,commonService) {
	var vm = this;
	vm.DCS = [];
	vm.specifiedDCS = [];
	vm.allUserGroupDetails = [];
	vm.checkFunctionalities = [];
	vm.selectedUserGroupFunctions=[];
	vm.functionsToBeChecked = []; 
	vm.updatedDCS = [];
	commonService.setData('changedDone',false);
	vm.fnEnableCreateBtn = function(data){
		vm.isUserName = data ? false:true;
	};
	 
	
	if(row !== 'add'){
		vm.selectedUserGroup = row.entity.name;
		vm.res = $http.post(urlService.USER_GROUP_MGMT_DASHBOARD_DATA,{"ugName": vm.selectedUserGroup,"username": sessionStorage.userName});
			vm.res.success(function (data, status, headers, config) {
				$("#showloader").css("display", "none");
			vm.allUserGroupDetails = data.mappingData[0];
			
			_.each( data.mappingData[0], function( val, key ) {
				vm.DCS.push( key);
			});
			vm.res = $http.post(urlService.GET_USER_GROUP_DATA,{"username": sessionStorage.userName,"ugName": vm.selectedUserGroup});
			vm.res.success(function (data, status, headers, config) {
				
				var selectedUserGroup = row.entity.name;
			vm.selectedUserGroupFunctions = data[0][vm.selectedUserGroup];
			vm.selectedUserGroupDetails = Object.keys(data[0][vm.selectedUserGroup]);
		
			_.each( vm.DCS, function( Dval, Dkey ) {
						if(vm.selectedUserGroupDetails.indexOf(Dval)>-1){
							vm.updatedDCS.push({'name':Dval,'isChecked' : true});
						}else{
							vm.updatedDCS.push({'name':Dval,'isChecked' : false});
						}
				
			});
		
				var index = 0;
					_.each(	vm.allUserGroupDetails, function( val, key ) {
						vm.checkFunctionalities.push({'name':key,'functions':[]});
						var data = vm.selectedUserGroupFunctions[key];
					
						for(var i =0; i < val.length;i++){
							if(data  && data.indexOf(val[i])>-1){
								vm.checkFunctionalities[index]['functions'].push({'name':val[i],'isChecked':true});
							}else{
								vm.checkFunctionalities[index]['functions'].push({'name':val[i],'isChecked':false});
							}
						if(i === val.length-1){
								++index;
						}
						}
				});
				
			});
			
			});
	
			vm.getCheckedGrp = function(dcName,functionalities,dcIschecked,isdc){
			var i;
				if(isdc == ''){
					vm.specifiedDCS = [];	
									for( i  = 0 ; i< vm.checkFunctionalities.length;i++){
										
										if(vm.checkFunctionalities[i].name === dcName){
											vm.checkFunctionalities[i].functions[functionalities].isChecked = !dcIschecked;
												
											_.each(	vm.checkFunctionalities[i].functions, function( val, key ) {
											
												vm.specifiedDCS.push(val.isChecked);
											});
										}
										
									}
									vm.updatedDCS[vm.DCS.indexOf(dcName)]['isChecked'] = vm.specifiedDCS.indexOf(true)>-1 ? true : false; 
							}
				else{
					//vm.updatedDCS[vm.DCS.indexOf(dcName)]['isChecked'] = !dcIschecked;
					var filteredFunctionalities = vm.checkFunctionalities[functionalities];
					vm.updatedDCS[functionalities]['isChecked'] = !dcIschecked; 
					if(filteredFunctionalities.name == dcName){
						for( i  = 0 ; i< filteredFunctionalities.functions.length;i++){
							vm.checkFunctionalities[functionalities].functions[i].isChecked = !dcIschecked;
						}
				 }				
		}
	}
}else{
				 
				vm.res = $http.post(urlService.USER_GROUP_MGMT_DASHBOARD_DATA,{"ugName": 'Administrator',"username": sessionStorage.userName});
					vm.res.success(function (data, status, headers, config) {
					vm.allUserGroupDetails = data.mappingData[0];
							_.each( data.mappingData[0], function( val, key ) {
								vm.DCS.push( key);
							});
								_.each( vm.DCS, function( Dval, Dkey ) {
										vm.updatedDCS.push({'name':Dval,'isChecked' : false});
							});
						var index = 0;
						_.each(	vm.allUserGroupDetails, function( val, key ) {
							vm.checkFunctionalities.push({'name':key,'functions':[]});
							for(var i =0; i < val.length;i++){
									vm.checkFunctionalities[index]['functions'].push({'name':val[i],'isChecked':false});
								if(i === val.length-1){
										++index;
								}
							}
						});

					});


					vm.fnNewUserGroupDetails= function(dcName,functionalities,dcIschecked,isdc){
						var i;
							if(isdc == ''){
								vm.specifiedDCS = [];	
												for( i  = 0 ; i< vm.checkFunctionalities.length;i++){
													
													if(vm.checkFunctionalities[i].name === dcName){
														vm.checkFunctionalities[i].functions[functionalities].isChecked = !dcIschecked;
															
														_.each(	vm.checkFunctionalities[i].functions, function( val, key ) {
														
															vm.specifiedDCS.push(val.isChecked);
														});
													}
													
												}
												vm.updatedDCS[vm.DCS.indexOf(dcName)]['isChecked'] = vm.specifiedDCS.indexOf(true)>-1 ? true : false; 
										}
							else{
								//vm.updatedDCS[vm.DCS.indexOf(dcName)]['isChecked'] = !dcIschecked;
								var filteredFunctionalities = vm.checkFunctionalities[functionalities];
								vm.updatedDCS[functionalities]['isChecked'] = !dcIschecked; 
								if(filteredFunctionalities.name == dcName){
									for( i  = 0 ; i< filteredFunctionalities.functions.length;i++){
										vm.checkFunctionalities[functionalities].functions[i].isChecked = !dcIschecked;
									}
							 }				
					}
				};

}
		//function to add and update userGroup Management Roles
			vm.save = function(type){
				$("#showloader").css("display", "block");			 		 
				var payloadArray = [];
				var payLoad = {
					"ugName": vm.selectedUserGroup,
					"username": sessionStorage.userName,
					"mappingData" : {}
				};
				
				_.each(	vm.checkFunctionalities, function( value, keys ) {
				
					_.each(value.functions, function( val, key ) {
						if(val.isChecked){
							payloadArray.push(val.name);
						}
					});
					if(payloadArray.length>0){
						payLoad.mappingData[value.name] = payloadArray;
					}
					payloadArray=[];
				});
				var url = type === 'add' ? urlService.ADD_USER_GROUP_DATA : urlService.UPDATE_USER_GROUP_DATA;
				vm.res = $http.post(url,payLoad);
				vm.res.success(function (data, status, headers, config) {
					commonService.setData('addResMessage','');
					commonService.setData('changedDone',true);
					commonService.setData('addResMessage',data);
				 
					
					$("#showloader").css("display", "none");
					$uibModalInstance.close();			 		 
					var a = data;
				});
			};
			vm.fnChahgeIcon = function(bool){
				if($('#arrow'+bool).attr('class')== "fa fa-caret-right"){
					$('#arrow'+bool).addClass("fa-caret-down");
					$('#arrow'+bool).removeClass("fa-caret-right");
				}else{
					$('#arrow'+bool).addClass("fa-caret-right");
					$('#arrow'+bool).removeClass("fa-caret-down");
				}
				
				};

		 
}

