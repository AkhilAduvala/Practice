
var app = angular.module('DimensionChanger', ['ngAnimate', 'ui.grid', 'ui.grid.selection',  'ui.grid.pagination', 'ui.grid.edit']);

app.controller('DimensionChangerCtrl', ['$scope', '$http', '$q', '$interval', 'uiGridValidateService', '$timeout','urlService','uiGridConstants','commonService', function ($scope, $http, $q, $interval, uiGridValidateService, $timeout,urlService,uiGridConstants,commonService) {
  $scope.isTable = false;
  $scope.disable = true;
  $scope.isupdate = true;
  $scope.isSuccess = false;
  $scope.isFailed = false;
  $scope.isClicked = false;
  $scope.isFieldValidate = false; //show validation error message
  $scope.pagefunctionality = $scope.functionality;
	$scope.pagedc = $scope.dcName;
  $("#showloader").css("display", "none");

  $scope.skuNmubervalid = function () {
    $scope.isSuccess = false;
    $scope.isFailed = false;
    var reg = /^[0-9a-zA-Z\_ ]+$/;
    if ($scope.skuNmuber == '' || $scope.skuNmuber == null || $scope.skuNmuber == undefined || $scope.skuNmuber == 32 || !(reg.test($scope.skuNmuber))) {
      $scope.disable = true;
    } else {
      $scope.disable = false;
    }
  };

  $scope.gridOptions = {
    paginationPageSizes: [15, 25, 50, 100],
    paginationPageSize: 15,
    enableSorting: true,
    useExternalPagination: true,
    enableColumnMenus: false,
     enableHorizontalScrollbar: false,
    cellEditableCondition: function ($scope) {
      //console.log($scope.row.entity);
      // put your enable-edit code here, using values from $scope.row.entity and/or $scope.col.colDef as you desire
      if ($scope.row.entity.changeble == "Y") {
        return $scope.row.entity.changeble;
      } // in this example, we'll only allow active rows to be edited

    }

  };

  /* =Validator for the text checking only.*/
  $scope.gridOptions.onRegisterApi = function (gridApi) {
    //set gridApi on scope
    $scope.gridApi = gridApi;

    $scope.gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
      $scope.pageNo =  newPage;
      $scope.pageSize = pageSize;
      $scope.getDimensionData();
   });

    gridApi.selection.on.rowSelectionChangedBatch($scope, function (rows) {
      $scope.isSuccess = false;
      $scope.isFailed = false;
      if ($scope.gridApi.selection.getSelectedRows().length == 0) {
        $scope.isupdate = true;
      } else {
        $scope.isupdate = false;
        validateDataAndEnableUpdate();
      }
    });

    gridApi.selection.on.rowSelectionChanged($scope, function (row) {
      $scope.isSuccess = false;
      $scope.isFailed = false;
      if ($scope.gridApi.selection.getSelectedRows().length > 0) {
        $scope.isupdate = false;
        validateDataAndEnableUpdate();
      } else {
        $scope.isupdate = true;
        validateDataAndEnableUpdate();
      }
    });

    function validateDataAndEnableUpdate() {
      $timeout(function () {
        var found = $('.ui-grid-cell-contents');
        if (found.hasClass('invalid')) {
          $scope.$apply(function () {
            $scope.isFieldValidate = true;
            $scope.isupdate = true;
          });
        } else if ($scope.gridApi.selection.getSelectedRows().length === 0) {
          $scope.$apply(function () {
            $scope.isupdate = true;
          });
        } else {
          $scope.$apply(function () {
            $scope.isFieldValidate = false;
            $scope.isupdate = false;
          });
        }
      });
    }


    // Just disabling update button while entering data on row input control.
    gridApi.edit.on.beginCellEdit($scope, function (rowEntity, colDef) {
      $scope.isSuccess = false;
      $scope.isFailed = false;
      $scope.$apply(function () {
        $scope.isupdate = true;
      });
      
    });

    gridApi.edit.on.afterCellEdit($scope, function (rowEntity, colDef, newValue, oldValue) {
     //$scope.msg.lastCellEdited = 'edited row id:' + rowEntity.id + ' Column:' + colDef.name + ' newValue:' + newValue + ' oldValue:' + oldValue ;
      $scope.isSuccess = false;
      $scope.isFailed = false;
      $scope.isFailedload = false;
      if (newValue != oldValue || newValue !== oldValue) {// To check old and new values same or not
        if (newValue == "") {
          //alert(colDef.name+" should not be Empty");

          //rowEntity[colDef.name] = oldValue;
          //  return;
        } else if (+(newValue) == oldValue) {

        } else {
          $scope.gridApi.selection.selectRow(rowEntity);
        }
      }
   
      $timeout(function () {
        var found = $('.ui-grid-cell-contents');
        if (found.hasClass('invalid')) {
          $scope.$apply(function () {

            $scope.isFieldValidate = true;
            $scope.isupdate = true;
          });
        }else if(found.hasClass('ui-grid-cell-contents-hidden')){
          $scope.isupdate = true;
         
        } else if (newValue != oldValue || newValue !== oldValue) {
          $scope.$apply(function () {
            $scope.isFieldValidate = false;
            $scope.isupdate = false;
          });
        } else if($scope.gridApi.selection.getSelectedRows().length !== 0){
          $scope.$apply(function () {
           $scope.isupdate = false;
           $scope.isFieldValidate = false;
          });
        }

      }, 100);
      

      $scope.$apply();
    });

  };


  uiGridValidateService.setValidator('numberChecker',
    function (argument) {
      return function (newValue, oldValue, rowEntity, colDef) {
        if (!newValue) {
          return /^[0-9]{0,5}(\.[0-9]{1,2})?$/.test(oldValue);
        } else {
          if (!(/^[0-9]{0,5}(\.[0-9]{1,2})?$/.test(oldValue))) {
            $scope.isupdate = true;
            $scope.$apply(function () {
              $scope.gridOptions.enableRowSelection = false;
            });
          } else {
            $scope.isupdate = false;
            $scope.gridOptions.enableRowSelection = true;
          }
          return /^[0-9]{0,5}(\.[0-9]{1,2})?$/.test(oldValue);
        }
      };
    },
    function (argument) {
      return 'Only numbers are allowed and max 5 digits with 2 decimal values are only accepted';
    }
  );

  $scope.gridOptions.isRowSelectable = function (row) {
    if (row.entity.changeble == "N") {
      return false;
    } else {
      return true;
    }
  };

  $scope.getDimensionData = function () {

    $scope.resmessage = "";
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $scope.isFieldValidate = false;
    $("#showloader").css("display", "block");
    $scope.pageNo = $scope.pageNo ? $scope.pageNo : 1;
    $scope.pageSize = $scope.pageSize ? $scope.pageSize: $scope.gridOptions.paginationPageSize;
    
/*
    var postDetails = {
      "dcName": $scope.pagedc,
      "userName": sessionStorage.userName,
      "uiSkuNmbr": $scope.skuNmuber.trim(),
      "pageNumber": $scope.pageNo,
      "pageSize": $scope.pageSize
    };

    var res = $http.post(urlService.SEARCH_DIMENSIONS, postDetails);*/

    var url = urlService.SEARCH_DIMENSIONS.replace('dName',$scope.pagedc);
    url = url.replace('uName',sessionStorage.userName);
    url = url.replace('skuNumber',$scope.skuNmuber.trim());
    url = url.replace('pNumber',$scope.pageNo);
    url = url.replace('pSize',$scope.pageSize);
 
    //var res = $http.get(url);
    var res = $http.get(url, {
    headers: {'x-api-key': sessionStorage.apikey}
    });
	
    res.success(function (data, status, headers, config) {
      $("#showloader").css("display", "none");

      if (data.errorMessage) {
        $scope.isTable = false;
        $scope.isFailed = true;
        $scope.resmessage = data.errorMessage;
      }
      else if(data.resMessage){
        $scope.isTable = false;
        $scope.isSuccess = true;
        $scope.resmessage = data.resMessage;
      }
      else if(data.length === 0){
        $scope.isTable = false;
        $scope.isFailed = true;
        $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
      }
      else {
        $scope.isTable = true;
        $scope.isupdate = true;

        $scope.gridOptions.columnDefs = [
          { name: 'skuId', enableCellEdit: false, visible: false },
          { name: 'dspSku', displayName: 'SKU', cellTooltip: true, headerTooltip: true,enableCellEdit: false,sort: { direction: uiGridConstants.ASC, priority: 1 }  },
          { name: 'length', displayName: 'Length',cellTooltip: true, headerTooltip: true,enableCellEdit: true,  sort: { direction: uiGridConstants.ASC },validators: { required: true,  numberChecker: true }, cellTemplate: 'ui-grid/cellTitleValidator' },
          { name: 'width', displayName: 'Width', cellTooltip: true, headerTooltip: true,enableCellEdit: true,  sort: { direction: uiGridConstants.ASC },validators: { required: true, numberChecker: true }, cellTemplate: 'ui-grid/cellTitleValidator' },
          { name: 'height', displayName: 'Height', cellTooltip: true, headerTooltip: true,enableCellEdit: true, sort: { direction: uiGridConstants.ASC },validators: { required: true,  numberChecker: true }, cellTemplate: 'ui-grid/cellTitleValidator' },
          {
            name: 'changeble', displayName: 'Editable',cellTooltip: true, headerTooltip: true,sort: { direction: uiGridConstants.ASC }, enableCellEdit: false,cellClass: function (grid, row, col, rowRenderIndex, colRenderIndex) {
              if (grid.getCellValue(row, col) == "Y") {
                return 'green';
              }
              return 'blue';
            }
          }
        ];

        $scope.gridOptions.totalItems  = data.totalNoOfRecords;  
        $scope.gridOptions.data = data.pageItems;
        if ($scope.gridOptions.data > 10) {
          $scope.gridOptions.enableVerticalScrollbar = true;
        } else {
          $scope.gridOptions.enableVerticalScrollbar = false;
          $scope.gridOptions.enableHorizontalScrollbar = 0;
        }
         }
      
    });

    res.error(function (data, status, headers, config) {
      $("#showloader").css("display", "none");
      $scope.isFailed = true;
      $scope.resmessage = "System failed. Please try again or contact WAALOS Support";

    });
    $scope.disableinput();
    
  };

$scope.disableinput= function(){
  setTimeout(function(){  $('.ui-grid-pager-control-input').attr( "disabled", true );  }, 2000);

};

  $scope.updateRecord = function () {
    $scope.resmessage = "";
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $scope.isFailedload = false;
    $scope.isFieldValidate = false;
    $scope.isRecordFound = false;
    $("#showloader").css("display", "block");
    var postRecords = [];
    angular.forEach($scope.gridApi.selection.getSelectedRows(), function (data, index) {
      var records = {
        "skuId": data.skuId,
        "dspSku": data.dspSku,
        "length": data.length,
        "width":data.width,
        "height": data.height,
        "changeble": data.changeble,
        "uiSkuNmbr": data.uiSkuNmbr,
        "dcName": $scope.pagedc,
        "userName": sessionStorage.userName
      };
      postRecords.push(records);
    });

    //var res = $http.post(urlService.UPDATE_DIMENSIONS, postRecords);
    var res = $http.put(urlService.UPDATE_DIMENSIONS, postRecords, {
    headers: {'x-api-key': sessionStorage.apikey}
    });
    res.success(function (data, status, headers, config) {
      $("#showloader").css("display", "none");
      if (data.errorMessage) {
        $scope.isFailed = true;
        $scope.resmessage = data.errorMessage;
      } 
       else {
        $scope.getDimensionData();
        $('.ui-grid-pager-control-input').attr( "disabled", true );
        $scope.isSuccess = true;
        $scope.resmessage = data.resMessage;
      }
    });

    res.error(function (data, status, headers, config) {
      $("#showloader").css("display", "none");
      $scope.isFailed = true;
      $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
    });
  };
//user favourites code start
$scope.addToFavourate = function(isClicked){
  $("#showloader").css("display", "block");
   if(typeof isClicked !== "boolean"){
    commonService.postServiceResponse(urlService.GET_FAVOURITES,{"username": sessionStorage.userName})
      .then(function(response){
    $("#showloader").css("display", "none");
          _.each(response,function(val,key){
            if(val.funName == $scope.functionality && val.dcName == $scope.dcName){
              $scope.isClicked = true;      
            }
          });
      },function(error){
    $("#showloader").css("display", "none");
    $scope.isClicked = false;  
      });
      //$scope.isClicked = ;
   }else{
    if(!$scope.isClicked){
      commonService.postServiceResponse(urlService.ADD_FAVOURITE,{"username": sessionStorage.userName,"dcName":$scope.dcName,"funName":$scope.functionality})
      .then(function(response){
    $("#showloader").css("display", "none");
    if(response.errorMessage){
      $scope.isClicked = isClicked;
      $scope.isFavouriteAdded= false; 
     $scope.$broadcast('showAlert',['']);
    }else{
      $scope.isClicked = !isClicked;
      $scope.isFavouriteAdded= true; 
      $scope.favouriteMsg = response.resMessage;
      $scope.$broadcast('ClickedOnFavourate',[$scope.dcName,$scope.functionality,$scope.isClicked]);
    } 
      },function(error){
    $("#showloader").css("display", "none");
      });
      
    }
   }
  
};
 
$scope.addToFavourate('load');
//user favourites code ends
}]);

