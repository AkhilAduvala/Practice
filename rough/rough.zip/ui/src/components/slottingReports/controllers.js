var app = angular.module('SlottingReports', ['ui.bootstrap', 'ngTouch', 'ui.grid',  'ui.grid.pagination']);

app.controller('slottingReportsController', ['$http', '$q', '$interval', '$timeout', 'urlService', 'uiGridConstants','$scope','commonService', function ($http, $q, $interval, $timeout, urlService, uiGridConstants,$scope,commonService) {
	var sr = this;
	sr.isSuccess = false;
	sr.isFailed = false;
	sr.resmessage = "";
	sr.isEdit = true;
	sr.isClicked = false;
	sr.isEditdataSources = false;
	sr.pagefunctionality = $scope.functionality;
	sr.pagedc = $scope.dcName;
	$("#showloader").css("display", "block");
	 
	sr.gridOptions = {
		enableSorting: true,
		multiSelect: false,
		enableRowSelection: false,//we can remove it later no use  of this
		enableSelectAll: false,//we can remove it later no use  of this             
		enableCellEdit: false, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
		enableCellEditOnFocus: true // set any editable column to allow edit on focus
	};
 
	
	sr.gridOptions.onRegisterApi = function (gridApi) {
		//set gridApi on scope
		
		sr.gridApi = gridApi;
	};

	sr.dataSources = function (tabNumber) {
		$("#showloader").css("display", "block");
		sr.mainTab = true;
		sr.gridOptions.data = '';
		sr.isSuccess = false;
		sr.isFailed = false;
		var url = '';
		var fileName = '';

		switch (tabNumber) {
            case '0':
				url = urlService.PRE_SLOT_ZONE_USAGE;
				//fileName = "preSlotZoneUsage.xlsx"
                		break;
            case '1':
				url = urlService.MULTIPLE_ZONE_STYLES;
				//fileName = "multipleZonesStyles.xlsx"
				break;
			case '2':
				url = urlService.PIGEON_HOLE;
				//fileName = "pigeonHole.xlsx"
				break;
			case '3':
				url = urlService.WRONG_PRODUCT_IN_ZONE;
				//fileName = "wrongProductInZone.xlsx"
				break;
            default:

		}

		url = url.replace('dName',sr.pagedc);
		url = url.replace('uName',sessionStorage.userName);
		
	
		var res = $http.get(url, {
                headers: {'x-api-key': sessionStorage.apikey}

            });
	
		res.success(function (data, status, headers, config) {
		 
			$("#showloader").css("display", "block");

			if (data.errorMessage) {
				sr.isFailed = true;
				sr.resmessage = data.errorMessage;
				sr.isTable = false;
			} else if (data.resMessage) {
				sr.isSuccess = true;
				sr.resmessage = data.resMessage;
				sr.isTable = false;
			} else {
				
				switch (tabNumber) {
					case '0':
						data = data[0].preSlotZoneDtoList;
						break;
					default:
					data = data;
					break;
		
				}
			
				//sr.gridOptions.exporterExcelFilename = fileName;
				fileName = '';
				sr.gridOptions.columnDefs = [];
			var width;
				_.each(data, function (value, key) {
					var length =Object.keys(data[0]).length;
					if (sr.gridOptions.columnDefs.length != length) {
						for (var i = 0; i < Object.keys(value).length; i++) {

							//regular expression to provide spaces at camel case notation and capitalize first letter in the word
							var displayName = Object.keys(value)[i].replace(/\w\S*/g, function (txt) {
								return txt.charAt(0).toUpperCase() + txt.substr(1);
							}).replace(/\s/g, "").replace(/([A-Z])/g, ' $1').trim();
							 if(tabNumber =='0'){
								 width = displayName.length>21 ? 250 : 160;
							 }else{
								width = "*";
							 }

							sr.gridOptions.columnDefs.push({ name: Object.keys(value)[i], displayName: displayName, enableCellEdit: false,width:width });
						}
					}
					 
				});
					
					

					sr.isTable = true;
	
					sr.gridOptions.data = data;
					
     			if (sr.gridOptions.data > 10) {
					sr.gridOptions.enableVerticalScrollbar = true;
					sr.gridOptions.enableHorizontalScrollbar = 1;
				} else {
					sr.gridOptions.enableVerticalScrollbar = false;
					sr.gridOptions.enableHorizontalScrollbar = 1;
				}

			
			}
		
			$('.ui-grid-pager-control input').prop("disabled", true);
			$(document).on("click",".ui-grid-menu-button", function () {
				$timeout(function(){
					$('.fa-download').remove();
					$('#menuitem-7 button[type="button"]').prepend( '<i class="fa fa-download" aria-hidden="true" style="color: #c9c9c9;"></i>');
				});
				$timeout(function(){
					//console.clear();	
				},3000);
			 });
			$("#showloader").css("display", "none");
		
		});
		$(document).on('click','body',function(){
			$timeout(function(){
			//console.clear();
			},1000);
		});
		res.error(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			sr.isFailed = true;
			sr.resmessage = "System failed. Please try again or contact WAALOS Support";

		});
	};
sr.dataSources('0');
	
	

	//user favourites code starts
	sr.addToFavourate = function(isClicked){
		$("#showloader").css("display", "block");
		 if(typeof isClicked !== "boolean"){
		  commonService.postServiceResponse(urlService.GET_FAVOURITES,{"username": sessionStorage.userName})
			.then(function(response){

			  $("#showloader").css("display", "none");
				_.each(response,function(val,key){
				  if(val.funName == $scope.functionality && val.dcName == $scope.dcName){
					sr.isClicked = true;      
				  }
				});
			},function(error){
			  $("#showloader").css("display", "none");
			  sr.isClicked = false; 
			});
			//sr.isClicked = ;
		 }else{
		  if(!sr.isClicked){
			commonService.postServiceResponse(urlService.ADD_FAVOURITE,{"username": sessionStorage.userName,"dcName":$scope.dcName,"funName":$scope.functionality})
			.then(function(response){


			  $("#showloader").css("display", "none");
			  if(response.errorMessage){
				sr.isFavouriteAdded= false; 
				sr.isClicked = false;      
				$scope.$broadcast('showAlert',['']);
			  }else{
				sr.isClicked = true;      
				sr.isClicked = !isClicked;
				sr.isFavouriteAdded= true; 
				sr.favouriteMsg = response.resMessage;
			  $scope.$broadcast('ClickedOnFavourate',[$scope.dcName,$scope.functionality,sr.isClicked]);
			  }
				
			},function(error){
			  sr.isClicked = false;
			  $("#showloader").css("display", "none");
			});
			sr.isClicked = !isClicked;
		  }else{
			$("#showloader").css("display", "none");
		  }
		 }
		
	  };
	  sr.addToFavourate('load');
	  //user favourites code ends



	  $scope.downloadExcel = function(type) {
		sr.isFailed = false;
		$("#showloader").css("display", "block");
		var url;
		url = urlService.SLOTING_DOWNLOAD_EXCEL;
	
	
	$http({
			method: 'POST',
			url: url,
			data: {"jobcode":type,"getSRGenericDto":sr.gridOptions.data},
			headers: {				
				'Content-type': 'application/json', 'x-api-key': sessionStorage.apikey
			},
			responseType: 'arraybuffer'
		
		})
	.success( function(data, status, headers) {
	
	$("#showloader").css("display", "none");
	
		if(data.byteLength == 55){
			sr.isFailed = true;
				  $('#alert-box').modal('show');
	
	
				  }else if(data.byteLength == 98){
					sr.isFailed = true;
					sr.resmessage = "Error in Downloading Excel file";
			return;
		}else{
			
			var octetStreamMime = 'application/octet-stream';
			var success = false;
	
			// Get the headers
			headers = headers();
			var filename;
			var blob;
			// Get the filename from the x-filename header or default to "download.bin"
			if(type== 'PZU'){
				 filename = headers['x-filename'] || 'PRESLOT_ZONE_USAGE.xlsx';
				}else if(type== 'MZS'){
					 filename = headers['x-filename'] || 'MULTIPLE_ZONE_STYLES.xlsx';
				}else if(type== 'PH'){
					 filename = headers['x-filename'] || 'PIGEONHOLE.xlsx'; 
				}else if(type== 'WI'){
					 filename = headers['x-filename'] || 'WRONGPRODUCT_INZONE.xlsx';
				}	
			// Determine the content type from the header or default to "application/octet-stream"
			var contentType = headers['content-type'] || octetStreamMime;
	
			try
			{
				// Try using msSaveBlob if supported
				console.log("Trying saveBlob method ...");
				blob = new Blob([data], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
				if(navigator.msSaveBlob)
					navigator.msSaveBlob(blob, filename);
				else {
					// Try using other saveBlob implementations, if available
					var saveBlob = navigator.webkitSaveBlob || navigator.mozSaveBlob || navigator.saveBlob;
					if(saveBlob === undefined) throw "Not supported";
					saveBlob(blob, filename);
				}
				console.log("saveBlob succeeded");
				success = true;
			} catch(ex)
			{
				console.log("saveBlob method failed with the following exception:");
				console.log(ex);
			}
	
			if(!success)
			{
				// Get the blob url creator
				var urlCreator = window.URL || window.webkitURL || window.mozURL || window.msURL;
				if(urlCreator)
				{
					// Try to use a download link
					var link = document.createElement('a');
					if('download' in link)
					{
						// Try to simulate a click
						try
						{
							// Prepare a blob URL
							console.log("Trying download link method with simulated click ...");
							 blob = new Blob([data], { type: contentType });
							url = urlCreator.createObjectURL(blob);
							link.setAttribute('href', url);
	
							// Set the download attribute (Supported in Chrome 14+ / Firefox 20+)
							link.setAttribute("download", filename);
	
							// Simulate clicking the download link
							var event = document.createEvent('MouseEvents');
							event.initMouseEvent('click', true, true, window, 1, 0, 0, 0, 0, false, false, false, false, 0, null);
							link.dispatchEvent(event);
							console.log("Download link method with simulated click succeeded");
							success = true;
	
						} catch(ex) {
							console.log("Download link method with simulated click failed with the following exception:");
							console.log(ex);
						}
					}
	
					if(!success)
					{
						// Fallback to window.location method
						try
						{
							// Prepare a blob URL
							// Use application/octet-stream when using window.location to force download
							console.log("Trying download link method with window.location ...");
							blob = new Blob([data], { type: octetStreamMime });
							url = urlCreator.createObjectURL(blob);
							window.location = url;
							console.log("Download link method with window.location succeeded");
							success = true;
						} catch(ex) {
							console.log("Download link method with window.location failed with the following exception:");
							console.log(ex);
						}
					}
	
				}
			}
	
			if(!success)
			{
				// Fallback to window.open method
				console.log("No methods worked for saving the arraybuffer, using last resort window.open");
				window.open(rowData.pathName, '_blank', '');
			}
		}
	})
	.error(function(data, status, config) {
	
		console.log("Request failed with status: " + status);
	$("#showloader").css("display", "none");

		sr.isFailed = true;
		sr.resmessage = "Error in downloading Excel File";
	
	});
	};

}]);