angular.module('massUpdateLoader',['ui.grid', 'ui.grid.selection', 'ui.bootstrap','ui.grid.autoResize','ui.grid.edit' ])
.controller('massUpdateLoaderController',['commonService','$http','$rootScope','$scope','urlService',function(commonService,$http,$rootScope,$scope,urlService){
 var mul = this;
 mul.isClicked = false;
 mul.skuType=['Non-Conveyable','Non-Sortable','High-Value','Normal'];  
 mul.type="Non-Conveyable"; 
  mul.uploadTypes =[{
    article : "Article",
    selected : true,
    value : "",
  },{
    model : "Model",
    size : "Size",
    selected : false,
    value : ["",""],
  },{
    sku : "SKU",
    selected : false,
    value : ""
  }
];
mul.dcName=$scope.dcName;
mul.pagefunctionality = $scope.functionality;
mul.duplicateArray  = JSON.stringify(mul.uploadTypes);
mul.previouschecked = '';
mul.getSelectedData = function(selectedRow,index,internalArrayIndex){
  mul.previouschecked = index;
  mul.iArrayIndex = internalArrayIndex;
  mul.newStr = '';
  if(!selectedRow){
    for(var i=0;i<mul.uploadTypes.length;i++){
      mul.uploadTypes[i].selected = index == i ? true : false;
      if(i != index){
        mul.uploadTypes[i].value = typeof mul.uploadTypes[i].value === 'object' ?  ['',''] : ''; 
      }
    }

  }else{
     if(typeof mul.uploadTypes[index].value === 'object'){
      mul.newStr = mul.uploadTypes[index].value[mul.iArrayIndex].replace(/[a-zA-Z0-9-]/g, "");
      mul.uploadTypes[index].value[mul.iArrayIndex] = mul.newStr.length > 0 ?  mul.uploadTypes[index].value[mul.iArrayIndex].replace(mul.newStr,''):mul.uploadTypes[index].value[mul.iArrayIndex];
     }else{
      mul.newStr = mul.uploadTypes[index].value.replace(/[a-zA-Z0-9-]/g, "");
      mul.uploadTypes[index].value = mul.newStr.length > 0 ?  mul.uploadTypes[index].value.replace(mul.newStr,''):mul.uploadTypes[index].value;
     }
 } 
};

mul.fnEnableSubmitBtn = function(){
  mul.disablebutton = true;
  _.each(mul.uploadTypes,function(value,key){

    if(typeof value.value == 'object' && value.selected){
      mul.disablebutton  = value.value[0] == '' ? true : false;
      mul.disablebutton  = value.value[1] == '' ? true : false;
    }else if(typeof value.value == 'string' && value.selected){
      mul.disablebutton  = value.value == '' ? true : false;
    }

  });
  return mul.disablebutton;
}; 
mul.fnResetData = function(){
  mul.uploadTypes = JSON.parse(mul.duplicateArray);
mul.type = 'Non-Conveyable';
mul.getSkytypeValue('Non-Conveyable');
};

mul.getSkytypeValue=function(type){

if(type=='Non-Conveyable'){
mul.skyTypeValue='NCV';
}else if(type=='Non-Sortable'){
mul.skyTypeValue='NST';
}else if(type=='High-Value'){
mul.skyTypeValue='HV';
}else{
mul.skyTypeValue='NR';
}
};
mul.fnPostData=function(){
  mul.resmessage = "";
  mul.isSuccess = false;
  mul.isFailed = false;
  $("#showloader").css("display", "block");

  var payLoad ={
    "dcName":mul.dcName,
    "userName":sessionStorage.userName,
    "skuType":mul.skyTypeValue,
    "article":mul.uploadTypes[0].value,
    "model":mul.uploadTypes[1].value[0],
    "size":mul.uploadTypes[1].value[1],
    "skuId":mul.uploadTypes[2].value};

$http.put(urlService.MASS_UPDATE_LOADER,payLoad, {
    headers: {'x-api-key': sessionStorage.apikey}
    })
  .success(function(data){

    $("#showloader").css("display", "none");
    mul.fnResetData();
  if (data.errorMessage) {
        mul.isFailed = true;
        mul.resmessage = data.errorMessage;

      } else {
      
        mul.isSuccess = true;
        mul.resmessage =data.resMessage;
    
      }
  })
  .error(function(data){
    $("#showloader").css("display", "none");
    mul.isFailed = true;
    mul.resmessage = "System failed. Please try again or contact WAALOS Support";
  });
  }; 


  //user favourites code starts

  mul.addToFavourate = function(isClicked){
    $("#showloader").css("display", "block");
     if(typeof isClicked !== "boolean"){
      commonService.postServiceResponse(urlService.GET_FAVOURITES,{"username": sessionStorage.userName})
        .then(function(response){
          $("#showloader").css("display", "none");
            _.each(response,function(val,key){
              if(val.funName == $scope.functionality && val.dcName == $scope.dcName){
                mul.isClicked = true;      
              }
            });
        },function(error){
          $("#showloader").css("display", "none");
          mul.isClicked = false; 
        });
        //mul.isClicked = ;
     }else{
      if(!mul.isClicked){
        commonService.postServiceResponse(urlService.ADD_FAVOURITE,{"username": sessionStorage.userName,"dcName":$scope.dcName,"funName":$scope.functionality})
        .then(function(response){
          $("#showloader").css("display", "none");
          if(response.errorMessage){
            mul.isFavouriteAdded= false; 
            mul.isClicked = false;      
            $scope.$broadcast('showAlert',['']);
          }else{
            mul.isClicked = true;      
            mul.isClicked = !isClicked;
            mul.isFavouriteAdded= true; 
            mul.favouriteMsg = response.resMessage;
          $scope.$broadcast('ClickedOnFavourate',[$scope.dcName,$scope.functionality,mul.isClicked]);
          }
            
        },function(error){
          mul.isClicked = false;
          $("#showloader").css("display", "none");
        });
        mul.isClicked = !isClicked;
      }else{
        $("#showloader").css("display", "none");
      }
     }
    
  };

  mul.addToFavourate('load');
  //user favourites code ends
}]);
