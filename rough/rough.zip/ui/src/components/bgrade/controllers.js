//'use strict';
	
var myApp = angular.module('BGrade');
$("#showloader").css("display", "none");
myApp.directive('fileModel', ['$parse', function ($parse) {
            return {
               restrict: 'A',
               link: function(scope, element, attrs) {
                  var model = $parse(attrs.fileModel);
                  var modelSetter = model.assign;
                  
                  element.bind('change', function(){
                     scope.$apply(function(){
                        modelSetter(scope, element[0].files[0]);
                     });
                  });
               }
            };
         }]);
      
         myApp.service('BGradeService', ['$http', function ($http) {
      
            this.uploadFileToUrl = function(dcName,userName,file,lotId, uploadUrl,$scope,isAfterDN){
				document.getElementById('list').innerHTML = '';
				document.getElementById('nextStep').innerHTML = '';
				$scope.isFailed=false;
				document.getElementById('nextStep').innerHTML = '';
				$scope.errorMessagesArray=[];
			
               var fd = new FormData();
               fd.append('dcName', "CDC");
			   fd.append('userName', userName);
			   //fd.append('file', file);
			  fd.append('lotId',lotId);
				 fd.append('isAfterDN',isAfterDN);
		            
               $http.post(uploadUrl, fd, {
                  transformRequest: angular.identity,
                  headers: {'Content-Type': undefined, 'x-api-key': sessionStorage.apikey}
               })
            
			   .success(function(response){
				console.log(JSON.stringify(response));//pradeep
				document.getElementById('list').innerHTML = '';
				 document.getElementById('nextStep').innerHTML = '';
				 
				 $("#showloader").css("display", "none");
				 if(response.errorMessage){
					 //document.getElementById('list').innerHTML = response.errorMessage;
					 $scope.uploadError = response.errorMessage;
				 }else{
					 $("#uploadCL").attr("disabled",true);
					 document.getElementById('list').innerHTML = response.resMessage;
					 $scope.errorMessagesArray = [];


				 }
			})
            
               .error(function(error){
				    $("#showloader").css("display", "none");
					 $scope.isFailedload = true;
					 document.getElementById('list').innerHTML = '';
					document.getElementById('nextStep').innerHTML = '';
               });
            };
         }]);
myApp.controller('BGradeController', ['$scope','$rootScope','$http','$window','BGradeService','urlService','commonService',function ($scope,$rootScope,$http,$window,BGradeService,urlService,commonService) {
	 $("#showloader").css("display", "none");

		$scope.disableDownload = true;
    	$scope.isClicked = false;

		$scope.allOptions = ["-Select Loader-","Stop_Style","T_Master_Data","T_Size_Translate","custom"];
		$scope.customer = $scope.allOptions[0];
		$scope.selectOption = function(){

			$scope.isFailed=false;
			 $scope.disable = false;
			$scope.uploadError = false;
			document.getElementById('nextStep').innerHTML = '';
			document.getElementById('list').innerHTML = '';
			$scope.errorMessagesArray=[];
			$("#uploadCL").attr("disabled",true);
			if($scope.customer == $scope.allOptions[0]){
				$("#uploadSpan,#uploadFileBGrade,#uploadCL").attr("disabled",true);
			}else if($scope.customer){
				if($scope.customer == "Stop_Style"){ $scope.customerval = "SSD";}
				else if($scope.customer == "T_Master_Data"){$scope.customerval = "BGLM";}
				else if($scope.customer == "T_Size_Translate"){$scope.customerval = "DST";}
				else if($scope.customer == "custom"){$scope.customerval = "CSTM";}
				$("#uploadSpan,#uploadFileBGrade").removeAttr("disabled");
			}
		};
		
	 $scope.disable = true;
	 $scope.pagedc = "CDC";
	  $scope.lotId  = "";
	  $scope.isFailedload = false;
	  $scope.uploadDataToDB = function(){	
		$("#showloader").css("display", "block");		 
		   var file = $scope.myFile;
		   var dcName = "CDC";			
		   var userName = sessionStorage.userName;
		   var lotId = $scope.lotId;
		   var isAfterDN = $scope.isAfterDN;
		   var uploadUrl = urlService.CUSTOMER_LOADER_UPLOAD_FILE;			 
		   BGradeService.uploadFileToUrl(dcName,userName,file,lotId, uploadUrl,$scope,isAfterDN);
	};
 	
	$scope.clearFile = function(){
		$scope.isFailed = false;
		$scope.excelReadErrors = false;
		$scope.errorMessagesArray = [];
		$scope.excelErrors = false;
		document.getElementById('list').innerHTML = '';
		document.getElementById('nextStep').innerHTML = '';
		$scope.disableDownload = true;		
	};


	var fileInput = document.getElementById("uploadFileBGrade");
	fileInput.onchange = function (evt) {
	 var target = evt.target || evt.srcElement;
	 if (target.value.length == 0) {
		 
		 
	   }else{
		 
		$scope.excelErrors = false;
		$scope.isFailedload = false;
		$scope.excelReadErrors = false;
		$scope.isFailed = false;
		$scope.uploadError = false;
		document.getElementById('list').innerHTML = '';
		document.getElementById('nextStep').innerHTML = '';
		$scope.errorMessagesArray = [];

		fileExtension = target.value.substr(target.value.lastIndexOf(".")+1);
		if (fileExtension == "xls") {
			$scope.isFailed = true;
			$scope.resmessage = "Please save this xls file into xlsx format and try again to Choose File";
			return false;
		}


		if (evt.target.value.indexOf(".xlsx") < 0) {
			$scope.isFailed = true;
			$scope.resmessage = "Please choose only XLSX file";
			return false;
		}
			
		var dcName = "CDC";
		var userName = sessionStorage.userName;
		var files = evt.target.files; // FileList object
		var fileval = $("input[type='file']").val();
		var output = [];
		if(fileval == '' || fileval == undefined || fileval == null){
			document.getElementById('list').innerHTML = '';
			document.getElementById('nextStep').innerHTML = '';
			$scope.disable = true;
		}else{
			$("#showloader").css("display", "block");
			var uploadUrl = urlService.BGRADEMASTER_CHOOSE_FILE;
			for (var i = 0, f; f = files[i]; i++) {
				output.push('<li><strong>', escape(f.name), '</strong> was choosen successfully</li>');
				localStorage.setItem("choosenFile",files[i]);
				var file = files[i];
				var fd = new FormData();
			   fd.append('dcName', dcName);
			   fd.append('userName', userName);
			   fd.append('file', file);
			   fd.append('dataLoaderType', $scope.customerval);
		
			   if(files[i].size < 1024*1024*10){
				 $http.post(uploadUrl, fd, {
					 transformRequest: angular.identity,
					 headers: {'Content-Type': undefined, 'x-api-key': sessionStorage.apikey}
				  })
			   
				  .success(function(response){
	
					if(response.lotId){
						
					$scope.isAfterDN = response.isAfterDN;
					 $scope.lotId = response.lotId;
				 if(response.successCount){
						$scope.disableDownload = false;
						 document.getElementById('list').innerHTML = response.successCount+' '+'Records are valid and uploaded successfully';
						 $("#showloader").css("display", "none");
					 }else{
						$scope.disableDownload = false;
					   document.getElementById('nextStep').innerHTML = 'Records are failed to upload';
					   $("#showloader").css("display", "none");
					 }					 
					}else if(response.errorMessage){
						$scope.disableDownload = true;
						$scope.excelReadErrors = true;
						$scope.excelReadError = response;
					    $("#showloader").css("display", "none");
					}else{
								   
						$scope.excelErrorsData = response;
						$scope.excelErrors = true;
						$("#showloader").css("display", "none");						
					   
					}
				})           
				  .error(function(err){
					$("#showloader").css("display", "none");
					$scope.isFailedload = true;
				  });
			   }else{
				 $("#showloader").css("display", "none");
				  $scope.isFailed = true;
				  $scope.resmessage = "File size should not exceed 10MB";
			 } 
			   
			}
		}
	 } 		
	}; 
		$("#uploadFileBGrade").click(function(evt) {
		var target = evt.target || evt.srcElement;
	
		if (target.value.length == 0) {

		}else if (target.value.length > 0) {
			target.value = null;
			var input = document.getElementById("uploadFileBGrade");
			input.value = '';
			input.type = '';
			input.type = 'file';
			document.getElementById("uploadFileBGrade").value = null;
	}
	});


$scope.downloadExcel = function() {
	$scope.isFailed = false;
	$("#showloader").css("display", "block");
	var url;
	url = urlService.BGRADEMASTER_DOWNLOAD_FILE.replace('loaderName',$scope.customerval);

$http({
		method: 'GET',
		url: url,
		headers: {				
			'Content-type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'x-api-key': sessionStorage.apikey
		},
		responseType: 'arraybuffer'
	})
.success( function(data, status, headers) {
$("#showloader").css("display", "none");

	if(data.byteLength == 55){
			$scope.isFailed = true;
			  $('#alert-box').modal('show');


			  }else if(data.byteLength == 98){
		$scope.isFailed = true;
		$scope.resmessage = "Error in Downloading Excel file";
		return;
	}else{
		
		var octetStreamMime = 'application/octet-stream';
		var success = false;
		var blob;
		// Get the headers
		headers = headers();

		// Get the filename from the x-filename header or default to "download.bin"
		var filename = headers['x-filename'] || 'BGrade.xlsx';

		// Determine the content type from the header or default to "application/octet-stream"
		var contentType = headers['content-type'] || octetStreamMime;

		try
		{
			// Try using msSaveBlob if supported
			console.log("Trying saveBlob method ...");
			 blob = new Blob([data], { type: contentType });
			if(navigator.msSaveBlob)
				navigator.msSaveBlob(blob, filename);
			else {
				// Try using other saveBlob implementations, if available
				var saveBlob = navigator.webkitSaveBlob || navigator.mozSaveBlob || navigator.saveBlob;
				if(saveBlob === undefined) throw "Not supported";
				saveBlob(blob, filename);
			}
			console.log("saveBlob succeeded");
			success = true;
		} catch(ex)
		{
			console.log("saveBlob method failed with the following exception:");
			console.log(ex);
		}

		if(!success)
		{
			// Get the blob url creator
			var urlCreator = window.URL || window.webkitURL || window.mozURL || window.msURL;
			if(urlCreator)
			{
				// Try to use a download link
				var link = document.createElement('a');
				if('download' in link)
				{
					// Try to simulate a click
					try
					{
						// Prepare a blob URL
						console.log("Trying download link method with simulated click ...");
						 blob = new Blob([data], { type: contentType });
						 url = urlCreator.createObjectURL(blob);
						link.setAttribute('href', url);

						// Set the download attribute (Supported in Chrome 14+ / Firefox 20+)
						link.setAttribute("download", filename);

						// Simulate clicking the download link
						var event = document.createEvent('MouseEvents');
						event.initMouseEvent('click', true, true, window, 1, 0, 0, 0, 0, false, false, false, false, 0, null);
						link.dispatchEvent(event);
						console.log("Download link method with simulated click succeeded");
						success = true;

					} catch(ex) {
						console.log("Download link method with simulated click failed with the following exception:");
						console.log(ex);
					}
				}

				if(!success)
				{
					// Fallback to window.location method
					try
					{
						// Prepare a blob URL
						// Use application/octet-stream when using window.location to force download
						console.log("Trying download link method with window.location ...");
						 blob = new Blob([data], { type: octetStreamMime });
						 url = urlCreator.createObjectURL(blob);
						window.location = url;
						console.log("Download link method with window.location succeeded");
						success = true;
					} catch(ex) {
						console.log("Download link method with window.location failed with the following exception:");
						console.log(ex);
					}
				}

			}
		}

		if(!success)
		{
			// Fallback to window.open method
			console.log("No methods worked for saving the arraybuffer, using last resort window.open");
			window.open(rowData.pathName, '_blank', '');
		}
	}
})
.error(function(data, status, config) {

	console.log("Request failed with status: " + status);
$("#showloader").css("display", "none");
	// Optionally write the error out to scope
	//$scope.errorDetails = "Request failed with status: " + status;
		$scope.isFailed = true;
		$scope.resmessage = "Error in downloading Excel File";

});
};
   }]);
  