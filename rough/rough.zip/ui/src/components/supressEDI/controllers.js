var app = angular.module('SupressEDI', ['ngAnimate', 'ui.grid', 'ui.grid.selection', 'ui.grid.pagination', 'ui.grid.edit']);

app.controller('SupressEDIController', ['$scope', '$http', '$q', '$interval', '$timeout', 'urlService', 'uiGridConstants', 'commonService', function ($scope, $http, $q, $interval, $timeout, urlService, uiGridConstants, commonService) {
	$scope.isSuccess = false;
	$scope.isFailed = false;
	$scope.searchDisable = true;
	$scope.btndisable = true;
	$scope.singleSku = true;
	$scope.isTable = false;
	$scope.pagefunctionality = $scope.functionality;
	$scope.pagedc = $scope.dcName;
	$("#showloader").css("display", "none");


	$scope.gridOptions = {
		///paginationPageSizes: [15, 25, 50, 100],
		//paginationPageSize: 15,
		//useExternalPagination: true,
		enableColumnMenus: false,
		enableSorting: true,
	};

	$scope.gridOptions.onRegisterApi = function (gridApi) {
		$scope.gridApi = gridApi;

		/*$scope.gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
		  $scope.pageNo =  newPage;
		  $scope.pageSize = pageSize;
		  $scope.searchLoadNumbers();
	   });*/

		gridApi.selection.on.rowSelectionChangedBatch($scope, function (rows) {
			$scope.isSuccess = false;
			$scope.isFailed = false;
			if ($scope.gridApi.selection.getSelectedRows().length == 0) {
				$scope.btndisable = true;
			} else {
				$scope.btndisable = false;
			}
		});

		gridApi.selection.on.rowSelectionChanged($scope, function (row) {
			$scope.isSuccess = false;
			$scope.isFailed = false;
			if ($scope.gridApi.selection.getSelectedRows().length > 0) {
				$scope.btndisable = false;

			} else {
				$scope.btndisable = true;
			}
		});
	};

	$scope.gridOptions.isRowSelectable = function (row) {
		if (+(row.entity.statCode) > 60) {
			return false;
		} else {
			return true;
		}
	};

	$scope.checkLoadNumber = function () {
		$scope.isSuccess = false;
		$scope.isFailed = false;
		var reg = /^[0-9a-zA-Z\_ ]+$/;
		if ($scope.loadNumber == undefined || $scope.loadNumber == "") {
			$scope.searchDisable = true; $scope.isFailed = false;
		} else if ($scope.loadNumber == undefined || $scope.loadNumber == 32 || !(reg.test($scope.loadNumber))) {
			$scope.searchDisable = true;

			$scope.isFailed = true;
			$scope.resmessage = "Please enter a valid data";
		} else {
			$scope.searchDisable = false;
		}
	};

	$scope.searchLoadNumbers = function () {
		$scope.isSuccess = false;
		$scope.isFailed = false;
		$scope.pageNo = $scope.pageNo ? $scope.pageNo : 1;
		$scope.pageSize = $scope.pageSize ? $scope.pageSize : $scope.gridOptions.paginationPageSize;
		$("#showloader").css("display", "block");
		if ($scope.loadNumber) { $scope.ldnum = $scope.loadNumber; }
		var url = urlService.GET_SUPRESS_DATA.replace('dName', $scope.dcName);
		url = url.replace('uName', sessionStorage.userName);
		url = url.replace('lNbr', $scope.ldnum);
		//url = url.replace('pNumber',$scope.pageNo);
		//url = url.replace('pSize',$scope.pageSize);

		var res = $http.get(url, {
			headers: { 'x-api-key': sessionStorage.apikey }
		});

		res.success(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			if (data.errorMessage) {
				$scope.isTable = false;
				$scope.isFailed = true;
				$scope.resmessage = data.errorMessage;
			}
			else if (data.resMessage) {
				$scope.isTable = false;
				$scope.isSuccess = true;
				$scope.resmessage = data.resMessage;
			}
			else if (data.length === 0) {
				$scope.isTable = false;
				$scope.isFailed = true;
				$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
			}
			else {
				$scope.isTable = true;

				$scope.gridOptions.columnDefs = [
					{ field: 'loadNbr', displayName: 'LOAD_NBR', enableCellEdit: false, },
					{ name: 'statCode', displayName: 'STAT_CODE', enableCellEdit: false },
					{ name: 'shipVia', displayName: 'SHIP_VIA', enableCellEdit: false },
					{ name: 'shipmentNbr', displayName: 'SHPMT_NBR', enableCellEdit: false },
					{ name: 'csupressEdi', displayName: 'C_SUPPRESS_EDI', enableCellEdit: false },
				];

				//$scope.gridOptions.totalItems  = data.totalNoOfRecords;  
				//$scope.gridOptions.data = data.pageItems;
				$scope.gridOptions.data = data;



				if ($scope.gridOptions.data > 10) {
					$scope.gridOptions.enableVerticalScrollbar = true;
				} else {
					$scope.gridOptions.enableVerticalScrollbar = false;
					$scope.gridOptions.enableHorizontalScrollbar = 0;
				}
			}
		});
		res.error(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			$scope.isFailed = true;
			$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
		});
	};


	$scope.confirmEDI = function () {
		// (type == "supress") ? $scope.title = "Supress EDI" : $scope.title = "Enable EDI";
		//(type == "supress") ? $scope.btnTitle = "Supress EDI" : $scope.btnTitle = "Enable EDI";
		$scope.title = "Suppress/Enable EDI";
		$scope.btnTitle = "Suppress/Enable EDI";
		$('#confirmModel').modal('show');
	};

	$scope.supressEDI = function () {
		$scope.gridApi.selection.getSelectedRows().map(function (data) {
			data.dcName = $scope.dcName;
			data.userName = sessionStorage.userName;
		});
		$scope.isSuccess = false;
		$scope.isFailed = false;
		$("#showloader").css("display", "block");
		var url = urlService.SUPRESS_EDI;
		var res = $http.put(url, $scope.gridApi.selection.getSelectedRows(), {
			headers: { 'x-api-key': sessionStorage.apikey }
		});
		res.success(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			if (data.errorMessage) {
				$scope.isFailed = true;
				$scope.resmessage = data.errorMessage;
			} else if (data.resMessage) {
				$scope.searchLoadNumbers();
				$scope.isSuccess = true;
				$scope.resmessage = data.resMessage;
				$scope.btndisable = true;
			}
			else if (data.length === 0) {
				$scope.isTable = false;
				$scope.isFailed = true;
				$scope.resmessage = "System failed. Please try again or contact WAALOS Support";

			}
		});
		res.error(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			$scope.isFailed = true;
			$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
		});
	};

	//user favourites code start
	$scope.isClicked = false;
	$scope.addToFavourate = function (isClicked) {
		$("#showloader").css("display", "block");
		if (typeof isClicked !== "boolean") {
			commonService.postServiceResponse(urlService.GET_FAVOURITES, { "username": sessionStorage.userName })
				.then(function (response) {
					$("#showloader").css("display", "none");
					_.each(response, function (val, key) {
						if (val.funName == $scope.functionality && val.dcName == $scope.dcName) {
							$scope.isClicked = true;
						}
					});
				}, function (error) {
					$("#showloader").css("display", "none");
					$scope.isClicked = false;
				});
		} else {
			if (!$scope.isClicked) {
				commonService.postServiceResponse(urlService.ADD_FAVOURITE, { "username": sessionStorage.userName, "dcName": $scope.dcName, "funName": $scope.functionality })
					.then(function (response) {
						$("#showloader").css("display", "none");
						if (response.errorMessage) {
							$scope.isFavouriteAdded = false;
							$scope.isClicked = false;
							$scope.$broadcast('showAlert', ['']);
						} else {
							$scope.isClicked = true;
							$scope.isClicked = !isClicked;
							$scope.isFavouriteAdded = true;
							$scope.favouriteMsg = response.resMessage;
							$scope.$broadcast('ClickedOnFavourate', [$scope.dcName, $scope.functionality, $scope.isClicked]);
						}

					}, function (error) {
						$scope.isClicked = false;
						$("#showloader").css("display", "none");
					});
				$scope.isClicked = !isClicked;
			} else {
				$("#showloader").css("display", "none");
			}
		}
	};
	$scope.addToFavourate('load');
	//user favourites code ends
}]);


//000057420  //000057400


