
var app = angular.module('Bgradelabeltool', ['ui.grid.autoResize', 'ngAnimate', 'ui.grid','ui.grid.pagination']);

app.controller('BgradelabeltoolCtrl', ['$scope', '$http', '$q', '$interval', '$window','urlService','uiGridConstants','commonService', function ($scope, $http, $q, $interval, $window,urlService,uiGridConstants,commonService) {
	$scope.pagefunctionality = $scope.functionality;
	$scope.pagedc = $scope.dcName;
	$scope.isSuccess = false;
	$scope.isFailed = false;
	$scope.isFieldValidate = false;
	document.getElementById("anynumber").focus();

	
			/**	This function is used to get the printers based on the dc name	**/
	$scope.getdefaultPrinter = function(){
                                var url = urlService.DEFAULT_PRINTERS.replace("dName",$scope.pagedc);
                                url = url.replace('uName',sessionStorage.userName);
                                var res = $http.get(url, {
                                 // headers: {'x-api-key': sessionStorage.apikey} 
                                });

                                res.success(function (data, status, headers, config) {
                                  if (data.errorMessage) {
                                               // $scope.isFailed = true;
                                               // $scope.resmessage = data.errorMessage;
                                                $scope.getPrinterList();
                                                }else if(data.resMessage){
                                                 // $scope.isSuccess = true;
                                                 // $scope.resmessage = "Default Printer Not Updated";
                                                  $scope.getPrinterList();
                                                }else{
                                                                $scope.defaultprinter = data;
                                                                $scope.printerip = data[0].printerIp;
                                                                $scope.getPrinterList();
                                                }
                                });
                                res.error(function (data, status, headers, config) {
                                 // $scope.isFailed = true;
                                 // $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
                                  $scope.getPrinterList();
                                });  
  };
	$scope.getdefaultPrinter();



	$scope.getPrinterList = function(){
		var url = urlService.PRINTER_LIST.replace("dName",$scope.pagedc);
		url = url.replace('uName',sessionStorage.userName);
		var res = $http.get(url, {
			//headers: {'x-api-key': sessionStorage.apikey} 
		});

		res.success(function (data, status, headers, config) {
			if (data.errorMessage) {
				$scope.isFailed = true;
				$scope.resmessage = data.errorMessage;
	  		}else if(data.resMessage){
					$scope.isSuccess = true;
					$scope.resmessage = data.resMessage;
				}else{
					$scope.printerslist = data;
					 for (var i = 0; i < $scope.printerslist.length; i++) {
              if($scope.printerip){
                if ($scope.printerslist[i].printerIp == $scope.printerip) {
                  $scope.printer = $scope.printerslist[i];
                  break;
                }
              }else{
                $scope.printer = $scope.printerslist[0];
              }
            }

			
				}
		});
		res.error(function (responce, status, headers, config) {
			$scope.isFailed = true;
			$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
		});  
	};



	//Three grid data
	$scope.gridOptionsThreegrid = {
		enableColumnMenus: false,
		enableSorting: true,
		multiSelect: false,
		enableRowSelection: true,//we can remove it later no use  of this
		enableSelectAll: true,//we can remove it later no use  of this             
		enableCellEdit: false, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
		enableCellEditOnFocus: true // set any editable column to allow edit on focus
	};
	$scope.gridOptionsThreegrid.onRegisterApi = function (gridApi) {
		//set gridApi on scope
		$scope.gridApi = gridApi;

		gridApi.selection.on.rowSelectionChanged($scope, function (rows) {
			$scope.isSuccess = false;
			$scope.isFailed = false;
			if(rows.isSelected == true){
				$scope.sixgridDdata(rows.entity.style);
			}
			
		  });
	};

//Six Grid data
	$scope.gridOptionsSixgrid = {
		enableColumnMenus: false,
		enableSorting: true,
		multiSelect: false,
		enableRowSelection: true,//we can remove it later no use  of this
		enableSelectAll: true,//we can remove it later no use  of this             
		enableCellEdit: false, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
		enableCellEditOnFocus: true, // set any editable column to allow edit on focus
		};
		$scope.gridOptionsSixgrid.onRegisterApi = function (gridApi) {
			//set gridApi on scope
			$scope.gridApi = gridApi;
	
			gridApi.selection.on.rowSelectionChanged($scope, function (rows) {
				$scope.isSuccess = false;
				$scope.isFailed = false;
				if(rows.isSelected == true){
					$scope.printing(rows);
				}
			
			  });
		};


//Six grid data for cat and article  popup
		$scope.gridOptionsSixgrid2 = {
			enableColumnMenus: false,
			enableSorting: true,
			multiSelect: false,
			enableRowSelection: true,//we can remove it later no use  of this
			enableSelectAll: true,//we can remove it later no use  of this             
			enableCellEdit: false, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
			enableCellEditOnFocus: true // set any editable column to allow edit on focus
			};
			$scope.gridOptionsSixgrid2.onRegisterApi = function (gridApi) {
				//set gridApi on scope
				$scope.gridApi = gridApi;
		
				gridApi.selection.on.rowSelectionChanged($scope, function (rows) {
					$scope.isSuccess = false;
					$scope.isFailed = false;
					if(rows.isSelected == true){
						$scope.printing(rows);
					}
				
				  });
			};

			//Scan barcode or enter user input
	$scope.BarcodeScanNum = function($event){

		var keyCode = $event.which || $event.keyCode;
		$scope.userData = $event.currentTarget.value;
	  
		$scope.isFieldValidate = false;
		var reg = /^[0-9\_ ]+$/;

	        if($scope.userData){
			if($scope.userData.length < 5 || $scope.userData.length > 20 || $scope.userData == '' || $scope.userData == null || $scope.userData == undefined || $scope.userData == 32 || !(reg.test($scope.userData))){
			$scope.isFieldValidate = true;
                        $scope.isSuccess = false;
		        $scope.isFailed = false;

			return false;
			}
		}

		if($scope.userData  && keyCode === 13){	
		 
			if($scope.userData.length < 5 || $scope.userData.length > 20 || $scope.userData == '' || $scope.userData == null || $scope.userData == undefined || $scope.userData == 32 || !(reg.test($scope.userData))){
			$scope.isFieldValidate = true;
                        $scope.isSuccess = false;
		        $scope.isFailed = false;

			return false;
			}
			
			else{
			        $scope.isSuccess = false;
		                $scope.isFailed = false;

				var url = urlService.SEARCH_BGRADE_BARCODE.replace('dName',$scope.pagedc);
				url = url.replace('uName',sessionStorage.userName);
				url = url.replace('barcode',$scope.userData );
				url = url.replace('printeripnum',$scope.printer.printerIp);
				url = url.replace('printerport',$scope.printer.printerPort );
		
				
				var res = $http.get(url, {
				 headers: {'x-api-key': sessionStorage.apikey}
				});
			
			$("#showloader").css("display", "block");
				res.success(function (data, status, headers, config) {
				  $("#showloader").css("display", "none");
				
				  if (data.bgradeData.errorMessage) {
					$scope.isTable = false;
					$scope.isTable1 = false;
					$scope.isTable2 = false;
					$scope.isFailed = true;
					$scope.resmessage = data.bgradeData.errorMessage;
					document.getElementById("anynumber").focus();
					return false;
				  }
				  else if (data.bgradeData.resMessage) {
					$scope.isTable = false;
					$scope.isTable1 = false;
					$scope.isTable2 = false;
					$scope.isSuccess = true;
					$scope.resmessage = data.bgradeData.resMessage;
					$scope.barcodeval = "";
					document.getElementById("anynumber").focus();
					return false;
				  }
				  else if (data.bgradeData.length === 0 || data.bgradeData.length == "") {
					$scope.isTable = false;
					$scope.isTable1 = false;
					$scope.isTable2 = false;
					$scope.isSuccess = true;
					$scope.barcodeval = "";
					document.getElementById("anynumber").focus();
					$scope.resmessage = "Style Not Found";
					return false;
    				}
					if(data.bgradeData.categoryNames){
						$scope.isTable = false;
						$scope.isTable1 = false;
						$scope.isTable2 = false;
						$("#catSearchModel").modal('show');
						$scope.orgSku = data.articleData;
						$scope.cats = data.bgradeData.mappingData[0];
						$scope.CatList = Object.keys($scope.cats);
						$scope.CatName = $scope.CatList[0];
						$scope.article =  $scope.cats[$scope.CatName][0];
						var temp = [];
						$scope.cats[$scope.CatName].map(function(prop){
						temp.push(prop);
					});
		 
					$scope.articles = temp;
					 $scope.art = $scope.articles[0];
					 $scope.printFlag = "S";
				}else{
				
					if(data.bgradeData.sizeLst){
			//$scope.pageNo = $scope.pageNo ? $scope.pageNo : 1;
		//$scope.pageSize = $scope.pageSize ? $scope.pageSize: $scope.gridOptionsSmall.paginationPageSize;
		$scope.isTable = false;
		$scope.isTable1 = true;
		$scope.isTable2 = false;
		$scope.orgSku = data.articleData;
		$scope.gridOptionsSixgrid.columnDefs = [
			
				
					{ name: 'style', displayName: 'Style', enableCellEdit: false, sort: { direction: uiGridConstants.ASC, priority: 1 },  cellTooltip: true, headerTooltip: true,
					cellClass: function (grid, row, col, rowRenderIndex, colRenderIndex) {
						if(data.bgradeData.defaultSize !=null){
					
						if (row.entity.newSize == data.bgradeData.defaultSize[0].newSize) {
							return 'greenbgone';
						}
						return ;
					}
					}
				
				},
					{ name: 'origSize', displayName: 'Orinal Size', enableCellEdit: false, cellTooltip: true, headerTooltip: true,
					cellClass: function (grid, row, col, rowRenderIndex, colRenderIndex) {
						if(data.bgradeData.defaultSize !=null){
							
								if (row.entity.newSize == data.bgradeData.defaultSize[0].newSize) {
									return 'greenbgone';
								}
								return ;
							}
					}
				},
					{ name: 'newSize', displayName: 'New Size', enableCellEdit: false, cellTooltip: true, headerTooltip: true, visibility: false,
					cellClass: function (grid, row, col, rowRenderIndex, colRenderIndex) {
						if(data.bgradeData.defaultSize !=null){
							
								if (row.entity.newSize == data.bgradeData.defaultSize[0].newSize) {
									return 'greenbgone';
								}
								return ;
							}
					}
				},	
					{ name: 'skuDesc', displayName: 'SKU Decription', enableCellEdit: false, cellTooltip: true, headerTooltip: true, visibility: false, 
					cellClass: function (grid, row, col, rowRenderIndex, colRenderIndex) {
						if(data.bgradeData.defaultSize !=null){
							
								if (row.entity.newSize == data.bgradeData.defaultSize[0].newSize) {
									return 'greenbgone';
								}
								return ;
							}
					}
				},
					{ name: 'categorie', displayName: 'Categorie', enableCellEdit: false, cellTooltip: true, headerTooltip: true, visibility: false,
					cellClass: function (grid, row, col, rowRenderIndex, colRenderIndex) {
						if(data.bgradeData.defaultSize !=null){
							
								if (row.entity.newSize == data.bgradeData.defaultSize[0].newSize) {
									return 'greenbgone';
								}
								return ;
							}
					}
				},
					{ name: 'skuBrcd', displayName: 'Sku Barcode', enableCellEdit: false, cellTooltip: true, headerTooltip: true, visibility: false,
					cellClass: function (grid, row, col, rowRenderIndex, colRenderIndex) {
						if(data.bgradeData.defaultSize !=null){
							
								if (row.entity.newSize == data.bgradeData.defaultSize[0].newSize) {
									return 'greenbgone';
								}
								return ;
							}
					}
				}
				
				
				];
	

		 //$scope.gridOptions.rowTemplate = '<div style="background-color: aquamarine" ng-click="grid.appScope.fnOne(row)" ng-repeat="col in colContainer.renderedColumns track by col.colDef.name" class="ui-grid-cell" ui-grid-cell></div>';
		 //$scope.gridOptionsSixgrid.totalItems  = data.palletLocDtlsDtoList.totalNoOfRecords;  
		 $scope.gridOptionsSixgrid.data = data.bgradeData.sizeLst;
 
		 if ($scope.gridOptionsSixgrid.data.length > 10) {
			 $scope.gridOptionsSixgrid.enableVerticalScrollbar = 1;
			 $scope.gridOptionsSixgrid.enableHorizontalScrollbar = 0;
		 } else {
			 $scope.gridOptionsSixgrid.enableVerticalScrollbar = 0;
			 $scope.gridOptionsSixgrid.enableHorizontalScrollbar = 0;
		 }
		 $scope.printFlag = "P";
		
		 _.each($scope.gridOptionsSixgrid.data, function (val, key) {
			if(data.bgradeData.defaultSize !=null){
			if(val.newSize == data.bgradeData.defaultSize[0].newSize){
				$scope.printingdefault(val);
			}
		}
			
		});
	}else {
	//$scope.pageNo = $scope.pageNo ? $scope.pageNo : 1;
		// $scope.pageSize = $scope.pageSize ? $scope.pageSize: $scope.gridOptionsSmall.paginationPageSize;
		$scope.isTable = true;
		$scope.isTable1 = false;
		$scope.isTable2 = false;
		$scope.orgSku = data.articleData;
		$scope.gridOptionsThreegrid.columnDefs = [
		 
			{ name: 'style', displayName: 'Style', enableCellEdit: false, sort: { direction: uiGridConstants.ASC, priority: 1 },  cellTooltip: true, headerTooltip: true},
			{ name: 'skuDesc', displayName: 'SKU Decription', enableCellEdit: false, cellTooltip: true, headerTooltip: true },
			{ name: 'count', displayName: 'Count', enableCellEdit: false, cellTooltip: true, headerTooltip: true, visibility: false }
		
			
			
		];

		//$scope.gridOptionsBig.totalItems  = data.swcDtoList.totalNoOfRecords;  
		$scope.gridOptionsThreegrid.data = data.bgradeData;

		if ($scope.gridOptionsThreegrid.data.length > 10) {
			$scope.gridOptionsThreegrid.enableVerticalScrollbar = 1;
			$scope.gridOptionsThreegrid.enableHorizontalScrollbar = 1;
		} else {
			$scope.gridOptionsThreegrid.enableVerticalScrollbar = 0;
			$scope.gridOptionsThreegrid.enableHorizontalScrollbar = 1;
		}
		$scope.printFlag = "P";
	}
	document.getElementById("anynumber").focus();

}
				  //$('.ui-grid-pager-control input').prop( "disabled", true );
	});
				res.error(function (data, status, headers, config) {
				  $("#showloader").css("display", "none");
				  $scope.isFailed = true;
				  $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
			
				});
					
		  }
		}

};

//Back to three grid
$scope.isback  = function(){
  $scope.isSuccess = false;
  $scope.isFailed = false;
	$scope.isFieldValidate = false;

  $scope.isTable = true;
  $scope.isTable1 = false;
  $scope.isTable2 = false;
  $scope.isBack = false;
document.getElementById("anynumber").focus();
};

//Six grid from three grid
$scope.sixgridDdata = function(selectedstyle){
	$scope.isSuccess = false;
	$scope.isFailed = false;
	$scope.isFieldValidate = false;

	var url = urlService.BGRADE_THREE_GRID_DATA.replace('styleid',selectedstyle);
	url = url.replace('BarCode',$scope.userData);
	
	var res = $http.get(url, {
		headers: {'x-api-key': sessionStorage.apikey}
	 });

	$("#showloader").css("display", "block");
		res.success(function (data, status, headers, config) {
		  $("#showloader").css("display", "none");
		
		  if (data.bgradeData.errorMessage) {
			$scope.isFailed = true;
			$scope.resmessage = data.bgradeData.errorMessage;
			document.getElementById("anynumber").focus();
		  }
		  else if (data.bgradeData.resMessage) {
			$scope.isSuccess = true;
			$scope.resmessage = data.bgradeData.resMessage;
			document.getElementById("anynumber").focus();
		  }
		  else if (data.bgradeData.length === 0) {
			$scope.isFailed = true;
			$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
		  }else{
			$scope.isTable = false;
			$scope.isTable1 = true;
			$scope.isTable2 = false;
			$scope.isBack = true;
			$scope.orgSku = data.articleData;
			$scope.gridOptionsSixgrid.columnDefs = [
		
			
				{ name: 'style', displayName: 'Style', enableCellEdit: false, sort: { direction: uiGridConstants.ASC, priority: 1 },  cellTooltip: true, headerTooltip: true,
				cellClass: function (grid, row, col, rowRenderIndex, colRenderIndex) {
					if(data.bgradeData.defaultSize !=null){
				
					if (row.entity.newSize == data.bgradeData.defaultSize[0].newSize) {
						return 'greenbgone';
					}
					return ;
				}
				}
			
			},
				{ name: 'origSize', displayName: 'Orinal Size', enableCellEdit: false, cellTooltip: true, headerTooltip: true,
				cellClass: function (grid, row, col, rowRenderIndex, colRenderIndex) {
					if(data.bgradeData.defaultSize !=null){
						
							if (row.entity.newSize == data.bgradeData.defaultSize[0].newSize) {
								return 'greenbgone';
							}
							return ;
						}
				}
			},
				{ name: 'newSize', displayName: 'New Size', enableCellEdit: false, cellTooltip: true, headerTooltip: true, visibility: false,
				cellClass: function (grid, row, col, rowRenderIndex, colRenderIndex) {
					if(data.bgradeData.defaultSize !=null){
						
							if (row.entity.newSize == data.bgradeData.defaultSize[0].newSize) {
								return 'greenbgone';
							}
							return ;
						}
				}
			},	
				{ name: 'skuDesc', displayName: 'SKU Decription', enableCellEdit: false, cellTooltip: true, headerTooltip: true, visibility: false, 
				cellClass: function (grid, row, col, rowRenderIndex, colRenderIndex) {
					if(data.bgradeData.defaultSize !=null){
						
							if (row.entity.newSize == data.bgradeData.defaultSize[0].newSize) {
								return 'greenbgone';
							}
							return ;
						}
				}
			},
				{ name: 'categorie', displayName: 'Categorie', enableCellEdit: false, cellTooltip: true, headerTooltip: true, visibility: false,
				cellClass: function (grid, row, col, rowRenderIndex, colRenderIndex) {
					if(data.bgradeData.defaultSize !=null){
						
							if (row.entity.newSize == data.bgradeData.defaultSize[0].newSize) {
								return 'greenbgone';
							}
							return ;
						}
				}
			},
				{ name: 'skuBrcd', displayName: 'Sku Barcode', enableCellEdit: false, cellTooltip: true, headerTooltip: true, visibility: false,
				cellClass: function (grid, row, col, rowRenderIndex, colRenderIndex) {
					if(data.bgradeData.defaultSize !=null){
						
							if (row.entity.newSize == data.bgradeData.defaultSize[0].newSize) {
								return 'greenbgone';
							}
							return ;
						}
				}
			}
			
			
			];

	 //$scope.gridOptionsSixgrid.totalItems  = data.palletLocDtlsDtoList.totalNoOfRecords;  
	 $scope.gridOptionsSixgrid.data = data.bgradeData.sizeLst;

	 if ($scope.gridOptionsSixgrid.data.length > 10) {
		 $scope.gridOptionsSixgrid.enableVerticalScrollbar = 1;
		 $scope.gridOptionsSixgrid.enableHorizontalScrollbar = 0;
	 } else {
		 $scope.gridOptionsSixgrid.enableVerticalScrollbar = 0;
		 $scope.gridOptionsSixgrid.enableHorizontalScrollbar = 0;
	 }
	 _.each($scope.gridOptionsSixgrid.data, function (val, key) {
		if(data.bgradeData.defaultSize !=null){
		if(val.newSize == data.bgradeData.defaultSize[0].newSize){
			$scope.printingdefault(val);
		}
	}
	});
	document.getElementById("anynumber").focus();
	}
});
res.error(function (data, status, headers, config) {
	$("#showloader").css("display", "none");
	$scope.isFailed = true;
	$scope.resmessage = "System failed. Please try again or contact WAALOS Support";

});
	 
};

$scope.getArticle = function () {
	$scope.articles= [];
	$scope.cats[$scope.CatName].map(function(data){
		 $scope.articles.push(data);
	 });
  
	 $scope.CatName  = $scope.CatName;
	 $scope.art = '';
	 $scope.art = $scope.articles[0];
		
		 };

$scope.changeFunValue = function(funName){
	$scope.art = funName;
};

//Search using article and cat
$scope.searchCat = function(){

	$('#catSearchModel').modal('hide');
	$scope.isSuccess = false;
	$scope.isFailed = false;
	$scope.isFieldValidate = false;

	var url = urlService.BGRADE_THREE_GRID_DATA.replace('styleid',$scope.art.split(': ')[1]);
	url = url.replace('BarCode',$scope.userData);
	var res = $http.get(url, {
		headers: {'x-api-key': sessionStorage.apikey}
	 });

	$("#showloader").css("display", "block");

		res.success(function (data, status, headers, config) {
		  $("#showloader").css("display", "none");
		
		  if (data.bgradeData.errorMessage) {
			$scope.isFailed = true;
			$scope.resmessage = data.bgradeData.errorMessage;
			document.getElementById("anynumber").focus();
		  }
		  else if (data.bgradeData.resMessage) {
			$scope.isSuccess = true;
			$scope.resmessage = data.bgradeData.resMessage;
			document.getElementById("anynumber").focus();
		  }
		  else if (data.bgradeData.length === 0) {
			$scope.isFailed = true;
			$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
			document.getElementById("anynumber").focus();
		  }else{
			$scope.isTable = false;
			$scope.isTable1 = false;
			$scope.isTable2 = true;
			$scope.orgSku = data.articleData;
			$scope.gridOptionsSixgrid2.columnDefs = [
		
			
				{ name: 'style', displayName: 'Style', enableCellEdit: false, sort: { direction: uiGridConstants.ASC, priority: 1 },  cellTooltip: true, headerTooltip: true,
				cellClass: function (grid, row, col, rowRenderIndex, colRenderIndex) {
					if(data.bgradeData.defaultSize !=null){
				
					if (row.entity.newSize == data.bgradeData.defaultSize[0].newSize) {
						return 'greenbgone';
					}
					return ;
				}
				}
			
			},
				{ name: 'origSize', displayName: 'Orinal Size', enableCellEdit: false, cellTooltip: true, headerTooltip: true,
				cellClass: function (grid, row, col, rowRenderIndex, colRenderIndex) {
					if(data.bgradeData.defaultSize !=null){
						
							if (row.entity.newSize == data.bgradeData.defaultSize[0].newSize) {
								return 'greenbgone';
							}
							return ;
						}
				}
			},
				{ name: 'newSize', displayName: 'New Size', enableCellEdit: false, cellTooltip: true, headerTooltip: true, visibility: false,
				cellClass: function (grid, row, col, rowRenderIndex, colRenderIndex) {
					if(data.bgradeData.defaultSize !=null){
						
							if (row.entity.newSize == data.bgradeData.defaultSize[0].newSize) {
								return 'greenbgone';
							}
							return ;
						}
				}
			},	
				{ name: 'skuDesc', displayName: 'SKU Decription', enableCellEdit: false, cellTooltip: true, headerTooltip: true, visibility: false, 
				cellClass: function (grid, row, col, rowRenderIndex, colRenderIndex) {
					if(data.bgradeData.defaultSize !=null){
						
							if (row.entity.newSize == data.bgradeData.defaultSize[0].newSize) {
								return 'greenbgone';
							}
							return ;
						}
				}
			},
				{ name: 'categorie', displayName: 'Categorie', enableCellEdit: false, cellTooltip: true, headerTooltip: true, visibility: false,
				cellClass: function (grid, row, col, rowRenderIndex, colRenderIndex) {
					if(data.bgradeData.defaultSize !=null){
						
							if (row.entity.newSize == data.bgradeData.defaultSize[0].newSize) {
								return 'greenbgone';
							}
							return ;
						}
				}
			},
				{ name: 'skuBrcd', displayName: 'Sku Barcode', enableCellEdit: false, cellTooltip: true, headerTooltip: true, visibility: false,
				cellClass: function (grid, row, col, rowRenderIndex, colRenderIndex) {
					if(data.bgradeData.defaultSize !=null){
						
							if (row.entity.newSize == data.bgradeData.defaultSize[0].newSize) {
								return 'greenbgone';
							}
							return ;
						}
				}
			}
			
			];

	 //$scope.gridOptionsSixgrid.totalItems  = data.palletLocDtlsDtoList.totalNoOfRecords;  
	 		$scope.gridOptionsSixgrid2.data = data.bgradeData.sizeLst;

			if ($scope.gridOptionsSixgrid2.data.length > 10) {
				$scope.gridOptionsSixgrid2.enableVerticalScrollbar = 1;
				$scope.gridOptionsSixgrid2.enableHorizontalScrollbar = 0;
			} else {
				$scope.gridOptionsSixgrid2.enableVerticalScrollbar = 0;
				$scope.gridOptionsSixgrid2.enableHorizontalScrollbar = 0;
			}
			$scope.printFlag = "P";

			_.each($scope.gridOptionsSixgrid2.data, function (val, key) {
				if(data.bgradeData.defaultSize !=null){
				if(val.newSize == data.bgradeData.defaultSize[0].newSize){
					$scope.printingdefault(val);
				}
			}
			});
		document.getElementById("anynumber").focus();
			
			}


		});
		res.error(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			$scope.isFailed = true;
			$scope.resmessage = "System failed. Please try again or contact WAALOS Support";

		});

};
	 
// Printing label or price tag
$scope.printing = function(rows){

	$scope.isSuccess = false;
	$scope.isFailed = false;
	$scope.isFieldValidate = false;

	var postData = {
		"style": rows.entity.style,
    "skuDesc": rows.entity.skuDesc,
    "skuBrcd": rows.entity.skuBrcd,
    "categorie": rows.entity.categorie,
    "origSize": rows.entity.origSize,
    "newSize": rows.entity.newSize,
    "printerIp": $scope.printer.printerIp,
    "printerPort": $scope.printer.printerPort,
    "printFlag":$scope.printFlag,
	};

	var res = $http.post(urlService.BGRADE_PRINT_LABEL, postData, {
		headers: {'x-api-key': sessionStorage.apikey}
	});

	$("#showloader").css("display", "block");
	
	res.success(function (data, status, headers, config) {
		 $("#showloader").css("display", "none");
	
		  if (data.errorMessage) {
			$scope.isFailed = true;
			$scope.resmessage = data.errorMessage;
			document.getElementById("anynumber").focus();
		  }
		  else if (data.resMessage) {
			$scope.isSuccess = true;
			$scope.resmessage = data.resMessage;
			$scope.barcodeval = "";
			document.getElementById("anynumber").focus();
			//$scope.gridApi.selection.clearSelectedRows();
		  }
		 
	});
	res.error(function (data, status, headers, config) {
		
		$("#showloader").css("display", "none");
		$scope.isFailed = true;
		$scope.resmessage = "System failed. Please try again or contact WAALOS Support";

	});

};

	 
// Printing label or price tag
$scope.printingdefault = function(rowdata){
	
		$scope.isSuccess = false;
		$scope.isFailed = false;
		$scope.isFieldValidate = false;
	
		var postData = {
			"style": rowdata.style,
			"skuDesc": rowdata.skuDesc,
			"skuBrcd": rowdata.skuBrcd,
			"categorie": rowdata.categorie,
			"origSize": rowdata.origSize,
			"newSize": rowdata.newSize,
			"printerIp": $scope.printer.printerIp,
			"printerPort": $scope.printer.printerPort,
			"printFlag":$scope.printFlag,
		};
	
		var res = $http.post(urlService.BGRADE_PRINT_LABEL, postData, {
			headers: {'x-api-key': sessionStorage.apikey}
		});
	
		$("#showloader").css("display", "block");
		
		res.success(function (data, status, headers, config) {
			 $("#showloader").css("display", "none");
		
				if (data.errorMessage) {
				$scope.isFailed = true;
				$scope.resmessage = data.errorMessage;
				}
				else if (data.resMessage) {
					if(data.resMessage == "Label printed successfully"){
						$scope.isSuccess = true;
						$scope.resmessage = "Highlighted Label printed successfully";
						$scope.barcodeval = "";
						document.getElementById("anynumber").focus();
					}else{
						$scope.isSuccess = true;
						$scope.resmessage = data.resMessage;
						$scope.barcodeval = "";
						document.getElementById("anynumber").focus();
						//$scope.gridApi.selection.clearSelectedRows();
					}
				
				}
			 
		});
		res.error(function (data, status, headers, config) {
			
			$("#showloader").css("display", "none");
			$scope.isFailed = true;
			$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
	
		});
	
	};



//user favourites code start
$scope.isClicked = false;

$scope.addToFavourate = function(isClicked){
    $("#showloader").css("display", "block");
     if(typeof isClicked !== "boolean"){
      commonService.postServiceResponse(urlService.GET_FAVOURITES,{"username": sessionStorage.userName})
        .then(function(response){
          $("#showloader").css("display", "none");
            _.each(response,function(val,key){
              if(val.funName == $scope.functionality && val.dcName == $scope.dcName){
                $scope.isClicked = true;      
              }
            });
        },function(error){
          $("#showloader").css("display", "none");
          $scope.isClicked = false; 
        });
        //$scope.isClicked = ;
     }else{
      if(!$scope.isClicked){
        commonService.postServiceResponse(urlService.ADD_FAVOURITE,{"username": sessionStorage.userName,"dcName":$scope.dcName,"funName":$scope.functionality})
        .then(function(response){
          $("#showloader").css("display", "none");
          if(response.errorMessage){
            $scope.isFavouriteAdded= false; 
            $scope.isClicked = false;      
            $scope.$broadcast('showAlert',['']);
          }else{
            $scope.isClicked = true;      
            $scope.isClicked = !isClicked;
            $scope.isFavouriteAdded= true; 
            $scope.favouriteMsg = response.resMessage;
          $scope.$broadcast('ClickedOnFavourate',[$scope.dcName,$scope.functionality,$scope.isClicked]);
          }
            
        },function(error){
          $scope.isClicked = false;
          $("#showloader").css("display", "none");
        });
        $scope.isClicked = !isClicked;
      }else{
        $("#showloader").css("display", "none");
      }
     }
    
  };
  $scope.addToFavourate('load');
  //user favourites code ends
}]);


