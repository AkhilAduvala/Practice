var app = angular.module('LM-WMUserAddition', ['ngTouch', 'ui.grid', 'ui.grid.edit', 'ui.grid.cellNav','ui.grid.selection','ui.grid.pagination','ui.grid.validate']);

app.controller('LM-WMUserAdditionController', ['$scope', '$http', '$q', '$interval','$timeout','urlService', 'uiGridConstants','commonService', function ($scope, $http, $q, $interval,$timeout,urlService,uiGridConstants,commonService) {
 $scope.disable = true;
 $scope.isupdate = true;
 $scope.isSuccess = false;
 $scope.isFailed = false;
 $scope.isClicked = false;
 $scope.pagefunctionality = $scope.functionality;
 $scope.pagedc = $scope.dcName;
 $("#showloader").css("display", "none");

 
 //function to get the dropdown values from backend
$scope.getLMWMUserData = function () {
	$scope.lmwmSupervisorDto = [];
	$scope.lmwmDepartmentDto = [];
	$scope.lmwmshiftDto = [];
	$scope.supervisorId = [];
	 $("#showloader").css("display", "block");
	 $scope.isSuccess = false;
	 $scope.isFailed = false;
	 var url = urlService.LM_WN_Drpdown.replace('dName',$scope.pagedc);
	 url = url.replace('uName',sessionStorage.userName);




 $http.get(url,{
	 headers: {'x-api-key': sessionStorage.apikey}
})



.success(function(data){
		$("#showloader").css("display", "none");
    if (data.errorMessage) {
			$scope.isFailed = true;
      $scope.resmessage = data.errorMessage;

    }else{
	  if(data.lmwmSupervisorDto){
		  _.each(data.lmwmSupervisorDto,function(value,key){
		//	 $scope.supervisorId.push(value.login_user_id);
		//	$scope.lmwmSupervisorDto.push(value.last_name +' '+ value.first_name); 
		$scope.lmwmSupervisorDto.push(value); 
		  });
	  }
	  if(data.lmwmDepartmentDto){
		   _.each(data.lmwmDepartmentDto,function(value,key){
			 
			//$scope.lmwmDepartmentDto.push(value.dept_code +'-'+ value.description);
		$scope.lmwmDepartmentDto.push(value);	  
		  });
	  }
	  if(data.lmwmshiftDto){
		   _.each(data.lmwmshiftDto,function(value,key){
			   
			//$scope.lmwmshiftDto.push(value.shift_code +'-'+ value.description);	  
		$scope.lmwmshiftDto.push(value);	
		  });
	  }
	 $scope.supervisor = data.lmwmSupervisorDto[0];
	 $scope.ddepartment = data.lmwmDepartmentDto[0];
	 $scope.shift = data.lmwmshiftDto[0];	
		$scope.getsupervisorFunctionality($scope.supervisor);
		$scope.getddepartmentFunctionality( $scope.ddepartment);
		$scope.getshiftFunctionality($scope.shift);
	
	}
  }).error(function(data){
	  $("#showloader").css("display", "none");
		$scope.isFailed = true;
    $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
  });
  
  };
$scope.getsupervisorFunctionality = function(modelValue){
	$scope.supervisorId = modelValue;
};
$scope.getddepartmentFunctionality= function(modelValue){
	$scope.departmentId = modelValue;
};

$scope.getshiftFunctionality= function(modelValue){
	$scope.shiftrId = modelValue;
};
//function to save the data
$scope.lmwmUserDataValidate = function () {
	$scope.isSuccess = false;
	$scope.isFailed = false;
  $("#showloader").css("display", "block");
 var payload =  {
          "dcName":$scope.pagedc,
	  "userName": sessionStorage.userName, 
	  "firstName": $scope.firstName,
	  "lastName": $scope.lastName, 
	  "clone_user_id": $scope.cloneUserId,
	  "emplye_id":  $scope.employeeId,
	  "super_id": $scope.supervisorId.supervisor_id,
	  "dept_code": 	$scope.departmentId.dept_id,
	  "shift_code":$scope.shiftrId.shift_id, 
	  }; 
  $http.put(urlService.INSERT_LMWN_Data,payload,{
	 headers: {'x-api-key': sessionStorage.apikey}
})

//$http.put(urlService.INSERT_LMWN_Data,payload)
  .success(function (data, status, headers, config) {
    $("#showloader").css("display", "none");
    if (data.errorMessage) {
			$scope.isFailed = true;
      $scope.resmessage = data.errorMessage;

    }else if(data.resMessage){
			$scope.isSuccess = true;
      $scope.resmessage = data.resMessage;
  
	  $scope.lmwmForm.$setPristine();
	   $scope.firstName = '';
	  $scope.lastName = '';
	  $scope.cloneUserId = '';
	  $scope.employeeId = '';  
    }
  })
  .error(function (data, status, headers, config) {
    $("#showloader").css("display", "none");
    $scope.isFailed = true;
    $scope.resmessage = "System failed. Please try again or contact WAALOS Support";

  });

};
$scope.getLMWMUserData();
//user favourites code starts
$scope.addToFavourate = function(isClicked){
	$("#showloader").css("display", "block");
	 if(typeof isClicked !== "boolean"){
		commonService.postServiceResponse(urlService.GET_FAVOURITES,{"username": sessionStorage.userName})
			.then(function(response){
				$("#showloader").css("display", "none");
					_.each(response,function(val,key){
						if(val.funName == $scope.functionality && val.dcName == $scope.dcName){
							$scope.isClicked = true;      
						}
					});
			},function(error){
				$("#showloader").css("display", "none");
				$scope.isClicked = false; 
			});
			//$scope.isClicked = ;
	 }else{
		if(!$scope.isClicked){
			commonService.postServiceResponse(urlService.ADD_FAVOURITE,{"username": sessionStorage.userName,"dcName":$scope.dcName,"funName":$scope.functionality})
			.then(function(response){
				$("#showloader").css("display", "none");
				if(response.errorMessage){
					$scope.isFavouriteAdded= false; 
					$scope.isClicked = false;      
					$scope.$broadcast('showAlert',['']);
				}else{
					$scope.isClicked = true;      
					$scope.isClicked = !isClicked;
					$scope.isFavouriteAdded= true; 
					$scope.favouriteMsg = response.resMessage;
				$scope.$broadcast('ClickedOnFavourate',[$scope.dcName,$scope.functionality,$scope.isClicked]);
				}
					
			},function(error){
				$scope.isClicked = false;
				$("#showloader").css("display", "none");
			});
			$scope.isClicked = !isClicked;
		}else{
			$("#showloader").css("display", "none");
		}
	 }
	
};
$scope.addToFavourate('load');
//user favourites code ends
}]);
