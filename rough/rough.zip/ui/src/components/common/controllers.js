angular.module('Common')
    .controller('CommonController', ['$scope', '$http', '$location', '$rootScope', '$routeParams','$window','$timeout','commonService','urlService', function ($scope, $http, $location, $rootScope, $routeParams,$window,$timeout,commonService,urlService) {
   
		
        $scope.getFunctionality = function () {
   
		
           $rootScope.dcFunctionalities= [];
           $rootScope.DCDetails[$scope.dcName].map(function(data){
            $rootScope.dcFunctionalities.push(data.functnal_nm);
            });
	     
            $rootScope.dcName = $scope.dcName;
            $rootScope.functionality = '';
            $scope.functionality = $rootScope.dcFunctionalities[0];
            localStorage.removeItem("choosenFile");
            $rootScope.functionality = $rootScope.dcFunctionalities[0];

        };
        $scope.selectFunctionality = function () {
            localStorage.removeItem("choosenFile");// used to remove selected item from localstorage
        };
		
       // if(sessionStorage.expiratinoTime){
           // var time = sessionStorage.expiratinoTime;
           // $timeout(function(){
                //commonService.setData();
                //sessionStorage.clear();
                 //$window.location.assign('#/login');
            //},time);	
           // } 

	 if(sessionStorage.expiratinoTime){
             var time = sessionStorage.expiratinoTime;
	   	$timeout(function (){

		 $("#logoutModel").modal('show');
             },time);
           } 
            $rootScope.$on('DrpValues',function(event,args){
                $scope.showDocument(args);
            })
            $scope.$on('changeDrpValues',function(event,args){
               $scope.showDocument(args);
               });
               $scope.changeFunValue = function(funName){
                $rootScope.functionality = funName;
               }
        $scope.showDocument = function (args) {
           // args = args ? args : [$rootScope.dcName,$rootScope.functionality];
            var argumentsVlaue = args;
            if(!args){
                args = [$rootScope.dcName,$rootScope.functionality];
            }else{
		if($rootScope.DCDetails[args[0]]){
                $rootScope.DCDetails[args[0]].map(function(data){
                    if(data.functnal_nm.replace(/\s/g,'') == args[1]){
                        $rootScope.functionality = data.functnal_nm;
                    }

              });
		}
            }

            if ($scope.dcName == "") {
                //alert("please select dc");
                return;
            }

            if ($scope.functionality == "") {
                //alert("please select functionality");
                return;
            }
         
            if(args){
            var funName = funName? funName :  $rootScope.functionality;
            $rootScope.dcName=args[0];
            $rootScope.functionality='';
            $rootScope.functionality=funName;
            $rootScope.dcFunctionalities=[];
            if($rootScope.DCDetails[args[0]]){
            $rootScope.DCDetails[args[0]].map(function(data){
            $rootScope.dcFunctionalities.push(data.functnal_nm);
            });
	    }
            $scope.functionality=funName;
            if(!argumentsVlaue){
                $location.path("/home/"+$scope.dcName+"/"+$scope.functionality.replace(/\s/g,''));
            }
            }else{
            $rootScope.dcName=$scope.dcName;
            $rootScope.functionality=$scope.functionality;
                    $location.path("/home/"+$scope.dcName+"/"+$scope.functionality.replace(/\s/g,''));
            }
                        
            setTimeout(function(){ 
                jQuery("#toggling").addClass('row row-offcanvas row-offcanvas-left active');
                jQuery("#arrow-toggle").removeClass('arrow-toggle');
                jQuery('#arrow-toggle img').attr('src', 'img/expand.png');
                jQuery("#Form-elements").css("display", "none");
                jQuery("#back-selection").css("display", "block");

             }, 100);
   

        };

        jQuery('[data-toggle=offcanvas]').click(function () {

            if (jQuery('.sidebar-offcanvas').css('background-color') == 'rgb(255, 255, 255)') {

                jQuery('.list-group-item').attr('tabindex', '-1');

            } else {

                jQuery('.list-group-item').attr('tabindex', '');

            }

            if (jQuery("#toggling").attr('class') == "row row-offcanvas row-offcanvas-left") {
                jQuery("#toggling").addClass('row row-offcanvas row-offcanvas-left active');
                jQuery("#arrow-toggle").removeClass('arrow-toggle');
                jQuery('#arrow-toggle img').attr('src', 'img/expand.png');
                jQuery("#Form-elements").css("display", "none");
                jQuery("#back-selection").css("display", "block");
            } else {
                jQuery("#toggling").removeClass('active');
                jQuery("#arrow-toggle").addClass('arrow-toggle');
                jQuery('#arrow-toggle img').attr('src', 'img/collpase.png');
                jQuery("#Form-elements").css("display", "block");
                jQuery("#back-selection").css("display", "none");

            }



        });



    }])

  .controller('Header', ['$scope', '$http', '$location', '$rootScope', '$routeParams','$window','$timeout','commonService','urlService', function ($scope, $http, $location, $rootScope, $routeParams,$window,$timeout,commonService,urlService) {
       
       $scope.userGroupName = sessionStorage.ugName;
	$scope.userName = sessionStorage.userName;
	$scope.fName = sessionStorage.fName;
 	$scope.lName= sessionStorage.lName;
   

  	$scope.profile = function(){
        $location.path("/userprofile");
       }
 $scope.OpenInNewTab1396 = function() {
  var url ="http://deheremman3196:9010";
  var win = window.open(url, '_blank');
  win.focus();
  }

 $scope.OpenInNewTab1397 = function() {
  var url ="http://deheremman3197:9010";
  var win = window.open(url, '_blank');
  win.focus();
  }
       //favourites code start
       $scope.loadFavourites = function(){
        commonService.postServiceResponse(urlService.GET_FAVOURITES,{"username": sessionStorage.userName})
            .then(function(response){
                $scope.favourateList = response;
            },function(error){

            });
            }
        $scope.$on('ClickedOnFavourate',function(event,args){
            $scope.loadFavourites();
        })
        $scope.fnDeleteFavourate = function(functionalityName){ 
                $rootScope.selectedFavouriteDc = functionalityName;
                $('#deleteFavourateAlert').modal({backdrop: 'static',show:true});        
        }
        $rootScope.deleFavourate = function(){
            commonService.postServiceResponse(urlService.DELETE_FAVOURITE,{"username": sessionStorage.userName,"dcName":$scope.selectedFavouriteDc.dcName,"funName":$scope.selectedFavouriteDc.funName})
            .then(function(response){
                if($location.path().indexOf('home')>-1){
                    $rootScope.$broadcast('deletedFavourate',['']); 
                }else{
                    $location.path("/home/" +$scope.selectedFavouriteDc.dcName+"/"+$scope.selectedFavouriteDc.funName.replace(/\s/g,''));
                }
                $scope.loadFavourites();
            },function(error){

            });
            $('#deleteFavourateAlert').modal('hide');
        }
        $scope.$on('showAlert',function(event,args){
            $('#overFlowFavourateAlert').modal('show');
        });
        $scope.loadFavourites();
        //favourites code end
       $scope.fnLogout = function(){
         commonService.setData();
         sessionStorage.clear();
		   $("#logoutModel").modal('hide');

         $window.location.assign('#/login');
       }
	$scope.continueSession = function(){
	   $("#logoutModel").modal('hide');
	}

       $scope.goToPath=function(path){
        $rootScope.$broadcast('changeDrpValues',[path.dcName,path.funName]);
        $location.path("/home/"+path.dcName+"/"+path.funName.replace(/\s/g,''));
        }
       
    }]);

    