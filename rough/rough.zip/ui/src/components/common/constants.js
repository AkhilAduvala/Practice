angular.module('Authentication').constant('urlService', {

    ADFS_AUTH:'https://waalos.adidas.com:9002/usrcntrl/authenticateUser',

	UPLOADURL_CUBISCAN : 'https://waalos.int.api.3stripes.io/waalos/cubiscan/launchcubiscanLoader',
	UPLOADURL_CUBISCAN_LOADER : 'https://waalos.int.api.3stripes.io/waalos/cubiscanLoader/uploadFile',
	//UPLOADURL_CUBISCAN_LOADER : 'https://waalos.int.api.3stripes.io/waalos/cubiscanLoader/uploadFile',
	CUBISCAN_DOWNLOAD_ERRORS:'https://waalos.int.api.3stripes.io/waalos/wmsCntrl/downloadexcel?lotid=LID&jobcode=CBL',
	
	ASN_DELIVERY_DATE_CHOOSEFILE : 'https://waalos.int.api.3stripes.io/waalos/wmsCntrl/asndateupload',
	ASN_DELIVERY_DATE_UPLOADFILE : 'https://waalos.int.api.3stripes.io/waalos/file-processing/updshipdeliverydate/launchUploadfile',
	UPDATE_SHIPMENT_DELIVERY_DATE_DOWNLOAD_ERRORS: 'https://waalos.int.api.3stripes.io/waalos/wmsCntrl/downloadexcel?lotid=LID&jobcode=USADDL',

	SEARCH_BLOCKING_SESSIONS : 'https://waalos.int.api.3stripes.io/waalos/slotting/blockingsession?dcName=dName&userName=uName&pageNumber=pNumber&pageSize=pSize',
	KILL_BLOCKING_SESSIONS : 'https://waalos.int.api.3stripes.io/waalos/slotting/blockingsession',

	LAUNCH_DATE_CHANGER : 'https://waalos.int.api.3stripes.io/waalos/dateChanger/launchdatechanger',
	DATE_CHANGER_LOADER : 'https://waalos.int.api.3stripes.io/waalos/dateChangerLoader/uploadFile',
	DATECHANGE_DOWNLOAD_ERRORS:'https://waalos.int.api.3stripes.io/waalos/wmsCntrl/downloadexcel?lotid=LID&jobcode=DCL',
								 
	SEARCH_DIMENSIONS :  'https://waalos.int.api.3stripes.io/waalos/wmsCntrl/dimensiondtls?dcName=dName&userName=uName&uiSkuNmbr=skuNumber&pageNumber=pNumber&pageSize=pSize',
	UPDATE_DIMENSIONS : 'https://waalos.int.api.3stripes.io/waalos/wmsCntrl/dimensiondtls',
								             
	GET_HOLIDAYS_DATA : 'https://waalos.int.api.3stripes.io/waalos/wmsCntrl/holiday?dcName=dName&userName=uName&pageNumber=pNumber&pageSize=pSize',
	ADD_HOLIDAY : 'https://waalos.int.api.3stripes.io/waalos/wmsCntrl/holiday',
	MANAGE_HOLIDAYS : 'https://waalos.int.api.3stripes.io/waalos/wmsCntrl/holiday',

	GET_HOME_PAGE_DATA : 'https://waalos.adidas.com:9002/usrcntrl/getHomePageData',

	IMMEDIATE_NEEDS_DATA : 'https://waalos.int.api.3stripes.io/waalos/immediateNeeds/loadData', 
	IMM_NEEDS_LOADER_UPLOAD_FILE :  'https://waalos.int.api.3stripes.io/waalos/immNeedsLoader/uploadFile',
	IMMEDIATE_NEEDS_DOWNLOAD:'https://waalos.int.api.3stripes.io/waalos/wmsCntrl/downloadexcel?lotid=LID&jobcode=IML',

	DELETE_PICK_CLEANUP_TCKTS : 'https://waalos.int.api.3stripes.io/waalos/wmscleanUpCntrl/pickclnuptck',
	GET_PICK_CLEANUP_TCKTS_ALL : 'https://waalos.int.api.3stripes.io/waalos/wmscleanUpCntrl/pickclnuptck?dcName=dName&userName=uName&pageNumber=pNumber&pageSize=pSize',
	GET_PICK_CLEANUP_TCKTS : 'https://waalos.int.api.3stripes.io/waalos/wmscleanUpCntrl/searchPickclnuptck?dcName=dName&userName=uName&pickCntrlNum=pcNum',

	IP_GOAL_CHANGER : 'https://waalos.int.api.3stripes.io/waalos/wmsCntrl/ipgoals?dcName=dName&userName=uName&pageNumber=pNumber&pageSize=pSize',
	WMS_CNTRL_IP_GOAL_CHANGER : 'https://waalos.int.api.3stripes.io/waalos/wmsCntrl/ipgoals',

	SEARCH_MANIFEST_CARTONS : 'https://waalos.int.api.3stripes.io/waalos/inventoryCntrl/manifestcartdtls?dcName=dName&userName=uName&pickCartNbr=pkctNumber',
	DELETE_MANIFEST_CARTONS : 'https://waalos.int.api.3stripes.io/waalos/inventoryCntrl/manifestcartdtls',

	GENERATE_MASS_LOAD :  'https://waalos.int.api.3stripes.io/waalos/wmsCntrl/generateMassLoad',
	GET_ALL_SHIPVIA: 'https://waalos.int.api.3stripes.io/waalos/wms/wmsCntrl/getAllShipVia?dcName=dName&userName=uName',

    GET_PKT_PDF_ARCHIVE_DATA  : 'https://waalos.int.api.3stripes.io/waalos/slotting/pdfarchive?pickcntrlnmbr=pktCtr&dcName=dName',	
	GET_PKT_PDF_ARCHIVE  : 'https://waalos.int.api.3stripes.io/waalos/slotting/pdfarchive?dcName=dName&userName=uName&pageNumber=pNumber&pageSize=pSize&uiPktCtrlNbr=pktCtrlNbr&searchFlag=searchFlg',
	
	LAUNCH_PKT_PROFILE_LOADER : 'https://waalos.int.api.3stripes.io/waalos/pktprofile/launchpktProfileLoader',
	PICK_TICKET_PROGILE_UPLOADFILE : 'https://waalos.int.api.3stripes.io/waalos/pickTicketProfile/uploadFile',
	PKTPROFILE_DOWNLOAD_ERRORS:'https://waalos.int.api.3stripes.io/waalos/wmsCntrl/downloadexcel?lotid=LID&jobcode=PPL',

	INVENTORY_CNTRL_SEARCH_CARTS : 'https://waalos.int.api.3stripes.io/waalos/inventoryCntrl/unlockCartId?dcName=dName&userName=uName&pickCartNbr=pkctNumber',
	INVENTORY_CNTRL_UNLOCK_CART  : 'https://waalos.int.api.3stripes.io/waalos/inventoryCntrl/unlockCartId',

	GET_VIRTUAL_WAREHOUSE  : 'https://waalos.int.api.3stripes.io/waalos/inventoryCntrl/virtualwarehouse?dcName=dName&userName=uName',
    UPDATE_VIRTUAL_WAREHOUSE : 'https://waalos.int.api.3stripes.io/waalos/inventoryCntrl/virtualwarehouse',

	LAUNCH_RETAIL_RETURN_LOADER : 'https://waalos.int.api.3stripes.io/waalos/retailReturnsLoader/retailReturns',
	UPLOAD_RETAIL_RETURN_LOADER : 'https://waalos.int.api.3stripes.io/waalos/retailReturns/launchRetailReturn',
	GET_RETAIL_RETURN_LOADER:'https://waalos.int.api.3stripes.io/waalos/retailReturnsLoader/retailReturns?dcName=dName&userName=uName&pageNumber=pNumber&pageSize=pSize&searchVal=searchValue',
	DELETE_RETAIL_RETURN_LOADER:'https://waalos.int.api.3stripes.io/waalos/retailReturnsLoader/deleteIndividualCase',
	DELETE_RETAIL_RETURN_CASES:'https://waalos.int.api.3stripes.io/waalos/retailReturnsLoader/deleteCases',
	RETAIL_RETURNS_LOADER_ERRORS:'https://waalos.int.api.3stripes.io/waalos/wmsCntrl/downloadexcel?lotid=LID&jobcode=RRL',

	USER_GROUP_MGMT_DASHBOARD_DATA : 'https://waalos.adidas.com:9002/permissnCntrl/getUGDashboard',
	GET_USER_GROUP_DATA : 'https://waalos.adidas.com:9002/permissnCntrl/getUserGroupData',
	UPDATE_USER_GROUP_DATA : 'https://waalos.adidas.com:9002/permissnCntrl/updateUserGroup',
	ADD_USER_GROUP_DATA : 'https://waalos.adidas.com:9002/permissnCntrl/addNewUserGroup',
	DELETE_USER_GROUP_GRID_ROW : 'https://waalos.adidas.com:9002/permissnCntrl/deleteUserGroup',

	SEARCH_UGS : 'https://waalos.adidas.com:9002/permissnCntrl/searchUGS',
	USER_MGMT_ALL_USER_DATA : 'https://waalos.adidas.com:9002/usrcntrl/searchAllUserDetails',
    USER_MGMT_MODIFY_USER : 'https://waalos.adidas.com:9002/usrcntrl/modifyUser',
    USER_MGMT_DELETE_USER : 'https://waalos.adidas.com:9002/usrcntrl/deactivateUser',
    USER_MGMT_ADD_USER : 'https://waalos.adidas.com:9002/usrcntrl/addUser',
    USER_MGMT_FILTER_USER : 'https://waalos.adidas.com:9002/usrcntrl/searchUserByFilter',

    MASS_UPDATE_LOADER:'https://waalos.int.api.3stripes.io/waalos/inventoryCntrl/tjMassUpdate',//pradeep 9/1/18
	
	//Manual slotting
	UPLOADURL_MANUAL_SLOTTING : "https://waalos.int.api.3stripes.io/waalos/manualSlotting/uploadFile",
	MANUAL_SLOTTING_DOWNLOAD_ERRORS:'https://waalos.int.api.3stripes.io/waalos/wmsCntrl/downloadexcel?lotid=LID&jobcode=MSL',

	GET_WS_INVENTORY_RESRV_TRANS : 'https://waalos.int.api.3stripes.io/waalos/inventoryCntrl/getWSInventoryResrvTrans?dcName=dName&userName=uName',//pradeep 9/1/18
    GET_WS_INVENTORY_ACTIVE_TRANS : 'https://waalos.int.api.3stripes.io/waalos/inventoryCntrl/getWSInventoryActiveTrans?dcName=dName&userName=uName',//pradeep 9/1/18
    SYNC_All_ACTIVE_TRANS : 'https://waalos.int.api.3stripes.io/waalos/inventoryCntrl/syncAllActiveTrans',//pradeep 9/1/18
    SYNC_All_ACTIVE_TRANS_SPCAll : 'https://waalos.int.api.3stripes.io/waalos/inventoryCntrl/syncAllActiveTransSPCall'  ,//pradeep 9/1/18
    SYNC_All_RESRV_TRANS : 'https://waalos.int.api.3stripes.io/waalos/inventoryCntrl/syncAllResrvTrans',//pradeep 9/1/18
   	SYNC_All_RESRV_TRANS_SPCAll : 'https://waalos.int.api.3stripes.io/waalos/inventoryCntrl/syncAllResrvTransSPCall',//pradeep 9/1/18

	GET_NSNC_RULE : 'https://waalos.int.api.3stripes.io/waalos/wmsCntrl/nsncrule?dcName=dName&userName=uName',
	UPDATE_NSNC_RULE:'https://waalos.int.api.3stripes.io/waalos/wmsCntrl/nsncrule',

	//Job scheduler
    GET_JOB_SCHEDULER_DATA : 'https://waalos.int.api.3stripes.io/waalos/logisticsslotting/slotting/jobscheduler?dcName=dName&userName=uName&pageNumber=pNumber&pageSize=pSize',
    INVOKE_JOB_SCHEDULER : 'https://waalos.int.api.3stripes.io/waalos/logisticsslotting/slotting/invokejobscheduler?hostname=hname&jobscript=jscript',

	//slotting reports
	PRE_SLOT_ZONE_USAGE: "https://waalos.int.api.3stripes.io/waalos/logisticsreports/reports/preSlotZoneUsage?dcName=dName&userName=uName",
	MULTIPLE_ZONE_STYLES: "https://waalos.int.api.3stripes.io/waalos/logisticsreports/reports/multipleZoneStyles?dcName=dName&userName=uName",
	PIGEON_HOLE: "https://waalos.int.api.3stripes.io/waalos/logisticsreports/reports/pigeonHole?dcName=dName&userName=uName",
	WRONG_PRODUCT_IN_ZONE: "https://waalos.int.api.3stripes.io/waalos/logisticsreports/reports/wrongProductInZone?dcName=dName&userName=uName",
        SLOTING_DOWNLOAD_EXCEL:"https://waalos.int.api.3stripes.io/waalos/logistics/reports/downloadData",

	//outboud
	UPLOAD_OUTBOUND:'https://waalos.int.api.3stripes.io/waalos/outboundPrepLdr/launchOutboundPrepLdr',
	UPLOAD_OUTBOUND_PREP_LOADER : 'https://waalos.int.api.3stripes.io/waalos/outboundprep/uploadFile',
	GET_OUTBOUND_PREP_LOADER_VAS_CODES:'https://waalos.int.api.3stripes.io/waalos/outboundprep/vascode?dcName=dName&userName=uName&pageNumber=pNumber&pageSize=pSize',
	ADD_OUTBOUND_PREP_LOADER_VAS_CODE:'https://waalos.int.api.3stripes.io/waalos/outboundprep/vascode',
	DELETE_OUTBOUND_PREP_LOADER_VAS_CODES:'https://waalos.int.api.3stripes.io/waalos/outboundprep/vascode?vasCode=vCode&dcName=dName&userName=uName',
	OUTBOUND_PREP_LOADER_ERRORS:'https://waalos.int.api.3stripes.io/waalos/wmsCntrl/downloadexcel?lotid=LID&jobcode=OPL',
	
	//customer loader
    GET_ALL_CUSTOMERS:'https://waalos.int.api.3stripes.io/waalos/logisticscustomertool/custLoaderCtrl/getAllCustomers?dcName=dName&userName=uName',
	CUSTOMER_LOADER_CHOOSE_FILE : 'https://waalos.int.api.3stripes.io/waalos/customertool/custLoaderCtrl/uploadFile',
	CUSTOMER_LOADER_UPLOAD_FILE : 'https://waalos.int.api.3stripes.io/waalos/customerLoader/launchCustLdr',
	CUSTOMER_DOWNLOAD_ERRORS:'https://waalos.int.api.3stripes.io/waalos/wmsCntrl/downloadexcel?lotid=LID&jobcode=CUL',
	
	//fav
	GET_FAVOURITES :  "https://waalos.adidas.com:9002/permissnCntrl/getFavorites",
	ADD_FAVOURITE : "https://waalos.adidas.com:9002/permissnCntrl/addFavorite",
	DELETE_FAVOURITE : "https://waalos.adidas.com:9002/permissnCntrl/deleteFavorite",
	
	LM_WN_Drpdown : "https://waalos.int.api.3stripes.io/waalos/wmsCntrl/lmwmuser?dcName=dName&userName=uName",
	INSERT_LMWN_Data : "https://waalos.int.api.3stripes.io/waalos/wmsCntrl/lmwmuser",

	// manhattan user addition
    WM_USER_MGMT_ALL_USER_DATA:'https://waalos.int.api.3stripes.io/waalos/wmsCntrl/manhattanuser?dcName=dName&userName=uName&pageNumber=pNumber&pageSize=pSize',
	WM_ADD_USER_DATA:'https://waalos.int.api.3stripes.io/waalos/wmsCntrl/manhattanuser',
	WM_DELETE_USER_DATA:'https://waalos.int.api.3stripes.io/waalos/wmsCntrl/manhattanuser?dcName=dName&userName=uName&userId=empId',
	WM_SEARCH_USERS:'https://waalos.int.api.3stripes.io/waalos/wmsCntrl/searchmanhattanuser?dcName=dName&userName=uName&empId=emID&firstName=fName&lastName=lName',
	WM_ADD_USER_GENARATE:'https://waalos.int.api.3stripes.io/waalos/wmsCntrl/projecteduser',

	//ate slotting sj
		ATE_SLOTTING_SJ:'https://waalos.int.api.3stripes.io/waalos/logisticsslotting/ateSzSlotting/datasource?dcName=dName&userName=uName',
	ATE_SLOTTING_SJ_DELETE:'https://waalos.int.api.3stripes.io/waalos/logisticsslotting/ateSzSlotting/datasource?dcName=dName&userName=uName&grpType=gType',
	ATE_SLOTTING_SJ_DELETE_ALL:'https://waalos.int.api.3stripes.io/waalos/logisticsslotting/ateSzSlotting/taskdtls?dcName=dName&userName=uName',
	ATE_SLOTTING_SJ_RESET_DATASOURCES:'https://waalos.int.api.3stripes.io/waalos/logisticsslotting/ateSzSlotting/datasource',
	ATE_SLOTTING_SJ_REPORT_PRE_TASK_RELEASE:'https://waalos.int.api.3stripes.io/waalos/logisticsslotting/ateSzSlotting/taskdtls?dcName=dName&userName=uName&grpType=gType',
	ATE_SLOTTING_SJ_RUNSLOT:'https://waalos.int.api.3stripes.io/waalos/logisticsslotting/ateSzSlotting/invokeReleaseJob?hostname=hname&jobscript=jscript', 
	ATE_SLOTTING_SJ_RELESE_TASK:'https://waalos.int.api.3stripes.io/waalos/logisticsslotting/ateSzSlotting/releasetaskdtls?dcName=dName&userName=uName&grpType=gType',
	ATE_SLOTTING_SJ_RELESE_TASK_ADD:'https://waalos.int.api.3stripes.io/waalos/logisticsslotting/ateSzSlotting/getAisles?dcName=dName&userName=uName&grpType=gType&grpAttr=gAttr',
	ATE_SLOTTING_SJ_RELESE_TASK_LOWERGRID:'https://waalos.int.api.3stripes.io/waalos/logisticsslotting/ateSzSlotting/releasetask',
	ATE_SLOTTING_SJ_RELESE_TASK_CANCEL:'https://waalos.int.api.3stripes.io/waalos/logisticsslotting/ateSzSlotting/releasetask',
	ATE_SLOTTING_SJ_RELESE_TASK_GET:'https://waalos.int.api.3stripes.io/waalos/logisticsslotting/ateSzSlotting/releasetaskattrbt?dcName=Suzhou&userName=mallasoj&grpAttr=96&wrkZone=D1APP&wrkType=Deslot&aisles=01&dspSku=G90509 750L',
	ATE_SLOTTING_SJ_RUN_A_SLOT:'https://awaalos.int.api.3stripes.io/waalos/logisticsslotting/ateSzSlotting/invokeRunSlotJob?dcName=dName&grpType=gType',
	//ATE_SLOTTING_SJ_EDIT_GETFORECASTSOURCE:'https://waalos.int.api.3stripes.io/waalos/logisticsslotting/ateSzSlotting/forecastSource?dcName=dName&userName=uName&grpType=tempid',
	//ATE_SLOTTING_SJ_FORCAST_SOURCE_UPDATE:'https://waalos.int.api.3stripes.io/waalos/logisticsslotting/ateSzSlotting/forecastSource',
        ATE_SLOTTING_SJ_FORCAST_SOURCE_UPDATE:'https://waalos.int.api.3stripes.io/waalos/logistics/ateSzSlotting/forecastSource',
	ATE_SLOTTING_SJ_EDIT_GETFORECASTSOURCE:'https://waalos.int.api.3stripes.io/waalos/slotting/ateSzSlotting/forecastSource?dcName=dName&userName=uName&grpType=tempid',
	ATE_SLOTTING_SJ_RELESE_TASK_LOWERGRID_SEARCH:'https://waalos.int.api.3stripes.io/waalos/logisticsslotting/ateSzSlotting/releasetaskattrbt?dcName=dName&userName=uNamej&grpAttr=gType&wrkZone=gAttr&wrkType=WTypr&aisles=ailas&dspSku=dspNum',
	ATE_SLOTTING_SJ_RELESE:'https://waalos.int.api.3stripes.io/waalos/logisticsslotting/ateSzSlotting/invokeReleaseJob',

	ATE_SLOTTING_SJ_ZONE:'https://waalos.int.api.3stripes.io/waalos/logisticsslotting/ateSzSlotting/zone?dcName=dName&userName=uName',
	ATE_SLOTTING_SJ_ZONE_ADD:'https://waalos.int.api.3stripes.io/waalos/logisticsslotting/ateSzSlotting/zone',
	ATE_SLOTTING_SJ_ZONE_ASSOCATE:'https://waalos.int.api.3stripes.io/waalos/logisticsslotting/ateSzSlotting/associatezone?dcName=dName&userName=uName&grpAttr=zoneid',
	ATE_SLOTTING_SJ_ZONE_ASSOCATE_UPDATE:'https://waalos.int.api.3stripes.io/waalos/logisticsslotting/ateSzSlotting/associatezone',
	ATE_SLOTTING_SJ_ZONE_DELETE:'https://waalos.int.api.3stripes.io/waalos/logisticsslotting/ateSzSlotting/zone?dcName=dName&userName=uNamej&zoneId=zoneid',
	ATE_SLOTTING_SJ_ZONE_PROB_DATA:'https://waalos.int.api.3stripes.io/waalos/logisticsslotting/ateSzSlotting/prodtype?dcName=dName&userName=uName',
	ATE_SLOTTING_SJ_ZONE_PROB_DATA_UPDATE:'https://waalos.int.api.3stripes.io/waalos/logisticsslotting/ateSzSlotting/prodtype',
	ATE_SLOTTING_SJ_SLOTTING_GROUPS_GET:'https://waalos.int.api.3stripes.io/waalos/logisticsslotting/ateSzSlotting/getSltGrpDtls?dcName=dName&userName=uName&grpType=gType',
	ATE_SLOTTING_SJ_SLOTTING_GROUPS_EDIT:'https://waalos.int.api.3stripes.io/waalos/logisticsslotting/ateSzSlotting/sltgrprules?dcName=dName&userName=uName&grpType=gType&gtpAttr=grpAttr',
	ATE_SLOTTING_SJ_SKU_GET:'https://waalos.int.api.3stripes.io/waalos/logisticsslotting/ateSzSlotting/dspsku?dcName=dName&userName=uName&grpType=gType',
	ATE_SLOTTING_SJ_ADD_SKU:'https://waalos.int.api.3stripes.io/waalos/logisticsslotting/ateSzSlotting/dspsku',
	//ATE_SLOTTING_SJ_DELETE_SKU:'https://waalos.int.api.3stripes.io/waalos/logisticsslotting/ateSzSlotting/dspsku?dcName=dName&userName=uName&grpType=gType&skuId=skuid',
	 ATE_SLOTTING_SJ_DELETE_SKU:'https://waalos.int.api.3stripes.io/waalos/logistics/ateSzSlotting/dspsku?dcName=dName&userName=uName&grpType=gType&skuId=skuid',
         ATE_SLOTTING_SJ_ITEM_GROUP:'https://waalos.int.api.3stripes.io/waalos/logisticsslotting/ateSzSlotting/getItemGrpDtls?dcName=dName&userName=uName',
	//ATE_SLOTTING_SJ_UPDATE_GROUP:'https://waalos.int.api.3stripes.io/waalos/logisticsslotting/ateSzSlotting/sltgrprules',
        ATE_SLOTTING_SJ_UPDATE_GROUP:'https://waalos.int.api.3stripes.io/waalos/logistics/ateSzSlotting/sltgrprules',
        ATE_SLOTTING_SJ_ZONE_DOWNLOAD:'https://waalos.int.api.3stripes.io/waalos/logisticsslotting/ateSzSlotting/download/releaseData',

	//ate slotting TJ
	ATE_SLOTTING_TJ_GET_ZONES_DATA:'https://waalos.int.api.3stripes.io/waalos/logisticsslotting/slottingTJ/zones?dcName=dName&userName=uName',
	ATE_SLOTTING_TJ_GET_ZONE_LOCATION_DATA:'https://waalos.int.api.3stripes.io/waalos/logisticsslotting/slottingTJ/zoneloc?dcName=dName&userName=uName',
	ATE_SLOTTING_TJ_ZONE_UPDATE:'https://waalos.int.api.3stripes.io/waalos/logisticsslotting/slottingTJ/zones',
	ATE_SLOTTING_TJ_LOCATION_UPDATE:'https://waalos.int.api.3stripes.io/waalos/logisticsslotting/slottingTJ/zoneloc',
	ATE_SLOTTING_SJ_GET_ZONES_AUTOMATIC_LOC_DATA:'https://waalos.int.api.3stripes.io/waalos/logisticsslotting/slottingTJ/zoneauto?dcName=dName&userName=uName',
	ATE_SLOTTING_SJ_UPDATE_ZONE_AUTOMATIC_LOC:'https://waalos.int.api.3stripes.io/waalos/logisticsslotting/slottingTJ/zoneauto?dcName=dName',
	ATE_SLOTTING_TJ_GET_DATASOURCE_DETAILS : "https://waalos.int.api.3stripes.io/waalos/logisticsslotting/slottingTJ/tjdatasource?dcName=dName&userName=uName",
	RESET_DATA_SOURCE : "https://waalos.int.api.3stripes.io/waalos/logisticsslotting/slottingTJ/tjdatasource",
	ATE_SLOTTING_TJ_EDIT_DATASOURCE : "https://waalos.int.api.3stripes.io/waalos/logisticsslotting/slottingTJ/onEditDataSourcedetails?dcName=dName&userName=uName&grpType=gType",
	DATASOURCE_GENERATE_EDIT_SCREEN : "https://waalos.int.api.3stripes.io/waalos/logisticsslotting/slottingTJ/onGenerateOfEditScreen?dcName=dName&userName=uName",
	EDIT_SCREEN_SAVE : "https://waalos.int.api.3stripes.io/waalos/logisticsslotting/slottingTJ/onSaveOfEditScreen",
	RUN_A_SLOT : "https://waalos.int.api.3stripes.io/waalos/logisticsslotting/slottingTJ/runslot?dcName=dName&userName=uName",
	ADD_DESLOT : "https://waalos.int.api.3stripes.io/waalos/logisticsslotting/slottingTJ/deandnewslot?dcName=dName&userName=uName&workType=slottype",
	ADD_NEW_SLOT : "https://waalos.int.api.3stripes.io/waalos/logisticsslotting/slottingTJ/deandnewslot?dcName=dName&userName=uName&workType=slottype",
	DESLOT_RELEASE : "https://waalos.int.api.3stripes.io/waalos/logisticsslotting/slottingTJ/deandnewslot", 
	NEW_SLOT_RELEASE : "https://waalos.int.api.3stripes.io/waalos/logisticsslotting/slottingTJ/deandnewslot",

	//prewave report
    GET_PREWAVE_NUMBERS : "https://waalos.int.api.3stripes.io/waalos/logisticsprewave/prewave/getPWNumbers?dcName=dName&username=uName",
	GET_BASE_INFO_DETAILS : "https://waalos.int.api.3stripes.io/waalos/prewave/getBaseInfoDtls",
	GET_REPLEN_DETAILS : "https://waalos.int.api.3stripes.io/waalos/logisticsprewave/prewave/getReplenDtls",
	GET_DIM_ISSUES_DETAILS : "https://waalos.int.api.3stripes.io/waalos/logisticsprewave/prewave/getDimIssuesDtls",
	GET_MISSING_INV_DETAILS  : "https://waalos.int.api.3stripes.io/waalos/logisticsprewave/prewave/getMissingInvDtls",
	GET_TRANSPLAN_DETAILS : "https://waalos.int.api.3stripes.io/waalos/logisticsprewave/prewave/getTransplanDtls",
	GET_WAVE_PLAN_DETAILS : "https://waalos.int.api.3stripes.io/waalos/logisticsprewave/prewave/getWaveplanDtls",
	NO_PERM_PROFILE_DETAILS  : "https://waalos.int.api.3stripes.io/waalos/logisticsprewave/prewave/noPermProfileDtls",
	GET_MANIFEST_DATA : "https://waalos.int.api.3stripes.io/waalos/logisticsprewave/prewave/getManifest",
	GET_ESTIMATIONS : "https://waalos.int.api.3stripes.io/waalos/prewave/getEstimations",
    GET_PREWAVE_CLEAR_CACHE:"https://waalos.int.api.3stripes.io/waalos/logisticsprewave/prewave/prewaveClearCache",
    GET_PREWAVE_DOWNLOAD_NOPREM:"https://waalos.int.api.3stripes.io/waalos/logisticsprewave/prewave/downloadData",
	GET_PIECE_PICK_DETAILS:"https://waalos.int.api.3stripes.io/waalos/prewave/piecePick",
	GET_INT2_DETAILS:"https://waalos.int.api.3stripes.io/waalos/prewave/int2",
	GET_ESTIMATIONS_DETAILS: "https://waalos.int.api.3stripes.io/waalos/prewave/getEstimationDtls",
	GET_PREPACKVOLUMEISSUES: "https://waalos.int.api.3stripes.io/waalos/prewave/getPrePackVolumeIssues",
	GET_PREPACKORDERQUANTITYISSUES: "https://waalos.int.api.3stripes.io/waalos/prewave/getPrePackOrderQuantityIssues",
	GET_PREPACKORDERSIZEISSUES: "https://waalos.int.api.3stripes.io/waalos/prewave/getPrePackOrderSizeIssues",

	//upload crd 
	UPDATECRD_DOWNLOAD_ERRORS:"https://waalos.int.api.3stripes.io/waalos/wmsdatacntrl/downloadUpdateCrd?lotid=LID&jobcode=UCR",
	UPLOADURL_UPLOADCRD:"https://waalos.int.api.3stripes.io/waalos/updateCrdLdr/launchUpdateCrd",
	UPLOADURL_UPLOADCRD_LOADER:"https://waalos.int.api.3stripes.io/waalos/wmsdatacntrl/uploadUpdateCrdFile",
	
		
    //B-grade tool
	SEARCH_BGRADE_BARCODE:"https://waalos.int.api.3stripes.io/waalos/wmsextCntrl/bgradelabel?dcName=dName&userName=uName&barCode=barcode&printerIp=printeripnum&printerPort=printerport",
	BGRADE_PRINT_LABEL:"https://waalos.int.api.3stripes.io/waalos/wmsextCntrl/printLabel",
	BGRADE_THREE_GRID_DATA:"https://waalos.int.api.3stripes.io/waalos/wmsextCntrl/bgradeselectsize?style=styleid&barcode=BarCode",

	//bgrade master data
	BGRADEMASTER_CHOOSE_FILE:"https://waalos.int.api.3stripes.io/waalos/wmsdatacntrl/initialdataloader",
	BGRADEMASTER_DOWNLOAD_FILE:"https://waalos.int.api.3stripes.io/waalos/wmsdatacntrl/downloadfulldata?jobcode=loaderName",

	// Airtcle dim
	SEARCH_ARTICLE_DIMENSIONS:"https://waalos.int.api.3stripes.io/waalos/wmsextCntrl/getarticleDimsskudtls?dcName=dName&userName=uName&pageNumber=pNumber&pageSize=pSize&style=aiticleNum",
	COPY_ARTICLE_DIMENSIONS:"https://waalos.int.api.3stripes.io/waalos/wmsextCntrl/updatearticledimsdtls",
	
	//Wave buddy
	WAVE_BUDDY_UPDATE : "https://waalos.int.api.3stripes.io/waalos/wavebuddy/update",
	WAVE_BUDDY_DROP_DOWN : "https://waalos.int.api.3stripes.io/waalos/wavebuddy/getSLDData",	


	// STO Label Creator
	STO_LABEL_PRINT : "https://waalos.int.api.3stripes.io/waalos/stolabelcreator/printlabel",
	
	//Footlocker Label Reprint 
	FOOTLOCKER_GET_SKU : "https://waalos.int.api.3stripes.io/waalos/wmsextCntrl/footLockerLabel?dcName=dName&userName=uName&caseNbr=cNbr",
	FOOTLOCKER_PRINT : "https://waalos.int.api.3stripes.io/waalos/wmsextCntrl/printfootprintlabel",

	//PickCart Reprint
	PICKCART_REPRINT : "https://waalos.int.api.3stripes.io/waalos/wmsextCntrl/printpickcartlabel",

	//Supress EDI
	GET_SUPRESS_DATA : "https://waalos.int.api.3stripes.io/waalos/wmsextCntrl/supressEdi?dcName=dName&userName=uName&loadNbr=lNbr",
	SUPRESS_EDI : "https://waalos.int.api.3stripes.io/waalos/wmsextCntrl/supressEdi",

	
	//Load Control
	SEARCH_LOAD_CONTROL:"https://waalos.int.api.3stripes.io/waalos/loadControl/getLoadData?dcName=dName&userInput=userinput&userName=uName",
    CHECK_PALLET_LOAD_CONTROL:"https://waalos.int.api.3stripes.io/waalos/loadControl/checkPallet?dcName=dName&palletId=palletID&userName=uName&pageSize=pSize&pageNumber=pNumber",
    LOAD_CONTROL_BIG:"https://waalos.int.api.3stripes.io/waalos/loadControl/SWCData?dcName=dName&loadNbr=loadnum&swc=swcnum&userName=uName&pageSize=pSize&pageNumber=pNumber",
    LOAD_CONTROL_SMALL:"https://waalos.int.api.3stripes.io/waalos/loadControl/palletLoc?dcName=dName&loadNbr=loadnum&swc=swcnum&userName=uName&pageSize=pSize&pageNumber=pNumber",
    LOAD_CONTROL_SWC:"https://waalos.int.api.3stripes.io/waalos/loadControl/checkPalletSWC?dcName=dName&swc=swcnum&userName=uName&pageSize=pSize&pageNumber=pNumber",
    LOAD_CONTROL_PRINT:"https://waalos.int.api.3stripes.io/waalos/loadControl/printlabel",

	//User Profile
	USER_PROFILE_PRINTERS:"https://waalos.adidas.com:9002/usrcntrl/printerAllDtls?userName=uName",
	USER_PROFILE_SAVE_PRINTER:"https://waalos.adidas.com:9002/usrcntrl/setprinterDtls",

	//printer details
	DEFAULT_PRINTERS:"https://waalos.adidas.com:9002/usrcntrl/dcprinterDtls?dcName=dName&userName=uName",
	PRINTER_LIST:"https://waalos.adidas.com:9002/usrcntrl/printerDtls?dcName=dName",

    //Print Tote LPN
	PRINT_TOTE_LPN : "https://waalos.int.api.3stripes.io/waalos/wmsextCntrl/printToteLpn",

	//Reprint LPN
	REPRINT_LPN : "https://waalos.int.api.3stripes.io/waalos/wmsextCntrl/reprintLpn",

	
       //Location Update
	LOCATION_UPDATE_GET_lOCATIONCLASS:"https://waalos.int.api.3stripes.io/waalos/locationBuddy/locations?dcName=dName&userName=uName&locType=LocType&locationClass=LocationClass&area=Area&zone=Zone&workArea=workarea&aisle=Aisle&bay=Bay&level=Level&action=Action",
	LOCATION_UPDATE_GET_FINAL_GRID:"https://waalos.int.api.3stripes.io/waalos/locationBuddy/locationByFilter?dcName=dName&userName=uName&locationClass=LocationClass&area=Area&zone=Zone&workArea=workarea&aisle=Aisle&bay=Bay&level=Level&action=Action&position=Position&pageNumber=pNumber&pageSize=pSize",
	LOCATION_UPDATE_GET_LOCATIONBARCODE:"https://waalos.int.api.3stripes.io/waalos/locationBuddy/locationByBrcd?dcName=dName&userName=uName&locBrcd=locBarcode&action=Action",
	UPDATE_LOCATIONS_PUT_LOCATIONBARCODE:"https://waalos.int.api.3stripes.io/waalos/locationBuddy/updateLocation",
	UPDATE_LOCATIONS_GET_PICKLOCATIONS:"https://waalos.int.api.3stripes.io/waalos/locationBuddy/pickLocAssignZone?userName=uName&dcName=dName&workArea=workarea",
	UPDATE_LOCATIONS_PUT_ENABLE_DISABLE:"https://waalos.int.api.3stripes.io/waalos/locationBuddy/enableDisableLoc",
        LOCATION_UPDATE_DOWNLOAD_ERRORS:"https://waalos.int.api.3stripes.io/waalos/locationBuddy/download/locationData?dcName=dName&userName=uName&locationClass=LocationClass&area=Area&zone=Zone&workArea=workarea&aisle=Aisle&bay=Bay&level=Level&action=Action&position=Position&jobcode=jcodeId",
	LOCATION_ENABLE_DISABLE_DOWNLOAD_ERRORS:"https://waalos.int.api.3stripes.io/waalos/locationBuddy/download/locationData?dcName=dName&userName=uName&locationClass=LocationClass&area=Area&zone=Zone&workArea=workarea&aisle=Aisle&bay=Bay&level=Level&action=Action&position=Position&jobcode=jcodeId",
	
	//Location cleanup buddy
	LOCATION_CLEANUP_BUDDY:"https://waalos.int.api.3stripes.io/waalos/locationBuddy/cleanup",

	//SKU Profiling
	UPDATE_SKU_PROFILING : "https://waalos.int.api.3stripes.io/waalos/wmsextCntrl/skuProfiling",
	GET_PRINTER_LIST : "https://waalos.adidas.com:9002/usrcntrl/printerDtls?dcName=dName",

    //Pick by data https
	PICKBY_DATE_GET_FILTERS_DATA:"https://waalos.int.api.3stripes.io/waalos/pickByDate/filters?dcName=dName&userName=uName",
	PICKBY_DATE_GET_TOSHIP_UNITS:"https://waalos.int.api.3stripes.io/waalos/pickByDate/toShipUnits?dcName=dName&userName=uName",
	PICKBY_DATE_GET_MARKETS:"https://waalos.int.api.3stripes.io/waalos/pickByDate/toShipUnitDtls?dcName=dName&userName=uName&market=marKet",
	PICKBY_DATE_GET_FILTERS_GRID:"https://waalos.int.api.3stripes.io/waalos/pickByDate/gridData",
	PICKBY_DATE_POST_FILTERS_GRID:"https://waalos.int.api.3stripes.io/waalos/pickByDate/gridDataDetails",
	PICKBY_DATE_GET_MARKED_UNITS:"https://waalos.int.api.3stripes.io/waalos/pickByDate/markedUnits?dcName=dName&userName=uName&pageSize=pSize&pageNumber=pNumber",
	PICKBY_DATE_GET_SHIPED_UNITS:"https://waalos.int.api.3stripes.io/waalos/pickByDate/shippedUnits?dcName=dName&userName=uName&pageSize=pSize&pageNumber=pNumber",
	PICKBY_DATE_POST_MASK_MARK:"https://waalos.int.api.3stripes.io/waalos/pickByDate/massMark",
	PICKBY_DATE_POST_CLEAR_SETS:"https://waalos.int.api.3stripes.io/waalos/pickByDate/clearSets",
	PICK_BY_DATE_UPDATE:"https://waalos.int.api.3stripes.io/waalos/pickByDate/clearSets",
	PICK_BY_DATE_LOADER_CHOOSE_FILE:"https://waalos.int.api.3stripes.io/waalos/wmsdatacntrl/uploadPickByDateFile",
	PICK_BY_DATE_LOADER_UPLOAD_FILE:"https://waalos.int.api.3stripes.io/waalos/pickByDateLdr/launchPickByDate",
	PICKBYDATE_DOWNLOAD_ERRORS:"https://waalos.int.api.3stripes.io/waalos/wmsdatacntrl/downloadPickByDate?lotid=LID&jobcode=PBD",

	//wave failure
	
	GET_WAVE_FAILURE_DETAILS : "https://waalos.int.api.3stripes.io/waalos/wmsextCntrl/wavefailuredtls?dcName=dName&userName=uName&pageNumber=pNumber&pageSize=pSize&waves=wavenum",
	UPDATE_Wave_FAILURE : "https://waalos.int.api.3stripes.io/waalos/wmsextCntrl/updatewavefailure",
	
	//ip comrsial invoice
	CHECK_SHIPMENTS : "https://waalos.int.api.3stripes.io/waalos/crossBrdrFunctions/checkShipments?dcName=dName&userName=uName&shipments=sList&pageSize=pSize&pageNumber=pNumber&pageReq=pFlag",
	UPDATE_SHIPMENTS:"https://waalos.int.api.3stripes.io/waalos/crossBrdrFunctions/updateShipments",
 
    //sortation wave
	SORTATION_WAVE_DROPDOWN:"https://waalos.int.api.3stripes.io/waalos/returnsSortation/seasons?dcName=dName&userName=uName",
	SORTATION_WAVE_GET_DEMAND:"https://waalos.int.api.3stripes.io/waalos/returnsSortation/demandTask?minNbrAppUnits=minNbrAppNum&minNbrFtwUnits=minNbrFtwNum&maxNbrOfUnits=maxNbrUnitNum&userName=uName&dcName=dName&pageSize=pSize&pageNumber=pNumber",
	SORTATION_WAVE_GET_STANDARED:"https://waalos.int.api.3stripes.io/waalos/returnsSortation/standardCase?minNbrAppUnits=minNbrAppNum&minNbrFtwUnits=minNbrFtwNum&fullCaseOnly=fullcaseBoolean&dcName=dName&userName=uName&pageNumber=pNumber&pageSize=pSize",
	SORTATION_WAVE__DEMAND_POST_CREATE_TASK:"https://waalos.int.api.3stripes.io/waalos/returnsSortation/createTask",
        SORTATION_WAVE_GET_CLEANUP_TASK:"https://waalos.int.api.3stripes.io/waalos/returnsSortation/cleanUpTask?maxNbrOfUnits=maxcleanupTask&firstReceivedDate=datecleanupTask&seasons=seasonsCleanupTask&userName=uName&dcName=dName&pageSize=pSize&pageNumber=pNumber",
	
	//location cleanup bdc
        LOCATION_CLEANUP_GET_COUNT:"https://waalos.int.api.3stripes.io/waalos/locationBuddy/getLcnClnUpCnt?dcName=dName&userName=uName&cleanUpDate=date&functionality=functionName",
	LOCATION_CLEANUP_PUT_BOTH:"https://waalos.int.api.3stripes.io/waalos/locationBuddy/updateLcnClnUp",
	
	//replenshment list
        GET_REPLENSHMENT_LIST:"https://waalos.int.api.3stripes.io/waalos/wmsextCntrl/getreplenishment?userName=uName&pageNumber=pNumber&pageSize=pSize&dcName=dName",
	DOWNLOAD_REPLENSHMENT_LIST:"https://waalos.int.api.3stripes.io/waalos/wmsextCntrl/downloadreplenishment?jobcode=jbcode&dcname=dName",
	
	//infodc
	INFO_DC_SCRIPT_GET_DATA_WMSERVER:"https://waalos.int.api.3stripes.io/waalos/wmsextCntrl/getinfoDcWmsDtls?functionality=funname&searchValue=searchval&userName=uName&pageNumber=pNumber&pageSize=pSize",
	INFO_DC_SCRIPT_GET_DATA:"https://waalos.int.api.3stripes.io/waalos/wmsextCntrl/getinfoDcGenDtls?functionality=funname&userName=uName&pageNumber=pNumber&pageSize=pSize",
	
	//Dim update
	DIM_UPDATE_GET_DATA:"https://waalos.int.api.3stripes.io/waalos/wmsextCntrl/dimStgData?userName=uName&pageSize=pSize&pageNumber=pNumber&region=regName",
	DIM_UPDATE_RUN_JOB:"https://waalos.int.api.3stripes.io/waalos/scheduler/invokeDimUpdate",
	//sku marking
	SKUMARKING_VIEW_MARKED:"https://waalos.int.api.3stripes.io/waalos/wmsadd/markedSkus?userName=uName&dcName=dName&pageSize=pSize&pageNumber=pNumber",
	SKUMARKING_MS_CAPACITY:"https://waalos.int.api.3stripes.io/waalos/wmsadd/msCapacity?userName=uName&dcName=dName",
	SKUMARKING_TOP_SKUS:"https://waalos.int.api.3stripes.io/waalos/wmsadd/topSkus?userName=uName&dcName=dName&fromWeek=fweek&toWeek=tweek&pageSize=pSize&pageNumber=pNumber",
	SKUMARKING_TOP_SKUS_UPDATE:"https://waalos.int.api.3stripes.io/waalos/wmsadd/markSkus ",
	UPLOADURL_QULITYSKUS_UPLOAD:"https://waalos.int.api.3stripes.io/waalos/markSku/loadData",
	UPLOADURL_QULITYSKUS_CHOOSE:"https://waalos.int.api.3stripes.io/waalos/wmsadd/uploadSkuMarkFile",
	//Budget Capacity
	BUDGET_CAPACITY_GET_DATA: "https://waalos.int.api.3stripes.io/waalos/wmsadd/getBudgetData?dcName=dName&userName=uName&year=bYear",
	BUDGET_CAPACITY_DATA_UPDATE : "https://waalos.int.api.3stripes.io/waalos/wmsadd/saveBudgetData",
	GET_USER_DETAILS: "https://waalos.int.api.3stripes.io/waalos/wmsadd/getUsrDtls?dcName=dName&userName=uName",
	DEMAND_FORECAST_CHOOSE_FILE: "https://waalos.int.api.3stripes.io/waalos/wmsadd/uploadDemandForecastFile",
	DEMAND_FORECAST_UPLOAD_FILE: "https://waalos.int.api.3stripes.io/waalos/demandforecast/launchdemandforecast",
	DEMAND_FORECAST_DOWNLOAD_EXCEL: "https://waalos.int.api.3stripes.io/waalos/wmsadd/downloadexcel?lotid=LID&jobcode=jCode&dcname=dName",
	DEMAND_FORECAST_SEARCH_Data: "https://waalos.int.api.3stripes.io/waalos/wmsadd/getjobstatus?userName=uName&pageNumber=pNumber&pageSize=pSize&fromDate=fDate&toDate=tDate&searchCriteria=sCriteria&lotId=jobId",
	
	//Appointment File Upload
	APPOINTMENT_CHOOSE_FILE: "https://waalos.int.api.3stripes.io/waalos/uploadAppointmentFile/uploadFile/handleFileUpload",
	APPOINTMENT_FILE_ERRORS:'https://waalos.int.api.3stripes.io/waalos/wmsCntrl/downloadexcel?lotid=LID&jobcode=APU',

	//ATE Sea Feature
	ATE_SLOTTING_SZ_GET_DATASOURCE_DETAILS : "https://waalos.int.api.3stripes.io/waalos/slotting/ateSEASlotting/getDataSourceDetails?dcName=dName&userName=uName",
	RUN_A_SLOT_SZ : "https://waalos.int.api.3stripes.io/waalos/slotting/ateSEASlotting/runAslot?dcName=dName&userName=uName", 
	PH_ATE_SLOTTING:'https://waalos.int.api.3stripes.io/waalos/slotting/ateSEASlotting/saveSlottingMenu?dcName=dName&userName=uName&grpType=80&slotSelected=AS',
	HK_ATE_SLOTTING:'https://waalos.int.api.3stripes.io/waalos/slotting/ateSEASlotting/saveSlottingMenuforHK?dcName=dName&userName=uName&zone=uZone&prodSelected=uProdSelected&slotSelected=uSlotSelected&grpType=80',
	TW_ATE_SLOTTING:'https://waalos.int.api.3stripes.io/waalos/slotting/ateSEASlotting/saveSlottingMenuforTW?dcName=dName&userName=uName&group=uGroup&slotSelected=uSlotSelected&grpType=80',
	ADD_DESLOT_SZ : "https://waalos.int.api.3stripes.io/waalos/slotting/ateSEASlotting/addDeSlotAndNewSlot?dcName=dName&userName=uName&workType=slottype",
	ADD_NEW_SLOT_SZ : "https://waalos.int.api.3stripes.io/waalos/slotting/ateSEASlotting/addDeSlotAndNewSlot?dcName=dName&userName=uName&workType=slottype",
	ATE_SLOTTING_REJECT_LIST: "https://waalos.int.api.3stripes.io/waalos/slotting/ateSEASlotting/rejectListDetails?dcName=dName&userName=uName",
	DESLOT_RELEASE_SZ : "https://waalos.int.api.3stripes.io/waalos/slotting/ateSEASlotting/releaseDeSlotOrNewSlot", 
	NEW_SLOT_RELEASE_SZ : "https://waalos.int.api.3stripes.io/waalos/slotting/ateSEASlotting/releaseDeSlotOrNewSlot",

	//customer sku upload
	UPLOADURL_CUST_SKU : 'https://waalos.int.api.3stripes.io/waalos/file-processing/customersku/launchcustomerSkuUpload',
	CUSTOMER_SKU_UPLOAD : 'https://waalos.int.api.3stripes.io/waalos/wms/CustomerSKUUpload/uploadFile',

	//Tracking update
	TRACKING_UPDATE : 'https://waalos.int.api.3stripes.io/waalos/wms/trackingUpdate/uploadFile',
	UPLOADURL_TRACKING : 'https://waalos.int.api.3stripes.io/waalos/file-processing/trackingUpdate/launchTrackingUpdate',
	
	//pick ticket upload
	PICK_TICKET_UPLOAD_CHOOSEFILE : "https://waalos.int.api.3stripes.io/waalos/wmsadd/pickTicketUploadFile",
	PICK_TICKET_UPLOAD_UPLOADFILE : "https://waalos.int.api.3stripes.io/waalos/file-processing/pktupload/launchpktUploadLoader",
	PKTUPLOAD_DOWNLOAD_ERRORS: "https://waalos.int.api.3stripes.io/waalos/wmsadd/downloadexcel?lotid=LID&jobcode=PUL",

	
	//clear consolidation Locations	
	GET_LOCATION_DETAILS: "https://waalos.int.api.3stripes.io/waalos/wmsadd/clearLocationDtls?dcName=dName&userName=uName&pageNumber=pNumber&pageSize=pSize&locationBrcds=barcode",
	UPDATE_LOCATION_DETAILS: "https://waalos.int.api.3stripes.io/waalos/wmsadd/clearConsolidationLocations",

	//Load Plan Upload
	LOAD_PLAN_UPLOAD: "https://waalos.int.api.3stripes.io/waalos/wms/loadPlanUpload/uploadFile",
	LOAD_PLAN_UPLOAD_FILE: "https://waalos.int.api.3stripes.io/waalos/file-processing/loadPlan/launchLoadPlanner",
	LOADPLAN_DOWNLOAD_ERRORS:'https://waalos.int.api.3stripes.io/waalos/wmsCntrl/downloadexcel?lotid=LID&jobcode=LPU',

	//Ecom Upload
	ECOM_UPLOAD: 'https://waalos.int.api.3stripes.io/waalos/wms/ecomUpload/submit',
	ECOM_DOWNLOAD_EXCEL: 'https://waalos.int.api.3stripes.io/waalos/wms/wmsCntrl/ecomExcel?lotid=LID &jobcode=EPL',

	 //SZ1 API
	ATE_SLOTTING_SZ_DS:'https://waalos.int.api.3stripes.io/waalos/ateslotting/ateSlottingService/dataSource?dcName=dName&userName=uName',
	ATE_SLOTTING_SZ1_ZONE:'https://waalos.int.api.3stripes.io/waalos/ateslotting/ateSlottingService/zone?dcName=dName&userName=uName',
	ATE_SLOTTING_SZ1_ZONE_ADD:'https://waalos.int.api.3stripes.io/waalos/ateslotting/ateSlottingService/zone',
	ATE_SLOTTING_UPLD_FRCST: 'https://waalos.int.api.3stripes.io/waalos/ateslotting/ateSlottingService/uploadForecastData',
	ATE_SLOTTING_SZ_REJECT_LIST:'https://waalos.int.api.3stripes.io/waalos/ateslotting/ateSlottingService/rejectList?dcName=dName&userName=uName&lotId=ulotid',
	ATE_SLOTTING_RUN_A_SLOT:'https://waalos.int.api.3stripes.io/waalos/ateslotting/ateSlottingService/performAssignment?dcName=dName&userName=uName&lotId=ulotid&grpType=96',
	ATE_SLOTTING_SJ_SLOTTING_GROUPS_GET_SZ1:'https://waalos.int.api.3stripes.io/waalos/ateslotting/ateSlottingService/getSltGrpDtls?dcName=dName&userName=uName&grpType=gType',
	ATE_SLOTTING_SZ_THRESHOLD_DATA_UPDATE: 'https://waalos.int.api.3stripes.io/waalos/ateslotting/ateSlottingService/updateThresholdConfigValue?dcName=dName&userName=uName&thresholdValue=uThres',
	ATE_SLOTTING_SZ1_ZONE_ASSOCATE:'https://waalos.int.api.3stripes.io/waalos/ateslotting/ateSlottingService/associatezone?dcName=dName&userName=uName&grpAttr=zoneid',
	ATE_SLOTTING_SZ_ZONE_ASSOCATE_UPDATE:'https://waalos.int.api.3stripes.io/waalos/ateslotting/ateSlottingService/associatezone',
	ATE_SLOTTING_SZ_ZONE_DELETE:'https://waalos.int.api.3stripes.io/waalos/ateslotting/ateSlottingService/zone?dcName=dName&userName=uName&zoneId=zoneid',
	ATE_SLOTTING_SZ1_GETDATA:'https://waalos.int.api.3stripes.io/waalos/ateslotting/ateSlottingService/getThresholdConfigValue?dcName=dName&userName=uName',
	ATE_SLOTTING_SZ1_UPDATE_GROUP:'https://waalos.int.api.3stripes.io/waalos/ateslotting/ateSlottingService/sltgrprules',
	ATE_SLOTTING_SZ1_SLOTTING_GROUPS_EDIT:'https://waalos.int.api.3stripes.io/waalos/ateslotting/ateSlottingService/sltgrprules?dcName=dName&userName=uName&grpType=gType&grpAttr=gtpAttr',
	ATE_SLOTTING_SZ1_ITEM_GROUP:'https://waalos.int.api.3stripes.io/waalos/ateslotting/ateSlottingService/getItemGrpDtls?dcName=dName&userName=uName',
	ATE_SLOTTING_SZ1_RELESE_TASK: 'https://waalos.int.api.3stripes.io/waalos/ateSlottingService/getDeSlotReSlotOrNewSlotRecords?dcName=dName&userName=uName&workType=gType&lotId=ulotid', 
	ATE_SLOTTING_SZ1_DYNAMIC_DETAILS:'https://waalos.int.api.3stripes.io/waalos/ateslotting/ateSlottingService/getDynamicLocationDetails?dcName=dName&userName=uName&lotId=ulotid',
	ATE_SLOTTING_SZ1_ADD_TASK: 'https://waalos.int.api.3stripes.io/waalos/ateslotting/ateSlottingService/getDeSlotReSlotOrNewSlotRecords?dcName=dName&userName=uName&workType=wrktype&lotId=ulotid',
	ATE_SLOTTING_SZ1_RELEASE_TASK: 'https://waalos.int.api.3stripes.io/waalos/ateslotting/ateSlottingService/releaseTasks?dcName=dName&userName=uName&workType=wrktype&lotId=ulotid',
  
	//Invoice Loader
	INVOICE_LOADER_CHOOSEFILE : 'https://waalos.int.api.3stripes.io/waalos/wmsadd/invoiceLoaderFile',
	INVOIC_LOADER_UPLOADFILE : 'https://waalos.int.api.3stripes.io/waalos/file-processing/invoiceLoader/launchInvoiceLoader',
	INVOIC_LOADER_DOWNLOAD_ERRORS: 'https://waalos.int.api.3stripes.io/waalos/wmsadd/downloadexcel?lotid=LID&jobcode=IVL',
		
	//Freight Terms
	GET_ALL_CODE_DESCRIPTION :'https://waalos.int.api.3stripes.io/waalos/wmsadd/getAllCodeId?dcName=dName&userName=uName',
	UPDATE_FREIGHT_TERMS: 'https://waalos.int.api.3stripes.io/waalos/wmsadd/updateFreightTerms',
	
	//tforce
	TFORCE_URL: 'https://waalos.int.api.3stripes.io/waalos/wmsadd/invokeTforceJob',
  
  	//WayBill Solution
	WAYBILL_SOLUTION: 'https://waalos.int.api.3stripes.io/waalos/wms/wayBillSolution/uploadFile',
	
	//Pick Ticket Shipment Loader
	PICK_TICKET_SHIPMENT_LOADER_CHOOSEFILE : 'https://waalos.int.api.3stripes.io/waalos/wmsadd/pktShpmtUploadFile',
	PICK_TICKET_SHIPMENT_LOADER_UPLOADFILE : 'https://waalos.int.api.3stripes.io/waalos/file-processing/pktshpmtupload/launchpktShipmentLoader',
	PKTSHIPMENT_DOWNLOAD_ERRORS: 'https://waalos.int.api.3stripes.io/waalos/wmsadd/downloadexcel?lotid=LID&jobcode=PSL',
	
	//Consolidation Location Update
	CONSOL_LOCATION_UPDATE_CHOOSEFILE : 'https://waalos.int.api.3stripes.io/waalos/wmsadd/consolidationLocUploadFile',
	CONSOL_LOCATION_UPDATE_UPLOADFILE : 'https://waalos.int.api.3stripes.io/waalos/file-processing/consolocupload/launchconsolidationLocLoader',
	CONSOL_LOCATION_UPDATE_DOWNLOAD_ERRORS: 'https://waalos.int.api.3stripes.io/waalos/wmsadd/downloadexcel?lotid=LID&jobcode=CLU',
	
	//Hot pick details
	HOT_PICK_BATCH_GET_DTLS:'https://waalos.int.api.3stripes.io/waalos/wmsaddHotPick/getHotPickBatchDtls?username=uName&dcName=dName',
	HOT_PICK_BATCH_GET_RULES:'https://waalos.int.api.3stripes.io/waalos/wmsaddHotPick/getHotPickBatchRules?username=uName&dcName=dName',
	HOT_PICK_BATCH_SAVE_RULE:'https://waalos.int.api.3stripes.io/waalos/wmsaddHotPick/saveHotPickBatchRules',
	HOT_PICK_BATCH_GET_PICKTICKETS:'https://waalos.int.api.3stripes.io/waalos/wmsaddHotPick/getPickTicketsList',
	HOT_PICK_BATCH_DEL:'https://awaalos.int.api.3stripes.io/waalos/wmsaddHotPick/delHotPickBatchDtls',
	HOT_PICK_BATCH_GET_RULE_BY_ID:'https://waalos.int.api.3stripes.io/waalos/wmsaddHotPick/getHotPickBatchRuleById?username=uName&dcName=dName&hotPickBatchId=hpBatchId',
	HOT_PICK_BATCH_SAVE_PICKTICKET:'https://waalos.int.api.3stripes.io/waalos/wmsaddHotPick/saveHotPickBatchPickTickets',
	
		//vas pick urlService
	VAS_PICK_GET_DTLS:'https://waalos.int.api.3stripes.io/waalos/wmsaddVasPick/getWaveAllocations?username=uName&dcName=dName&waveNbr=wNumber',
	VAS_PICK_ASSIGN:'https://waalos.int.api.3stripes.io/waalos/wmsaddVasPick/assignLocations',

	// Inv Sync
	INV_SYNC_JOB_STATS : 'https://waalos.int.api.3stripes.io/waalos/invSync/getInvSyncJobStats?username=uName&dcName=dName',
	INV_SYNC_RUN_JOB : 'https://waalos.int.api.3stripes.io/waalos/invSync/invokeInvSync',
	SAVE_INV_SYNC_DTLS : 'https://waalos.int.api.3stripes.io/waalos/invSync/saveSyncDetails',
		
	//EcomCarrierRouteUpdate
	ECOM_CARRIER_ROUTE_UPLOAD_CHOOSEFILE: 'https://waalos.int.api.3stripes.io/waalos/wmsadd/ecomCarrierUploadFile',
	ECOM_CARRIER_ROUTE_UPLOADFILE : 'https://waalos.int.api.3stripes.io/waalos/file-processing/ecomCarrierupload/launchEcomUploadLoader',
	ECOMUPLOAD_DOWNLOAD_ERRORS: 'https://waalos.int.api.3stripes.io/waalos/wmsadd/downloadexcel?lotid=LID&jobcode=ECU',
	
	//Prioritize Replen
	PRIORITIZE_REPLEN: 'https://waalos.int.api.3stripes.io/waalos/wmsadd/orderPrioritize',
	
	//resubmit message
	RESUBMIT_MESSAGE: 'https://waalos.int.api.3stripes.io/waalos/wmsaddResubmitMsg/resubmitMessage',
	
	//Asn Loader
	ASN_LOADER_CHOOSEFILE : 'https://waalos.int.api.3stripes.io/waalos/wmsadd/asnUploadFile',
	ASN_LOADER_UPLOADFILE : 'https://waalos.int.api.3stripes.io/waalos/file-processing/asnupload/launchasnUploadLoader',
	ASN_LOADER_DOWNLOAD_ERRORS: 'https://waalos.int.api.3stripes.io/waalos/wmsadd/downloadexcel?lotid=LID&jobcode=ALU',	
	
	//Dedicated Attribute Update
	UPDATE_ATTRIBUTE:'https://waalos.int.api.3stripes.io/waalos/wmsadd/updateDedicatedAttr',
	OLPN_DATA: 'https://waalos.int.api.3stripes.io/waalos/wmsaddResubmitMsg/getOlpndata?lpnnumber=olpnlpnnumber&dcName=dcname',

	//Sort Batch Loader
	SORT_BATCH_LOADER_CHOOSEFILE : 'https://waalos.int.api.3stripes.io/waalos/wmsadd/sortBatchUploadFile',
	SORT_BATCH_LOADER_UPLOADFILE : 'https://waalos.int.api.3stripes.io/waalos/file-processing/sortBatchupload/launchSortBatchLoader',
	SORT_BATCH_LOADER_DOWNLOAD_ERRORS: 'https://waalos.int.api.3stripes.io/waalos/wmsadd/downloadexcel?lotid=LID&jobcode=SBU',

	//Cancel Sort
	GET_SORT_DETAILS : "https://waalos.int.api.3stripes.io/waalos/wmsadd/cancelSortDtls?dcName=dName&userName=uName&pageNumber=pNumber&pageSize=pSize&batchNumber=batchnumber&asnNumber=asnnumber",
	CANCEL_SORT_DETAILS : "https://waalos.int.api.3stripes.io/waalos/wmsadd/cancelSortBatch",

	//Address update
	GET_ADDRESS_DETAILS:'https://waalos.int.api.3stripes.io/waalos/wmsaddAddressUpdate/getAddressDetails?dcName=dName&orderId=disOrder',
	GET_STATE_COUNTRY:"https://waalos.int.api.3stripes.io/waalos/wmsaddAddressUpdate/getStateCountryDetails?dcName=dName&flag=stateCountryFlag&country=cntry",
	UPDATE_ADDRESS_DETAILS:'https://waalos.int.api.3stripes.io/waalos/wmsaddAddressUpdate/updateAddress',
	
	//Routing Buddy
	GET_DROP_DOWN_LIST: 'https://waalos.int.api.3stripes.io/waalos/wmsaddRoutingBuddy/getDropDownDetails?dcName=dName&dropDownFlag=flag',
	UPDATE_ROUTING_BUDDY_DETAILS: 'https://waalos.int.api.3stripes.io/waalos/wmsaddRoutingBuddy/updateOrder',
	
	//Printer Configuration
	GET_PRINTER_DTLS : "https://waalos.int.api.3stripes.io/waalos/wmsadd/getPrinterDtls",
	DOWNLOAD_PRINTER_DTLS : "https://waalos.int.api.3stripes.io/waalos/wmsadd/downloadPrinterData",
	PRINTER_CONFIG_DTLS: "https://waalos.int.api.3stripes.io/waalos/wmsadd/printerConfigUploadFile",
	
	//Deslot Items
	DESLOT_ITEMS:"https://waalos.int.api.3stripes.io/waalos/wmsadd/deslotitems"	,
	
	//ship via update
    GET_SHIPMENT_IDS : "https://waalos.int.api.3stripes.io/waalos/wmsadd/getShipmentids?dcName=dName&username=uName",
	UPDATE_SHIPMENT_IDS : "https://waalos.int.api.3stripes.io/waalos/wmsadd/updateShipmentids",
	
	//Prewave Deselect
	PRE_VIEW_WAVE_DESELECT_CHOOSEFILE : 'https://waalos.int.api.3stripes.io/waalos/wmsadd/previewwaveDeselectUploadFile',
	PRE_VIEW_WAVE_DESELECT_UPLOADFILE : 'https://waalos.int.api.3stripes.io/waalos/file-processing/previewwavedeselect/launchpreviewwaveDeselect',
	PRE_VIEW_WAVE_DESELECT_DOWNLOAD_ERRORS: 'https://waalos.int.api.3stripes.io/waalos/wmsadd/downloadexcel?lotid=LID&jobcode=OPDL',
	
	//fedexcltv
	GET_MANIFEST_DETAILS : "https://waalos.int.api.3stripes.io/waalos/wmsadd/fedexManifestDtls?dcName=dName&userName=uName&pageNumber=pNumber&pageSize=pSize",
	INVOKE_FEDEX : "https://waalos.int.api.3stripes.io/waalos/wmsadd/invokeFedexJob",
	
	//Update third party billing address
	GET_DROP_DOWN_LIST_THIRD_PARTY_CUSTOMER: 'https://waalos.int.api.3stripes.io/waalos/wmsadd/getThirdPartyCustomers?dcName=dName',
	UPDATE_THIRD_PARTY_ADDRESS: 'https://waalos.int.api.3stripes.io/waalos/wmsadd/upadateThirdPartyAdd',
	
		//KHT Tool
	KHT_SKU_DTLS: "https://waalos.int.api.3stripes.io/waalos/wmsaddKhtTool/getSkuDetails?dcName=dName&skuVal=skuInpt",
	GET_KHT_SKU_DTLS: "https://waalos.int.api.3stripes.io/waalos/wmsaddKhtTool/getKhtSkuDetails?dcName=dName&skuVal=skuInpt&printerIp=prntrIp&printerPort=prntrPort&machineType=mType&compType=cType",
	GET_SKU_PROF_LIST: "https://waalos.int.api.3stripes.io/waalos/wmsaddKhtTool/getSkuProfDetails?dcName=dName",
	UPDATE_KHT_DETAILS:"https://waalos.int.api.3stripes.io/waalos/wmsaddKhtTool/updateKhttData",
	UPDATE_ACHOLHOL_TYPE:"https://waalos.int.api.3stripes.io/waalos/wmsaddKhtTool/updateAlcoholType",
	DELETE_KHT_DETAILS:"https://waalos.int.api.3stripes.io/waalos/wmsaddKhtTool/deleteKhttData",

	//EFC PALLET LABEL
	EFC_PALLET_LABEL:"https://waalos.int.api.3stripes.io/waalos/wmsadd/printEFCPalletlabel",
	
	//Sequence Number Update
	SEQUENCE_NUMBER_UPDATE: "https://waalos.int.api.3stripes.io/waalos/wmsadd/sequenceNumberUpdate",
	
	//Pallet Count Estimator
	PALLET_COUNT_ESTIMATOR:"https://waalos.int.api.3stripes.io/waalos/wmsadd/palletCountEstimator",
	
	//Sortation Rule Upload
	SORTATION_RULE_UPLOAD_LOADER_CHOOSEFILE : 'https://waalos.int.api.3stripes.io/waalos/wmsadd/sortationRuleUploadLoaderFile',
	SORTATION_RULE_UPLOAD_LOADER_UPLOADFILE : 'https://waalos.int.api.3stripes.io/waalos/file-processing/sortationRuleUploadLoader/launchSortationRuleUploadLoader',
	SORTATION_RULE_UPLOAD_LOADER_DOWNLOAD_ERRORS: 'https://waalos.int.api.3stripes.io/waalos/wmsadd/downloadexcel?lotid=LID&jobcode=SRUL',
	
	//Remove DEDICATED Keyword
	REMOVE_DEDICATED_KEYWORD_CHOOSEFILE : 'https://waalos.int.api.3stripes.io/waalos/wmsadd/removeDedicatedKeywordLoaderFile',
	REMOVE_DEDICATED_KEYWORD_UPLOADFILE : 'https://waalos.int.api.3stripes.io/waalos/file-processing/removeDedicatedKeywordLoader/launchRemoveDedicatedKeywordLoader',
	REMOVE_DEDICATED_KEYWORD_DOWNLOAD_ERRORS: 'https://waalos.int.api.3stripes.io/waalos/wmsadd/downloadexcel?lotid=LID&jobcode=RDKL',
	
	//Order Bulk Update Loader
	ORDER_BULK_UPDATE_LOADER_CHOOSEFILE : 'https://waalos.int.api.3stripes.io/waalos/wmsadd/orderBulkUpdateLoaderFile',
	ORDER_BULK_UPDATE_LOADER_UPLOADFILE : 'https://waalos.int.api.3stripes.io/waalos/file-processing/orbupload/launchodbUpdateLoader',
	ODBUPDATE_DOWNLOAD_ERRORS: 'https://waalos.int.api.3stripes.io/waalos/wmsadd/downloadexcel?lotid=LID&jobcode=OBUL',
	
	//Lock Unlock Shipment Loader
	LOCKUNLOCK_SHIPMENT_LOADER_CHOOSEFILE : 'https://waalos.int.api.3stripes.io/waalos/immNeedsLoader/uploadFileLockUnlockShipment',
	LOCKUNLOCK_SHIPMENT_LOADER_UPLOADFILE : 'https://waalos.int.api.3stripes.io/waalos/file-processing/lockUnlockShipment/uploadFile',
	LOCKUNLOCK_SHIPMENT_LOADER_DOWNLOAD_ERRORS: 'https://waalos.int.api.3stripes.io/waalos/wmsadd/downloadexcel?lotid=LID&jobcode=LUS',
	
	//Price Ticket Loader
	PRICE_TICKET_LOADER_CHOOSEFILE : 'https://waalos.int.api.3stripes.io/waalos/wmsadd/priceTicketLoaderFile',
	PRICE_TICKET_LOADER_UPLOADFILE : 'https://waalos.int.api.3stripes.io/waalos/file-processing/priceTicketuploadSZX/updatePriceTicketLoader',
	PRICE_TICKET_LOADER_DOWNLOAD_ERRORS: 'https://waalos.int.api.3stripes.io/waalos/wmsadd/downloadexcel?lotid=LID&jobcode=PTL',
	
	//Sorter Batch Loader
	SORTER_BATCH_LOADER_CHOOSEFILE : 'https://waalos.int.api.3stripes.io/waalos/wmsadd/sortBatchUploadFile',
	SORTER_BATCH_LOADER_UPLOADFILE : 'https://waalos.int.api.3stripes.io/waalos/file-processing/sorterBatchupload/checkAsnStatus',
	SORTER_BATCH_LOADER_UPLOADFILE_2 : 'https://waalos.int.api.3stripes.io/waalos/file-processing/sorterBatchupload/updateSorterBatchLoader',
	SORTER_BATCH_LOADER_DOWNLOAD_ERRORS: 'https://waalos.int.api.3stripes.io/waalos/wmsadd/downloadexcel?lotid=LID&jobcode=SBAX',
	
	//Item Bulk Update Loader
	ITEM_BULK_UPDATE_UPLOAD_CHOOSEFILE : 'https://waalos.int.api.3stripes.io/waalos/wmsadd/itemBulkUpdateLoaderFile',
	ITEM_BULK_UPDATE_UPLOAD_UPLOADFILE : 'https://waalos.int.api.3stripes.io/waalos/file-processing/itemBulkUpdateLoader/launchItemBulkUpdateLoader',
	ITEM_BULK_UPDATE_DOWNLOAD_ERRORS: 'https://waalos.int.api.3stripes.io/waalos/wmsadd/downloadexcel?lotid=LID&jobcode=IBUL',

	//CSV Automation
	CSV_Automation : 'https://waalos.int.api.3stripes.io/waalos/wmsadd/getCSVAutomation',
	
	//SorterCleanup:
	SorterCleanUP_GETLOCATION : 'https://waalos.int.api.3stripes.io/waalos/wmsextCntrl/getsorterLocation?dcName=dName',
	SorterCleanUP_UPDATELOCATION: 'https://waalos.int.api.3stripes.io/waalos/wmsextCntrl/SorterCleanup',
	
	//Trouble Marking
	TROUBLE_MARKING: 'https://waalos.int.api.3stripes.io/waalos/wmsadd/troubleMarking'

	});
