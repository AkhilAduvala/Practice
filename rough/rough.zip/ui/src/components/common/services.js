
angular.module('Authentication')
.factory('commonService',
    ['Base64', '$http','$q',
    function (Base64, $http,$q) {
		var service = {};
		var userData = {};
		service.getServiceResponse = getServiceResponse;
		service.postServiceResponse = postServiceResponse;
		service.putServiceResponse = putServiceResponse;
		service.getData = getData;
		service.setData = setData;
		//returns the promise object of get service
		function getServiceResponse(serviceUrl,header){
			var deffered = $q.defer();
				$http.get(serviceUrl,header).success(function(data){
						deffered.resolve(data);
					}).error(function(data){
						deffered.reject(data);
					});
				return deffered.promise;
			}
			
		// returns the promise object of post service
		function postServiceResponse(serviceUrl,payLoad,header){
			var deffered = $q.defer();
			$http.post(serviceUrl,payLoad,header).success(function(data){
				deffered.resolve(data);
			}).error(function(error){
				deffered.reject(error);
			});
			return deffered.promise;
		}
		
		// returns the promise object of put service
		function putServiceResponse(serviceUrl,payLoad,header){
			var deffered = $q.defer();
			$http.put(serviceUrl,payLoad,header).success(function(data){
				deffered.resolve(data);
			}).error(function(error){
				deffered.reject(error);
			});
			return deffered.promise;
		}
		
		//private data        
          function setData(key , data){
			  if(key === undefined){
				  userData = {};
			  }else{
				  userData[key] = data; 
				} 
            }
            //getter
           function getData(key){
			   if(userData.hasOwnProperty(key)){
					return userData[key];
			   }
            }
			
		return service;
		
	}]);