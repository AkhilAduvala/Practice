var app = angular.module('ReplenishmentList', ['ngTouch', 'ui.grid', 'ui.grid.edit', 'ui.grid.cellNav','ui.grid.selection','ui.grid.pagination','ui.grid.validate']);

app.controller('replenishmentListController', ['$scope', '$http', '$q', '$interval','$timeout','urlService', 'uiGridConstants','commonService', function ($scope, $http, $q, $interval,$timeout,urlService,uiGridConstants,commonService) {
 $scope.isTable = false;
 $scope.isupdate = true;
 $scope.isSuccess = false;
 $scope.isFailed = false;
 $scope.isClicked = false;
 $scope.pagefunctionality = $scope.functionality;
 $scope.pagedc = $scope.dcName;
 $("#showloader").css("display", "none");

  $scope.gridOptions = { 
    paginationPageSizes: [15, 25, 50, 100],
    paginationPageSize: 100,
    useExternalPagination: true,
    enableSorting: true,
    enableColumnMenus: false,
	  multiSelect:false,
    enableRowSelection: true,//we can remove it later no use  of this
    enableSelectAll: true,//we can remove it later no use  of this             
    enableCellEdit: false, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
    enableCellEditOnFocus: true // set any editable column to allow edit on focus
 
  };

  $scope.gridOptions.onRegisterApi = function(gridApi){
    //set gridApi on scope
    $scope.gridApi = gridApi; 
    $scope.gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
      $scope.pageNo =  newPage;
      $scope.pageSize = pageSize;
      $scope.getReplenshmentList();
   });
   
   };

$scope.getReplenshmentList = function () {
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $scope.pageNo = $scope.pageNo ? $scope.pageNo : 1;
    $scope.pageSize = $scope.pageSize ? $scope.pageSize: $scope.gridOptions.paginationPageSize;
    $("#showloader").css("display", "block");

    var url = urlService.GET_REPLENSHMENT_LIST.replace('dName',$scope.pagedc);
    url = url.replace('uName',sessionStorage.userName);
    url = url.replace('pNumber',$scope.pageNo);
    url = url.replace('pSize',$scope.pageSize);
    //var res = $http.get(url);
var res = $http.get(url, {
    headers: {'x-api-key': sessionStorage.apikey}
});
    res.success(function (data, status, headers, config) {
      $("#showloader").css("display", "none");
	
      if (data.errorMessage) {
        $scope.isFailed = true;
        $scope.resmessage = data.errorMessage;

      } else if (data.resMessage) {
					$scope.isTable = false;
					$scope.isSuccess = true;
          $scope.resmessage = data.resMessage;
          $scope.isupdate = true;
					
      }else {
		   $scope.gridOptions.columnDefs = [
			{ name: 'area',displayName:'Area', width:80,enableCellEdit: false, sort: { direction: uiGridConstants.ASC, priority: 1 },  cellTooltip: true, headerTooltip: true,},
			{ name: 'location', displayName: 'Location',  enableCellEdit: false,cellTooltip: true, headerTooltip: true},
			{ name: 'dspLocn', displayName: 'DSP Locn',enableCellEdit: false,cellTooltip: true, headerTooltip: true },
			{ name: 'pltId', displayName: 'Plt Id' ,enableCellEdit: false,cellTooltip: true, headerTooltip: true },
			{ name: 'wave', displayName: 'Wave',width:100,enableCellEdit: false,cellTooltip: true, headerTooltip: true },
			{ name: 'prio', displayName: 'Prio',enableCellEdit: false,cellTooltip: true, headerTooltip: true },
			{ name: 'pgi', displayName: 'PGI',width:100,enableCellEdit: false,cellTooltip: true, headerTooltip: true  },
			{ name: 'alreadySent', displayName: 'Already Sent' ,width:100,enableCellEdit: false,cellTooltip: true, headerTooltip: true  },
			{ name: 'forWave', displayName: 'For Wave',enableCellEdit: false,cellTooltip: true, headerTooltip: true  },
			{ name: 'otherWaves', displayName: 'Other Waves',width:300,enableCellEdit: false,cellTooltip: true, headerTooltip: true  }

   	  ];
        $scope.isTable = true;
        $scope.isupdate = false;
        $scope.gridOptions.totalItems  = data.totalNoOfRecords;  
        $scope.gridOptions.data = data.pageItems;
		
        if ($scope.gridOptions.data > 10) {
          $scope.gridOptions.enableVerticalScrollbar = true;
        } else {
          $scope.gridOptions.enableVerticalScrollbar = false;
          $scope.gridOptions.enableHorizontalScrollbar = 0;
        }
        
	
      }
      $('.ui-grid-pager-control input').prop( "disabled", true );
    });
    res.error(function (data, status, headers, config) {
      $("#showloader").css("display", "none");
      $scope.isFailed = true;
      $scope.resmessage = "System failed. Please try again or contact WAALOS Support";

    });
  };
  $scope.getReplenshmentList();


  $scope.downloadExcel = function(type) {
		$scope.isFailed = false;
		$("#showloader").css("display", "block");
		var url;
	  url = urlService.DOWNLOAD_REPLENSHMENT_LIST.replace('jbcode','REP');
    url = url.replace('dName',$scope.pagedc);
  
	$http({
			method: 'GET',
			url: url,
			headers: {				
				'Content-type': 'application/json', 'x-api-key': sessionStorage.apikey
			},
			responseType: 'arraybuffer'
		
		})
	.success( function(data, status, headers) {
	
	$("#showloader").css("display", "none");
	
		if(data.byteLength == 55){
			$scope.isFailed = true;
				  $('#alert-box').modal('show');
	
	
				  }else if(data.byteLength == 98){
					$scope.isFailed = true;
					$scope.resmessage = "Error in Downloading Excel file";
			return;
		}else{
			
			var octetStreamMime = 'application/octet-stream';
			var success = false;
	
			// Get the headers
			headers = headers();
			var filename;
			var blob;
			// Get the filename from the x-filename header or default to "download.bin"
      filename = headers['x-filename'] || 'Replenishment_List.xlsx';
			// Determine the content type from the header or default to "application/octet-stream"
			var contentType = headers['content-type'] || octetStreamMime;
	
			try
			{
				// Try using msSaveBlob if supported
				console.log("Trying saveBlob method ...");
				blob = new Blob([data], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
				if(navigator.msSaveBlob)
					navigator.msSaveBlob(blob, filename);
				else {
					// Try using other saveBlob implementations, if available
					var saveBlob = navigator.webkitSaveBlob || navigator.mozSaveBlob || navigator.saveBlob;
					if(saveBlob === undefined) throw "Not supported";
					saveBlob(blob, filename);
				}
				console.log("saveBlob succeeded");
				success = true;
			} catch(ex)
			{
				console.log("saveBlob method failed with the following exception:");
				console.log(ex);
			}
	
			if(!success)
			{
				// Get the blob url creator
				var urlCreator = window.URL || window.webkitURL || window.mozURL || window.msURL;
				if(urlCreator)
				{
					// Try to use a download link
					var link = document.createElement('a');
					if('download' in link)
					{
						// Try to simulate a click
						try
						{
							// Prepare a blob URL
							console.log("Trying download link method with simulated click ...");
							 blob = new Blob([data], { type: contentType });
							url = urlCreator.createObjectURL(blob);
							link.setAttribute('href', url);
	
							// Set the download attribute (Supported in Chrome 14+ / Firefox 20+)
							link.setAttribute("download", filename);
	
							// Simulate clicking the download link
							var event = document.createEvent('MouseEvents');
							event.initMouseEvent('click', true, true, window, 1, 0, 0, 0, 0, false, false, false, false, 0, null);
							link.dispatchEvent(event);
							console.log("Download link method with simulated click succeeded");
							success = true;
	
						} catch(ex) {
							console.log("Download link method with simulated click failed with the following exception:");
							console.log(ex);
						}
					}
	
					if(!success)
					{
						// Fallback to window.location method
						try
						{
							// Prepare a blob URL
							// Use application/octet-stream when using window.location to force download
							console.log("Trying download link method with window.location ...");
							blob = new Blob([data], { type: octetStreamMime });
							url = urlCreator.createObjectURL(blob);
							window.location = url;
							console.log("Download link method with window.location succeeded");
							success = true;
						} catch(ex) {
							console.log("Download link method with window.location failed with the following exception:");
							console.log(ex);
						}
					}
	
				}
			}
	
			if(!success)
			{
				// Fallback to window.open method
				console.log("No methods worked for saving the arraybuffer, using last resort window.open");
				window.open(rowData.pathName, '_blank', '');
			}
		}
	})
	.error(function(data, status, config) {
	
		console.log("Request failed with status: " + status);
	$("#showloader").css("display", "none");

		$scope.isFailed = true;
		$scope.resmessage = "Error in downloading Excel File";
	
	});
	}; 
  

   //user favourites code start
   $scope.addToFavourate = function(isClicked){
    $("#showloader").css("display", "block");
     if(typeof isClicked !== "boolean"){
      commonService.postServiceResponse(urlService.GET_FAVOURITES,{"username": sessionStorage.userName})
        .then(function(response){
          $("#showloader").css("display", "none");
            _.each(response,function(val,key){
              if(val.funName == $scope.functionality && val.dcName == $scope.dcName){
                $scope.isClicked = true;      
              }
            });
        },function(error){
          $("#showloader").css("display", "none");
          $scope.isClicked = false; 
        });
        //$scope.isClicked = ;
     }else{
      if(!$scope.isClicked){
        commonService.postServiceResponse(urlService.ADD_FAVOURITE,{"username": sessionStorage.userName,"dcName":$scope.dcName,"funName":$scope.functionality})
        .then(function(response){
          $("#showloader").css("display", "none");
          if(response.errorMessage){
            $scope.isFavouriteAdded= false; 
            $scope.isClicked = false;      
            $scope.$broadcast('showAlert',['']);
          }else{
            $scope.isClicked = true;      
            $scope.isClicked = !isClicked;
            $scope.isFavouriteAdded= true; 
            $scope.favouriteMsg = response.resMessage;
          $scope.$broadcast('ClickedOnFavourate',[$scope.dcName,$scope.functionality,$scope.isClicked]);
          }
            
        },function(error){
          $scope.isClicked = false;
          $("#showloader").css("display", "none");
        });
        $scope.isClicked = !isClicked;
      }else{
        $("#showloader").css("display", "none");
      }
     }
    
  };
   $scope.addToFavourate('load');
   // user favourites code end
}]);

