var app = angular.module('KhtTool');

app.controller('KhtToolController', ['$scope', '$http', '$q', '$interval', '$timeout', 'urlService', 'uiGridConstants', 'commonService', function ($scope, $http, $q, $interval, $timeout, urlService, uiGridConstants, commonService) {
    $scope.isTable = false;
    $scope.showDNNumbers = true;
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $scope.disableGetWeight = false;
    $scope.pagefunctionality = $scope.functionality;
    $scope.pagedc = $scope.dcName;
    $scope.disableUpdate = true;
    //$scope.old = false;
    //$scope.latest = true;
    //$scope.taskval = 'N';
	$scope.taskval = 'N';
    $scope.hideDropDwn = true;
	$scope.viewDetails = false;
	$scope.calVol = false;
    $scope.skuData = [];
    $scope.defaultDropDownVal = 'SKU Profile Type';
   // $scope.SPList= "SKU Profile Type";
    $("#sku-nbr").focus();
    $scope.values = {
        "sku": ''
    };

    $scope.dropDownHide = function () {
        if ($scope.skuqty == "TOP SKU QTY") {
            $scope.hideDropDwn = false;
        } else {
            $scope.stdcaseqty = $scope.skuqty;
            $scope.hideDropDwn = true;
        }
    };

    $scope.init = function () {

        if ($scope.dcName == "CDC") {
            $scope.hidesef = true;
            $scope.hidecdc = false;
        }
        else {
            $scope.hidesef = false;
            $scope.hidecdc = true;

        }
    };
	
    $scope.dynamicVolume = function () {
	//	if($scope.calVol){
			$scope.uvolume = ($scope.ulength * $scope.uwidth * $scope.uheight).toFixed(2) ;
	//	}
		
    };	


    $scope.gridOptionsCaseInfo = {
        enableSorting: true,
        enableColumnMenus: false,
        multiSelect: false,
        enableRowSelection: true,//we can remove it later no use  of this
        enableSelectAll: true,//we can remove it latgridOptionsTwoer no use  of this             
        enableCellEdit: false, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
        enableCellEditOnFocus: true // set any editable column to allow edit on focus

    };
    $scope.gridOptionsCaseInfo.onRegisterApi = function (gridApi) {
        $scope.gridApi = gridApi;

    };

    $scope.gridOptionsCase = {
        enableColumnMenus: false,
        enableSorting: true,
        multiSelect: false,
        enableHorizontalScrollbar: true,
        enableRowSelection: true,//we can remove it later no use  of this
        enableSelectAll: true,//we can remove it later no use  of this             
        enableCellEdit: false, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
        enableCellEditOnFocus: true // set any editable column to allow edit on focus
    };
    $scope.gridOptionsLogicalDvrt = {
    //    enableColumnMenus: false,
        enableSorting: true,
        multiSelect: false,
        enableHorizontalScrollbar: true,
//        enableRowSelection: true,//we can remove it later no use  of this
//        enableSelectAll: true,//we can remove it later no use  of this             
        enableCellEdit: false, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
        enableCellEditOnFocus: true // set any editable column to allow edit on focus
    };

    $scope.gridOptionsCase.onRegisterApi = function (gridApi) {
        $scope.gridApi = gridApi;

        gridApi.selection.on.rowSelectionChangedBatch($scope, function (rows) {
            $scope.isSuccess = false;
            $scope.isFailed = false;
            if ($scope.gridApi.selection.getSelectedRows().length == 0) {
                $scope.isUpdate = true;
            } else {
                $scope.isUpdate = false;
            }
        });

        gridApi.selection.on.rowSelectionChanged($scope, function (row) {
            $scope.isSuccess = false;
            $scope.isFailed = false;
            if ($scope.gridApi.selection.getSelectedRows().length > 0) {
                $scope.isUpdate = false;
            } else {
                $scope.isUpdate = true;
            }
        });
    };




    // Validation airticle number
    $scope.checkSKUNumber = function () {
        $scope.isSuccess = false;
        $scope.isFailed = false;
        $scope.userInput = $scope.values.sku;
        var reg = /^[0-9\_ ]+$/;
        if ($scope.values.sku == undefined || $scope.values.sku == "") {
            $scope.disable = true; $scope.isFailed = false;
        } else if ($scope.values.sku == undefined || $scope.values.sku == 32 || !(reg.test($scope.values.sku))) {
            $scope.disable = true;

            $scope.isFailed = true;
            $scope.resmessage = "Please enter a valid data";
        } else {
            $scope.disable = false;
        }
    };

    $scope.task = function (taskval) {
        $scope.taskval = taskval;


        if ($scope.taskval == "O") {
            $scope.old = true;
            $scope.latest = false;
        }
        else if ($scope.taskval == "N") {
            $scope.old = false;
            $scope.latest = true;
        }

    };

    $scope.getPrinterList = function () {
        var url = urlService.PRINTER_LIST.replace("dName", "KHT-".concat($scope.pagedc));
        url = url.replace('uName', sessionStorage.userName);
        var res = $http.get(url, {
            // headers: {'x-api-key': sessionStorage.apikey} 
        });

        res.success(function (data, status, headers, config) {
            if (data.errorMessage) {
                $scope.isFailed = true;
                $scope.resmessage = data.errorMessage;
            } else if (data.resMessage) {
                $scope.isSuccess = true;
                $scope.resmessage = data.resMessage;
            } else {	
                if ($scope.hidecdc == false) {
                    $scope.getSPDetails();
                }
                $scope.printerslist = data;
 		//printerslist.sort((a,b) => (a.printerName > b.printerName) ? 1 : ((b.printerName > a.printerName) ? -1 : 0));



                for (var i = 0; i < $scope.printerslist.length; i++) {
                    if ($scope.printerip) {
                        if ($scope.printerslist[i].printerIp == $scope.printerip) {
                            $scope.printer = $scope.printerslist[i];
                            break;
                        }
                    } else {
                        $scope.printer = $scope.printerslist[0];
                    }
                }
            }
        });
        res.error(function (responce, status, headers, config) {
            $scope.isFailed = true;
            $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
        });
    };

    /** This function is used to get drop down details for SKU Profile  **/
    $scope.getSPDetails = function () {
        var url = urlService.GET_SKU_PROF_LIST.replace('dName', $scope.pagedc);
        var res = $http.get(url, { headers: { 'x-api-key': sessionStorage.apikey } });
        res.success(function (data, status, headers, config) {
            $("#showloader").css("display", "none");
            if (data.errorMessage) {
                $scope.isFailed = true;
                $scope.resmessage = data.errorMessage;

            } else if (data.resMessage) {
                $scope.isSuccess = true;
                $scope.resmessage = data.resMessage;

            } else {
                $scope.SPdropDownList = data;
                $("#showloader").css("display", "none");

            }
            $('.ui-grid-pager-control input').prop("disabled", true);
        });
        res.error(function (data, status, headers, config) {
            $("#showloader").css("display", "none");
            $scope.isFailed = true;
        });
	
    };

    $scope.getdefaultPrinter = function () {
        var url = urlService.DEFAULT_PRINTERS.replace("dName", "KHT-".concat($scope.pagedc));
        url = url.replace('uName', sessionStorage.userName);
        var res = $http.get(url, {
            // headers: {'x-api-key': sessionStorage.apikey} 
        });

        res.success(function (data, status, headers, config) {
            if (data.errorMessage) {
                $scope.getPrinterList();
            } else if (data.resMessage) {
                $scope.getPrinterList();
            } else {
                $scope.defaultprinter = data;
                $scope.printerip = data[0].printerIp;
                $scope.getPrinterList();
            }
        });
        res.error(function (data, status, headers, config) {
            $scope.getPrinterList();
        });
    };
    $scope.getPrinterList();


    // onenter Validation sku number
    $scope.skuNum = function ($event) {
		$scope.values.sku = $event.currentTarget.value;
		$scope.userInput = $event.currentTarget.value;
        var keyCode = $event.which || $event.keyCode;
        var reg = /^[0-9\_ ]+$/;
        if ($event.currentTarget.value.length > 1 && keyCode === 13 && $event.currentTarget.value != undefined && $event.currentTarget.value != "" && $event.currentTarget.value != 32 && (reg.test($event.currentTarget.value))) {
            $scope.disable = false;
            $scope.getSkuDtls();
        }
        else if ( keyCode === 113 ) {
            $scope.disable = false;
            $scope.getWeight();
        }	
       else if (keyCode === 114 ) {
            $scope.disable = false;
            $scope.updateKhtDetails();
        }
		
       else if (keyCode === 13) {
            if ($event.currentTarget.value == "" || $event.currentTarget.value.length < 1 || $event.currentTarget.value == undefined || $event.currentTarget.value == 32 || !(reg.test($event.currentTarget.value))) {
                $scope.disable = true;
                $scope.isFailed = true;
                $scope.resmessage = "Please enter a valid data";
            }
        }

    };
	
/*  $scope.getkeys = function (event) {
$scope.keyval = event.keyCode;
        if ( keyval === 113 ) {
            $scope.disable = false;
            $scope.getWeight();
        }	
        if ( keyval === 114) {
            $scope.disable = false;
            $scope.updateKhtDetails();
        }
};	 */

    $scope.scrolldown = function () {


        document.body.scrollTop = 580;
        document.documentElement.scrollTop = 580;
        $scope.showRules = true;

    }; 
    $scope.scrollup = function () {
        document.body.scrollTop = 0;
        document.documentElement.scrollTop = 0;
    };




    $scope.getSkuDtls = function () {
        //console.log($scope.lpn);
        $scope.isFailed = false;
        $scope.isSuccess = false;

        $("#showloader").css("display", "block");
        var payload = {

            "skuVal": $scope.values.sku,
            "dcName": $scope.pagedc
        };

        var url = urlService.KHT_SKU_DTLS.replace('dName', $scope.pagedc);
        url = url.replace('skuInpt', $scope.values.sku);
        var res = $http.get(url, { headers: { 'x-api-key': sessionStorage.apikey } });

        res.success(function (data, status, headers, config) {
            $("#showloader").css("display", "none");
            if (data.errorMessage) {
				$scope.viewDetails = false;
                $scope.isFailed = true;
                $scope.resmessage = data.errorMessage;
                $scope.disableUlength = true;
                $scope.ulength = '';
                $scope.disableUwidth = true;
                $scope.uwidth = '';
                $scope.disableUweight = true;
                $scope.uweight = '';
                $scope.disableUheight = true;
                $scope.uheight = '';
                $scope.disableUvolume = true;
                $scope.uvolume = '';
                $scope.disableArticles = true;
                $scope.articles = '';
                $scope.disableStdcaseqty = true;
                $scope.stdcaseqty = '';
                $scope.disableClength = true;
                $scope.clength = '';
                $scope.disableCwidth = true;
                $scope.cwidth = '';
                $scope.disableCweight = true;
                $scope.cweight = '';
                $scope.disableCheight = true;
                $scope.cheight = '';
                $scope.disablecvolume = true;
                $scope.cvolume = '';
                //$scope.disableUpdate = true;
            } else if (data.resMessage) {
				$scope.viewDetails = false;
                $scope.isSuccess = true;
                $scope.resmessage = data.resMessage;
            } else {
				$scope.viewDetails = true;
				$scope.updateprofAll = true;
                //$scope.data = data.khtDetailsDto;
                $scope.disableGetWeight = false;
                $scope.disableUlength = false;
                $scope.ulength = data.khtDetailsDto[0].unitLen;
                $scope.disableUwidth = false;
                $scope.uwidth = data.khtDetailsDto[0].unitWidth;
                $scope.disableUweight = false;
                $scope.uweight = data.khtDetailsDto[0].unitWt;
                $scope.disableUheight = false;
                $scope.uheight = data.khtDetailsDto[0].unitHt;
                $scope.disableUvolume = false;
                $scope.uvolume = data.khtDetailsDto[0].unitVol;

                $scope.disableClength = false;
                $scope.clength = data.khtDetailsDto[0].stdCaseLen;
                $scope.disableCwidth = false;
                $scope.cwidth = data.khtDetailsDto[0].stdCaseWidth;
                $scope.disableCweight = false;
                $scope.cweight = data.khtDetailsDto[0].stdCaseWt;
                $scope.disableCheight = false;
                $scope.cheight = data.khtDetailsDto[0].stdCaseHt;
                $scope.disableCvolume = false;
                $scope.cvolume = data.khtDetailsDto[0].stdCaseVol;
                $scope.alloctype = data.khtDetailsDto[0].alcoholType;
                $scope.disableArticles = false;
                $scope.articles = data.topStdQty.length;
                $scope.disableStdCaseQty = false;
                $scope.stdcaseqty = data.khtDetailsDto[0].stdCaseQty;
                $scope.realqty = data.khtDetailsDto[0].vocollectBaseQty;
				$scope.knownwcs = data.khtDetailsDto[0].miscAlpha2;
				$scope.sendwcs = data.khtDetailsDto[0].miscAlpha3;
				$scope.skuid = data.khtDetailsDto[0].skuId;
				$scope.prodType = data.khtDetailsDto[0].prodType;
				$scope.stdcasevol = data.khtDetailsDto[0].stdCaseVol;
				if($scope.uweight !=  null ){
					$scope.disableUpdate = false;
				}
                $scope.hideDropDwn = false;
                $scope.skuData = data.topStdQty;
                $scope.skuData.unshift("TOP SKU QTY");
                $scope.skuqty = $scope.skuData[0];
				$scope.SPList=$scope.alloctype;	
				if ($scope.alloctype == '1')
				{
					$scope.compType = false;
				}
				else{
					$scope.compType = false;
				}
                // iterate over each element in the array
                for (var i = 0; i < $scope.SPdropDownList.length; i++) {
                    // look for the entry with a matching `code` value
                    if ($scope.SPdropDownList[i].spCodeId == $scope.alloctype) {
                     $scope.defaultDropDownVal = $scope.SPdropDownList[i].dropDownList;
		    
			// $scope.SPList= $scope.defaultDropDownVal;
			
                    }
					else if($scope.alloctype ==null){
						$scope.defaultDropDownVal = '';
					}
                }
                $scope.gridOptionsCase.columnDefs = [
                    { name: 'invLockCode', displayName: 'LockCode', width: 120, enableCellEdit: false, cellTooltip: true, headerTooltip: true },
                    { name: 'codeDesc', width: 200, displayName: 'CodeDesc', width: 170, enableCellEdit: false, cellTooltip: true, headerTooltip: true },
                    { name: 'caseNbr', displayName: 'CaseNbr', width: 135, enableCellEdit: false, cellTooltip: true, headerTooltip: true },
					{ name: 'caseQty', displayName: 'CaseQty', width: 135, enableCellEdit: false, cellTooltip: true, headerTooltip: true },
                ];				
				$scope.gridOptionsLogicalDvrt.columnDefs = [
                    { name: 'logicalDvrt', displayName: 'Logical Divert', width: 120, enableCellEdit: false, cellTooltip: true, headerTooltip: true },

                ];

                $scope.gridOptionsCaseInfo.columnDefs = [
                    { name: 'caseNbr', displayName: 'Case Nbr',  enableCellEdit: false, cellTooltip: true, headerTooltip: true },
                    { name: 'caseQty',  displayName: 'case Quantity',  enableCellEdit: false, cellTooltip: true, headerTooltip: true },
                    { name: 'sku', displayName: 'SKU', enableCellEdit: false, cellTooltip: true, headerTooltip: true },
					{ name: 'skuAttr1', displayName: 'SKU ATTR 1', enableCellEdit: false, cellTooltip: true, headerTooltip: true },
					{ name: 'coo', displayName: 'COO', enableCellEdit: false, cellTooltip: true, headerTooltip: true },
                ];
                $scope.isTable = true;

                $scope.gridOptionsCase.data = data.khtCaseCodeDto;
				$scope.gridOptionsCaseInfo.data=data.khtCaseInfoDto;
				$scope.gridOptionsLogicalDvrt.data=data.khtLogicalDvrt;
                if ($scope.gridOptionsCase.data > 10  ) {
                    $scope.gridOptionsCase.enableVerticalScrollbar = true;
                    $scope.gridOptionsCase.enableHorizontalScrollbar = true;
                } else {
                    $scope.gridOptionsCase.enableVerticalScrollbar = false;
                    $scope.gridOptionsCase.enableHorizontalScrollbar = true;
                }
			    if ($scope.gridOptionsLogicalDvrt.data > 10  ) {
                    $scope.gridOptionsLogicalDvrt.enableVerticalScrollbar = true;
                    $scope.gridOptionsLogicalDvrt.enableHorizontalScrollbar = true;
                } else {
                    $scope.gridOptionsLogicalDvrt.enableVerticalScrollbar = false;
                    $scope.gridOptionsLogicalDvrt.enableHorizontalScrollbar = true;
                }
                if ($scope.gridOptionsCaseInfo.data > 10 ) {
                    $scope.gridOptionsCaseInfo.enableVerticalScrollbar = true;
                    $scope.gridOptionsCaseInfo.enableHorizontalScrollbar = true;
                } else {
                    $scope.gridOptionsCaseInfo.enableVerticalScrollbar = false;
                    $scope.gridOptionsCaseInfo.enableHorizontalScrollbar = true;
                }				

                $("#showloader").css("display", "none");
            }
            $('.ui-grid-pager-control input').prop("disabled", true);
        });
        res.error(function (data, status, headers, config) {
            $("#showloader").css("display", "none");
            $scope.isFailed = true;
        });

	

    };

$scope.changeDisableBtn = function () {
	
	if($scope.uweight != null && $scope.uweight != ""){
		$scope.disableUpdate = false;
	}else {
		$scope.disableUpdate = true;
	}
}

    $scope.getWeight = function () {
        //console.log($scope.lpn);
        $scope.isFailed = false;
        $scope.isSuccess = false;

        $("#showloader").css("display", "block");
        var payload = {

            "skuVal": $scope.values.sku,
            "dcName": $scope.pagedc,
            "printerIp": $scope.printerIp,
            "printerPort": $scope.printerPort
        };

        var url = urlService.GET_KHT_SKU_DTLS.replace('dName', $scope.pagedc);
        url = url.replace('skuInpt', $scope.values.sku);
        url = url.replace('prntrIp', $scope.printer.printerIp);
        url = url.replace('prntrPort', $scope.printer.printerPort);
        //"messageType": $scope.taskval
        url = url.replace("mType", $scope.taskval);
		url = url.replace("cType", ($scope.compType === true ) ? 'Y' : 'N');
        var res = $http.get(url, { headers: { 'x-api-key': sessionStorage.apikey } });


        res.success(function (data, status, headers, config) {
            $("#showloader").css("display", "none");
            if (data.errorMessage) {
                $scope.isFailed = true;
                $scope.resmessage = data.errorMessage;
                $scope.ulength = '';
                $scope.uwidth = '';;
                $scope.uweight = '';
                $scope.uheight = '';
                $scope.uvolume = '';
                $scope.articles = '';
                $scope.stdcaseqty = '';
                $scope.clength = '';
                $scope.cwidth = '';
                $scope.cweight = '';
                $scope.cheight = '';
                $scope.cvolume = '';
                $scope.disableUpdate = true;
            } else if (data.resMessage) {
                $scope.isSuccess = true;
                $scope.resmessage = data.resMessage;
				$scope.disableUpdate = true;
            } 
			else {
				$scope.calVol = false;
				$scope.disableUpdate = false;
                $scope.disableUlength = false;
                $scope.ulength = (data.unitLen)/10;
                $scope.disableUwidth = false;
                $scope.uwidth = (data.unitWidth)/10;
                $scope.disableUweight = false;
                $scope.uweight = (data.unitWt);
                $scope.disableUheight = false;
                $scope.uheight = (data.unitHt)/10;
                $scope.disableUvolume = false;
              //  $scope.uvolume = Math.round($scope.ulength * $scope.uwidth * $scope.uheight)/100 ;
		$scope.uvolume = ($scope.ulength * $scope.uwidth * $scope.uheight).toFixed(2);

                $("#showloader").css("display", "none");
            }
            $('.ui-grid-pager-control input').prop("disabled", true);
        });
        res.error(function (data, status, headers, config) {
            $("#showloader").css("display", "none");
            $scope.isFailed = true;
        });
    };



    $scope.resetData = function () {
        $scope.disable1 = true;
        $scope.disable2 = true;
    };
	
	$scope.updateKhtDetails=function(){
		 $scope.isSuccess = false;
         $scope.isFailed = false;
	   $("#showloader").css("display", "block");

	if(($scope.uweight== null || $scope.uweight ==undefined || $scope.SPList == undefined) && ($scope.pagedc == 'CDC')){
			$("#showloader").css("display", "none");
		    $scope.isFailed = true;
            $scope.resmessage = "Please select sku type";
	   }else{	
			if($scope.pagedc == 'CDC'){
		   var payload = {
			"dcName": $scope.pagedc,
			"skuId": $scope.skuid,
            "userName": sessionStorage.userName ,
            "unitLen": $scope.ulength,
            "unitWidth": $scope.uwidth,
            "unitHt": $scope.uheight,
			"unitWt": $scope.uweight,
			"unitVol": $scope.uvolume,
			"stdCaseQty": $scope.stdcaseqty,
			"stdCaseLen": $scope.clength,
			"stdCaseWidth": $scope.cwidth,
			"stdCaseHt": $scope.cheight, 
			"stdCaseWt": $scope.cweight,
			"alcoholType": $scope.SPList,
			"vocollectBaseQty":$scope.realqty,
			"miscAlpha2": $scope.knownwcs,
			"miscAlpha3":$scope.sendwcs,
			"prodType":$scope.prodType,
			"stdCaseVol": $scope.stdcasevol,
			"updateprofAll": $scope.updateprofAll === true ? 'Y' : 'N',
			"khtCaseCodeDto":$scope.gridApi.selection.getSelectedRows()
        };
		
			}else{
				var payload = {
			"dcName": $scope.pagedc,
			"skuId": $scope.skuid,
            "userName": sessionStorage.userName ,
            "unitLen": $scope.ulength,
            "unitWidth": $scope.uwidth,
            "unitHt": $scope.uheight,
			"unitWt": $scope.uweight,
			"unitVol": $scope.uvolume,
			"stdCaseQty": $scope.stdcaseqty,
			"stdCaseLen": $scope.clength,
			"stdCaseWidth": $scope.cwidth,
			"stdCaseHt": $scope.cheight, 
			"stdCaseWt": $scope.cweight,
			"stdCaseVol": $scope.cvolume
				};			
			}
		 var res = $http.put(urlService.UPDATE_KHT_DETAILS, payload, {
            headers: { 'x-api-key': sessionStorage.apikey }
        });
         res.success(function(data, status, headers, config) {
            $("#showloader").css("display", "none");
            if (data.errorMessage) {
                $scope.isFailed = true;
                $scope.resmessage = data.errorMessage;
            } else {
				$scope.getSkuDtls();	
                $scope.isSuccess = true;
                $scope.resmessage = data.resMessage;
            }
        });
        res.error(function(data, status, headers, config) {
            $("#showloader").css("display", "none");
            $scope.isFailed = true;
            $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
        });
	   
        }
	}	

	$scope.deleteKhtDetails=function(){
		 $scope.isSuccess = false;
         $scope.isFailed = false;
	   $("#showloader").css("display", "block");

	if(($scope.uweight== null || $scope.uweight ==undefined || $scope.SPList == undefined) && ($scope.pagedc == 'CDC')){
			$("#showloader").css("display", "none");
		    $scope.isFailed = true;
            $scope.resmessage = "Please select sku type";
	   }else{	
	   if($scope.pagedc == 'CDC'){
		   var payload = {
			"dcName": $scope.pagedc,
			"khtCaseCodeDto":$scope.gridApi.selection.getSelectedRows()
        };
	   }
	   else{
		   		   var payload = {
			"dcName": $scope.pagedc,
        };

	   }
		 var res = $http.put(urlService.DELETE_KHT_DETAILS, payload, {
            headers: { 'x-api-key': sessionStorage.apikey }
        });
         res.success(function(data, status, headers, config) {
            $("#showloader").css("display", "none");
            if (data.errorMessage) {
                $scope.isFailed = true;
                $scope.resmessage = data.errorMessage;
            } else {
				$scope.getSkuDtls();
                $scope.isSuccess = true;
                $scope.resmessage  = data.resMessage;
				//$scope.getSkuDtls();
            }
        });
        res.error(function(data, status, headers, config) {
            $("#showloader").css("display", "none");
            $scope.isFailed = true;
            $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
        });
	   
        }
	}	
	
		$scope.saveAlcoholType=function(){
		
		 $scope.isSuccess = false;
         $scope.isFailed = false;
	   $("#showloader").css("display", "block");

	if($scope.values.sku == undefined || $scope.values.sku == ""){
			$("#showloader").css("display", "none");
		    $scope.isFailed = true;
            $scope.resmessage = "Please Enter SKU Number";
	   }else{	

		   var payload = {
			"dcName": $scope.pagedc,
			"skuVal": $scope.values.sku,
            "userName": sessionStorage.userName ,
			"alcoholType": $scope.SPList,
			};
		
		 var res = $http.put(urlService.UPDATE_ACHOLHOL_TYPE, payload, {
            headers: { 'x-api-key': sessionStorage.apikey }
        });
         res.success(function(data, status, headers, config) {
            $("#showloader").css("display", "none");
            if (data.errorMessage) {
                $scope.isFailed = true;
                $scope.resmessage = data.errorMessage;
            } else {
                $scope.isSuccess = true;
                $scope.resmessage = data.resMessage;
				$scope.getSkuDtls();
//				$scope.getWeight();
            }
        });
        res.error(function(data, status, headers, config) {
            $("#showloader").css("display", "none");
            $scope.isFailed = true;
            $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
        });
	   
        }
	}	



    //user favourites code starts
    $scope.isClicked = false;
    $scope.addToFavourate = function (isClicked) {
        $("#showloader").css("display", "block");
        if (typeof isClicked !== "boolean") {
            commonService.postServiceResponse(urlService.GET_FAVOURITES, { "username": sessionStorage.userName })
                .then(function (response) {
                    $("#showloader").css("display", "none");
                    _.each(response, function (val, key) {
                        if (val.funName == $scope.functionality && val.dcName == $scope.dcName) {
                            $scope.isClicked = true;
                        }
                    });
                }, function (error) {
                    $("#showloader").css("display", "none");
                    $scope.isClicked = false;
                });
            //$scope.isClicked = ;
        } else {
            if (!$scope.isClicked) {
                commonService.postServiceResponse(urlService.ADD_FAVOURITE, { "username": sessionStorage.userName, "dcName": $scope.dcName, "funName": $scope.functionality })
                    .then(function (response) {
                        $("#showloader").css("display", "none");
                        if (response.errorMessage) {
                            $scope.isFavouriteAdded = false;
                            $scope.isClicked = false;
                            $scope.$broadcast('showAlert', ['']);
                        } else {
                            $scope.isClicked = true;
                            $scope.isClicked = !isClicked;
                            $scope.isFavouriteAdded = true;
                            $scope.favouriteMsg = response.resMessage;
                            $scope.$broadcast('ClickedOnFavourate', [$scope.dcName, $scope.functionality, $scope.isClicked]);
                        }

                    }, function (error) {
                        $scope.isClicked = false;
                        $("#showloader").css("display", "none");
                    });
                $scope.isClicked = !isClicked;
            } else {
                $("#showloader").css("display", "none");
            }
        }

    };
    $scope.addToFavourate('load');
    //user favourites code ends		




}]);