var app = angular.module('SkuMarking', ['ui.bootstrap', 'ngTouch', 'ui.grid', 'ui.grid.pagination', 'daterangepicker','ui.grid.exporter']);
app.directive('fileModel', ['$parse', function ($parse) {
	return {
		restrict: 'A',
		link: function (scope, element, attrs) {
			var model = $parse(attrs.fileModel);
			var modelSetter = model.assign;

			element.bind('change', function () {
				scope.$apply(function () {
					modelSetter(scope, element[0].files[0]);
				});
			});
		}
	};
}]);

app.service('fileUpload', ['$http', function ($http) {

	this.uploadFileToUrl = function (dcName, userName, file, lotId, uploadUrl, $scope) {
		$("#showloader").css("display", "block");
	//	document.getElementById('list').innerHTML = '';
	//	document.getElementById('nextStep').innerHTML = '';
		var fd = new FormData();
		fd.append('dcName', dcName);
		fd.append('userName ', userName);

		fd.append('lotId', lotId);

		$http.post(uploadUrl, fd, {
			transformRequest: angular.identity,
			headers: { 'Content-Type': undefined, 'x-api-key': sessionStorage.apikey }
		})

			.success(function (response) {

				$("#showloader").css("display", "none");
				if (response.errorMessage) {
					
						$scope.isFailed = true;
						$scope.resmessage =  response.errorMessage;
						
					}else if(response.resMessage) {
						
						$scope.isSuccess = true;
						$scope.resmessage =  response.resMessage;
						$('#status').css('visibility', 'hidden');
						$scope.disable = true;
					}
			})

			.error(function (error) {
				$("#showloader").css("display", "none");
				$scope.isFailed = true;
				$scope.resmessage = "System failed. Please try again or contact WAALOS Support";

			});
	};
}]);
app.controller('SkuMarkingController', ['$http', '$q', '$interval', '$timeout', 'urlService', 'uiGridConstants', '$scope', 'commonService', 'fileUpload', function ($http, $q, $interval, $timeout, urlService, uiGridConstants, $scope, commonService, fileUpload) {
	$scope.disable = true;
	$scope.lotId = "";
	$scope.isFailedload = false;
	$scope.disableDownload = true;
	$scope.isSuccess = false;
	$scope.isFailed = false;
	$scope.resmessage = "";
	$scope.isEdit = true;
	$scope.isClicked = false;
	$scope.pagefunctionality = $scope.functionality;
	$scope.pagedc = $scope.dcName;
	$scope.mainTab = true;
	$scope.isresponce = false;
	$scope.isExcelFile = false;
	$scope.isExcelFileErrors = false;

	$scope.gridOptionsexcelFile = {

		enableSorting: true,
		useExternalPagination: true,
		multiSelect: true,
		enableRowSelection: true,//we can remove it later no use  of this
		enableSelectAll: true,//we can remove it later no use  of this             

	};
	$scope.isUpdateExcel = true;
	$scope.gridOptionsexcelFile.onRegisterApi = function (gridApi) {
		//set gridApi on scope
		$scope.gridApi = gridApi;

	};

	$scope.gridOptionsexcelFileErrors = {

		enableSorting: true,
		useExternalPagination: true,
    	exporterMenuCsv: false,
		exporterMenuPdf: false,
		enableGridMenu: true,
		exporterExcelSheetName: 'Sheet1',
		exporterExcelFilename: 'shipment_Wave_CtrlNbr.xlsx',
		multiSelect: false,
		enableColumnResizing: true,
		gridMenuShowHideColumns: false,
		exporterMenuVisibleData: false,
		enableRowSelection: false,//we can remove it later no use  of this
		enableSelectAll: false,//we can remove it later no use  of this             
		enableCellEdit: false, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
		enableCellEditOnFocus: true // set any editable column to allow edit on focus

	};

	$scope.uploadFile = function () {
		$("#showloader").css("display", "block");
		var file = $scope.myFile;
		var dcName = $scope.pagedc;
		var userName = sessionStorage.userName;
		var lotId = $scope.lotId;
		var uploadUrl = urlService.UPLOADURL_QULITYSKUS_UPLOAD;
		fileUpload.uploadFileToUrl(dcName, userName, file, lotId, uploadUrl, $scope);
	};

	$scope.clearFile = function () {
		$scope.isFailed = false;
		$scope.excelReadErrors = false;
		$scope.excelErrors = false;
		document.getElementById('list').innerHTML = '';
		document.getElementById('nextStep').innerHTML = '';
		$scope.errorMessagesArray = [];
		$scope.disableDownload = true;
	};


	var fileInput = document.getElementById("uploadFile");
	$scope.uploadchange = function (evt) {

		if (evt.value.length == 0) {


		} else {

			$scope.excelErrors = false;
			$scope.isFailedload = false;
			$scope.excelReadErrors = false;
			$scope.isFailed = false;
			//document.getElementById('list').innerHTML = '';
			//document.getElementById('nextStep').innerHTML = '';
			$scope.errorMessagesArray = [];

			fileExtension = evt.value.substr((evt.value.lastIndexOf('.') + 1));

			if (fileExtension == "xls") {
				$scope.isFailed = true;
				$scope.resmessage = "Please save this xls file into xlsx format and try again to Choose File";
				return false;
			}


			if (evt.value.indexOf(".xlsx") < 0) {
				$scope.isFailed = true;
				$scope.resmessage = "Please choose only XLSX file";
				return false;
			}


			var dcName = $scope.dcName;
			var userName = sessionStorage.userName;
			var files = evt.files;
			var fileval = $("input[type='file']").val();
			var output = [];
			if (fileval == '' || fileval == undefined || fileval == null) {
				//document.getElementById('list').innerHTML = '';
				//document.getElementById('nextStep').innerHTML = '';
				$scope.disable = false;
			} else {
				$("#showloader").css("display", "block");
				var uploadUrl = urlService.UPLOADURL_QULITYSKUS_CHOOSE;
				for (var i = 0, f; f = files[i]; i++) {
					output.push('<li><strong>', escape(f.name), '</strong> was choosen successfully</li>');
					localStorage.setItem("choosenFile", files[i]);
					var file = files[i];
					var fd = new FormData();
					fd.append('dcName', dcName);
					fd.append('userName', userName);
					fd.append('file', file);
					if (files[i].size < 1024 * 1024 * 10) {
						$http.post(uploadUrl, fd, {
							transformRequest: angular.identity,
							headers: { 'Content-Type': undefined, 'x-api-key': sessionStorage.apikey }
						})

							.success(function (response) {
								$("#showloader").css("display", "none");
								$scope.isresponce = true;
								$scope.disable = true;
								$scope.errorcount = response.errorCount;
								$scope.successcount = response.successCount;
								$scope.status = response.status;
								if (response.errorDtoLst != null) {
									if (response.errorDtoLst.length > 0) {
										$scope.errorList = response.errorDtoLst;
										if ($scope.successcount == 0) {
											$scope.errorListData('allerrors');
										}
									}
								}
								if (response.lotId) {
									$scope.lotId = response.lotId;
									if (response.validSkuMarkDataList != null) {
										if (response.validSkuMarkDataList.length > 0) {
											$scope.disable = false;
											$scope.isExcelFile = true;
											$scope.gridOptionsexcelFile.columnDefs = [
												
												{ name: 'rowNum', displayName: 'Row Num', cellTooltip: true, headerTooltip: true },
												{ name: 'status', displayName: 'Status', cellTooltip: true, headerTooltip: true },
												{ name: 'style', displayName: 'Style', visible: true },
												{ name: 'techSize', displayName: 'Tech Size', cellTooltip: true, headerTooltip: true },
												{ name: 'model', displayName: 'Model', cellTooltip: true, headerTooltip: true },
											    { name: 'startWeek', displayName: 'Start Week', cellTooltip: true, headerTooltip: true },
												{ name: 'comment', displayName: 'Comment', cellTooltip: true, headerTooltip: true },
											
											];
											$scope.gridOptionsexcelFile.data = response.validSkuMarkDataList;
											if ($scope.gridOptionsexcelFile.data.length > 10) {
												$scope.gridOptionsexcelFile.enableVerticalScrollbar = 1;
												$scope.gridOptionsexcelFile.enableHorizontalScrollbar = 1;
											} else {
												$scope.gridOptionsexcelFile.enableVerticalScrollbar = 0;
												$scope.gridOptionsexcelFile.enableHorizontalScrollbar = 1;
											}
										}

									}
								} else if (response.errorMessage) {
									$scope.disable = true;
									$scope.isExcelFile = false;
								        $scope.isresponce = false;
									$scope.isFailed = true;
									$scope.resmessage = response.errorMessage;
								} else {
									$scope.disable = true;
									$scope.isSuccess = true;
									$scope.resmessage = response.resMessage;
								}
							})
							.error(function (err) {
								$("#showloader").css("display", "none");
								$scope.isFailed = true;
								if (data != null) {
									var result = data.replace(/(<([^>]+)>)/ig, "");
									$scope.resmessage = "System failed. Please try again or contact WAALOS Support ( " + result + " )";
								} else {
									$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
								}
							});
					} else {
						$("#showloader").css("display", "none");
						$scope.isFailed = true;
						$scope.resmessage = "File size should not exceed 10MB";
						$scope.errorMessagesArray = [];
					}

				}
			}
		}
	};

	$scope.errorListData = function (errorsfalg) {
		$scope.isSuccess = false;
		$scope.isFailed = false;
		$scope.isExcelFile = false;
		$scope.isExcelFileErrors = true;
		if (errorsfalg) {
			$scope.allErrors = false;
		} else {
			$scope.allErrors = true;
		}
		$scope.gridOptionsexcelFileErrors.columnDefs = [
			{ name: 'rowNo', displayName: 'Row Num', cellTooltip: true, headerTooltip: true },
			{ name: 'errorType', displayName: 'Error Type', cellTooltip: true, headerTooltip: true },
			{ name: 'errorDescription', displayName: 'Error Description', cellTooltip: true, headerTooltip: true }


		];

		$scope.gridOptionsexcelFileErrors.data = $scope.errorList;

		if ($scope.gridOptionsexcelFileErrors.data.length > 10) {
			$scope.gridOptionsexcelFileErrors.enableVerticalScrollbar = 1;
			$scope.gridOptionsexcelFileErrors.enableHorizontalScrollbar = 1;
		} else {
			$scope.gridOptionsexcelFileErrors.enableVerticalScrollbar = 0;
			$scope.gridOptionsexcelFileErrors.enableHorizontalScrollbar = 1;
		}
	};

	$scope.backToSuccess = function () {
		$scope.isFailed = false;
		$scope.isExcelFile = true;
		$scope.isExcelFileErrors = false;
	};

	$scope.uploadclick = function () {
		var input = document.getElementById("uploadFile");
		if (input.value.length == 0) {
		} else if (input.value.length > 0) {
			input.value = null;
			input.value = '';
			input.type = '';
			input.type = 'file';
			document.getElementById("uploadFile").value = null;
		}
	};

	$scope.datePicker = {
		date: ""
	};
	$scope.datePicker.date = {
		startDate: moment().subtract(1, "days").format(),
		endDate: moment().format(),
	};
	$scope.minDate = moment().subtract(1, 'months').format();
	$scope.maxDate = moment().format();
	$scope.singleDate = moment();

	$scope.opts = {
		showWeekNumbers: true,
		hoverDate:false,
		locale: {
			applyClass: 'btn-green',
			applyLabel: "Apply",
			fromLabel: "From",
			format: "YYYY-MM-DD",
			toLabel: "To",
			cancelLabel: 'Cancel',
			customRangeLabel: 'Custom range',

		},
		ranges: {
			'Last 7 Days': [moment().subtract(6, 'days'), moment()],
			'Last 30 Days': [moment().subtract(29, 'days'), moment()]
		}
	};

	$scope.setStartDate = function () {
		$scope.datePicker.date.startDate = moment().subtract(4, "days").toDate();
	};

	$scope.setRange = function () {
		$scope.datePicker.date = {
			startDate: moment().subtract(5, "days"),
			endDate: moment()
		};
	};
	$scope.type = "getTopSkus";
	$scope.flags = {
		getTopSkus: true,
		msCapacity: false,
		isGetTopSkus: false,
		isMsCapacity: false
	};


	$scope.gridOptions = {
		paginationPageSizes: [15, 25, 50, 100],
		paginationPageSize: 15,
		enableSorting: true,
		useExternalPagination: true,

		multiSelect: false,
		enableRowSelection: false,//we can remove it later no use  of this
		enableSelectAll: false,//we can remove it later no use  of this             
		enableCellEdit: false, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
		enableCellEditOnFocus: true // set any editable column to allow edit on focus
	};

	$scope.gridOptions.onRegisterApi = function (gridApi) {
		//set gridApi on scope
		$scope.gridApi = gridApi;
		$scope.gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
			$scope.pageNo = newPage;
			$scope.pageSize = pageSize;
                        
		});
	};

	$scope.gridOptionsViewmarked = {
		paginationPageSizes: [15, 25, 50, 100],
		paginationPageSize: 15,
		enableSorting: true,
		useExternalPagination: true,

		multiSelect: false,
		enableRowSelection: false,//we can remove it later no use  of this
		enableSelectAll: false,//we can remove it later no use  of this             
		enableCellEdit: false, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
		enableCellEditOnFocus: true // set any editable column to allow edit on focus
	};

	$scope.gridOptionsViewmarked.onRegisterApi = function (gridApi) {
		//set gridApi on scope
		$scope.gridApi = gridApi;
		$scope.gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
			$scope.pageNo = newPage;
			$scope.pageSize = pageSize;
                     $scope.viewMarkedSkus();
		});
	};


	$scope.gridOptionsGettopskus = {
		paginationPageSizes: [15, 25, 50, 100],
		paginationPageSize: 15,
		enableSorting: true,
		useExternalPagination: true,

		multiSelect: true,
		enableRowSelection: true,//we can remove it later no use  of this
		enableSelectAll: true,//we can remove it later no use  of this             

	};
	$scope.isEdit = true;
	$scope.gridOptionsGettopskus.onRegisterApi = function (gridApi) {
		//set gridApi on scope
		$scope.gridApi = gridApi;
		$scope.gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
			$scope.pageNo = newPage;
			$scope.pageSize = pageSize;
			$scope.dateinfo();
		});

		gridApi.selection.on.rowSelectionChangedBatch($scope, function (rows) {
			$scope.isSuccess = false;
			$scope.isFailed = false;
			if ($scope.gridApi.selection.getSelectedRows().length == 0) {
				$scope.isEdit = true;
			} else {
				$scope.isEdit = false;

			}
		});

		gridApi.selection.on.rowSelectionChanged($scope, function (row) {
			$scope.isSuccess = false;
			$scope.isFailed = false;
			if ($scope.gridApi.selection.getSelectedRows().length > 0) {
				$scope.isEdit = false;
			} else {
				$scope.isEdit = true;

			}
		});

	};

	// Returns the week number as an integer
	//Watch for date changes

	$scope.getType = function (fun) {
		$scope.resmessage = "";
		$scope.isSuccess = false;
		$scope.isFailed = false;
		if (fun == "getTopSkus") {
			$scope.flags.getTopSkus = true;
			$scope.flags.msCapacity = false;
			$scope.flags.isMsCapacity = false;
		}
		else {
			$scope.flags.getTopSkus = false;
			$scope.flags.msCapacity = true;
			$scope.flags.isGetTopSkus = false;
			$scope.msCapacity();
		}

	};

	$scope.dateinfo = function () {
		Date.prototype.getWeek = function () {
			var onejan = new Date(this.getFullYear(), 0, 1);
			return Math.ceil((((this - onejan) / 86400000) + onejan.getDay() + 1) / 7);
		};
		var startDateformart = new Date($scope.datePicker.date.startDate);
		var endDateformart = new Date($scope.datePicker.date.endDate);
		var start = startDateformart.getWeek();
		var end = endDateformart.getWeek();

		$scope.resmessage = "";
		$scope.isSuccess = false;
		$scope.isFailed = false;
		$("#showloader").css("display", "block");

		$scope.pageNo = $scope.pageNo ? $scope.pageNo : 1;
		$scope.pageSize = $scope.pageSize ? $scope.pageSize : $scope.gridOptionsGettopskus.paginationPageSize;

		var url = urlService.SKUMARKING_TOP_SKUS.replace('uName', sessionStorage.userName);
		url = url.replace('dName', $scope.pagedc);
		//url = url.replace('fweek',start+"-"+new Date($scope.datePicker.date.startDate).getFullYear().toString().substr(-2));
		//url = url.replace('tweek',end+"-"+new Date($scope.datePicker.date.endDate).getFullYear().toString().substr(-2));
		url = url.replace('fweek', new Date($scope.datePicker.date.startDate).getFullYear().toString() + start);
		url = url.replace('tweek', new Date($scope.datePicker.date.endDate).getFullYear().toString() + end);
		url = url.replace('pNumber', $scope.pageNo);
		url = url.replace('pSize', $scope.pageSize);

		var res = $http.get(url, {
			headers: { 'x-api-key': sessionStorage.apikey }
		});

		res.success(function (data, status, headers, config) {

			$("#showloader").css("display", "none");

			if (data.errorMessage) {
				$scope.isTable = false;
				$scope.isFailed = true;
				$scope.resmessage = data.errorMessage;
			}
			else if (data.resMessage) {
				$scope.isTable = false;
				$scope.isSuccess = true;
				$scope.resmessage = data.resMessage;
			}
			else if (data.length === 0) {
				$scope.isTable = false;
				$scope.isFailed = true;
				$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
			}
			else {
				$scope.flags.isGetTopSkus = true;
				$scope.gridOptionsGettopskus.columnDefs = [
					{ name: 'sku', displayName: 'SKU', cellTooltip: true, headerTooltip: true },
					{ name: 'division', displayName: 'Division', cellTooltip: true, headerTooltip: true },
					{ name: 'brand', displayName: 'Brand', cellTooltip: true, headerTooltip: true },
					{ name: 'qty', displayName: 'Qty', cellTooltip: true, headerTooltip: true },
					{ name: 'estdRetQty', displayName: 'EstdRetQty', cellTooltip: true, headerTooltip: true },
					{ name: 'week', displayName: 'Week', cellTooltip: true, headerTooltip: true },
					{ name: 'currTopSku', displayName: 'CurrTopSku', cellTooltip: true, headerTooltip: true },
					{ name: 'skuStockInMS', displayName: 'SkuStockInMS', cellTooltip: true, headerTooltip: true }
				];

				$scope.gridOptionsGettopskus.totalItems = data.totalNoOfRecords;
				$scope.gridOptionsGettopskus.data = data.pageItems;

				if ($scope.gridOptionsGettopskus.data.length > 10) {
					$scope.gridOptionsGettopskus.enableVerticalScrollbar = 1;
					$scope.gridOptionsGettopskus.enableHorizontalScrollbar = 1;
				} else {
					$scope.gridOptionsGettopskus.enableVerticalScrollbar = 0;
					$scope.gridOptionsGettopskus.enableHorizontalScrollbar = 1;
				}
			}

		});

		res.error(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			$scope.isTable = false;
			$scope.isFailed = true;
			if (data != null) {
				var result = data.replace(/(<([^>]+)>)/ig, "");
				$scope.resmessage = "System failed. Please try again or contact WAALOS Support ( " + result + " )";
			} else {
				$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
			}

		});
		$scope.disableinput();
	};

	$scope.skutoMarkUpdate = function () {
		$scope.resmessage = "";
		$scope.isSuccess = false;
		$scope.isFailed = false;

		$("#showloader").css("display", "block");
		var postRecords = [];
		angular.forEach($scope.gridApi.selection.getSelectedRows(), function (data, index) {
			postRecords.push(data.sku);
		});
		var input =
			{
				"dcName": $scope.pagedc,
				"userName": sessionStorage.userName,
				"skus": postRecords
			};

		var url = urlService.SKUMARKING_TOP_SKUS_UPDATE;
		var res = $http.post(url, input, {
			headers: { 'x-api-key': sessionStorage.apikey }
		});

		res.success(function (data, status, headers, config) {

			$("#showloader").css("display", "none");

			if (data.errorMessage) {
				$scope.isTable = false;
				$scope.isFailed = true;
				$scope.resmessage = data.errorMessage;
			}
			else if (data.resMessage) {
				$scope.isTable = false;
				$scope.dateinfo();
				$scope.isSuccess = true;
				$scope.resmessage = data.resMessage;
				$scope.isEdit = true;
			}
			else if (data.length === 0) {
				$scope.isTable = false;
				$scope.isFailed = true;
				$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
			}
		});

		res.error(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			$scope.isTable = false;
			$scope.isFailed = true;
			if (data != null) {
				var result = data.replace(/(<([^>]+)>)/ig, "");
				$scope.resmessage = "System failed. Please try again or contact WAALOS Support ( " + result + " )";
			} else {
				$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
			}

		});
	};

	$scope.addtopsku = function () {
		$scope.resmessage = "";
		$scope.isSuccess = false;
		$scope.isFailed = false;
	};
	$scope.getTopSkus = function () {
		$scope.resmessage = "";
		$scope.isSuccess = false;
		$scope.isFailed = false;
	};



	$scope.viewMarkedSkus = function (val) {
		$scope.resmessage = "";
		$scope.isSuccess = false;
		$scope.isFailed = false;
		$("#showloader").css("display", "block");
		if (val) {
			$scope.pageNo = 1;
			$scope.pageSize = 15;
		} else {
                        $scope.pageNo = $scope.pageNo ? $scope.pageNo : 1;
			$scope.pageSize = $scope.pageSize ? $scope.pageSize : $scope.gridOptionsViewmarked.paginationPageSize;

		}

		var url = urlService.SKUMARKING_VIEW_MARKED.replace('uName', sessionStorage.userName);
		url = url.replace('dName', $scope.pagedc);
		url = url.replace('pNumber', $scope.pageNo);
		url = url.replace('pSize', $scope.pageSize);

		var res = $http.get(url, {
			headers: { 'x-api-key': sessionStorage.apikey }
		});

		res.success(function (data, status, headers, config) {

			$("#showloader").css("display", "none");

			if (data.errorMessage) {
				$scope.isTable = false;
				$scope.isFailed = true;
				$scope.resmessage = data.errorMessage;
			}
			else if (data.resMessage) {
				$scope.isTable = false;
				$scope.isSuccess = true;
				$scope.resmessage = data.resMessage;
			}
			else if (data.length === 0) {
				$scope.isTable = false;
				$scope.isFailed = true;
				$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
			}
			else {
				$scope.isTable = true;
				$scope.gridOptionsViewmarked.columnDefs = [
					{ name: 'skuId', displayName: 'SKU ID', cellTooltip: true, headerTooltip: true },
					{ name: 'week', displayName: 'Week', cellTooltip: true, headerTooltip: true },
					{ name: 'endWeek', displayName: 'End Week', cellTooltip: true, headerTooltip: true },
					{ name: 'priority', displayName: 'Priority', cellTooltip: true, headerTooltip: true },
					{ name: 'comment', displayName: 'Comment', cellTooltip: true, headerTooltip: true }
				];

				$scope.gridOptionsViewmarked.totalItems = data.totalNoOfRecords;
				$scope.gridOptionsViewmarked.data = data.pageItems;

				if ($scope.gridOptionsViewmarked.data.length > 10) {
					$scope.gridOptionsViewmarked.enableVerticalScrollbar = 1;
					$scope.gridOptionsViewmarked.enableHorizontalScrollbar = 1;
				} else {
					$scope.gridOptionsViewmarked.enableVerticalScrollbar = 0;
					$scope.gridOptionsViewmarked.enableHorizontalScrollbar = 1;
				}
			if(val){$scope.gridOptionsViewmarked.paginationCurrentPage  = 1;}
			setTimeout(function(){  $('.ui-grid-pager-control-input').attr( "disabled", true );  }, 2000);
			}
	


		});

		res.error(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			$scope.isTable = false;
			$scope.isFailed = true;
			if (data != null) {
				var result = data.replace(/(<([^>]+)>)/ig, "");
				$scope.resmessage = "System failed. Please try again or contact WAALOS Support ( " + result + " )";
			} else {
				$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
			}

		});
		$scope.disableinput();
	};

	$scope.disableinput = function () {
		setTimeout(function () { $('.ui-grid-pager-control-input').attr("disabled", true); }, 2000);

	};


	$scope.msCapacity = function (val) {
		$scope.resmessage = "";
		$scope.isSuccess = false;
		$scope.isFailed = false;
		$("#showloader").css("display", "block");
		if (val) {
			$scope.pageNo = $scope.pageNo ? $scope.pageNo : 1;
			$scope.pageSize = $scope.pageSize ? $scope.pageSize : $scope.gridOptions.paginationPageSize;
		} else {
			$scope.pageNo = 1;
			$scope.pageSize = 15;
		}

		var url = urlService.SKUMARKING_MS_CAPACITY.replace('uName', sessionStorage.userName);
		url = url.replace('dName', $scope.pagedc);


		var res = $http.get(url, {
			headers: { 'x-api-key': sessionStorage.apikey }
		});

		res.success(function (data, status, headers, config) {

			$("#showloader").css("display", "none");

			if (data.errorMessage) {
				$scope.isTable = false;
				$scope.isFailed = true;
				$scope.resmessage = data.errorMessage;
			}
			else if (data.resMessage) {
				$scope.isTable = false;
				$scope.isSuccess = true;
				$scope.resmessage = data.resMessage;
			}
			else if (data.length === 0) {
				$scope.isTable = false;
				$scope.isFailed = true;
				$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
			}
			else {
				$scope.flags.isMsCapacity = true;
				$scope.gridOptions.columnDefs = [
					{ name: 'stockType', displayName: 'Stock Type', cellTooltip: true, headerTooltip: true },
					{ name: 'qty', displayName: 'Qty', cellTooltip: true, headerTooltip: true },
					{ name: 'capacity', displayName: 'Capacity', cellTooltip: true, headerTooltip: true },
					{ name: 'fillGrade', displayName: 'Fill Grade', cellTooltip: true, headerTooltip: true }

				];


				$scope.gridOptions.data = data;

				if ($scope.gridOptions.data.length > 10) {
					$scope.gridOptions.enableVerticalScrollbar = 1;
					$scope.gridOptions.enableHorizontalScrollbar = 1;
				} else {
					$scope.gridOptions.enableVerticalScrollbar = 0;
					$scope.gridOptions.enableHorizontalScrollbar = 1;
				}
			}

		});

		res.error(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			$scope.isTable = false;
			$scope.isFailed = true;
			if (data != null) {
				var result = data.replace(/(<([^>]+)>)/ig, "");
				$scope.resmessage = "System failed. Please try again or contact WAALOS Support ( " + result + " )";
			} else {
				$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
			}

		});
		$scope.disableinput();
	};

	$scope.disableinput = function () {
		setTimeout(function () { $('.ui-grid-pager-control-input').attr("disabled", true); }, 2000);

	};

	$scope.addQulitySku = function(){
		$scope.resmessage = "";
		$scope.isSuccess = false;
		$scope.isFailed = false;
	};
	//user favourites code starts
	$scope.addToFavourate = function (isClicked) {
		$("#showloader").css("display", "block");
		if (typeof isClicked !== "boolean") {
			commonService.postServiceResponse(urlService.GET_FAVOURITES, { "username": sessionStorage.userName })
				.then(function (response) {

					$("#showloader").css("display", "none");
					_.each(response, function (val, key) {
						if (val.funName == $scope.functionality && val.dcName == $scope.dcName) {
							$scope.isClicked = true;
						}
					});
				}, function (error) {
					$("#showloader").css("display", "none");
					$scope.isClicked = false;
				});
			//$scope.isClicked = ;
		} else {
			if (!$scope.isClicked) {
				commonService.postServiceResponse(urlService.ADD_FAVOURITE, { "username": sessionStorage.userName, "dcName": $scope.dcName, "funName": $scope.functionality })
					.then(function (response) {


						$("#showloader").css("display", "none");
						if (response.errorMessage) {
							$scope.isFavouriteAdded = false;
							$scope.isClicked = false;
							$scope.$broadcast('showAlert', ['']);
						} else {
							$scope.isClicked = true;
							$scope.isClicked = !isClicked;
							$scope.isFavouriteAdded = true;
							$scope.favouriteMsg = response.resMessage;
							$scope.$broadcast('ClickedOnFavourate', [$scope.dcName, $scope.functionality, $scope.isClicked]);
						}

					}, function (error) {
						$scope.isClicked = false;
						$("#showloader").css("display", "none");
					});
				$scope.isClicked = !isClicked;
			} else {
				$("#showloader").css("display", "none");
			}
		}

	};
	$scope.addToFavourate('load');
	//user favourites code ends


	$scope.downloadExcel = function() {
		$scope.isFailed = false;
		$("#showloader").css("display", "block");
		var url;
		 url = urlService.DOWNLOAD_EXCEL.replace("lID",$scope.lotId);
		 url = url.replace('jCode',"MSU");
	
	$http({
			method: 'GET',
			url: url,
	
			headers: {				
				'Content-type': 'application/json', 'x-api-key': sessionStorage.apikey
			},
			responseType: 'arraybuffer'
		
		})
	.success( function(data, status, headers) {
	
	$("#showloader").css("display", "none");
	
		if(data.byteLength == 55){
				$scope.isFailed = true;
				  $('#alert-box').modal('show');
	
	
				  }else if(data.byteLength == 98){
			$scope.isFailed = true;
			$scope.resmessage = "Error in Downloading Excel file";
			return;
		}else{
			
			var octetStreamMime = 'application/octet-stream';
			var success = false;
	
			// Get the headers
			headers = headers();
			var blob;
			// Get the filename from the x-filename header or default to "download.bin"
			var filename = headers['x-filename'] || 'QulitySKU_Errors.xlsx';
	
			// Determine the content type from the header or default to "application/octet-stream"
			var contentType = headers['content-type'] || octetStreamMime;
	
			try
			{
				// Try using msSaveBlob if supported
				console.log("Trying saveBlob method ...");
				 blob = new Blob([data], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
				if(navigator.msSaveBlob)
					navigator.msSaveBlob(blob, filename);
				else {
					// Try using other saveBlob implementations, if available
					var saveBlob = navigator.webkitSaveBlob || navigator.mozSaveBlob || navigator.saveBlob;
					if(saveBlob === undefined) throw "Not supported";
					saveBlob(blob, filename);
				}
				console.log("saveBlob succeeded");
				success = true;
			} catch(ex)
			{
				console.log("saveBlob method failed with the following exception:");
				console.log(ex);
			}
	
			if(!success)
			{
				// Get the blob url creator
				var urlCreator = window.URL || window.webkitURL || window.mozURL || window.msURL;
				if(urlCreator)
				{
					// Try to use a download link
					var link = document.createElement('a');
					if('download' in link)
					{
						// Try to simulate a click
						try
						{
							// Prepare a blob URL
							console.log("Trying download link method with simulated click ...");
							 blob = new Blob([data], { type: contentType });
							 url = urlCreator.createObjectURL(blob);
							link.setAttribute('href', url);
	
							// Set the download attribute (Supported in Chrome 14+ / Firefox 20+)
							link.setAttribute("download", filename);
	
							// Simulate clicking the download link
							var event = document.createEvent('MouseEvents');
							event.initMouseEvent('click', true, true, window, 1, 0, 0, 0, 0, false, false, false, false, 0, null);
							link.dispatchEvent(event);
							console.log("Download link method with simulated click succeeded");
							success = true;
	
						} catch(ex) {
							console.log("Download link method with simulated click failed with the following exception:");
							console.log(ex);
						}
					}
	
					if(!success)
					{
						// Fallback to window.location method
						try
						{
							// Prepare a blob URL
							// Use application/octet-stream when using window.location to force download
							console.log("Trying download link method with window.location ...");
							 blob = new Blob([data], { type: octetStreamMime });
							 url = urlCreator.createObjectURL(blob);
							window.location = url;
							console.log("Download link method with window.location succeeded");
							success = true;
						} catch(ex) {
							console.log("Download link method with window.location failed with the following exception:");
							console.log(ex);
						}
					}
	
				}
			}
	
			if(!success)
			{
				// Fallback to window.open method
				console.log("No methods worked for saving the arraybuffer, using last resort window.open");
				window.open(rowData.pathName, '_blank', '');
			}
		}
	})
	.error(function(data, status, config) {
	
		console.log("Request failed with status: " + status);
	$("#showloader").css("display", "none");
		// Optionally write the error out to scope
		//$scope.errorDetails = "Request failed with status: " + status;
	$scope.isFailed = true;
			$scope.resmessage = "Error in downloading Excel File";
	
	});
	};

}]);