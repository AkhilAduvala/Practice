var app = angular.module('prewaveReport', ['ui.bootstrap', 'ngTouch', 'ui.grid', 'ui.grid.selection', 'ui.grid.pagination', 'ui.grid.exporter', 'ui.grid.autoResize']);
app.directive('fileModel', ['$parse', function ($parse) {
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {
            var model = $parse(attrs.fileModel);
            var modelSetter = model.assign;

            element.bind('change', function () {
                scope.$apply(function () {
                    modelSetter(scope, element[0].files[0]);
                });
            });
        }
    };
}]);
app.service('fileUpload2', ['$http', function ($http) {
    this.uploadFileToUrl = function (dcName, userName, file, lotId, uploadUrl, $scope) {
        $("#showloader").css("display", "block");
        document.getElementById('list').innerHTML = '';
        document.getElementById('nextStep').innerHTML = '';
        var fd = new FormData();
        fd.append('dcName', dcName);
        fd.append('userName', userName);

        fd.append('lotId', lotId);

        $http.post(uploadUrl, fd, {
            transformRequest: angular.identity,
            headers: { 'Content-Type': undefined, 'x-api-key': sessionStorage.apikey }
        })

            .success(function (response) {
                document.getElementById('list').innerHTML = '';
                document.getElementById('nextStep').innerHTML = '';
                $("#showloader").css("display", "none");
                if (response.errorMessage) {
                    $scope.uploadError = response.errorMessage;
                } else {
                    document.getElementById('list').innerHTML = response.resMessage;
                    pr.disable = true;
                    $scope.errorMessagesArray = [];


                }
            })

            .error(function (error) {
                $("#showloader").css("display", "none");
                pr.isFailedload = true;
                document.getElementById('list').innerHTML = '';
                document.getElementById('nextStep').innerHTML = '';
                $scope.errorMessagesArray = [];
            });
    };
}]);
app.controller('prewaveReportCtrl', ['$scope', '$http', '$q', '$interval', '$timeout', 'urlService', 'uiGridConstants', 'uiGridExporterConstants', 'uiGridExporterService', 'commonService','$rootScope', '$window', 'fileUpload2', function ($scope, $http, $q, $interval, $timeout, urlService, uiGridConstants, uiGridExporterConstants, uiGridExporterService, commonService, $rootScope, $window, fileUpload2) {
    var pr = this;
    pr.pagedc = $scope.dcName;
    pr.pagefunctionality = $scope.functionality;
    pr.isMianpage = false;
    pr.isClicked = false;
    pr.numberGridOptionssuccess = false;
    pr.numberGridOptionserror = false;
    pr.estimationDataBtn = false;
    pr.estimation = {};
    pr.selectedRowValues = [];
    pr.wavePlanning = false;
    pr.transPlanning = false;
    pr.maniFest = false;
    pr.nopermProfile = false;
    pr.replenishment = false;
    pr.estimationsInfo = false;
	pr.selectedRowValuesNew = [];
    pr.iswavePlanning = true;
    pr.istransPlanning = true;
    pr.ismaniFest = true;
    pr.isnopermProfile = true;
    pr.isreplenishment = true;
    pr.isestimationsInfo = true;
    var transPlanningData = [];
    pr.piecePick = false;
    pr.isPiecePick = false;
    pr.int2 = false;
    pr.isInt2 = false;
    pr.int2DtlsOneWms = true;
	pr.piecePickOneWms = true;
	pr.prePackVolumeIssues = false;
	pr.prePackOrderSizeIssues = false;
	pr.prePackOrderQuantityIssues = false;
    pr.piecePickOneWms = true;
    pr.estimationsOneWms = false;
    pr.isestimationsOneWms = false;
    pr.previewWave = true;
    pr.flag = false;
    pr.isTable = false;
    $("#showloader").css("display", "none");
    pr.disable = true;
    pr.disableDownload = true;
    pr.pagefunctionality = $scope.functionality;
    pr.pagedc = $scope.dcName;
    pr.lotId = "";
    pr.isClicked = false;
    pr.isFailedload = false;

    //Preview Wave Choosing and uploading and download excel
    $scope.prewaveDeselect = function () {
        var file = $scope.myFile;
        var dcName = $scope.dcName;
        var userName = sessionStorage.userName;
        var lotId = pr.lotId;
        //urlService.LAUNCH_PKT_PROFILE_LOADER
        var uploadUrl = urlService.PRE_VIEW_WAVE_DESELECT_UPLOADFILE;
        fileUpload2.uploadFileToUrl(dcName, userName, file, lotId, uploadUrl, $scope);
    };

    $scope.clearFile = function () {
        $scope.isFailed = false;
        $scope.excelReadErrors = false;
        $scope.excelErrors = false;
        document.getElementById('list').innerHTML = '';
        document.getElementById('nextStep').innerHTML = '';
        $scope.errorMessagesArray = [];
        pr.disableDownload = true;
    };

    var fileInput = document.getElementById("uploadFile");
    $scope.uploadchange = function (evt) {

        if (evt.value.length == 0) {


        } else {

            $scope.excelErrors = false;
            pr.isFailedload = false;
            $scope.excelReadErrors = false;
            $scope.isFailed = false;
            document.getElementById('list').innerHTML = '';
            document.getElementById('nextStep').innerHTML = '';
            $scope.errorMessagesArray = [];

            fileExtension = evt.value.substr((evt.value.lastIndexOf('.') + 1));

            if (fileExtension == "xls") {
                $scope.isFailed = true;
                $scope.resmessage = "Please save this xls file into xlsx format and try again to Choose File";
                return false;
            }


            if (evt.value.indexOf(".xlsx") < 0) {
                $scope.isFailed = true;
                $scope.resmessage = "Please choose only XLSX file";
                return false;
            }


            var dcName = $scope.dcName;
            var userName = sessionStorage.userName;
            var files = evt.files;
            var fileval = $("input[type='file']").val();
            var output = [];
            if (fileval == '' || fileval == undefined || fileval == null) {
                document.getElementById('list').innerHTML = '';
                document.getElementById('nextStep').innerHTML = '';
                pr.disable = false;
            } else {
                $("#showloader").css("display", "block");
                var uploadUrl = urlService.PRE_VIEW_WAVE_DESELECT_CHOOSEFILE;
                if (files[0]) {
                    output.push('<li><strong>', escape(files[0].name), '</strong> was choosen successfully</li>');
                    //localStorage.setItem("choosenFile", files[0]);
                    var file = files[0];
                    var fd = new FormData();
                    fd.append('dcName', dcName);
                    fd.append('userName', userName);
                    fd.append('file', file);
                    if (files[0].size < 1024 * 1024 * 10) {
                        $http.post(uploadUrl, fd, {
                            transformRequest: angular.identity,
                            headers: { 'Content-Type': undefined, 'x-api-key': sessionStorage.apikey }
                        })

                            .success(function (response) {
                                if (response.lotId) {
                                    pr.lotId = response.lotId;
                                    if (response.totalCount === response.errorCount) {
                                        pr.disableDownload = false;
                                        pr.disable = true;
                                        document.getElementById('nextStep').innerHTML = response.errorCount + ' ' + 'Out of' + ' ' + response.totalCount + ' ' + 'records are invalid';
                                        $scope.errorMessagesArray = response.errorDtoLst;
                                        $("#showloader").css("display", "none");
                                    } else {
                                        if (response.errorCount === 0) { pr.disableDownload = true; } else { pr.disableDownload = false; }
                                        pr.disable = false;
                                        document.getElementById('list').innerHTML = response.successCount + ' ' + 'Out of' + ' ' + response.totalCount + ' ' + 'records are valid -Please Proceed to Upload';
                                        $scope.errorMessagesArray = response.errorDtoLst;
                                        $("#showloader").css("display", "none");
                                    }
                                } else if (response.errorMessage) {
                                    pr.disableDownload = true;
                                    pr.disable = true;
                                    $scope.excelReadErrors = true;
                                    $scope.excelReadError = response;

                                    $("#showloader").css("display", "none");
                                } else {

                                    pr.disable = true;
                                    $scope.excelErrorsData = response;
                                    $scope.excelErrors = true;
                                    $("#showloader").css("display", "none");

                                }
                            })
                            .error(function (err) {
                                $("#showloader").css("display", "none");
                                pr.isFailedload = true;
                                $scope.errorMessagesArray = [];
                            });
                    } else {
                        $("#showloader").css("display", "none");
                        $scope.isFailed = true;
                        $scope.resmessage = "File size should not exceed 10MB";
                        $scope.errorMessagesArray = [];
                    }

                }
            }
        }
    };

    $scope.uploadclick = function () {

        var input = document.getElementById("uploadFile");

        if (input.value.length == 0) {

        } else if (input.value.length > 0) {
            input.value = null;
            input.value = '';
            input.type = '';
            input.type = 'file';
            document.getElementById("uploadFile").value = null;
        }
    };

    //Downloadin gerror excel for prevew Wave deselect
    $scope.downloadExcel1 = function () {
        $scope.isFailed = false;
        $("#showloader").css("display", "block");
        var url;
        url = urlService.PRE_VIEW_WAVE_DESELECT_DOWNLOAD_ERRORS.replace('LID', pr.lotId);


        $http({
            method: 'GET',
            url: url,
            headers: {
                'Content-type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'x-api-key': sessionStorage.apikey
            },
            responseType: 'arraybuffer'
        })
            .success(function (data, status, headers) {

                $("#showloader").css("display", "none");

                if (data.byteLength == 55) {
                    $scope.isFailed = true;
                    $('#alert-box').modal('show');


                } else if (data.byteLength == 98) {
                    $scope.isFailed = true;
                    $scope.resmessage = "Error in Downloading Excel file";
                    return;
                } else {

                    var octetStreamMime = 'application/octet-stream';
                    var success = false;
                    var blob;
                    // Get the headers
                    headers = headers();

                    // Get the filename from the x-filename header or default to "download.bin"
                    var filename = headers['x-filename'] || 'PreviewwaveDeselect_Error.xlsx';

                    // Determine the content type from the header or default to "application/octet-stream"
                    var contentType = headers['content-type'] || octetStreamMime;

                    try {
                        // Try using msSaveBlob if supported
                        console.log("Trying saveBlob method ...");
                        blob = new Blob([data], { type: contentType });
                        if (navigator.msSaveBlob)
                            navigator.msSaveBlob(blob, filename);
                        else {
                            // Try using other saveBlob implementations, if available
                            var saveBlob = navigator.webkitSaveBlob || navigator.mozSaveBlob || navigator.saveBlob;
                            if (saveBlob === undefined) throw "Not supported";
                            saveBlob(blob, filename);
                        }
                        console.log("saveBlob succeeded");
                        success = true;
                    } catch (ex) {
                        console.log("saveBlob method failed with the following exception:");
                        console.log(ex);
                    }

                    if (!success) {
                        // Get the blob url creator
                        var urlCreator = window.URL || window.webkitURL || window.mozURL || window.msURL;
                        if (urlCreator) {
                            // Try to use a download link
                            var link = document.createElement('a');
                            if ('download' in link) {
                                // Try to simulate a click
                                try {
                                    // Prepare a blob URL
                                    console.log("Trying download link method with simulated click ...");
                                    blob = new Blob([data], { type: contentType });
                                    url = urlCreator.createObjectURL(blob);
                                    link.setAttribute('href', url);

                                    // Set the download attribute (Supported in Chrome 14+ / Firefox 20+)
                                    link.setAttribute("download", filename);

                                    // Simulate clicking the download link
                                    var event = document.createEvent('MouseEvents');
                                    event.initMouseEvent('click', true, true, window, 1, 0, 0, 0, 0, false, false, false, false, 0, null);
                                    link.dispatchEvent(event);
                                    console.log("Download link method with simulated click succeeded");
                                    success = true;

                                } catch (ex) {
                                    console.log("Download link method with simulated click failed with the following exception:");
                                    console.log(ex);
                                }
                            }

                            if (!success) {
                                // Fallback to window.location method
                                try {
                                    // Prepare a blob URL
                                    // Use application/octet-stream when using window.location to force download
                                    console.log("Trying download link method with window.location ...");
                                    blob = new Blob([data], { type: octetStreamMime });
                                    url = urlCreator.createObjectURL(blob);
                                    window.location = url;
                                    console.log("Download link method with window.location succeeded");
                                    success = true;
                                } catch (ex) {
                                    console.log("Download link method with window.location failed with the following exception:");
                                    console.log(ex);
                                }
                            }

                        }
                    }

                    if (!success) {
                        // Fallback to window.open method
                        console.log("No methods worked for saving the arraybuffer, using last resort window.open");
                        window.open(rowData.pathName, '_blank', '');
                    }
                }
            })
            .error(function (data, status, config) {

                console.log("Request failed with status: " + status);
                $("#showloader").css("display", "none");
                // Optionally write the error out to scope
                //$scope.errorDetails = "Request failed with status: " + status;
                $scope.isFailed = true;
                $scope.resmessage = "Error in downloading Excel File";

            });
    };
    //Ending preview wave choose and upload
	
	if(pr.pagedc == "OneWMS-BDC" ){
		pr.prePackVolumeIssues = true;
		pr.prePackOrderSizeIssues = true;
		pr.prePackOrderQuantityIssues = true;
		console.log('setting prePackIssues true for BDC');
	}else{
		pr.prePackVolumeIssues = false;
		pr.prePackOrderSizeIssues = false;
		pr.prePackOrderQuantityIssues = false;
		console.log('setting prePackIssues false for other DC');
	}

    if (pr.pagedc == "OneWMS-US1" || pr.pagedc == "OneWMS-US2" ||  pr.pagedc == "OneWMS-BDC") {
        //pr.int2DtlsOneWms = false;
        //pr.piecePickOneWms = false;
        //pr.maniFest=true;
    } else {
        pr.int2DtlsOneWms = true;
        pr.piecePickOneWms = true;
        pr.estimationsOneWms = true;
        pr.isestimationsOneWms = true;

    }

    //ui grid options
    pr.numberGridOptions = {

        enableColumnMenus: false,
        enableSorting: true,
        enableRowSelection: true,//we can remove it later no use  of this
        enableSelectAll: true,//we can remove it later no use  of this             
        enableCellEdit: false, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
        enableCellEditOnFocus: true, // set any editable column to allow edit on focus

    };
	    pr.numberGridOptionsNew = {

        enableColumnMenus: false,
        enableSorting: true,
        enableRowSelection: true,//we can remove it later no use  of this
        enableSelectAll: true,//we can remove it later no use  of this             
        enableCellEdit: false, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
        enableCellEditOnFocus: true, // set any editable column to allow edit on focus

    };
    pr.gridOptions = angular.copy(pr.numberGridOptions);
	 pr.gridOptions = angular.copy(pr.numberGridOptionsNew);
	
    pr.TransPlanninggridOptions = angular.copy(pr.numberGridOptions);
    pr.estimationsGridOptions = angular.copy(pr.numberGridOptions);
    pr.int2OneWms = {
        enableColumnMenus: false,
        enableSorting: true,
        enableRowSelection: true,//we can remove it later no use  of this
        enableSelectAll: true,//we can remove it later no use  of this             
        enableCellEdit: false, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
        enableCellEditOnFocus: true, // set any editable column to allow edit on focus
    };
    pr.int2OneWms = {
        exporterExcelFilename: 'INT2.xlsx',
        exporterExcelLinkElement: angular.element(document.querySelectorAll(".custom-excel-link-location")),
    };

    pr.int2OneWms.onRegisterApi = function (gridApi) {
        //set gridApi on scope
        pr.gridApiInt2 = gridApi;
    };
    pr.piecePickDtls = {
        enableColumnMenus: false,
        enableSorting: true,
        enableRowSelection: true,//we can remove it later no use  of this
        enableSelectAll: true,//we can remove it later no use  of this             
        enableCellEdit: false, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
        enableCellEditOnFocus: true, // set any editable column to allow edit on focus
    };
    pr.piecePickDtls = {
        exporterExcelFilename: 'PiecePick.xlsx',
        exporterExcelLinkElement: angular.element(document.querySelectorAll(".custom-excel-link-location")),
    };

    pr.piecePickDtls.onRegisterApi = function (gridApi) {
        //set gridApi on scope
        pr.gridApiPiece = gridApi;
    };
	
	pr.prePackIssues = {
		enableColumnMenus: false,
		enableSorting: true,
		enableRowSelection: true,//we can remove it later no use  of this
		enableSelectAll: true,//we can remove it later no use  of this             
		enableCellEdit: false, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
		enableCellEditOnFocus: true, // set any editable column to allow edit on focus
	};
	pr.prePackIssues = {
		exporterExcelFilename: 'PrePackIssues.xlsx',
		exporterExcelLinkElement: angular.element(document.querySelectorAll(".custom-excel-link-location")),
	};

	pr.prePackIssues.onRegisterApi = function (gridApi) {
		//set gridApi on scope
		pr.gridApiprePackIssues = gridApi;
	};
    pr.gridOptions.onRegisterApi = function (gridApi) {

    };
    pr.TransPlanninggridOptions.onRegisterApi = function (gridApi) {

    };
  //on RegisterApi calls
    pr.numberGridOptions.onRegisterApi = function (gridApi) {
        //set gridApi on scope
        pr.gridApi = gridApi;
        gridApi.selection.on.rowSelectionChangedBatch(null, function (row) {

            pr.isSuccess = false;
            pr.isFailed = false;
            var booleanValues = [];
            _.each(row, function (value, key) {
                booleanValues.push(value.isSelected);
                pr.selectedRowValues.push({ 'number': value.entity.prewaveNumbers, 'isSelected': value.isSelected });

            });

            if (booleanValues.indexOf(true) >= 0) {
                pr.searchDisable = false;
            } else {
                pr.selectedRowValues = [];
                pr.searchDisable = true;
            }
        });
        gridApi.selection.on.rowSelectionChanged(null, function (row) {
            var booleanValues = [];

            var number = _.find(pr.selectedRowValues, function (obj) {
                return obj.number == row.entity.prewaveNumbers;
            });
            if (!number) {
                pr.selectedRowValues.push({ 'number': row.entity.prewaveNumbers, 'isSelected': row.isSelected });
            } else {
                _.each(pr.selectedRowValues, function (value, key) {
                    if (value.number == row.entity.prewaveNumbers) {
                        pr.selectedRowValues[key].isSelected = row.isSelected;
                        pr.selectedRowValues = _.reject(pr.selectedRowValues, function (d) {
                            return d.isSelected == false;
                        });
                    }
                });
            }
            _.each(pr.selectedRowValues, function (value, key) {
                booleanValues.push(value.isSelected);
            });
            if (booleanValues.indexOf(true) >= 0) {
                pr.searchDisable = false;
            } else {
                pr.searchDisable = true;
            }
            // pr.prewaveNmuber = '';
            pr.isSuccess = false;
            pr.isFailed = false;
        });
    };

    //on RegisterApi calls
    pr.numberGridOptionsNew.onRegisterApi = function (gridApi) {
        //set gridApi on scope
        pr.gridApi = gridApi;
        gridApi.selection.on.rowSelectionChangedBatch(null, function (row) {

            pr.isSuccess = false;
            pr.isFailed = false;
            var booleanValues = [];
            _.each(row, function (value, key) {
                booleanValues.push(value.isSelected);
                pr.selectedRowValuesNew.push({ 'ship_wave_nbr': value.entity.prewaveNumbers, 'isSelected': value.isSelected });

            });

            if (booleanValues.indexOf(true) >= 0) {
                pr.searchDisable = false;
            } else {
                pr.selectedRowValuesNew = [];
                pr.searchDisable = true;
            }
        });
        gridApi.selection.on.rowSelectionChanged(null, function (row) {
            var booleanValues = [];

            var ship_wave_nbr = _.find(pr.selectedRowValuesNew, function (obj) {
                return obj.ship_wave_nbr == row.entity.prewaveNumbers;
            });
            if (!ship_wave_nbr) {
                pr.selectedRowValuesNew.push({ 'ship_wave_nbr': row.entity.prewaveNumbers, 'isSelected': row.isSelected });
            } else {
                _.each(pr.selectedRowValuesNew, function (value, key) {
                    if (value.ship_wave_nbr == row.entity.prewaveNumbers) {
                        pr.selectedRowValuesNew[key].isSelected = row.isSelected;
                        pr.selectedRowValuesNew = _.reject(pr.selectedRowValuesNew, function (d) {
                            return d.isSelected == false;
                        });
                    }
                });
            }
            _.each(pr.selectedRowValuesNew, function (value, key) {
                booleanValues.push(value.isSelected);
            });
            if (booleanValues.indexOf(true) >= 0) {
                pr.searchDisable = false;
            } else {
                pr.searchDisable = true;
            }
            // pr.prewaveNmuber = '';
            pr.isSuccess = false;
            pr.isFailed = false;
        });
    };

    //searching thorugh selection and input text
    pr.getDimensionData = function (modelValue) {
        if (modelValue == 'valueChanged') {
            pr.searchDisable = pr.selectedRowValues.length ? false : true;
            //pr.gridApi.selection.clearSelectedRows();
        } else {
            //pr.prewaveReportdata(pr.prewaveNmuber ? pr.prewaveNmuber :pr.selectedRowValues); 
            var searchedValues = [];
            _.each(pr.selectedRowValues, function (val, key) {
                searchedValues.push(val.number);
            });
            $scope.searchedValues = searchedValues;
            pr.prewaveClearCache(searchedValues);

        }
    };

    pr.getDimensionDataNew = function (modelValue) {

        if (modelValue == 'valueChanged') {
            pr.searchDisable = pr.selectedRowValues.length ? false : true;
            //pr.gridApi.selection.clearSelectedRows();
        } else {

            //pr.prewaveReportdata(pr.prewaveNmuber ? pr.prewaveNmuber :pr.selectedRowValues); 


            pr.numberGridOptionsNew.data = pr.selectedRowValuesNew;
            //pr.(searchedValues);
            pr.selectedRowValuesNew = [];
            $scope.downloadExcel("PDL");
            pr.prewaveReportdata(14, '');
        }
    };

    //function to seperate the keys and values from json as Object.values is not supproted in IE
    function convertJsontoArray(values) {
        var keyValues = {
            'keys': [],
            'values': []
        };
        if (values.length) {
            _.each(values, function (val, key) {
                _.each(val, function (val, key) {
                    keyValues.keys.push(key);
                    keyValues.values.push(val);
                });
            });
        } else {
            _.each(values, function (val, key) {
                keyValues.keys.push(key);
                keyValues.values.push(val);
            });
        }

        return keyValues;
    }
    pr.fillEstimations = function () {

        if (pr.estimatedTabData) {
            $("#showloader").css("display", "none");
            pr.estimationsGridInstSpecKeys = convertJsontoArray(pr.tableData).keys;
            pr.estimationsGridInstSpecValues = convertJsontoArray(pr.tableData).values;
            pr.showInstallationSpecificDiv = false;
            pr.estimationsGridInstSpecKeys[pr.estimationsGridInstSpecKeys.indexOf('locnsNeededVal')] = "Locns Needed";
            pr.estimationsGridInstSpecKeys[pr.estimationsGridInstSpecKeys.indexOf('missingDimsVal')] = "Missing Dim";
            pr.estimationsGridInstSpecKeys[pr.estimationsGridInstSpecKeys.indexOf('missingInventoryVal')] = "Missing Inv";
            _.each(pr.estimationsGridInstSpecValues, function (val, key) {
                if (pr.estimationsGridInstSpecKeys[key] == 'missingInventory' && typeof pr.estimationsGridInstSpecValues[key] == "object") {
                    pr.estimationsGridInstSpecKeys.splice(key, 1);
                    var objVal = pr.estimationsGridInstSpecValues[key];
                    pr.estimationsGridInstSpecValues.splice(key, 1);
                    _.each(objVal, function (value, keys) {
                        pr.estimationsGridInstSpecKeys.push(keys);
                        pr.estimationsGridInstSpecValues.push(value);
                    });
                }

                if (val && val > 0) {
                    pr.showInstallationSpecificDiv = true;
                }
            });

            _.each(pr.estimationsGridInstSpecKeys, function (val, key) {
                pr.installSpecificDatakeys.push(val);
            });
            _.each(pr.estimationsGridInstSpecValues, function (val, key) {
                val = val == null ? '0.0' : val;
                pr.installSpecificDataValues.push(val);
            });
            pr.estimationDataBtn = true;
        } else {
            $("#showloader").css("display", "none");
        }

    };
    pr.fnResetData = function () {
        pr.estimation = {};
        pr.isMianpage = false;
        pr.searchshow = false;
        pr.searchDisable = false;
        pr.baseInfoData = '';
        pr.estimationsGridOptions.data = "";
        pr.estimationsGridOptions.columnDefs = [];
        pr.estimatedTabData = '';
        pr.estimatedTabGridData = '';
        pr.estimationDataBtn = false;
    };

    $scope.exportPiecePickExcel = function () {
        var grid = pr.gridApiPiece.grid;
        var rowTypes = uiGridExporterConstants.ALL;
        var colTypes = uiGridExporterConstants.ALL;
        uiGridExporterService.excelExport(grid, rowTypes, colTypes);
    };

	$scope.exportPrePackIssuesExcel = function () {
		var grid = pr.gridApiprePackIssues.grid;
		var rowTypes = uiGridExporterConstants.ALL;
		var colTypes = uiGridExporterConstants.ALL;
		uiGridExporterService.excelExport(grid, rowTypes, colTypes);
	};
	
    $scope.exportInt2Excel = function () {
        var grid = pr.gridApiInt2.grid;
        var rowTypes = uiGridExporterConstants.ALL;
        var colTypes = uiGridExporterConstants.ALL;
        uiGridExporterService.excelExport(grid, rowTypes, colTypes);
    };

	pr.getPrePackVolumeIssues = function () {
		pr.isTable = true;
		pr.resmessage = "";
		$("#showloader").css("display", "block");
		var res = $http.post(urlService.GET_PREPACKVOLUMEISSUES, { "dcName": $scope.dcName, "prewaveNumbers": $scope.searchedValues },
			{
				headers: { 'x-api-key': sessionStorage.apikey },

			});
		res.success(function (data, status, headers, config) {
			pr.searchDisable = true;
			pr.estimationDataBtn = true;
			pr.searchshow = true;
			if (data.errorMessage) {
				pr.isTable = false;
				pr.isFailed = true;
				pr.resmessage = data.errorMessage;
				$("#showloader").css("display", "none");
			} else if (data.resMessage) {
				pr.isTable = false;
				pr.isSuccess = true;
				pr.resmessage = data.resMessage;
				$("#showloader").css("display", "none");
			} else {
				pr.tableData = [];
				pr.gridData = {}
				pr.prePackIssues.columnDefs = [
					{ name: "shipWaveNbr", displayName: "Ship Wave Number", enableCellEdit: false },
					{ name: "waveNbr", displayName: "Wave Number", enableCellEdit: false },		
					{ name: "tcOrderId", displayName: "TcOrderId", enableCellEdit: false },
					{ name: "ppackGrpCode", displayName: "ppack Group Code", enableCellEdit: false },
					{ name: "assortNbr", displayName: "Assort Number", enableCellEdit: false },
					{ name: "cartonType", displayName: "Carton Type", enableCellEdit: false },
					{ name: "prePackVol", displayName: "Pre Pack Volume", enableCellEdit: false },
					{ name: "maxVol", displayName: "Max Volume", enableCellEdit: false }
				];
				pr.prePackIssues.data = data;
				$("#showloader").css("display", "none");
			}
		});
	};
	
		pr.getPrePackOrderQuantityIssues = function () {
		pr.isTable = true;
		pr.resmessage = "";
		$("#showloader").css("display", "block");
		var res = $http.post(urlService.GET_PREPACKORDERQUANTITYISSUES, { "dcName": $scope.dcName, "prewaveNumbers": $scope.searchedValues },
			{
				headers: { 'x-api-key': sessionStorage.apikey },

			});
		res.success(function (data, status, headers, config) {
			pr.searchDisable = true;
			pr.estimationDataBtn = true;
			pr.searchshow = true;
			if (data.errorMessage) {
				pr.isTable = false;
				pr.isFailed = true;
				pr.resmessage = data.errorMessage;
				$("#showloader").css("display", "none");
			} else if (data.resMessage) {
				pr.isTable = false;
				pr.isSuccess = true;
				pr.resmessage = data.resMessage;
				$("#showloader").css("display", "none");
			} else {
				pr.tableData = [];
				pr.gridData = {}
				pr.prePackIssues.columnDefs = [
					{ name: "waveNbr", displayName: "Wave Number", enableCellEdit: false },		
					{ name: "tcOrderId", displayName: "TcOrderId", enableCellEdit: false },
					{ name: "ppackGrpCode", displayName: "ppack Group Code", enableCellEdit: false },
					{ name: "assortNbr", displayName: "Assort Number", enableCellEdit: false },
					{ name: "ppackQty", displayName: "PPack Quantity", enableCellEdit: false },
					{ name: "orderQty", displayName: "Order Quantity", enableCellEdit: false },
					{ name: "itemName", displayName: "Item Name", enableCellEdit: false },
					{ name: "cartons", displayName: "Cartons", enableCellEdit: false },
					{ name: "fraction", displayName: "Fraction", enableCellEdit: false }
				];
				pr.prePackIssues.data = data;
				$("#showloader").css("display", "none");
			}
		});
	};
	
		pr.getPrePackOrderSizeIssues = function () {
		pr.isTable = true;
		pr.resmessage = "";
		$("#showloader").css("display", "block");
		var res = $http.post(urlService.GET_PREPACKORDERSIZEISSUES, { "dcName": $scope.dcName, "prewaveNumbers": $scope.searchedValues },
			{
				headers: { 'x-api-key': sessionStorage.apikey },

			});
		res.success(function (data, status, headers, config) {
			pr.searchDisable = true;
			pr.estimationDataBtn = true;
			pr.searchshow = true;
			if (data.errorMessage) {
				pr.isTable = false;
				pr.isFailed = true;
				pr.resmessage = data.errorMessage;
				$("#showloader").css("display", "none");
			} else if (data.resMessage) {
				pr.isTable = false;
				pr.isSuccess = true;
				pr.resmessage = data.resMessage;
				$("#showloader").css("display", "none");
			} else {
				pr.tableData = [];
				pr.gridData = {}
				pr.prePackIssues.columnDefs = [
					{ name: "waveNbr", displayName: "Wave Number", enableCellEdit: false },		
					{ name: "tcOrderId", displayName: "TcOrderId", enableCellEdit: false },
					{ name: "ppackGrpCode", displayName: "ppack Group Code", enableCellEdit: false },
					{ name: "assortNbr", displayName: "Assort Number", enableCellEdit: false },
					{ name: "nbrOfRatios", displayName: "nbrOfRatios", enableCellEdit: false }
				];
				pr.prePackIssues.data = data;
				$("#showloader").css("display", "none");
			}
		});
	};
	
    //function to get piece pick details for one wms us1
    pr.getPiecePickDtls = function () {
        pr.isTable = true;
        pr.resmessage = "";
        $("#showloader").css("display", "block");
        var res = $http.post(urlService.GET_ESTIMATIONS, { "dcName": $scope.dcName, "prewaveNumbers": $scope.searchedValues },
            {
                headers: { 'x-api-key': sessionStorage.apikey },

            });
        res.success(function (data, status, headers, config) {
            pr.searchDisable = true;
            pr.estimationDataBtn = true;
            pr.searchshow = true;
            if (data.errorMessage) {
                pr.isTable = false;
                pr.isFailed = true;
                pr.resmessage = data.errorMessage;
                $("#showloader").css("display", "none");
            } else if (data.resMessage) {
                pr.isTable = false;
                pr.isSuccess = true;
                pr.resmessage = data.resMessage;
                $("#showloader").css("display", "none");
            } else {
                pr.tableData = [];
                pr.gridData = {}
                pr.piecePickDtls.columnDefs = [
                    { name: "codeInfo", displayName: "Code Info", enableCellEdit: false },
                    { name: "int150Cases", displayName: "INT 50 Units", enableCellEdit: false }
                ];
                pr.piecePickDtls.data = data;
                $("#showloader").css("display", "none");
            }
        });
    };

    //function to retrieve int2 details for one wms us1 data when clicked on button
    pr.getInt2Dtls = function () {
        pr.isTable = true;
        pr.resmessage = "";
        $("#showloader").css("display", "block");
        var res = $http.post(urlService.GET_ESTIMATIONS, { "dcName": $scope.dcName, "prewaveNumbers": $scope.searchedValues },
            {
                headers: { 'x-api-key': sessionStorage.apikey },

            });
        res.success(function (data, status, headers, config) {
            pr.searchDisable = true;
            pr.searchshow = true;
            if (data.errorMessage) {
                pr.isTable = false;
                pr.isFailed = true;
                pr.resmessage = data.errorMessage;
                $("#showloader").css("display", "none");
            } else if (data.resMessage) {
                pr.isTable = false;
                pr.isSuccess = true;
                pr.resmessage = data.resMessage;
                $("#showloader").css("display", "none");
            } else {
                pr.tableData = [];
                pr.gridData = {}
                pr.int2OneWms.columnDefs = [
                    { name: "codeInfo", displayName: "Code Info", enableCellEdit: false },
                    { name: "int2Cases", displayName: "INT 2 Cases", enableCellEdit: false },
                    { name: "int2Units", displayName: "INT 2 Units", enableCellEdit: false },

                ];
                pr.int2OneWms.data = data;
                $("#showloader").css("display", "none");
            }
        });
    };
    //function to retrieve Estimation tab data when clicked on button
    pr.getEstimationsData = function () {
        pr.isTable = true;
        pr.resmessage = "";
        $("#showloader").css("display", "block");
        if (pr.estimation.length > 0) {
            if ($scope.dcName === "OneWMS-Panama") {
                pr.estimationsGridOptions.columnDefs = [
                    { name: "codeInfo", displayName: "Code Info", enableCellEdit: false },
                    { name: "int1Cases", displayName: "INT 1 Cases", enableCellEdit: false },
                    { name: "int1Units", displayName: "INT 1 Units", enableCellEdit: false },
                    { name: "int2Cases", displayName: "INT 2 Cases", enableCellEdit: false },
                    { name: "int2Units", displayName: "INT 2 Units", enableCellEdit: false },
                    { name: "int150Cases", displayName: "INT 50 Units", enableCellEdit: false }
                ];
            }
            else if ($scope.dcName === "OneWMS-Brazil" || $scope.dcName === "OneWMS-Chile" || $scope.dcName === "OneWMS-Mexico" || $scope.dcName === "OneWMS-US1" || $scope.dcName === "OneWMS-US2" || $scope.dcName === "OneWMS-BDC" ) {
                pr.estimationsGridOptions.columnDefs = [
                    { name: "codeInfo", displayName: "Code Info", enableCellEdit: false },
                    { name: "int1Cases", displayName: "INT 1 Cases", enableCellEdit: false },
                    { name: "int1Units", displayName: "INT 1 Units", enableCellEdit: false },
                    { name: "int2Cases", displayName: "INT 2 Cases", enableCellEdit: false },
                    { name: "int2Units", displayName: "INT 2 Units", enableCellEdit: false },
                    { name: "int150Cases", displayName: "INT 50 Units", enableCellEdit: false }
                ];
            }/* else if ($scope.dcName === "OneWMS-US1" || $scope.dcName === "OneWMS-US2" ) {
						pr.estimationsGridOptions.columnDefs = [
							{ name: "brand", displayName: "Brand", enableCellEdit: false },
							{ name: "channel", displayName: "Channel", enableCellEdit: false },
							{ name: "int2Units", displayName: "INT 2 Units", enableCellEdit: false },
							{ name: "int150Cases", displayName: "INT 50 Units", enableCellEdit: false }

						];
					} */
            else {
                pr.estimationsGridOptions.columnDefs = [
                    { name: "codeInfo", displayName: "Code Info", enableCellEdit: false, width: 140 },
                    { name: "int1Cases", displayName: "INT 1 Cases", enableCellEdit: false, width: 140 },
                    { name: "int1Units", displayName: "INT 1 Units", enableCellEdit: false, width: 140 },
                    { name: "int2Cases", displayName: "INT 2 Cases", enableCellEdit: false, width: 140 },
                    { name: "int2Units", displayName: "INT 2 Units", enableCellEdit: false, width: 140 },
                    { name: "int150Cases", displayName: "INT 50 Units", enableCellEdit: false, width: 140 },
                    { name: "int150Units", displayName: "INT 150 Units", enableCellEdit: false, width: 130 },
                    { name: "vasInt2Cases", displayName: "VAS Full", enableCellEdit: false, width: 130 },
                    { name: "vasInt2Units", displayName: "VAS Full Units", enableCellEdit: false, width: 130 }
                ];
            }
            pr.estimationsGridOptions.data = pr.estimation;
            $("#showloader").css("display", "none");
        } else {
            var res = $http.post(urlService.GET_ESTIMATIONS, { "dcName": $scope.dcName, "prewaveNumbers": $scope.searchedValues },
                {
                    headers: { 'x-api-key': sessionStorage.apikey },

                });
            res.success(function (data, status, headers, config) {
                pr.searchDisable = true;
                pr.estimationDataBtn = true;
                pr.searchshow = true;
                if (data.errorMessage) {
                    pr.isTable = false;
                    pr.isFailed = true;
                    pr.resmessage = data.errorMessage;
                    $("#showloader").css("display", "none");
                } else if (data.resMessage) {
                    pr.isTable = false;
                    pr.isSuccess = true;
                    pr.resmessage = data.resMessage;
                    $("#showloader").css("display", "none");
                } else {
                    pr.tableData = [];
                    pr.gridData = {}

                    if ($scope.dcName === "OneWMS-Panama") {
                        pr.estimationsGridOptions.columnDefs = [
                            { name: "codeInfo", displayName: "Code Info", enableCellEdit: false },
                            { name: "int1Cases", displayName: "INT 1 Cases", enableCellEdit: false },
                            { name: "int1Units", displayName: "INT 1 Units", enableCellEdit: false },
                            { name: "int2Cases", displayName: "INT 2 Cases", enableCellEdit: false },
                            { name: "int2Units", displayName: "INT 2 Units", enableCellEdit: false },
                            { name: "int150Cases", displayName: "INT 50 Units", enableCellEdit: false }
                        ];
                    } else if ($scope.dcName === "OneWMS-Brazil" || $scope.dcName === "OneWMS-Chile" || $scope.dcName === "OneWMS-Mexico" || $scope.dcName === "OneWMS-US1" || $scope.dcName === "OneWMS-US2" || $scope.dcName === "OneWMS-BDC" ) {
                        pr.estimationsGridOptions.columnDefs = [
                            { name: "codeInfo", displayName: "Code Info", enableCellEdit: false },
                            { name: "int1Cases", displayName: "INT 1 Cases", enableCellEdit: false },
                            { name: "int1Units", displayName: "INT 1 Units", enableCellEdit: false },
                            { name: "int2Cases", displayName: "INT 2 Cases", enableCellEdit: false },
                            { name: "int2Units", displayName: "INT 2 Units", enableCellEdit: false },
                            { name: "int150Cases", displayName: "INT 50 Units", enableCellEdit: false }
                        ];
                    }
                    /* 					else if ($scope.dcName === "OneWMS-US1" || $scope.dcName === "OneWMS-US2" ) {
                                            pr.estimationsGridOptions.columnDefs = [
                                                { name: "brand", displayName: "Brand", enableCellEdit: false },
                                                { name: "channel", displayName: "Channel", enableCellEdit: false },
                                                { name: "int2Units", displayName: "INT 2 Units", enableCellEdit: false },
                                                { name: "int150Cases", displayName: "INT 50 Units", enableCellEdit: false }
                    
                                            ];
                                        } */
                    else {
                        pr.estimationsGridOptions.columnDefs = [
                            { name: "codeInfo", displayName: "Code Info", enableCellEdit: false, width: 140 },
                            { name: "int1Cases", displayName: "INT 1 Cases", enableCellEdit: false, width: 140 },
                            { name: "int1Units", displayName: "INT 1 Units", enableCellEdit: false, width: 140 },
                            { name: "int2Cases", displayName: "INT 2 Cases", enableCellEdit: false, width: 140 },
                            { name: "int2Units", displayName: "INT 2 Units", enableCellEdit: false, width: 140 },
                            { name: "int150Cases", displayName: "INT 50 Units", enableCellEdit: false, width: 140 },
                            { name: "int150Units", displayName: "INT 150 Units", enableCellEdit: false, width: 130 },
                            { name: "vasInt2Cases", displayName: "VAS Full", enableCellEdit: false, width: 130 },
                            { name: "vasInt2Units", displayName: "VAS Full Units", enableCellEdit: false, width: 130 }
                        ];
                    }
                    pr.estimationsGridOptions.data = data;
                    pr.estimation = data;
                    pr.estimationDataBtn = true;
                    $("#showloader").css("display", "none");
                }
            });
        }


    };
    //function to get the data for grid on load and while navigating from tab to tab
    pr.prewaveReportdata = function (tabnumber, searchedValues) {
        if (pr.estimation.length > 0) {
            pr.estimationDataBtn = true;
        } else {
            pr.estimationDataBtn = false;
        }
        pr.isSuccess = false;
        pr.isTable = false;
        pr.isFailed = false;
        pr.isEdit = true;
        pr.isDelete = true;
        pr.isMianpage = true;
        pr.isEditdataSources = false;
        $("#showloader").css("display", "block");
        //var url = urlService.ATE_SLOTTING_SJ.replace('dName', $scope.pagedc);
        //url = url.replace('uName', sessionStorage.userName);
        if (pr.baseInfoData && (tabnumber == '0' || !tabnumber)) {
            pr.isTable = true;
            var data = pr.baseInfoData;
            pr.basegridDatakeys = convertJsontoArray(data.basegridData).keys;
            pr.basegridDataValues = convertJsontoArray(data.basegridData).values;
            pr.installSpecificDatakeys = convertJsontoArray(data.installSpecificData).keys;
            pr.installSpecificDataValues = convertJsontoArray(data.installSpecificData).values;
            pr.prodTypeKeys = convertJsontoArray(data.prodTypeData).keys;
            pr.prodTypeValues = convertJsontoArray(data.prodTypeData).values;
            if (!tabnumber) {
                pr.getEstimationsData();
            } else {
                pr.fillEstimations();
            }
        } else {
            var url = '';
            if (tabnumber == '0') {
                url = urlService.GET_BASE_INFO_DETAILS;
            } else if (tabnumber == '1') {
                url = urlService.GET_REPLEN_DETAILS;
            } else if (tabnumber == '2') {
                url = urlService.GET_DIM_ISSUES_DETAILS;
            } else if (tabnumber == '3') {
                url = urlService.GET_TRANSPLAN_DETAILS;
            } else if (tabnumber == '4') {
                url = urlService.GET_WAVE_PLAN_DETAILS;
            } else if (tabnumber == '5') {
                url = urlService.GET_MISSING_INV_DETAILS;
            } else if (tabnumber == '6') {
                url = urlService.NO_PERM_PROFILE_DETAILS;
            } else if (tabnumber == '9') {
                url = urlService.GET_MANIFEST_DATA;
            } else if (tabnumber == '10') {
                url = urlService.GET_PIECE_PICK_DETAILS;
            } else if (tabnumber == '11') {
                url = urlService.GET_INT2_DETAILS;
            } else if (tabnumber == '13') {
                url = urlService.GET_ESTIMATIONS_DETAILS;
            }
            else if (tabnumber == '14') {
                pr.flag = true;
                url = urlService.GET_PREWAVE_NUMBERS.replace('dName', $scope.dcName);
                url = url.replace('uName', sessionStorage.userName);

            }

            if (pr.flag == false) {

                var res = $http.post(url, { "dcName": $scope.dcName, "prewaveNumbers": searchedValues ? searchedValues : $scope.searchedValues },
                    {
                        headers: { 'x-api-key': sessionStorage.apikey },

                    });

            }
            else {
                var res = $http.get(url, {
                    headers: { 'x-api-key': sessionStorage.apikey }

                });
                pr.flag = false;
            }

            res.success(function (data, status, headers, config) {
                if (pr.estimation.length > 0) {
                    pr.estimationDataBtn = true;
                } else {
                    pr.estimationDataBtn = false;
                }
                pr.searchDisable = true;
                pr.searchshow = true;
                if (pr.pagedc == "CDC") {
                    pr.estimationDataBtn = true;
                }
                if (data.errorMessage) {
                    pr.isTable = false;
                    if (data.errorMessage == "This tab-information is not applicable to the DC selected" && tabnumber == '3') { pr.transPlanning = true; }
                    pr.isFailed = true;
                    pr.resmessage = data.errorMessage;
                    $("#showloader").css("display", "none");
                } else if (data.resMessage) {
                    pr.isTable = false;
                    pr.isSuccess = true;
                    pr.resmessage = data.resMessage;
                    $("#showloader").css("display", "none");
                } else {

                    pr.isTable = true;

                    if (tabnumber == '0') {

                        pr.baseInfoData = data;
                        pr.basegridDatakeys = convertJsontoArray(data.basegridData).keys;
                        pr.basegridDataValues = convertJsontoArray(data.basegridData).values;
                        pr.installSpecificDatakeys = convertJsontoArray(data.installSpecificData).keys;
                        pr.installSpecificDataValues = convertJsontoArray(data.installSpecificData).values;
                        pr.prodTypeKeys = convertJsontoArray(data.prodTypeData).keys;
                        pr.prodTypeValues = convertJsontoArray(data.prodTypeData).values;
                        $("#showloader").css("display", "none");

                    } else if (tabnumber == '1') {

                    }else if (tabnumber == '14') {
                        var prewaveNumbers = [];
                        pr.numberGridOptionsNew.columnDefs = [];
                        //regular expression to provide spaces at camel case notation and capitalize first letter in the word

                        pr.isTable = true;
                        if (($scope.dcName === "OneWMS-Panama") || ($scope.dcName === "OneWMS-Brazil") || ($scope.dcName === "OneWMS-Chile") || ($scope.dcName === "OneWMS-Mexico") || ($scope.dcName === "OneWMS-US1") || ($scope.dcName === "OneWMS-US2") || $scope.dcName === "OneWMS-BDC" ) {
                            pr.numberGridOptionsNew.columnDefs.push(
                                { name: 'prewaveNumbers', displayName: "Prewave Number", enableCellEdit: false }
                            );
                            pr.numberGridOptionsNew.data = data.prewaveDatalst;
                        } else {
                            _.each(data.orderId, function (val, key) {
                                orderId.push({ "orderId": val });
                            });
                            pr.numberGridOptionsNew.columnDefs.push({ name: 'orderId', displayName: "Prewave Numbers", enableCellEdit: false });
                            pr.numberGridOptionsNew.data = orderId;
                        }
                        $("#showloader").css("display", "none");
                        if (pr.numberGridOptionsNew.data > 10) {
                            pr.numberGridOptionsNew.enableVerticalScrollbar = true;
                            pr.numberGridOptionsNew.enableHorizontalScrollbar = 1;
                        } else {
                            pr.numberGridOptionsNew.enableVerticalScrollbar = false;
                            pr.numberGridOptionsNew.enableHorizontalScrollbar = 1;
                        }
                    }  
					else if (tabnumber == '2') {
                        if (($scope.dcName === "OneWMS-Panama") || ($scope.dcName === "OneWMS-Brazil") || ($scope.dcName === "OneWMS-Chile") || ($scope.dcName === "OneWMS-Mexico")) {
                            pr.gridOptions.columnDefs = [
                                { name: "pick_wave_nbr", displayName: "Pick Wave Number", enableCellEdit: false, width: 180 },
                                { name: "pickticket", displayName: "Distribution Order", enableCellEdit: false, width: 180 },
                                { name: "dsp_sku", displayName: "SKU", enableCellEdit: false, width: 180 },
                                { name: "season", displayName: "Season", enableCellEdit: false, width: 180 },
                                { name: "style", displayName: "Style", enableCellEdit: false, width: 180 },
                                { name: "style_sfx", displayName: "Style Sfx", enableCellEdit: false, width: 180 },
                                { name: "color", displayName: "Tech Size", enableCellEdit: false, width: 180 },
                                { name: "color_sfx", displayName: "Color Sfx", enableCellEdit: false, width: 180 },
                                { name: "size_desc", displayName: "Size Desc", enableCellEdit: false, width: 180 },
                                { name: "oper_code", displayName: "Oper Code", enableCellEdit: false, width: 180 },
                                { name: "sku_brcd", displayName: "SKU Barcode", enableCellEdit: false, width: 180 },
                                { name: "unit_ht", displayName: "Unit Height", enableCellEdit: false, width: 180 },
                                { name: "unit_len", displayName: "Unit Length", enableCellEdit: false, width: 180 },
                                { name: "unit_width", displayName: "Unit Width", enableCellEdit: false, width: 180 },
                                { name: "unit_wt", displayName: "Unit Weight", enableCellEdit: false, width: 180 },
                                { name: "unit_vol", displayName: "Unit Volume", enableCellEdit: false, width: 180 },
                                { name: "std_case_ht", displayName: "Std Case Height", enableCellEdit: false, width: 180 },
                                { name: "std_case_len", displayName: "Std Case length", enableCellEdit: false, width: 180 },
                                { name: "std_case_width", displayName: "Std Case Width", enableCellEdit: false, width: 180 },
                                { name: "std_case_vol", displayName: "Std Case Volume", enableCellEdit: false, width: 180 },
                                { name: "std_case_wt", displayName: "Std Case Weight", enableCellEdit: false, width: 180 },
                                { name: "std_case_qty", displayName: "Std Case Quantity", enableCellEdit: false, width: 180 },
                                { name: "std_plt_qty", displayName: "Std Plt Quantity ", enableCellEdit: false, width: 180 }
                            ];
                        } else if (($scope.dcName === "OneWMS-US1") || ($scope.dcName === "OneWMS-US2") || ($scope.dcName === "OneWMS-BDC")) {
                            pr.gridOptions.columnDefs = [
                                { name: "pick_wave_nbr", displayName: "Pick Wave Number", enableCellEdit: false, width: 180 },
                                { name: "pickticket", displayName: "Distribution Order", enableCellEdit: false, width: 180 },
                                { name: "dsp_sku", displayName: "DSP SKU", enableCellEdit: false, width: 180 },
                                { name: "style_sfx", displayName: "Style Sfx", enableCellEdit: false, width: 180 },
                                { name: "size_desc", displayName: "Size Desc", enableCellEdit: false, width: 180 },
                                { name: "sku_brcd", displayName: "SKU Barcode", enableCellEdit: false, width: 180 },
                                { name: "unit_ht", displayName: "Unit Height", enableCellEdit: false, width: 180 },
                                { name: "unit_len", displayName: "Unit Length", enableCellEdit: false, width: 180 },
                                { name: "unit_width", displayName: "Unit Width", enableCellEdit: false, width: 180 },
                                { name: "unit_wt", displayName: "Unit Weight", enableCellEdit: false, width: 180 },
                                { name: "unit_vol", displayName: "Unit Volume", enableCellEdit: false, width: 180 },
                                { name: "std_case_ht", displayName: "Std Case Height", enableCellEdit: false, width: 180 },
                                { name: "std_case_len", displayName: "Std Case length", enableCellEdit: false, width: 180 },
                                { name: "std_case_width", displayName: "Std Case Width", enableCellEdit: false, width: 180 },
                                { name: "std_case_vol", displayName: "Std Case Volume", enableCellEdit: false, width: 180 },
                                { name: "std_case_wt", displayName: "Std Case Weight", enableCellEdit: false, width: 180 },
                                { name: "std_case_qty", displayName: "Std Case Quantity", enableCellEdit: false, width: 180 },
                                { name: "std_plt_qty", displayName: "Std Plt Quantity ", enableCellEdit: false, width: 180 }
                            ];
                        }
                        else {
                            pr.gridOptions.columnDefs = [
                                { name: "pick_wave_nbr", displayName: "Pick Wave Number", enableCellEdit: false, width: 180 },
                                { name: "pickticket", displayName: "Pick Ticket", enableCellEdit: false, width: 180 },
                                { name: "dsp_sku", displayName: "DSP SKU", enableCellEdit: false, width: 180 },
                                { name: "season", displayName: "Season", enableCellEdit: false, width: 180 },
                                { name: "style", displayName: "Style", enableCellEdit: false, width: 180 },
                                { name: "style_sfx", displayName: "Style Sfx", enableCellEdit: false, width: 180 },
                                { name: "color", displayName: "Color", enableCellEdit: false, width: 180 },
                                { name: "color_sfx", displayName: "Color Sfx", enableCellEdit: false, width: 180 },
                                { name: "size_desc", displayName: "Size Description", enableCellEdit: false, width: 180 },
                                { name: "oper_code", displayName: "Oper Code", enableCellEdit: false, width: 180 },
                                { name: "sku_brcd", displayName: "SKU Barcode", enableCellEdit: false, width: 180 },
                                { name: "unit_ht", displayName: "Unit Height", enableCellEdit: false, width: 180 },
                                { name: "unit_len", displayName: "Unit Length", enableCellEdit: false, width: 180 },
                                { name: "unit_width", displayName: "Unit Width", enableCellEdit: false, width: 180 },
                                { name: "unit_wt", displayName: "Unit Weight", enableCellEdit: false, width: 180 },
                                { name: "unit_vol", displayName: "Unit Volume", enableCellEdit: false, width: 180 },
                                { name: "std_case_ht", displayName: "Std Case Height", enableCellEdit: false, width: 180 },
                                { name: "std_case_len", displayName: "Std Case length", enableCellEdit: false, width: 180 },
                                { name: "std_case_width", displayName: "Std Case Width", enableCellEdit: false, width: 180 },
                                { name: "std_case_vol", displayName: "Std Case Volume", enableCellEdit: false, width: 180 },
                                { name: "std_case_wt", displayName: "Std Case Weight", enableCellEdit: false, width: 180 },
                                { name: "std_case_qty", displayName: "Std Case Quantity", enableCellEdit: false, width: 180 },
                                { name: "std_plt_qty", displayName: "Std Plt Quantity ", enableCellEdit: false, width: 180 }
                            ];
                        }
                        pr.isTable = true;
                        pr.gridOptions.data = data;

                        $("#showloader").css("display", "none");
                    } else if (tabnumber == '3') {
                        // pr.estCartonModeData = Object.values(data.estCartonModeData[0]);
                        // pr.estCartonModekeys = Object.keys(data.estCartonModeData[0]);
                        // pr.estCartonShipviaData = Object.values(data.estCartonShipviaData[0]);
                        // pr.estCartonShipviakeys = Object.keys(data.estCartonShipviaData[0]);
                        // var  estCubingData = data.estCubingData;
                        pr.gridOptions.columnDefs = [
                            { name: "shipToCntry", displayName: "Ship to Country", enableCellEdit: false },
                            { name: "estShipVia", displayName: "Estimated Ship Via", enableCellEdit: false },
                            { name: "billShipVia", displayName: "Bill Ship Via", enableCellEdit: false },
                            { name: "estCartons", displayName: "Estimated Cartons", enableCellEdit: false },
                            { name: "estVol", displayName: "Estimated Volume", enableCellEdit: false },
                            { name: "estWt", displayName: "Estimated Weight", enableCellEdit: false },
                        ];
                        pr.TransPlanninggridOptions.columnDefs = [
                            { name: "estCartons", displayName: "Estimated Cartons", enableCellEdit: false },
                            { name: "estVol", displayName: "Estimated Volume", enableCellEdit: false },
                            { name: "estWt", displayName: "Estimated Weight", enableCellEdit: false },
                            { name: "mode", displayName: "Mode", enableCellEdit: false }
                        ];
                        pr.isTable = true;
                        transPlanningData = data;
                        pr.gridOptions.data = data.estCartonShipviaData;
                        pr.TransPlanninggridOptions.data = data.estCartonModeData;

                        $("#showloader").css("display", "none");

                    }
                    else if (tabnumber == '4') {
                        var estCubingData = data.estCubingData;
                        pr.gridOptions.columnDefs = [
                            { name: "pickTicket", displayName: "Pick Ticket", enableCellEdit: false },
                            { name: "estCartons", displayName: "Estimated Cartons", enableCellEdit: false },
                            { name: "estRepacks", displayName: "Estimated Repacks", enableCellEdit: false },
                            { name: "estShipVia", displayName: "Estimated Ship Via", enableCellEdit: false },
                            { name: "estVol", displayName: "Estimated Volume", enableCellEdit: false },
                            { name: "estWt", displayName: "Estimated Weight", enableCellEdit: false }

                        ];
                        pr.isTable = true;
                        pr.gridOptions.data = estCubingData;


                        pr.cusSuppliedLabelKeys = convertJsontoArray(data.cusSuppliedLabelData).keys;
                        pr.cusSuppliedLabelData = convertJsontoArray(data.cusSuppliedLabelData).values;
                        pr.specVASWorkStationKeys = convertJsontoArray(data.specVASWorkStationData).keys;
                        pr.specVASWorkStationData = convertJsontoArray(data.specVASWorkStationData).values;
                        pr.repacksCartonKeys = convertJsontoArray(data.repacksCartonData).keys;
                        pr.repacksCartonData = convertJsontoArray(data.repacksCartonData).values;
                        pr.fullCasesKeys = convertJsontoArray(data.fullCasesData).keys;
                        pr.fullCasesData = convertJsontoArray(data.fullCasesData).values;
                        pr.vasOutboundPrepKeys = convertJsontoArray(data.vasOutboundPrepData).keys;
                        pr.vasOutboundPrepData = convertJsontoArray(data.vasOutboundPrepData).values;
                        pr.looseUnitsByAreaKeys = convertJsontoArray(data.looseUnitsByArea).keys;
                        pr.looseUnitsByArea = convertJsontoArray(data.looseUnitsByArea).values;

                        if (pr.gridOptions.data > 10) {
                            pr.gridOptions.enableVerticalScrollbar = true;
                            pr.gridOptions.enableHorizontalScrollbar = 1;
                        } else {
                            pr.gridOptions.enableVerticalScrollbar = false;
                            pr.gridOptions.enableHorizontalScrollbar = 1;
                        }
                        $("#showloader").css("display", "none");
                    } else if (tabnumber == '6') {
                        if ($scope.dcName === "OneWMS-Panama") {
                            pr.gridOptions.columnDefs = [
                                { name: "ship_wave_nbr", displayName: "Pick Wave Number", enableCellEdit: false, width: 180 },
                                { name: "pkt_ctrl_nbr", displayName: "Distribution Order", enableCellEdit: false, width: 180 },
                                { name: "dsp_sku", displayName: "SKU", enableCellEdit: false, width: 180 },
                                { name: "style", displayName: "Style", enableCellEdit: false, width: 180 },
                                { name: "color", displayName: "Tech Size", enableCellEdit: false, width: 180 },
                                { name: "size_desc", displayName: "Size Desc", enableCellEdit: false, width: 180 },
                                { name: "sku_brcd", displayName: "SKU Barcode", enableCellEdit: false, width: 180 },
                                { name: "slot_misc_4", displayName: "Curr Season", enableCellEdit: false, width: 180 },
                                { name: "prod_type", displayName: "Product Type", enableCellEdit: false, width: 180 },
                                { name: "prod_group", displayName: "Brand", enableCellEdit: false, width: 180 },
                                { name: "std_case_qty", displayName: "Std Case Quantity", enableCellEdit: false, width: 180 },
                                { name: "carton_type", displayName: "Carton Type", enableCellEdit: false, width: 180 }
                            ];
                        }
                        else if ($scope.dcName === "OneWMS-Brazil" || $scope.dcName === "OneWMS-Chile" || $scope.dcName === "OneWMS-Mexico") {
                            pr.gridOptions.columnDefs = [
                                { name: "ship_wave_nbr", displayName: "Pick Wave Number", enableCellEdit: false, width: 180 },
                                { name: "pkt_ctrl_nbr", displayName: "Distribution Order", enableCellEdit: false, width: 180 },
                                { name: "dsp_sku", displayName: "Item Name", enableCellEdit: false, width: 180 },
                                { name: "style", displayName: "Style", enableCellEdit: false, width: 180 },
                                { name: "color", displayName: "Tech Size", enableCellEdit: false, width: 180 },
                                { name: "size_desc", displayName: "Size Desc", enableCellEdit: false, width: 180 },
                                { name: "sku_brcd", displayName: "SKU Barcode", enableCellEdit: false, width: 180 },
                                { name: "slot_misc_4", displayName: "Curr Season", enableCellEdit: false, width: 180 },
                                { name: "prod_type", displayName: "Product Type", enableCellEdit: false, width: 180 },
                                { name: "prod_group", displayName: "Brand", enableCellEdit: false, width: 180 },
                                { name: "std_case_qty", displayName: "Std Case Quantity", enableCellEdit: false, width: 180 },
                                { name: "carton_type", displayName: "Carton Type", enableCellEdit: false, width: 180 }
                            ];
                        }
                        else if ($scope.dcName === "OneWMS-US1" || $scope.dcName === "OneWMS-US2" || $scope.dcName === "OneWMS-BDC") {
                            pr.gridOptions.columnDefs = [
                                { name: "itemName", displayName: "Item Name", enableCellEdit: false, width: 180 },
                                { name: "itemStyleSfx", displayName: "Item Style sfx", enableCellEdit: false, width: 180 },
                                { name: "itemSizeDesc", displayName: "Item Size Desc", enableCellEdit: false, width: 180 },
                                { name: "itemBrcd", displayName: "Item Barcode", enableCellEdit: false, width: 180 },
                                { name: "prod_type", displayName: "Prod Type", enableCellEdit: false, width: 180 },
                                { name: "brand", displayName: "Brand", enableCellEdit: false, width: 180 },
                                { name: "qty", displayName: "Quantity", enableCellEdit: false, width: 180 }
                            ];
                        }
                        else {
                            pr.gridOptions.columnDefs = [
                                { name: "ship_wave_nbr", displayName: "Pick Wave Number", enableCellEdit: false, width: 180 },
                                { name: "pkt_ctrl_nbr", displayName: "Pick Ticket", enableCellEdit: false, width: 180 },
                                { name: "dsp_sku", displayName: "Dsp SKU", enableCellEdit: false, width: 180 },
                                { name: "season", displayName: "Season", enableCellEdit: false, width: 180 },
                                { name: "style", displayName: "Style", enableCellEdit: false, width: 180 },
                                { name: "style_sfx", displayName: "Style Sfx", enableCellEdit: false, width: 180 },
                                { name: "color", displayName: "Color", enableCellEdit: false, width: 180 },
                                { name: "color_sfx", displayName: "Color Sfx", enableCellEdit: false, width: 180 },
                                { name: "size_desc", displayName: "Size Description", enableCellEdit: false, width: 180 },
                                { name: "sku_brcd", displayName: "SKU Barcode", enableCellEdit: false, width: 180 },
                                { name: "slot_misc_4", displayName: "Slot Misc 4", enableCellEdit: false, width: 180 },
                                { name: "prod_type", displayName: "Product Type", enableCellEdit: false, width: 180 },
                                { name: "prod_group", displayName: "Product Group", enableCellEdit: false, width: 180 },
                                { name: "std_case_qty", displayName: "Std Case Quantity", enableCellEdit: false, width: 180 },
                                { name: "carton_type", displayName: "Carton Type", enableCellEdit: false, width: 180 }
                            ];
                        }
                        pr.isTable = true;
                        pr.gridOptions.data = data;

                        $("#showloader").css("display", "none");
                    } else if (tabnumber == '5') {
                        if ($scope.dcName === "OneWMS-Panama") {
                            pr.gridOptions.columnDefs = [
                                { name: "pick_wave_nbr", displayName: "Pick Wave Number", enableCellEdit: false, width: 160 },
                                { name: "pkt_ctrl_nbr", displayName: "Distribution Order", enableCellEdit: false, width: 160 },
                                { name: "dsp_sku", displayName: "Sku", enableCellEdit: false, width: 120 },
                                { name: "season", displayName: "Season", enableCellEdit: false, width: 120 },
                                { name: "style_sfx", displayName: "Style Sfx", enableCellEdit: false, width: 120 },
                                { name: "color", displayName: "Tech Size", enableCellEdit: false, width: 120 },
                                { name: "color_sfx", displayName: "Color Sfx", enableCellEdit: false, width: 120 },
                                { name: "size_desc", displayName: "Size Desc", enableCellEdit: false, width: 120 },
                                { name: "code_desc", displayName: "Brand", enableCellEdit: false, width: 120 },
                                { name: "qty", displayName: "Quantity", enableCellEdit: false, width: 120 }
                            ];
                        } else if ($scope.dcName === "OneWMS-Brazil" || $scope.dcName === "OneWMS-Chile" || $scope.dcName === "OneWMS-Mexico") {
                            pr.gridOptions.columnDefs = [
                                { name: "pickWaveNbr", displayName: "Pick Wave Number", enableCellEdit: false, width: 160 },
                                { name: "pktCtrlNbr", displayName: "Distribution Order", enableCellEdit: false, width: 160 },
                                { name: "itemId", displayName: "Item Id", enableCellEdit: false, width: 120 },
                                { name: "itemName", displayName: "Item Name", enableCellEdit: false, width: 120 },
                                { name: "itemStyleSfx", displayName: "Style Sfx", enableCellEdit: false, width: 120 },
                                { name: "itemSizeDesc", displayName: "Size Desc", enableCellEdit: false, width: 120 },
                                { name: "codeDesc", displayName: "Brand", enableCellEdit: false, width: 120 },
                                //{ name: "flag", displayName: "Inv Flag", enableCellEdit: false, width: 120 },
                                { name: "invnAvail", displayName: "Inv Avail", enableCellEdit: false, width: 120 },
                                { name: "skuNeedByOrder", displayName: "Need By Order", enableCellEdit: false, width: 120 },
                                { name: "skuNeedByTotal", displayName: "Need By Total", enableCellEdit: false, width: 120 },
                                { name: "missingTotal", displayName: "Quantity", enableCellEdit: false, width: 120 }
                            ];
                        }
                        else if ($scope.dcName === "OneWMS-US1" || $scope.dcName === "OneWMS-US2" || $scope.dcName === "OneWMS-BDC") {
                            pr.gridOptions.columnDefs = [
                                { name: "pickWaveNbr", displayName: "Pick Wave Number", enableCellEdit: false, width: 160 },
                                { name: "pktCtrlNbr", displayName: "Distribution Order", enableCellEdit: false, width: 160 },
                                { name: "itemId", displayName: "Item Id", enableCellEdit: false, width: 120 },
                                { name: "itemName", displayName: "Item Name", enableCellEdit: false, width: 120 },
                                { name: "itemStyleSfx", displayName: "Style Sfx", enableCellEdit: false, width: 120 },
                                { name: "itemSizeDesc", displayName: "Size Desc", enableCellEdit: false, width: 120 },
                                { name: "codeDesc", displayName: "Brand", enableCellEdit: false, width: 120 },
                                { name: "flag", displayName: "Inv Flag", enableCellEdit: false, width: 120 },
                                { name: "invnAvail", displayName: "Inv Avail", enableCellEdit: false, width: 120 },
                                { name: "skuNeedByOrder", displayName: "Need By Order", enableCellEdit: false, width: 120 },
                                { name: "skuNeedByTotal", displayName: "Need By Total", enableCellEdit: false, width: 120 },
                                { name: "missingTotal", displayName: "Missing Total", enableCellEdit: false, width: 120 },
                                { name: "noInventory", displayName: "No Inventory", enableCellEdit: false, width: 120 },
                                { name: "wsiDc1", displayName: "WSI DC1", enableCellEdit: false, width: 120 },
                                { name: "unAllocatable", displayName: "UnAllocatable", enableCellEdit: false, width: 140 }
                            ];
                        }

                        else {
                            pr.gridOptions.columnDefs = [
                                { name: "pick_wave_nbr", displayName: "Pick Wave Number", enableCellEdit: false },
                                { name: "pkt_ctrl_nbr", displayName: "Pick Ticket", enableCellEdit: false },
                                { name: "dsp_sku", displayName: "Dsp Sku", enableCellEdit: false },
                                { name: "season", displayName: "Season", enableCellEdit: false },
                                { name: "style", displayName: "Style", enableCellEdit: false },
                                { name: "style_sfx", displayName: "Style Sfx", enableCellEdit: false },
                                { name: "color", displayName: "Color", enableCellEdit: false },
                                { name: "color_sfx", displayName: "Color Sfx", enableCellEdit: false },
                                { name: "size_desc", displayName: "Size Description", enableCellEdit: false },
                                { name: "code_desc", displayName: "Code Description", enableCellEdit: false },
                                { name: "qty", displayName: "Quantity", enableCellEdit: false }
                            ];
                        }
                        pr.isTable = true;
                        pr.downloadfile = true;
                        pr.gridOptions.data = data;
                        $("#showloader").css("display", "none");
                    } else if (tabnumber == '9') {
                        pr.gridOptions.columnDefs = [
                            { name: "pickWaveNbr", displayName: "Wave", enableCellEdit: false, width: 150 },
                            { name: "pktCntrlNbr", displayName: "Pickticket", enableCellEdit: false, width: 150 },
                            { name: "noShipTo", displayName: "No Ship To", enableCellEdit: false, width: 150 },
                            { name: "shipToCity", displayName: "No City", enableCellEdit: false, width: 150 },
                            { name: "shipToState", displayName: "No State", enableCellEdit: false, width: 150 },
                            { name: "shipToCntry", displayName: "No Country", enableCellEdit: false, width: 150 },
                            { name: "shipVia", displayName: "No Ship Via", enableCellEdit: false, width: 150 },
                            { name: "noTel", displayName: "No Telephone", enableCellEdit: false, width: 150 },
                            { name: "noShipToContact", displayName: "No Contact", enableCellEdit: false, width: 150 },
                            { name: "commitDate", displayName: "No Commit Date", enableCellEdit: false, width: 150 },
                            { name: "collectAcctNbr", displayName: "No Act Nbr", enableCellEdit: false, width: 150 },
                            { name: "shipZip", displayName: "No Zip", enableCellEdit: false, width: 150 }
                        ];
                        pr.isTable = true;
                        pr.gridOptions.data = data;
                        $("#showloader").css("display", "none");
                    } else if (tabnumber == '10') {

                        if ($scope.dcName === "OneWMS-US1" || $scope.dcName === "OneWMS-US2" || $scope.dcName === "OneWMS-BDC") {
                            pr.gridOptions.columnDefs = [
                                { name: "brand", displayName: "Brand", enableCellEdit: false },
                                { name: "ppWhlslCount", displayName: "Wholesale Count", enableCellEdit: false },
                                { name: "ppRtlCount", displayName: "Retail Count", enableCellEdit: false },
                                { name: "ppEcomCount", displayName: "Ecom Count", enableCellEdit: false },
                                { name: "ppWhlsVasCount", displayName: "Wholesale - VAS", enableCellEdit: false },
                                { name: "ppWhlsNonVasCount", displayName: "Wholesale - Non - VAS", enableCellEdit: false }

                            ];
                        }
                        else {
                            pr.gridOptions.columnDefs = [
                                { name: "brand", displayName: "Brand", enableCellEdit: false },
                                { name: "ppWhlslCount", displayName: "Wholesale Count", enableCellEdit: false },
                                { name: "ppRtlCount", displayName: "Retail Count", enableCellEdit: false },
                                { name: "ppEcomCount", displayName: "Ecom Count", enableCellEdit: false },
                            ];
                        }
                        pr.isTable = true;
                        pr.gridOptions.data = data;
                        $("#showloader").css("display", "none");
                    } else if (tabnumber == '11') {

                        if ($scope.dcName === "OneWMS-US1" || $scope.dcName === "OneWMS-US2" || $scope.dcName === "OneWMS-BDC") {
                            /* 							var res = $http.post(urlService.GET_ESTIMATIONS, { "dcName": $scope.dcName, "prewaveNumbers": $scope.searchedValues },
                                                            {
                                                                headers: { 'x-api-key': sessionStorage.apikey },
                            
                                                            });
                                                        res.success(function (data, status, headers, config) {
                                                            pr.searchDisable = true;
                                                            pr.estimationDataBtn = true;
                                                            pr.searchshow = true;
                                                            if (data.errorMessage) {
                                                                pr.isTable = false;
                                                                pr.isFailed = true;
                                                                pr.resmessage = data.errorMessage;
                                                                $("#showloader").css("display", "none");
                                                            } else if (data.resMessage) {
                                                                pr.isTable = false;
                                                                pr.isSuccess = true;
                                                                pr.resmessage = data.resMessage;
                                                                $("#showloader").css("display", "none");
                                                            } else {
                                                                pr.tableData = [];
                                                                pr.gridData = {}
                            
                                                                pr.gridOptions.columnDefs = [
                                                                    { name: "Count", displayName: "Count", enableCellEdit: false },
                                                                    { name: "int2UnitsCount", displayName: "int2UnitsCount", enableCellEdit: false },
                                                                    { name: "int2CasesCount", displayName: "int2CasesCount", enableCellEdit: false },
                            
                                                                ];
                                                                pr.estimationsGridOptions.data = data;
                                                                pr.estimation = data;
                                                                pr.estimationDataBtn = true;
                                                                $("#showloader").css("display", "none");
                                                            }
                                                        }); */
                            if ($scope.dcName === "OneWMS-US1" || $scope.dcName === "OneWMS-US2" || $scope.dcName === "OneWMS-BDC") {

                                pr.gridOptions.columnDefs = [
                                    { name: "brand", displayName: "Brand", enableCellEdit: false },
                                    { name: "channel", displayName: "Channel", enableCellEdit: false },
                                    { name: "nonVasInt2Cases", displayName: "Non Vas Int2 Cases", enableCellEdit: false },
                                    { name: "nonVasInt2Units", displayName: "Non Vas Int2 Units", enableCellEdit: false },
                                    { name: "int2VasCases", displayName: "Int2 Vas Cases", enableCellEdit: false },
                                    { name: "int2VasUnits", displayName: "Int2 Vas Units", enableCellEdit: false },
                                ];
                            }

                        }
                        else {
                            /* 							if ($scope.dcName === "OneWMS-US1" || $scope.dcName === "OneWMS-US2" )
                                                        {
                                                        	
                                                            pr.gridOptions.columnDefs = [
                                                            { name: "brand", displayName: "Brand", enableCellEdit: false },
                                                            { name: "int2WhlslCount", displayName: "Wholesale Count", enableCellEdit: false },
                                                            { name: "int2RtlCount", displayName: "Retail Count", enableCellEdit: false },
                                                            { name: "int2EcomCount", displayName: "Ecom Count", enableCellEdit: false },
                                                            { name: "int2WhlsVasCount", displayName: "Wholesale - VAS", enableCellEdit: false },
                                                            { name: "int2WhlsNonVasCount", displayName: "Wholesale - Non - VAS", enableCellEdit: false },
                                                        ];
                                                        } */

                            pr.gridOptions.columnDefs = [
                                { name: "brand", displayName: "Brand", enableCellEdit: false },
                                { name: "int2WhlslCount", displayName: "Wholesale Count", enableCellEdit: false },
                                { name: "int2RtlCount", displayName: "Retail Count", enableCellEdit: false },
                                { name: "int2EcomCount", displayName: "Ecom Count", enableCellEdit: false },
                            ];

                        }
                        pr.isTable = true;
                        pr.gridOptions.data = data;
                        $("#showloader").css("display", "none");
                    }
                    else if (tabnumber == '13') {
                        var estTotalDto = data.estTotalDto;
                        pr.gridOptions.columnDefs = [
                            { name: "waveNbr", displayName: "Wave Number", enableCellEdit: false },
                            { name: "totalUnits", displayName: "Total Units", enableCellEdit: false },
                            { name: "sortable", displayName: "Sortable", enableCellEdit: false },
                            { name: "nonSortable", displayName: "Non Sortable", enableCellEdit: false },
                            { name: "estLpn", displayName: "Estimated LPN Count", enableCellEdit: false }

                        ];
                        pr.isTable = true;
                        pr.gridOptions.data = estTotalDto;


                        pr.reserveReplenDtoLabelKeys = convertJsontoArray(data.reserveReplenDto).keys;
                        pr.reserveReplenDtoLabelData = convertJsontoArray(data.reserveReplenDto).values;
                        pr.piecePickEcomDtoKeys = convertJsontoArray(data.piecePickEcomDto).keys;
                        pr.piecePickEcomDto = convertJsontoArray(data.piecePickEcomDto).values;
                        pr.packingDtoKeys = convertJsontoArray(data.packingDto).keys;
                        pr.packingDto = convertJsontoArray(data.packingDto).values;
                        pr.vasDtoKeys = convertJsontoArray(data.vasDto).keys;
                        pr.vasDto = convertJsontoArray(data.vasDto).values;

                        if (pr.gridOptions.data > 10) {
                            pr.gridOptions.enableVerticalScrollbar = true;
                            pr.gridOptions.enableHorizontalScrollbar = 1;
                        } else {
                            pr.gridOptions.enableVerticalScrollbar = false;
                            pr.gridOptions.enableHorizontalScrollbar = 1;
                        }
                        $("#showloader").css("display", "none");
                    }



                }

                if (pr.pagedc === "US1" || pr.pagedc === "US2" || pr.pagedc === "OneWMS-US1" || pr.pagedc === "OneWMS-US2" || pr.pagedc === "OneWMS-BDC") {
                    pr.piecePick = true;
                    pr.isPiecePick = true;
                    pr.int2 = true;
                    pr.isInt2 = true;
                    //pr.estimationsOneWms = true;
                    //pr.isestimationsOneWms = true;
                }

                if (pr.pagedc == "US1" || pr.pagedc == "US2" || pr.pagedc == "Brazil" || pr.pagedc == "Chile" || pr.pagedc == "Panama" || pr.pagedc == "Mexico" || pr.pagedc == "Montreal") {
                    pr.wavePlanning = true;
                    pr.transPlanning = true;

                    pr.iswavePlanning = false;
                    pr.istransPlanning = false;

                    $("#wavePlanning").attr("title", "This information is not applicable to your DC");
                    $("#transPlanning").attr("title", "This information is not applicable to your DC");
                }

                if (pr.pagedc == "OneWMS-Panama") {
                    pr.maniFest = true;
                    pr.replenishment = true;
                    pr.wavePlanning = true;
                    pr.transPlanning = true;
                    pr.ismaniFest = false;
                    pr.isreplenishment = false;
                    pr.iswavePlanning = false;
                    pr.istransPlanning = false;
                    $("#maniFest").attr("title", "This information is not applicable to your DC");
                    $("#replenishment").attr("title", "This information is not applicable to your DC");
                    $("#wavePlanning").attr("title", "This information is not applicable to your DC");
                    $("#transPlanning").attr("title", "This information is not applicable to your DC");
                }
               if (pr.pagedc == "OneWMS-Brazil") {
                    pr.maniFest = false;
                    pr.replenishment = true;
                    pr.wavePlanning = true;
                    pr.transPlanning = true;
                    pr.ismaniFest = true;
                    pr.isreplenishment = false;
                    pr.iswavePlanning = false;
                    pr.istransPlanning = false;
                    pr.previewWave = false;
                    //pr.isestimationsOneWms = true;
                    //$("#maniFest").attr("title", "This information is not applicable to your DC");
                    $("#replenishment").attr("title", "This information is not applicable to your DC");
                    $("#wavePlanning").attr("title", "This information is not applicable to your DC");
                    $("#transPlanning").attr("title", "This information is not applicable to your DC");

                }
				
				if (pr.pagedc == "OneWMS-Chile") {
					    pr.maniFest = false;
                    pr.replenishment = true;
                    pr.wavePlanning = true;
                    pr.transPlanning = true;
                    pr.ismaniFest = true;
                    pr.isreplenishment = false;
                    pr.iswavePlanning = false;
                    pr.istransPlanning = false;
					 pr.previewWave = false;
                    //$("#maniFest").attr("title", "This information is not applicable to your DC");
                    $("#replenishment").attr("title", "This information is not applicable to your DC");
                    $("#wavePlanning").attr("title", "This information is not applicable to your DC");
                    $("#transPlanning").attr("title", "This information is not applicable to your DC");
                }
				
                if (pr.pagedc == "OneWMS-Mexico" || $scope.dcName === "OneWMS-US1" || $scope.dcName === "OneWMS-US2" || pr.pagedc === "OneWMS-BDC") {
                    pr.maniFest = false;
                    pr.replenishment = true;
                    pr.wavePlanning = true;
                    pr.transPlanning = true;
                    pr.ismaniFest = true;
                    pr.isreplenishment = false;
                    pr.iswavePlanning = false;
                    pr.istransPlanning = false;
                    //$("#maniFest").attr("title", "This information is not applicable to your DC");
                    $("#replenishment").attr("title", "This information is not applicable to your DC");
                    $("#wavePlanning").attr("title", "This information is not applicable to your DC");
                    $("#transPlanning").attr("title", "This information is not applicable to your DC");
                }

                if (pr.pagedc == "Suzhou" || pr.pagedc == "Tianjin") {
                    pr.wavePlanning = true;
                    pr.transPlanning = true;
                    pr.maniFest = true;

                    pr.iswavePlanning = false;
                    pr.istransPlanning = false;
                    pr.ismaniFest = false;

                    $("#wavePlanning").attr("title", "This information is not applicable to your DC");
                    $("#transPlanning").attr("title", "This information is not applicable to your DC");
                    $("#maniFest").attr("title", "This information is not applicable to your DC");
                }
                if (pr.pagedc == "Scheinfeld-2") {
                    pr.wavePlanning = true;
                    pr.transPlanning = true;
                    pr.maniFest = true;
                    pr.nopermProfile = true;
                    pr.replenishment = true;

                    pr.iswavePlanning = false;
                    pr.istransPlanning = false;
                    pr.ismaniFest = false;
                    pr.isnopermProfile = false;
                    pr.isreplenishment = false;

                    $("#wavePlanning").attr("title", "This information is not applicable to your DC");
                    $("#transPlanning").attr("title", "This information is not applicable to your DC");
                    $("#maniFest").attr("title", "This information is not applicable to your DC");
                    $("#nopermProfile").attr("title", "This information is not applicable to your DC");
                    $("#replenishment").attr("title", "This information is not applicable to your DC");

                }

                if (pr.pagedc == "CDC") {

                    pr.maniFest = true;
                    pr.nopermProfile = true;
                    pr.replenishment = true;
                    pr.estimationsInfo = true;

                    pr.ismaniFest = false;
                    pr.isnopermProfile = false;
                    pr.isreplenishment = false;
                    pr.isestimationsInfo = false;

                    $("#estimationsInfo").attr("title", "This information is not applicable to your DC");
                    $("#maniFest").attr("title", "This information is not applicable to your DC");
                    $("#nopermProfile").attr("title", "This information is not applicable to your DC");
                    $("#replenishment").attr("title", "This information is not applicable to your DC");

                }



                $('.ui-grid-pager-control input').prop("disabled", true);
            });
            res.error(function (data, status, headers, config) {
                pr.searchDisable = true;
                pr.searchshow = true;
                if (pr.pagedc == "CDC") {
                    pr.estimationDataBtn = true;
                }
                $("#showloader").css("display", "none");
                pr.isFailed = true;
                pr.resmessage = "System failed. Please try again or contact WAALOS Support";

            });
        }
    };
    pr.esttab = function () {

        pr.isSuccess = false;
        pr.isFailed = false;
        if (pr.estimation.length > 0) {
            pr.isTable = true;
        } else {
            pr.isTable = false;
        }

        if (pr.pagedc == "CDC") {
            pr.estimationDataBtn = true;
            pr.cdcTab = true;
        } else {
            if (pr.estimation.length > 0) {
                pr.estimationDataBtn = true;
            } else {
                pr.estimationDataBtn = false;
            }

            pr.cdcTab = false;
        }
    };

    pr.prewaveClearCache = function (searchedValues) {
        pr.isSuccess = false;
        pr.isFailed = false;
        $("#showloader").css("display", "block");

        var url = urlService.GET_PREWAVE_CLEAR_CACHE;

        var res = $http.get(url, {
            headers: { 'x-api-key': sessionStorage.apikey }
        });
        res.success(function (data, status, headers, config) {
            $("#showloader").css("display", "none");
            if (data.errorMessage) {
                pr.prewaveReportdata('0', searchedValues);
            } else if (data.resMessage) {
                pr.prewaveReportdata('0', searchedValues);
            }

        });
        res.error(function (data, status, headers, config) {
            pr.prewaveReportdata('0', searchedValues);
        });
    };
    // function to get the number which need to be selected and pass in search 
    pr.getPrewaveNumbers = function () {
        pr.isMianpage = false;
        $("#showloader").css("display", "block");
        pr.numberGridOptions.data = [];
        pr.numberGridOptions.columnDefs = [];
        var url = urlService.GET_PREWAVE_NUMBERS.replace('dName', $scope.dcName);
        url = url.replace('uName', sessionStorage.userName);
        var res = $http.get(url, {
            headers: { 'x-api-key': sessionStorage.apikey }
        });
        res.success(function (data, status, headers, config) {
            delete data.dcName;

            if (data.errorMessage) {

                pr.numberGridOptionssuccess = false;
                pr.numberGridOptionserror = true;
                pr.resmessage = data.errorMessage;
                $("#showloader").css("display", "none");
            } else if (data.resMessage) {
                pr.numberGridOptionssuccess = true;
                pr.numberGridOptionserror = false;
                pr.resmessage = data.resMessage;
                $("#showloader").css("display", "none");
            } else {
                var prewaveNumbers = [];

                //regular expression to provide spaces at camel case notation and capitalize first letter in the word

                pr.isTable = true;
                if (($scope.dcName === "OneWMS-Panama") || ($scope.dcName === "OneWMS-Brazil") || ($scope.dcName === "OneWMS-Chile") || ($scope.dcName === "OneWMS-Mexico") || ($scope.dcName === "OneWMS-US1") || ($scope.dcName === "OneWMS-US2") || ($scope.dcName === "OneWMS-BDC")) {
                    pr.numberGridOptions.columnDefs.push(
                        { name: 'prewaveNumbers', displayName: "Prewave Number", enableCellEdit: false },
                        { name: 'waveType', displayName: "Prewave Type", enableCellEdit: false }
                    );
                    pr.numberGridOptions.data = data.prewaveDatalst;
                } else {
                    _.each(data.prewaveNumbers, function (val, key) {
                        prewaveNumbers.push({ "prewaveNumbers": val });
                    });
                    pr.numberGridOptions.columnDefs.push({ name: 'prewaveNumbers', displayName: "Prewave Numbers", enableCellEdit: false });
                    pr.numberGridOptions.data = prewaveNumbers;
                }
                $("#showloader").css("display", "none");
                if (pr.numberGridOptions.data > 10) {
                    pr.numberGridOptions.enableVerticalScrollbar = true;
                    pr.numberGridOptions.enableHorizontalScrollbar = 1;
                } else {
                    pr.numberGridOptions.enableVerticalScrollbar = false;
                    pr.numberGridOptions.enableHorizontalScrollbar = 1;
                }

            }

        });
        res.error(function (data, status, headers, config) {
            pr.numberGridOptionssuccess = false;
            pr.numberGridOptionserror = true;
            pr.resmessage = "System failed. Please try again or contact WAALOS Support";
            $("#showloader").css("display", "none");
            $scope.numberGridOptions.enableGridMenu = false;
        });
    };

    pr.addToFavourate = function (isClicked) {
        $("#showloader").css("display", "block");
        if (typeof isClicked !== "boolean") {
            commonService.postServiceResponse(urlService.GET_FAVOURITES, { "username": sessionStorage.userName })
                .then(function (response) {
                    $("#showloader").css("display", "none");
                    _.each(response, function (val, key) {
                        if (val.funName == $scope.functionality && val.dcName == $scope.dcName) {
                            pr.isClicked = true;
                        }
                    });
                }, function (error) {
                    $("#showloader").css("display", "none");
                });
            //pr.isClicked = ;
        } else {
            if (!pr.isClicked) {
                commonService.postServiceResponse(urlService.ADD_FAVOURITE, { "username": sessionStorage.userName, "dcName": $scope.dcName, "funName": $scope.functionality })
                    .then(function (response) {
                        $("#showloader").css("display", "none");
                        if (response.errorMessage) {
                            pr.isClicked = isClicked;
                            pr.isFavouriteAdded = false;
                            $scope.$broadcast('showAlert', ['']);
                        } else {
                            pr.isClicked = !isClicked;
                            pr.isFavouriteAdded = true;
                            pr.favouriteMsg = response.resMessage;
                            $scope.$broadcast('ClickedOnFavourate', [pr.dcName, $scope.functionality, pr.isClicked]);
                        }

                    }, function (error) {
                        $("#showloader").css("display", "none");
                    });
                pr.isClicked = !isClicked;
            } else {
                $("#showloader").css("display", "none");
            }
        }

    };

    pr.addToFavourate('load');
    pr.getPrewaveNumbers();



    $scope.scrolldown = function () {
        document.body.scrollTop = 500;
        document.documentElement.scrollTop = 500;
    };
    $scope.scrollup = function () {
        document.body.scrollTop = 0;
        document.documentElement.scrollTop = 0;
    };


    $scope.downloadExcel = function (jcode) {
        $scope.isFailed = false;
        $("#showloader").css("display", "block");
        var url;
        url = urlService.GET_PREWAVE_DOWNLOAD_NOPREM;
        var griddata;
        var gridTransPlanningData;
        if (($scope.dcName === "OneWMS-Brazil" && jcode == "MI") || ($scope.dcName === "OneWMS-Chile" && jcode == "MI") || ($scope.dcName === "OneWMS-Mexico" && jcode == "MI")) {
            jcode = "MIB";
        } else if (($scope.dcName === "OneWMS-US1" && jcode == "MI") || ($scope.dcName === "OneWMS-US2" && jcode == "MI") || ($scope.dcName === "OneWMS-BDC" && jcode == "MI")) {
            jcode = "MIUS12";
        }
        if (jcode == 'ET') {
            griddata = pr.estimationsGridOptions.data;
        } else if (jcode == 'TP') {
            //gridTransPlanningData.push(pr.gridOptions.data);
            //gridTransPlanningData.push(pr.TransPlanninggridOptions.data);
            gridTransPlanningData = transPlanningData;
        }
        else {
            
            if (jcode == "PDL") {
                griddata = pr.numberGridOptionsNew.data;
            }
            else {
                griddata = pr.gridOptions.data;
            }
        }

        $http({
            method: 'POST',
            url: url,
            data: { "jobcode": jcode, "getGenericDto": griddata, "getPWTransDto": gridTransPlanningData, "dcName": $scope.dcName },
            headers: {
                'Content-type': 'application/json', 'x-api-key': sessionStorage.apikey
            },
            responseType: 'arraybuffer'

        })
            .success(function (data, status, headers) {

                $("#showloader").css("display", "none");

                if (data.byteLength == 55) {
                    $scope.isFailed = true;
                    pr.isSuccess = true;
                    pr.resmessage = "No Record(s) Found";
                    return false;
                } else if (data.byteLength == 98) {
                    pr.isFailed = true;
                    pr.resmessage = "Error in Downloading Excel file";
                    return;
                } else {

                    var octetStreamMime = 'application/octet-stream';
                    var success = false;

                    // Get the headers
                    headers = headers();
                    var filename;
                    var blob;
                    // Get the filename from the x-filename header or default to "download.bin"
                    if (jcode == 'NPP') {
                        filename = headers['x-filename'] || 'NoPermProfileData.xlsx';
                    } else if (jcode == 'MI') {
                        filename = headers['x-filename'] || 'MissingInvData.xlsx';
                    } else if (jcode == 'ET') {
                        filename = headers['x-filename'] || 'EstimationsData.xlsx';
                    } else if (jcode == 'DI') {
                        filename = headers['x-filename'] || 'DimensionIssuesData.xlsx';
                    } else if (jcode == 'MF') {
                        filename = headers['x-filename'] || 'ManiFestData.xlsx';
                    } else if (jcode == 'TP') {
                        filename = headers['x-filename'] || 'TransplanningData.xlsx';
                    } else if (jcode == 'MIB') {
                        filename = headers['x-filename'] || 'MissingInvData.xlsx';
                    } else if (jcode == 'MIUS12') {
                        filename = headers['x-filename'] || 'MissingInvData.xlsx';
                    }                    else if (jcode == 'PDL') {
                        filename = headers['x-filename'] || 'PreviewWaveDeselectData.xlsx';
                    }

                    // Determine the content type from the header or default to "application/octet-stream"
                    var contentType = headers['content-type'] || octetStreamMime;

                    try {
                        // Try using msSaveBlob if supported
                        console.log("Trying saveBlob method ...");
                        blob = new Blob([data], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
                        if (navigator.msSaveBlob)
                            navigator.msSaveBlob(blob, filename);
                        else {
                            // Try using other saveBlob implementations, if available
                            var saveBlob = navigator.webkitSaveBlob || navigator.mozSaveBlob || navigator.saveBlob;
                            if (saveBlob === undefined) throw "Not supported";
                            saveBlob(blob, filename);
                        }
                        console.log("saveBlob succeeded");
                        success = true;
                    } catch (ex) {
                        console.log("saveBlob method failed with the following exception:");
                        console.log(ex);
                    }

                    if (!success) {
                        // Get the blob url creator
                        var urlCreator = window.URL || window.webkitURL || window.mozURL || window.msURL;
                        if (urlCreator) {
                            // Try to use a download link
                            var link = document.createElement('a');
                            if ('download' in link) {
                                // Try to simulate a click
                                try {
                                    // Prepare a blob URL
                                    console.log("Trying download link method with simulated click ...");
                                    blob = new Blob([data], { type: contentType });
                                    url = urlCreator.createObjectURL(blob);
                                    link.setAttribute('href', url);

                                    // Set the download attribute (Supported in Chrome 14+ / Firefox 20+)
                                    link.setAttribute("download", filename);

                                    // Simulate clicking the download link
                                    var event = document.createEvent('MouseEvents');
                                    event.initMouseEvent('click', true, true, window, 1, 0, 0, 0, 0, false, false, false, false, 0, null);
                                    link.dispatchEvent(event);
                                    console.log("Download link method with simulated click succeeded");
                                    success = true;

                                } catch (ex) {
                                    console.log("Download link method with simulated click failed with the following exception:");
                                    console.log(ex);
                                }
                            }

                            if (!success) {
                                // Fallback to window.location method
                                try {
                                    // Prepare a blob URL
                                    // Use application/octet-stream when using window.location to force download
                                    console.log("Trying download link method with window.location ...");
                                    blob = new Blob([data], { type: octetStreamMime });
                                    url = urlCreator.createObjectURL(blob);
                                    window.location = url;
                                    console.log("Download link method with window.location succeeded");
                                    success = true;
                                } catch (ex) {
                                    console.log("Download link method with window.location failed with the following exception:");
                                    console.log(ex);
                                }
                            }

                        }
                    }

                    if (!success) {
                        // Fallback to window.open method
                        console.log("No methods worked for saving the arraybuffer, using last resort window.open");
                        window.open(rowData.pathName, '_blank', '');
                    }
                }
            })
            .error(function (data, status, config) {

                console.log("Request failed with status: " + status);
                $("#showloader").css("display", "none");
                // Optionally write the error out to scope
                //$scope.errorDetails = "Request failed with status: " + status;
                pr.isFailed = true;
                pr.resmessage = "Error in downloading Excel File";

            });
    };


}]);
