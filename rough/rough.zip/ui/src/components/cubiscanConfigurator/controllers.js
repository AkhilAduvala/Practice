angular.module('cubiscanConfigurator', ['ui.grid', 'ui.grid.selection', 'ui.bootstrap', 'ui.grid.autoResize', 'ui.grid.edit'])
.controller('cubiscanConfiguratorController', ['commonService', '$http', '$scope', 'urlService', '$timeout', 'uiGridValidateService', 'uiGridConstants', function (commonService, $http, $scope, urlService, $timeout, uiGridValidateService, uiGridConstants) {
  var cc = this;
  cc.enableFirstCell = true;
  cc.enableSecondCell = true;
  cc.isFavouriteAdded = false;
  cc.isClicked = false;
  //cc.rowsChecked = false;//pradeep
  cc.editedRowData = [];
  cc.isTable = true;
  cc.isChecked = ['yes', 'no'];
  cc.dcName = $scope.dcName;
  cc.pagefunctionality = $scope.functionality;
  $('[data-toggle="tooltip"]').tooltip();
  cc.gridOptions = {
    enableColumnMenus: false,
    enableHorizontalScrollbar: false,
    multiSelect: true,//pradeep
    enableVerticalScrollbar: false,
    enableRowSelection: true,//we can remove it later no use  of this
    enableSelectAll: true,//we can remove it later no use  of this             
    enableCellEdit: cc.sampleJson, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
    enableCellEditOnFocus: true, // set any editable column to allow edit on focus
    columnDefs: [
      { name: 'dcName', displayName: '', cellEditableCondition: false },
      {
        name: 'unitLen', displayName: 'Length', sort: { direction: uiGridConstants.ASC }, validators: { required: true, numberChecker: true }, cellTemplate: 'ui-grid/cellTitleValidator', cellEditableCondition: function (cc) {
          if (cc.row.entity.dcName == 'Non-Sortable') {
            return cc.enableFirstCell;
          } else {
            return !cc.enableSecondCell;
          }
        }
      },
      {
        name: 'unitWidth', displayName: 'Width', sort: { direction: uiGridConstants.ASC }, validators: { required: true, numberChecker: true }, cellTemplate: 'ui-grid/cellTitleValidator', cellEditableCondition: function (cc) {
          if (cc.row.entity.dcName == 'Non-Sortable') {
            return cc.enableFirstCell;
          } else {
            return !cc.enableSecondCell;
          }
        }
      },
      {
        name: 'unitHt', displayName: 'Height', sort: { direction: uiGridConstants.ASC }, validators: { required: true, numberChecker: true }, cellTemplate: 'ui-grid/cellTitleValidator', cellEditableCondition: function (cc) {
          if (cc.row.entity.dcName == 'Non-Sortable') {
            return cc.enableFirstCell;
          } else {
            return !cc.enableSecondCell;
          }
        }
      },
      {
        name: 'unitWt', displayName: 'Weight', sort: { direction: uiGridConstants.ASC }, validators: { required: true, numberChecker: true }, cellTemplate: 'ui-grid/cellTitleValidator', cellEditableCondition: function (cc) {
          if (cc.row.entity.dcName == 'Non-Sortable') {
            return !cc.enableFirstCell;
          } else {
            return cc.enableSecondCell;
          }
        }
      },
      {
        name: 'unitVol', displayName: 'Volume', cellEditableCondition: function (cc) {
          if (cc.row.entity.dcName == 'Non-Sortable') {
            return cc.enableFirstCell;
          } else {
            return cc.enableSecondCell;
          }
        }
      },
      /*{name: 'nsncFlag', displayName: 'NSFC',
        cellTemplate:'<select  ng-click="grid.appScope.showMe()">  <option value="yes">YES</option>  <option value="no">NO</option></select>'
      }*/
      {
        name: 'nsncFlag', displayName: 'NSNC Flag', editableCellTemplate: 'ui-grid/dropdownEditor', width: '20%',//pradeep
        cellFilter: 'nsncFilter', editDropdownValueLabel: 'NSNC', editDropdownOptionsArray: [
          { id: 1, NSNC: 'Y' },
          { id: 2, NSNC: 'N' }
        ]
      },
    ],
    onRegisterApi: function (gridApi) {
      //set gridApi on scope
      cc.gridApi = gridApi;
      gridApi.selection.on.rowSelectionChanged(null, function (row) {
        cc.isFailed = false;
        cc.isSuccess = false;
        cc.rowsChecked = row.isSelected;
        cc.editedRowData = row.entity;
        validateDataAndEnableUpdate();
        cc.enableUpdateBtn = !cc.rowsChecked;
      });
      gridApi.edit.on.afterCellEdit(null, function (rowEntity, colDef, newValue, oldValue) {
        cc.isFailed = false;
        cc.isSuccess = false;
        if (colDef.name === 'nsncFlag') {//pradeep
          if (newValue === 1) {
            rowEntity.sizeOptions = cc.nsSizeDropdownOptions;
          } else {
            rowEntity.sizeOptions = cc.ncSizeDropdownOptions;
          }
        }
        if (newValue != oldValue || newValue !== oldValue) {// To check old and new values same or not
          if (newValue == "") {
          } else if (+(newValue) == oldValue) {

          } else {
            cc.gridApi.selection.selectRow(rowEntity);
          }
        }
      });

    }
  };
  uiGridValidateService.setValidator('numberChecker',
    function (argument) {
      return function (oldValue, newValue, rowEntity, colDef) {
        if (newValue == '') {
          cc.isFieldValidate = true;
          cc.enableUpdateBtn = true;
          $scope.$apply(function () {
            cc.gridOptions.enableRowSelection = false;
          });
          validateDataAndEnableUpdate();
        }
        else if (!newValue) {
          return /^[0-9]{0,5}(\.[0-9]{1,2})?$/.test(newValue);
        } else {
          if (!(/^[0-9]{0,5}(\.[0-9]{1,2})?$/.test(newValue))) {
            cc.isFieldValidate = true;
            cc.enableUpdateBtn = true;
            $scope.$apply(function () {
              cc.gridOptions.enableRowSelection = false;
            });
          } else {
            cc.isFieldValidate = false;
            cc.enableUpdateBtn = false;
            cc.gridOptions.enableRowSelection = true;
            validateDataAndEnableUpdate();
          }
          return /^[0-9]{0,5}(\.[0-9]{1,2})?$/.test(newValue);
        }
      };
    },
    function (argument) {
      return 'Only numbers are allowed and max 5 digits with 2 decimal values are only accepted';
    }
  );
  function validateDataAndEnableUpdate() {
    $timeout(function () {
      var found = $('.ui-grid-cell-contents');
      if (found.hasClass('invalid')) {
        $scope.$apply(function () {
          cc.isFieldValidate = true;
          cc.enableUpdateBtn = true;
        });
      } else if (cc.gridApi.selection.getSelectedRows().length === 0) {
        $scope.$apply(function () {
          cc.enableUpdateBtn = true;
        });
      } else {
        $scope.$apply(function () {
          cc.isFieldValidate = false;
          cc.enableUpdateBtn = false;
        });
      }
    }, 100);
  }
  cc.changeValue = function (grid, row) {
    var a = row.entity.drpvalue;
  };
  cc.getConfiguratorData = function () {

    cc.enableUpdateBtn = true;
    $("#showloader").css("display", "block");
    var url = urlService.GET_NSNC_RULE.replace('dName', $scope.dcName);
    url = url.replace('uName', sessionStorage.userName);

    //$http.get(url)//pradeep 9/1/18
$http.get(url, {//pradeep 9/1/18
           headers: {'x-api-key': sessionStorage.apikey}
     })
      .success(function (data) {
       $("#showloader").css("display", "none");
        if (data.errorMessage) {
          cc.isFailed = true;
          cc.isSuccess = false;
          cc.resmessage = data.errorMessage;
}else{
        for (i = 0; i < data.length; i++) {//pradeep
          if (data[i].nsncFlag === 'Y') {
            data[i].nsncFlag = 1;
            data[i].size = Math.floor(Math.random() * (5 - 1)) + 1;
            data[i].sizeOptions = $scope.nsSizeDropdownOptions;
          } else {
            data[i].nsncFlag = 2;
            data[i].size = Math.floor(Math.random() * (10 - 5)) + 5;
            data[i].sizeOptions = $scope.ncSizeDropdownOptions;
          }
        }
        cc.gridOptions.data = data;

        _.each(data, function (value, key) {
          if (value.refDesc == 'NS') {
            cc.gridOptions.data[key].dcName = 'Non-Sortable';
          } else if (value.refDesc == 'NC') {
            cc.gridOptions.data[key].dcName = 'Non-Conveyable';
          }
        });
}
        
      }).error(function (data) {
        $("#showloader").css("display", "none");
        cc.isFailed = true;
        cc.isSuccess = false;
        resmessage = "System failed. Please try again or contact WAALOS Support";
        cc.isTable = false;
      });
  };
  cc.getConfiguratorData();


  cc.fnUpdateGrid = function () {
    cc.isFailed = false;
    cc.isSuccess = false;
    $("#showloader").css("display", "block");
    var temp = [];
    var selectedRows = cc.gridApi.selection.getSelectedRows();
    for (var i = 0; i < selectedRows.length; i++) {
      var obj = {};
      obj.dcName = $scope.dcName;
      obj.userName = sessionStorage.userName;
      obj.nsncFlag = (cc.gridApi.selection.getSelectedRows()[i].nsncFlag === 1 ? cc.gridApi.selection.getSelectedRows()[i].nsncFlag = 'Y' : cc.gridApi.selection.getSelectedRows()[i].nsncFlag = 'N');
      obj.unitLen = cc.gridApi.selection.getSelectedRows()[i].unitLen;
      obj.unitWidth = cc.gridApi.selection.getSelectedRows()[i].unitWidth;
      obj.unitHt = cc.gridApi.selection.getSelectedRows()[i].unitHt;
      obj.unitWt = cc.gridApi.selection.getSelectedRows()[i].unitWt;
      obj.unitVol = cc.gridApi.selection.getSelectedRows()[i].unitVol;
      obj.refDesc = cc.gridApi.selection.getSelectedRows()[i].refDesc;
      temp.push(obj);
    }	

$http.put(urlService.UPDATE_NSNC_RULE,temp, {
           headers: {'x-api-key': sessionStorage.apikey}
     })

      .success(function (data) {
        $("#showloader").css("display", "none");
        if (data.errorMessage) {
          cc.isFailed = true;
          cc.isSuccess = false;
          cc.resmessage = data.errorMessage;
        } else {
          cc.isSuccess = true;
          cc.isFailed = false;
          cc.resmessage = data.resMessage;
          cc.getConfiguratorData();
        }
       
      })
      .error(function (data) {
        $("#showloader").css("display", "none");
        cc.isFailed = true;
        cc.isSuccess = false;
        cc.resmessage = "System failed. Please try again or contact WAALOS Support";
      });

  };
  //user favourite code start
  cc.addToFavourate = function(isClicked){
    $("#showloader").css("display", "block");
    if(typeof isClicked !== "boolean"){
      commonService.postServiceResponse(urlService.GET_FAVOURITES,{"username": sessionStorage.userName})
        .then(function(response){
          $("#showloader").css("display", "none");
            _.each(response,function(val,key){
              if(val.funName == $scope.functionality && val.dcName == $scope.dcName){
               cc.isClicked = true;      
              }
            });
        },function(error){
          $("#showloader").css("display", "none");
          cc.isClicked = false; 
        }); 
     }else{
    if(!cc.isClicked){
    commonService.postServiceResponse(urlService.ADD_FAVOURITE,{"username": sessionStorage.userName,"dcName":$scope.dcName,"funName":$scope.functionality})
    .then(function(response){
      $("#showloader").css("display", "none");
      if(response.errorMessage){
        cc.isClicked = isClicked;
        cc.isFavouriteAdded= false; 
       $scope.$broadcast('showAlert',['']);
      }else{
        cc.isClicked = !isClicked;
        cc.isFavouriteAdded= true; 
        cc.favouriteMsg = response.resMessage;
        $scope.$broadcast('ClickedOnFavourate',[cc.dcName,$scope.functionality,cc.isClicked]);
      }
        
    },function(error){
      $("#showloader").css("display", "none");
    });
    
  }
  }
  };
  cc.addToFavourate('load');
  //user favourite code ends

}])
.filter('nsncFilter', function () {//pradeep
  var options = {
    1: 'Y',
    2: 'N'
  };

  return function (input) {
    if (!input) {
      return '';
    } else {
      return options[input];
    }
  };
});