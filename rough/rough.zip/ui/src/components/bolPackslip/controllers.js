
var app = angular.module('BOLPackslip', ['ui.grid.autoResize', 'ngAnimate', 'ui.grid','ui.grid.pagination']);

app.controller('BOLPackslipController', ['$scope', '$http', '$q', '$interval', '$window','urlService','uiGridConstants','commonService', function ($scope, $http, $q, $interval, $window,urlService,uiGridConstants,commonService) {
	$scope.pagefunctionality = $scope.functionality;
	$scope.pagedc = $scope.dcName;
	$scope.isSuccess = false;
	$scope.isFailed = false;
	$scope.isFailedload = false;
	$scope.isClicked = false;
	$scope.disable = true;

	$scope.radiobutton = function (value) {
	$scope.radiobuttonvalue = value;
	
		};
	$scope.PktNumbervalid = function () {

		if ($scope.pktNumber == '' || $scope.pktNumber == null || $scope.pktNumber == undefined || $scope.pktNumber == 32) {
		  $scope.disable = true;
		} else {
		  $scope.disable = false;
		}
	 };
	
	$scope.gridOptions = {
		paginationPageSizes: [15, 25, 50, 100],
		paginationPageSize: 15,
		enableSorting: true,
		useExternalPagination: true,
		enableColumnMenus: false
	};

	$scope.gridOptions.multiSelect = true;

	$scope.gridOptions.onRegisterApi = function (gridApi) {
		//set gridApi on scope
		$scope.gridApi = gridApi;
		$scope.gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
			$scope.pageNo =  newPage;
			$scope.pageSize = pageSize;
			$scope.getBOLPackslipData();
		 });
	};
	
	$scope.getBOLPackslipData = function () {

		$scope.resmessage = "";
		$scope.isSuccess = false;
		$scope.isFailed = false;
		$scope.isFailedload = false;

		if($scope.radiobuttonvalue  == undefined || $scope.radiobuttonvalue==""){
			//$scope.isFailed = true;
			//$scope.resmessage = "Please select any of the search options above";
			//return false;
			$scope.radiobuttonvalue ="pktCntrlNbr";
		}
		
		var str_array =  ($scope.pktNumber.trim().replace(/\n/g, ",")).replace(/,+/g, ',').replace(/(^\s*,)|( ,\s*$)/g, '');
		var lastChar = str_array[str_array.length - 1];
		if (lastChar == ",") {
				 $scope.newStr = str_array.substring(0, str_array.length - 1);
			} else {
				$scope.newStr = str_array;
		}
	
		if (($scope.newStr.match(/,/g) || []).length > 9) {
				$scope.isFailed = true;
				$scope.resmessage = "Maximum 10 Carton numbers are allowed";
				return false;
			}

		$scope.pageNo = $scope.pageNo ? $scope.pageNo : 1;
		$scope.pageSize = $scope.pageSize ? $scope.pageSize: $scope.gridOptions.paginationPageSize;
		$("#showloader").css("display", "block");
		var dataObj = {
			"dcName": $scope.pagedc,
			"userName": localStorage.userName,
			"pageNumber": $scope.pageNo,
			"pageSize": $scope.pageSize,
			"uiPktCtrlNbr": $scope.newStr,//"0089149640"
			"searchFlg":$scope.searchType
		};
	
		//var res = $http.post(urlService.GET_EMEA_PDF_ARCHIVE, dataObj);


 		var url = urlService.GET_EMEA_PDF_ARCHIVE.replace('dName',$scope.pagedc);
		url = url.replace('uName',sessionStorage.userName);
		url = url.replace('pNumber',$scope.pageNo);
		url = url.replace('pSize',$scope.pageSize);
		url = url.replace('pktCtrlNbr',$scope.newStr);
		url = url.replace('searchFlg',$scope.searchType);
		//var res = $http.get(url);

$http.get(url, {
    headers: {'x-api-key': sessionStorage.apikey}
})

		.success(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			if (data.errorMessage) {
			
				$scope.isFailedload = true;
				$scope.errorMessage = data.errorMessage;
				$scope.isTable = false;
				
			}else if(data.resMessage) {
				
				$scope.isSuccess = true;
				$scope.resmessage = data.resMessage;
				$scope.isTable = false;
			}
			else {
				$scope.isTable = true;
				$scope.gridOptions.columnDefs = [
					{ name: 'id', enableCellEdit: false, visible: false },
					{ name: 'tcOrderId', displayName: 'ORDER_ID', enableCellEdit: false,width: 300 },
					{ name: 'tcShipmentId', displayName: 'SHIPMENT_ID', enableCellEdit: false,width: 300 },
					{ name: 'createDateTime', displayName: 'CREATE_DATE_TIME', enableCellEdit: false,width: 400},
					{
						name: 'pathname', displayName: 'DOCUMENT',  enableCellEdit: false,width: 250,
	
						cellTemplate: '<div class="ui-grid-cell-contents" ng-click="grid.appScope.showMe(row.entity)" title="{{COL_FIELD}}"><a href="javascript:void(0)"><i class="fa fa-file-pdf-o" style="color:red;font-size:16px;" aria-hidden="true"></i><a></div>'
					}
				];

				$scope.gridOptions.totalItems  = data.totalNoOfRecords;  
				$scope.gridOptions.data = data.pageItems;
				$(".ui-grid-pager-control input").attr("disabled","disabled");
				if ($scope.gridOptions.data > 10) {
					$scope.gridOptions.enableVerticalScrollbar = true;
				} else {
					$scope.gridOptions.enableVerticalScrollbar = false;
					$scope.gridOptions.enableHorizontalScrollbar = 1;
				}
				
			}
			
		})
		.error(function (data, status, headers, config) {
 
			$("#showloader").css("display", "none");
			$scope.isFailedload = true;
			$scope.errorMessage = "System Failed. Please try again or contact WAALOS Support";
		});
		$scope.disableinput();	
	};
	$scope.disableinput= function(){
		setTimeout(function(){  $('.ui-grid-pager-control-input').attr( "disabled", true );  }, 2000);
	  
	  };

	$scope.showMe = function(rowData) {
$scope.isFailed = false;
	$("#showloader").css("display", "block");
	var url;
		url = urlService.GET_PDF_BOLPACKSLIP.replace('dName',$scope.pagedc);
		url = url.replace('pthname',rowData.pathname);

	$http({
			method: 'POST',
			url: url,
			headers: {				
				'Content-type': 'application/json', 
				'x-api-key': sessionStorage.apikey,
			},
			responseType: 'arraybuffer'
		})
    .success( function(data, status, headers) {

$("#showloader").css("display", "none");
		console.log(data);
		console.log(status);
		if(data.errorMessage){
			$scope.isFailed = true;
			$scope.resmessage = data.errorMessage;
			return;
		}else{
			
			var octetStreamMime = 'application/octet-stream';
			var success = false;

			// Get the headers
			headers = headers();
			var blob;
			// Get the filename from the x-filename header or default to "download.bin"
			//var filename = headers['x-filename'] || 'waalos.pdf';
			var filename = headers['x-filename'] || 'Waalos_'+rowData.pathname.substring(rowData.pathname.lastIndexOf('/')+1,rowData.pathname.lastIndexOf('.'))+'.pdf';

			// Determine the content type from the header or default to "application/octet-stream"
			var contentType = headers['content-type'] || octetStreamMime;

			try
			{
				// Try using msSaveBlob if supported
				console.log("Trying saveBlob method ...");
				 blob = new Blob([data], { type: contentType });
				if(navigator.msSaveBlob)
					navigator.msSaveBlob(blob, filename);
				else {
					// Try using other saveBlob implementations, if available
					var saveBlob = navigator.webkitSaveBlob || navigator.mozSaveBlob || navigator.saveBlob;
					if(saveBlob === undefined) throw "Not supported";
					saveBlob(blob, filename);
				}
				console.log("saveBlob succeeded");
				success = true;
			} catch(ex)
			{
				console.log("saveBlob method failed with the following exception:");
				console.log(ex);
			}

			if(!success)
			{
				// Get the blob url creator
				var urlCreator = window.URL || window.webkitURL || window.mozURL || window.msURL;
				if(urlCreator)
				{
					// Try to use a download link
					var link = document.createElement('a');
					if('download' in link)
					{
						// Try to simulate a click
						try
						{
							// Prepare a blob URL
							console.log("Trying download link method with simulated click ...");
							 blob = new Blob([data], { type: contentType });
							 url = urlCreator.createObjectURL(blob);
							link.setAttribute('href', url);

							// Set the download attribute (Supported in Chrome 14+ / Firefox 20+)
							link.setAttribute("download", filename);

							// Simulate clicking the download link
							var event = document.createEvent('MouseEvents');
							event.initMouseEvent('click', true, true, window, 1, 0, 0, 0, 0, false, false, false, false, 0, null);
							link.dispatchEvent(event);
							console.log("Download link method with simulated click succeeded");
							success = true;

						} catch(ex) {
							console.log("Download link method with simulated click failed with the following exception:");
							console.log(ex);
						}
					}

					if(!success)
					{
						// Fallback to window.location method
						try
						{
							// Prepare a blob URL
							// Use application/octet-stream when using window.location to force download
							console.log("Trying download link method with window.location ...");
							 blob = new Blob([data], { type: octetStreamMime });
							 url = urlCreator.createObjectURL(blob);
							window.location = url;
							console.log("Download link method with window.location succeeded");
							success = true;
						} catch(ex) {
							console.log("Download link method with window.location failed with the following exception:");
							console.log(ex);
						}
					}

				}
			}

			if(!success)
			{
				// Fallback to window.open method
				console.log("No methods worked for saving the arraybuffer, using last resort window.open");
				window.open(rowData.pathName, '_blank', '');
			}
		}
    })
    .error(function(data, status, config) {

        console.log("Request failed with status: " + status);
$("#showloader").css("display", "none");
        // Optionally write the error out to scope
        //$scope.errorDetails = "Request failed with status: " + status;
$scope.isFailed = true;
			$scope.resmessage = "Error in downloading BOL Packslip";

    });
};

//user favourties code starts

$scope.addToFavourate = function(isClicked){
    $("#showloader").css("display", "block");
     if(typeof isClicked !== "boolean"){
      commonService.postServiceResponse(urlService.GET_FAVOURITES,{"username": sessionStorage.userName})
        .then(function(response){
          $("#showloader").css("display", "none");
            _.each(response,function(val,key){
              if(val.funName == $scope.functionality && val.dcName == $scope.dcName){
                $scope.isClicked = true;      
              }
            });
        },function(error){
          $("#showloader").css("display", "none");
          $scope.isClicked = false; 
        });
        //$scope.isClicked = ;
     }else{
      if(!$scope.isClicked){
        commonService.postServiceResponse(urlService.ADD_FAVOURITE,{"username": sessionStorage.userName,"dcName":$scope.dcName,"funName":$scope.functionality})
        .then(function(response){
          $("#showloader").css("display", "none");
          if(response.errorMessage){
            $scope.isFavouriteAdded= false; 
            $scope.isClicked = false;      
            $scope.$broadcast('showAlert',['']);
          }else{
            $scope.isClicked = true;      
            $scope.isClicked = !isClicked;
            $scope.isFavouriteAdded= true; 
            $scope.favouriteMsg = response.resMessage;
          $scope.$broadcast('ClickedOnFavourate',[$scope.dcName,$scope.functionality,$scope.isClicked]);
          }
            
        },function(error){
          $scope.isClicked = false;
          $("#showloader").css("display", "none");
        });
        $scope.isClicked = !isClicked;
      }else{
        $("#showloader").css("display", "none");
      }
     }
    
  };
$scope.addToFavourate('load');
//user favourites code ends
}]);


