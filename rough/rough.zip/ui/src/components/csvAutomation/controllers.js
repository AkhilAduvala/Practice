var app = angular.module('CsvAutomation');


app.controller('CsvAutomationController',['$scope', '$http', '$q', '$interval', '$timeout','urlService','uiGridConstants','commonService',function ($scope, $http, $q, $interval, $timeout,urlService,uiGridConstants,commonService) {
 $scope.isSuccess = false;
 $scope.isFailed = false;
 $scope.isEmpty = false;
 $scope.dataList = [];
 $scope.disable = true;
 $scope.pagefunctionality = $scope.functionality;
 $scope.pagedc = $scope.dcName;
 $scope.response = "";
 $("#Load-Number").focus();
 $("#showloader").css("display", "none"); 


 $scope.getCSVFile =function(){
	if($scope.form.$valid){ 
	 $scope.isSuccess = false;
	$scope.isFailed = false;
	$("#showloader").css("display", "block");
	/*var loadNumber = $scope.loadNumberInput;
	var payload = {
		"loadNumber":loadNumber,
		"dcName":$scope.pagedc,
		"userName":sessionStorage.userName
	};
	console.log(payload);
	var res = $http.post(urlService.CSV_Automation,payload, {
		headers: {'x-api-key': sessionStorage.apikey} 
	}); 
	
	var res = $http.post(urlService.CSV_Automation,{
	    params: {dcName: $scope.dcName, userName: sessionStorage.userName, loadNumber: $scope.loadNumberInput},
      headers: {'x-api-key': sessionStorage.apikey}
    });
	
	
	res.success(function (data, status, headers, config) {
	  $("#showloader").css("display", "none");
      $scope.response = data || "Cannot find CSV File";
	    $scope.isSuccess = true;
	}); 
	res.error(function (data, status, headers, config) {
	  $("#showloader").css("display", "none");
		$scope.isFailed = true;
		$scope.response = "System failed. Please try again or contact WAALOS Support";
	});*/

$scope.isSuccess = false;
		$scope.isFailed = false;
		$("#showloader").css("display", "block");
		var fd = new FormData();
		fd.append('dcName', $scope.dcName);
		fd.append('userName', sessionStorage.userName);
		fd.append('loadNumber', $scope.loadNumberInput);
         console.log("upload test......"+urlService.CSV_Automation);
		$http.post(urlService.CSV_Automation, fd, {
			transformRequest: angular.identity,
			headers: { 'Content-Type': undefined,'x-api-key': sessionStorage.apikey }
		})
		.success(function (data, status, headers, config) {
			$scope.dataList = data;
			console.log('data is ' + $scope.dataList);
			
		  if (data.errorMessage) {
			$scope.isFailed = true;
			 $scope.resmessagee = data.errorMessage;
			 $("#showloader").css("display", "none");
		  } else { //$scope.isSuccess = true;
			//$scope.resmessagee = data.status;
			$("#showloader").css("display", "none");
			if($scope.dataList.length == 0){
				$scope.isFailed = true;
				if($scope.dcName == 'CDC'){
					$scope.resmessagee =" No File Found , Please raise a ticket to EMEA_DE_RIE_WMS support";
				}else{
					$scope.resmessagee =" No File Found , Please raise a ticket to EMEA_DE_SEF_WMS support";
				}
				
				$scope.loadNumberInput =null;
			}
			if($scope.dataList.length != 0){
				$scope.isSuccess = true;
				$scope.resmessagee  =null;
				$scope.resmessagee  ="File Downloaded Successfully";
				//$scope.loadNumberInput =null;
			//Download file starts
			var octetStreamMime = 'application/octet-stream';
			var success = false;
			var blob;
			var filename = $scope.loadNumberInput+'.csv';
			var contentType = headers['content-type'] || octetStreamMime;
			var success = false;
			
			try{			
				blob = new Blob(["\ufeff",data], { type: contentType });
				if(navigator.msSaveBlob)
					navigator.msSaveBlob(blob, filename);
				else {
					// Try using other saveBlob implementations, if available
					var saveBlob = navigator.webkitSaveBlob || navigator.mozSaveBlob || navigator.saveBlob;
					if(saveBlob === undefined) throw "Not supported";
					saveBlob(blob, filename);
				}	
				console.log("saveBlob succeeded");
				success = true;	
				
			}catch(ex){
			console.log("saveBlob method failed with the following exception:");
			console.log(ex);
			}
			
			if(!success){
				// Get the blob url creator
			var urlCreator = window.URL || window.webkitURL || window.mozURL || window.msURL;
			if(urlCreator){
			
				// Try to use a download link
				var link = document.createElement('a');
				if('download' in link)
				{
					// Try to simulate a click
					try
					{
						// Prepare a blob URL
						console.log("Trying download link method with simulated click ...");
						blob = new Blob(["\ufeff",data], { type: contentType });
						//blob = new Blob(["\ufeff",data], {encoding: "iso_8859-15", type: "text/csv;charset=iso_8859-15"});
						 url = urlCreator.createObjectURL(blob);
						link.setAttribute('href', url);

						// Set the download attribute (Supported in Chrome 14+ / Firefox 20+)
						link.setAttribute("download", filename);

						// Simulate clicking the download link
						var event = document.createEvent('MouseEvents');
						event.initMouseEvent('click', true, true, window, 1, 0, 0, 0, 0, false, false, false, false, 0, null);
						console.log("first........12");
						link.dispatchEvent(event);
						console.log("Download link method with simulated click succeeded");
						success = true;
						$scope.loadNumberInput =null;
					} catch(ex) {
						console.log("Download link method with simulated click failed with the following exception:");
						console.log(ex);
					}
					
				}
				
				if(!success)
				{
						
					// Fallback to window.location method
					try
					{
						// Prepare a blob URL
						// Use application/octet-stream when using window.location to force download
						console.log("Trying download link method with window.location ...");
						 blob = new Blob(["\ufeff",data], { type: octetStreamMime });
						 url = urlCreator.createObjectURL(blob);
						 console.log("for just test===== ",url);
						window.location = url;
						console.log("Download link method with window.location succeeded");
						success = true;
					} catch(ex) {
						console.log("Download link method with window.location failed with the following exception:");
						console.log(ex);
					}
					
					
				}
			
			}			
			}
			
			if(!success){
			// Fallback to window.open method
			console.log("No methods worked for saving the arraybuffer, using last resort window.open");
			window.open(rowData.pathName, '_blank', '');
			}
			}
		//Download file ends
			
			
		  }
		})
		.error(function (data, status, headers, config) {
			scope.isSuccess = true;
		  scope.resMessage = "System failed. Please try again or contact WAALOS Support";
		  $("#showloader").css("display", "none");
		});	

	
	 
	}	 
 };

 
 
 //user favourites code start
$scope.isClicked = false;

$scope.addToFavourate = function(isClicked){
    $("#showloader").css("display", "block");
     if(typeof isClicked !== "boolean"){
      commonService.postServiceResponse(urlService.GET_FAVOURITES,{"username": sessionStorage.userName})
        .then(function(response){
          $("#showloader").css("display", "none");
            _.each(response,function(val,key){
              if(val.funName == $scope.functionality && val.dcName == $scope.dcName){
                $scope.isClicked = true;      
              }
            });
        },function(error){
          $("#showloader").css("display", "none");
          $scope.isClicked = false; 
        });
        //$scope.isClicked = ;
     }else{
      if(!$scope.isClicked){
        commonService.postServiceResponse(urlService.ADD_FAVOURITE,{"username": sessionStorage.userName,"dcName":$scope.dcName,"funName":$scope.functionality})
        .then(function(response){
          $("#showloader").css("display", "none");
          if(response.errorMessage){
            $scope.isFavouriteAdded= false; 
            $scope.isClicked = false;      
            $scope.$broadcast('showAlert',['']);
          }else{
            $scope.isClicked = true;      
            $scope.isClicked = !isClicked;
            $scope.isFavouriteAdded= true; 
            $scope.favouriteMsg = response.resMessage;
          $scope.$broadcast('ClickedOnFavourate',[$scope.dcName,$scope.functionality,$scope.isClicked]);
          }
            
        },function(error){
          $scope.isClicked = false;
          $("#showloader").css("display", "none");
        });
        $scope.isClicked = !isClicked;
      }else{
        $("#showloader").css("display", "none");
      }
     }
    
  };
  $scope.addToFavourate('load');
  //user favourites code ends


}]);