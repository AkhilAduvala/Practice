var app = angular.module('FootLockerLabelReprint');

app.controller('FootLockerController', ['$scope', '$http', '$q', '$interval', '$timeout','urlService','uiGridConstants','commonService', function ($scope, $http, $q, $interval, $timeout,urlService,uiGridConstants,commonService) {
  $scope.isSuccess = false;
  $scope.isFailed = false;
  $scope.showSku = false;
  $scope.disable = true;
  $scope.singleSku = true;
  $scope.pagefunctionality = $scope.functionality;
  $scope.pagedc = $scope.dcName;
  $scope.masterPolybags = true;
  $("#showloader").css("display", "none");
 

 $scope.getdefaultPrinter = function(){
		var url = urlService.DEFAULT_PRINTERS.replace("dName",$scope.pagedc);
		url = url.replace('uName',sessionStorage.userName);
		var res = $http.get(url, {
		  //headers: {'x-api-key': sessionStorage.apikey} 
		});

		res.success(function (data, status, headers, config) {
		  if (data.errorMessage) {
			//$scope.isFailed = true;
			//$scope.resmessage = data.errorMessage;
			$scope.getPrinterList();
			}else if(data.resMessage){
			 // $scope.isSuccess = true;
			//  $scope.resmessage = data.resMessage;
			  $scope.getPrinterList();
			}else{
				$scope.defaultprinter = data;
				$scope.printerip = data[0].printerIp;
				$scope.getPrinterList();
			}
		});
		res.error(function (data, status, headers, config) {
		//  $scope.isFailed = true;
		//  $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
		  $scope.getPrinterList();
		});  
  };
  $scope.getdefaultPrinter();

  $scope.getPrinterList = function(){
    var url = urlService.PRINTER_LIST.replace("dName",$scope.pagedc);
    url = url.replace('uName',sessionStorage.userName);
    var res = $http.get(url, {
      //headers: {'x-api-key': sessionStorage.apikey} 
    });

    res.success(function (data, status, headers, config) {
      if (data.errorMessage) {
        $scope.isFailed = true;
        $scope.resmessage = data.errorMessage;
        }else if(data.resMessage){
          $scope.isSuccess = true;
          $scope.resmessage = data.resMessage;
        }else{
          $scope.printerslist = data;
          
          for (var i = 0; i < $scope.printerslist.length; i++) {
            if($scope.printerip){
              if ($scope.printerslist[i].printerIp == $scope.printerip) {
                $scope.printer = $scope.printerslist[i];
                break;
              }
            }else{
              $scope.printer = $scope.printerslist[0];
            }
          }
        }
    });
    res.error(function (responce, status, headers, config) {
      $scope.isFailed = true;
      $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
    });  
  };

/**
	This function is used to clear the success/ failure msssages (based on flag value) and make the button disable
**/
  $scope.checkCaseNumber = function(){
	 /*$scope.isSuccess = false;
	 $scope.isFailed = false;
	  if($scope.caseNumber){
		  $scope.disable = false;
	  }else{
		  $scope.disable = true;
	  }*/
	  $scope.isSuccess = false;
	 $scope.isFailed = false;
	 $scope.disable = true;
  };


/**
	This function is used to call, when user press Enter button from the keyboard
**/
  $('#caseNumber').keyup(function (e){
    if($scope.caseNumber && e.keyCode == 13){
        $scope.getSKU();
    }
  });
  
  /***This function is used to get the sku's associated with the case number*/
   $scope.getSKU = function(){
	   $scope.isSuccess = false;
	   $scope.isFailed = false;
	   $scope.showSku = false;
	   $scope.disable = true;
	   $scope.singleSku = true;
	   $scope.skus = [];
	   $("#showloader").css("display", "block");
	   var url = urlService.FOOTLOCKER_GET_SKU.replace('dName', $scope.dcName);
		url = url.replace('uName', sessionStorage.userName);
		url = url.replace('cNbr',$scope.caseNumber);
		var res = $http.get(url, {
			headers: {'x-api-key': sessionStorage.apikey} 
		});
		res.success(function (data, status, headers, config) {
		  $("#showloader").css("display", "none");
		  if (data.errorMessage) {
			$scope.isFailed = true;
			$scope.resmessage = data.errorMessage;
		  } else if(data.length > 0){
				$scope.showSku = true;
				$scope.disable = false;
				$scope.skus = data[0];
				
				$scope.skus.actlQtyA = data[0] ? data[0].actlQty : "";
				$scope.skus.actlQtyB = data[1] ? data[1].actlQty : "";
				$scope.skus.actlQtyC = data[2] ? data[2].actlQty : "";
				$scope.skus.actlQtyD = data[3] ? data[3].actlQty : "";
				$scope.skus.actlQtyE = data[4] ? data[4].actlQty : "";
				$scope.skus.actlQtyF = data[5] ? data[5].actlQty : "";
				$scope.skus.actlQtyG = data[6] ? data[6].actlQty : "";
				$scope.skus.actlQtyH = data[7] ? data[7].actlQty : "";
				$scope.skus.actlQtyI = data[8] ? data[8].actlQty : "";
				$scope.skus.actlQtyJ = data[9] ? data[9].actlQty : "";
				$scope.skus.actlQtyK = data[10] ? data[10].actlQty : "";
				$scope.skus.actlQtyL = data[11] ? data[11].actlQty : "";
				
				$scope.skus.sizeA = "";
				$scope.skus.sizeB = "";
				$scope.skus.sizeC = "";
				$scope.skus.sizeD = "";
				$scope.skus.sizeE = "";
				$scope.skus.sizeF = "";
				$scope.skus.sizeG = "";
				$scope.skus.sizeH = "";
				$scope.skus.sizeI = "";
				$scope.skus.sizeJ = "";
				$scope.skus.sizeK = "";
				$scope.skus.sizeL = "";
				
				$scope.allSkus = data;
				$scope.masterPolybags = true;
				if(data.length == 1){
					$scope.singleSku = true;
					$scope.allowAlphaNum();
					//$scope.allowAlphaNumHiphen();
				}else{					
					$scope.singleSku = false;
					$scope.allowAlphaNum();
					//$scope.allowAlphaNumHiphen();
				}
		  }else{
			$scope.isSuccess = true;
			$scope.resmessage = data.resMessage;
		}
		});
		res.error(function (data, status, headers, config) {
		  $("#showloader").css("display", "none");
			$scope.isFailed = true;
			$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
		});
   };
  
  /**
	This function is used to Print(sent required data to backend)
**/
 $scope.printFootLocker = function(){
    $scope.isSuccess = false;
	  $scope.isFailed = false;
	  $scope.skus.po ? $scope.skus.po : ($scope.skus.po = "");
	  $scope.skus.skuNo ? $scope.skus.skuNo : ($scope.skus.skuNo = "");
	  $scope.skus.caselot ? $scope.skus.caselot : ($scope.skus.caselot = "");
	  $scope.skus.cartonNo ? $scope.skus.cartonNo : ($scope.skus.cartonNo = "");
	  $scope.skus.noOfPolyBags ? $scope.skus.noOfPolyBags : ($scope.skus.noOfPolyBags = "");
	  $scope.skus.orderNo ? $scope.skus.orderNo :($scope.skus.orderNo = "");
	  $scope.skus.printerIp = $scope.printer.printerIp;
	  $scope.skus.printerPort = $scope.printer.printerPort;
	  $scope.skus.dcName = $scope.dcName;
	  $scope.skus.userName = sessionStorage.userName;

	  if(!$scope.singleSku){
		 $scope.masterPolybags ? $scope.skus.multiPolyBags = "MM" : $scope.skus.multiPolyBags = "MNM"; 
	  }else{
		 $scope.masterPolybags ? $scope.skus.multiPolyBags = "SM" : $scope.skus.multiPolyBags = "SNM";  
	  }
	   if(!$scope.masterPolybags){
		delete $scope.skus.noOfPolyBags;
	  }
	 
	  $("#showloader").css("display", "block");
	  var url = urlService.FOOTLOCKER_PRINT;
		var res = $http.post(url,$scope.skus, {
			headers: {'x-api-key': sessionStorage.apikey} 
		});
		res.success(function (data, status, headers, config) {
		  $("#showloader").css("display", "none");
		  if (data.errorMessage) {
			$scope.isFailed = true;
			$scope.resmessage = data.errorMessage;
		  } else{
			 $scope.resmessage = data.resMessage;
			$scope.isSuccess = true;			 
		  }
		});
		res.error(function (data, status, headers, config) {
		  $("#showloader").css("display", "none");
			$scope.isFailed = true;
			$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
		});
	  
  };  

  $scope.allowNumbers = function(event,flag){
		$(event.target).val($(event.target).val().replace(/[^\d].+/, ""));
		if(event.which != 13){
			if ((event.which < 48 || event.which > 57)) {
				event.preventDefault();
			}
			
		}
  };
  $scope.allowAlphaNum = function(){
	 $('#ftl-order-no,#ftl-sku-no,#style-no,#caselot,#carton-no,#po').keypress( function(evt) { 
	   if (/^[a-z0-9]+$/i.test(String.fromCharCode(evt.charCode)) == false)  {
		  evt.returnValue = false; 
		  return false;
	   } 
	   });
  };
 $scope.allowAlphaNum();

 $scope.allowAlphaNumHiphen = function(evt){
   if (/^[a-z0-9]+$/i.test(String.fromCharCode(evt.charCode)) == false)  {
	  evt.preventDefault();
	  evt.returnValue = false; 
	  return false;
   } 
  };
  
  $scope.allowSpace = function(evt){
	  
	  if (/^[a-z\d\s]+$/i.test(String.fromCharCode(evt.charCode)) == false)  {
	  evt.returnValue = false; 
	  return false;
   } 
  };
//$scope.allowAlphaNumHiphen();   

//user favourites code start
$scope.isClicked = false;

$scope.addToFavourate = function(isClicked){
    $("#showloader").css("display", "block");
     if(typeof isClicked !== "boolean"){
      commonService.postServiceResponse(urlService.GET_FAVOURITES,{"username": sessionStorage.userName})
        .then(function(response){
          $("#showloader").css("display", "none");
            _.each(response,function(val,key){
              if(val.funName == $scope.functionality && val.dcName == $scope.dcName){
                $scope.isClicked = true;      
              }
            });
        },function(error){
          $("#showloader").css("display", "none");
          $scope.isClicked = false; 
        });
        //$scope.isClicked = ;
     }else{
      if(!$scope.isClicked){
        commonService.postServiceResponse(urlService.ADD_FAVOURITE,{"username": sessionStorage.userName,"dcName":$scope.dcName,"funName":$scope.functionality})
        .then(function(response){
          $("#showloader").css("display", "none");
          if(response.errorMessage){
            $scope.isFavouriteAdded= false; 
            $scope.isClicked = false;      
            $scope.$broadcast('showAlert',['']);
          }else{
            $scope.isClicked = true;      
            $scope.isClicked = !isClicked;
            $scope.isFavouriteAdded= true; 
            $scope.favouriteMsg = response.resMessage;
          $scope.$broadcast('ClickedOnFavourate',[$scope.dcName,$scope.functionality,$scope.isClicked]);
          }
            
        },function(error){
          $scope.isClicked = false;
          $("#showloader").css("display", "none");
        });
        $scope.isClicked = !isClicked;
      }else{
        $("#showloader").css("display", "none");
      }
     }
    
  };
  $scope.addToFavourate('load');
  //user favourites code ends

}]);

