var app = angular.module('RoutingBuddy');

app.controller('RoutingBuddyController', ['$scope', '$http', '$q', '$interval', '$timeout', 'urlService', 'uiGridConstants', 'commonService', function($scope, $http, $q, $interval, $timeout, urlService, uiGridConstants, commonService) {
    $scope.showDNNumbers = true;
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $scope.disable = true;
    $scope.disable1 = true;
    $scope.disable2 = true;
    $scope.pagefunctionality = $scope.functionality;
    $scope.pagedc = $scope.dcName;
    $scope.decant = true;
    $scope.noTarget = false;
	$scope.disableShipNbr=true;
	$scope.counter = 0;
	$scope.inputtype = 'PO';
	$scope.disableRemoveRule = true;
	$scope.disableViewResults =true;
	$scope.formData = {};
	$scope.showRules = false;
	$scope.updateScreen = true;	

	 $scope.init = function () {
        // check if there is query in url
        // and fire search in case its value is not empty
		if ($scope.dcName != "OneWMS-TDC"){
			$("#removeVasDiv").hide(); 
		 }
        if ($scope.dcName != "US2" && $scope.dcName != "OneWMS-US1" && $scope.dcName != "OneWMS-BDC" && $scope.dcName != "DTC" /*&& $scope.dcName != "OneWMS-US2"*/) {
            $scope.hideus = true;
            $scope.hideAll = false;
            $scope.dtcField = false;
            $scope.onewmsbdcField = true;
        }else if ($scope.dcName === "DTC"){ 
            $scope.onewmsbdcField = true;
            $scope.dtcField = true;
            $scope.hideus = false;
            $scope.hideAll = true;
        }else if ($scope.dcName === "OneWMS-BDC"){ 
            $scope.onewmsbdcField = false;
            $scope.hideus = true;
            $scope.hideAll = false;
            $scope.dtcField =false;
        }
        else {
            $scope.onewmsbdcField = true;
            $scope.hideus = false;
            $scope.hideAll = true;
            $scope.dtcField =false;
        }
    };  
	$scope.getStyle = function() {
		var style1 = "padding-left:55px";
		if ($scope.dcName === "DTC"){ 
            return style1;
        }
	}
	  $scope.gridOptionsOne = {
    paginationPageSizes: [15, 25, 50, 100],
    paginationPageSize: 15,
    useExternalPagination: true,
		enableColumnMenus: false,
		enableSorting: true,
		enableCellEdit: false, 
    enableCellEditOnFocus: true,
  };

    $scope.gridOptionsOne.onRegisterApi = function (gridApi) {
    
        //set gridApi on scope
	
        $scope.gridApi = gridApi;
    
        $scope.gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
          $scope.pageNo =  newPage;
          $scope.pageSize = pageSize;
          //$scope.shipedUnits();
		  $scope.submitPickRule();
       });
		
      };  
	
	$scope.dateOptions = {
    formatYear: 'yy',
    /* maxDate : new Date(new Date().getTime()-(6*24*60*60*1000)),//new Date(), */
    startingDay: 1
  };
  
  $scope.formats = ['dd-MMMM-yyyy', 'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate','yyyy-MM-dd HH:mm'];
  $scope.format = $scope.formats[4];
  $scope.altInputFormats = ['M!/d!/yyyy'];
  
  $scope.popup1 = {
    opened: false
  };
  
/*    
	/*
	$scope.scrolldown = function () {
		
		$scope.updateScreen = false;
		document.body.scrollTop = 600;
		document.documentElement.scrollTop = 600;
		$scope.showRules = true;
         $scope.secondRow = false;
        $scope.firstRow = false;
        $scope.thirdRow = false; */	
		/* $scope.inputs = [];		 */

	/* }; */
/*
	$scope.scrollup = function () {
		$scope.showRules = false;
		$scope.updateScreen = true;		
		document.body.scrollTop = 0;
		document.documentElement.scrollTop = 0;
	};		 */
    $scope.popup3 = {
        opened: true
      };
      $scope.open3 = function () {
        $scope.popup3.opened = true;
      };
    $scope.open1 = function () {
        $scope.popup1.opened = true;
      };
      
      
      $scope.popup2 = {
        opened: false
      };
  
  $scope.open2 = function () {
    $scope.popup2.opened = true;
		document.body.scrollTop = 0;
		document.documentElement.scrollTop = 0;	
  };    
 $scope.dt ="";
 $scope.dt2 = "";
  $scope.changedate = function(){

    $scope.isSuccess = false;
    $scope.isFailed = false;

    if( $scope.dt != "" && $scope.dt != undefined){
      $scope.disable = false;
    }else{
      $scope.disable = true;
      $scope.isFailed = true; 
      $scope.resmessage = "Please enter current or past date only, in format [DD-Month-YYYY]";
    }
if($scope.dt){
/* var date = new Date(new Date().getTime()-(6*24*60*60*1000)); */
var currentdate = date.getFullYear() + '-' + ('0' + (date.getMonth() + 1)).slice(-2) + '-' + ('0' + date.getDate()).slice(-2);
var actual = $scope.dt.getFullYear() + '-' + ('0' + ($scope.dt.getMonth() + 1)).slice(-2) + '-' + ('0' + $scope.dt.getDate()).slice(-2);
if(actual > currentdate){ $scope.disable = true; $scope.isFailed = true; 
          $scope.resmessage = "Please enter current or past date only, in format [DD-Month-YYYY HH:mm]"; } 
}
  };
  
    $scope.changedate2 = function(){

    $scope.isSuccess = false;
    $scope.isFailed = false;

    if( $scope.dt2 != "" && $scope.dt2 != undefined){
      $scope.disable = false;
    }else{
      $scope.disable = true;
      $scope.isFailed = true; 
	      $scope.resmessage = "Please enter current or past date only, in format [DD-Month-YYYY HH:mm]";
    }
if($scope.dt2){
/* var date = new Date(new Date().getTime()-(6*24*60*60*1000)); */
var currentdate = date.getFullYear() + '-' + ('0' + (date.getMonth() + 1)).slice(-2) + '-' + ('0' + date.getDate()).slice(-2);
var actual = $scope.dt2.getFullYear() + '-' + ('0' + ($scope.dt2.getMonth() + 1)).slice(-2) + '-' + ('0' + $scope.dt2.getDate()).slice(-2);
if(actual > currentdate){ $scope.disable = true; $scope.isFailed = true; 
        $scope.resmessage = "Please enter current or past date only, in format [DD-Month-YYYY HH:mm]"; } 
}
  }; 
  
  $scope.changedate3 = function(){

    $scope.isSuccess = false;
    $scope.isFailed = false;

    if( $scope.dtmst != "" && $scope.dtmst != undefined){
      $scope.disable = false;
    }else{
      $scope.disable = true;
      $scope.isFailed = true; 
      $scope.resmessage = "Please enter current or past date only, in format [DD-Month-YYYY HH:mm]";
    }
if($scope.dtmst){
//  var date = new Date(new Date().getTime()-(6*24*60*60*1000)); 
var currentdate = date.getFullYear() + '-' + ('0' + (date.getMonth() + 1)).slice(-2) + '-' + ('0' + date.getDate()).slice(-2);
var actual = $scope.dtmst.getFullYear() + '-' + ('0' + ($scope.dtmst.getMonth() + 1)).slice(-2) + '-' + ('0' + $scope.dtmst.getDate()).slice(-2);
if(actual > currentdate){ $scope.disable = true; $scope.isFailed = true; 
        $scope.resmessage = "Please enter current or past date only, in format [DD-Month-YYYY HH:mm]"; } 
}
  };  
  

  
	/**This function is used to validate order text area
  **/
    $scope.validateOrder = function() {
			$scope.isSuccess = false;
			$scope.isFailed = false;
            if ($scope.maxNbr == "" || $scope.maxNbr == undefined ) {
				$scope.isSuccess = false;
				$scope.isFailed = false;
				$scope.shipmentNbrCheck = false;
				$scope.shipmentNbr='';
				$scope.consNbrCheck = false;
				$scope.consNbrList='';
				$scope.freightTermCheck = false;
				$scope.freightTermList='';
				$scope.billAccountCheck = false;
				$scope.billAccountNo='';
				$scope.loadCodeCheck = false;
				$scope.loadCodeList='';
				$scope.loadComments = '';
				$scope.filterFieldCheck = false;
				$scope.filterFieldText='';
				$scope.shipViaCheck = false;
				$scope.shipViaList='';		
				$scope.exclCheck = false;
				$scope.removeVasCheck= false;
            }
           };
		   
	$scope.validateCheckBoxes= function(){
		if(!$scope.shipmentNbrCheck){
			$scope.shipmentNbr='';
		}
		if(!$scope.loadCodeCheck){
			$scope.loadCodeList='';
			$scope.loadComments='';
		}
		if(!$scope.pickupDateCheck){
			$scope.dt='';
		}
		if(!$scope.filterFieldCheck){
			$scope.filterFieldText='';
		}
		if(!$scope.freightTermCheck){
			$scope.freightTermList='';
		}
		if(!$scope.consNbrCheck){
			$scope.consNbrList='';
		}
		if(!$scope.billAccountCheck){
			$scope.billAccountNo='';
		}
		if(!$scope.shipViaCheck){
			$scope.shipViaList='';
		}	
		if(!$scope.deliveryDateCheck){
			$scope.dt2='';
		}	
        if(!$scope.mustReleaseDateCheck){
			$scope.dtmst='';
		}	
	}
    /** This function is used to get drop down details for Consolidator Numbers**/
    $scope.getDropDownDetails = function(taskval) {
        if($scope.dcName != "DTC"){
	$scope.taskval = taskval;
	$scope.inputs = [];	
     var url = urlService.GET_DROP_DOWN_LIST.replace('dName', $scope.pagedc);
     url = url.replace('flag', $scope.taskval );
	 var res = $http.get(url, { headers: { 'x-api-key': sessionStorage.apikey } });
	 res.success(function (data, status, headers, config) {
				$("#showloader").css("display", "none");
				if (data.errorMessage) {
					$scope.isFailed = true;
					$scope.resmessage = data.errorMessage;
					$scope.getFTDetails();
				} else if (data.resMessage) {
					$scope.isSuccess = true;
					$scope.resmessage = data.resMessage;
					$scope.getFTDetails();
				} else {
					$scope.dropDownList = data;
					$scope.getFTDetails();
					$("#showloader").css("display", "none");
				}
				if($scope.hideAll == false){
					$scope.getSearchRuleDetails();
				}
				$('.ui-grid-pager-control input').prop("disabled", true);
			});
			res.error(function (data, status, headers, config) {
				$("#showloader").css("display", "none");
				$scope.isFailed = true;
				$scope.getFTDetails();
			});
        }else{
            $scope.getFTDetails();
        }
    }

	 /** This function is used to get drop down details for Freight Term  **/
	$scope.getFTDetails = function() {
	var url = urlService.GET_DROP_DOWN_LIST.replace('dName', $scope.pagedc);
     url = url.replace('flag', 'FT' );
	 var res = $http.get(url, { headers: { 'x-api-key': sessionStorage.apikey } });
	 res.success(function (data, status, headers, config) {
				$("#showloader").css("display", "none");
				if (data.errorMessage) {
					$scope.isFailed = true;
					$scope.resmessage = data.errorMessage;
					$scope.getLCDetails(); 
				} else if (data.resMessage) {
					$scope.isSuccess = true;
					$scope.resmessage = data.resMessage;
					$scope.getLCDetails(); 
				} else {
					$scope.ftdropDownList = data;
					$scope.getLCDetails(); 
					$("#showloader").css("display", "none");
				}
				$('.ui-grid-pager-control input').prop("disabled", true);
			});
			res.error(function (data, status, headers, config) {
				$("#showloader").css("display", "none");
				$scope.isFailed = true;
				$scope.getLCDetails(); 
			});
	}
	
	
	 /** This function is used to get drop down details for Load Code  **/
	$scope.getLCDetails = function() {
	var url = urlService.GET_DROP_DOWN_LIST.replace('dName', $scope.pagedc);
     url = url.replace('flag', 'LC' );
	 var res = $http.get(url, { headers: { 'x-api-key': sessionStorage.apikey } });
	 res.success(function (data, status, headers, config) {
				$("#showloader").css("display", "none");
				if (data.errorMessage) {
					$scope.isFailed = true;
					$scope.resmessage = data.errorMessage;
					/* $scope.getSVDetails();  */
				} else if (data.resMessage) {
					$scope.isSuccess = true;
					$scope.resmessage = data.resMessage;
					/* $scope.getSVDetails();  */
				} else {
					$scope.LCdropDownList = data;
					$("#showloader").css("display", "none");
					/* $scope.getSVDetails();  */
				}
				if($scope.hideAll == false){
				$scope.getSVDetails();
				}
				$('.ui-grid-pager-control input').prop("disabled", true);
			});
			res.error(function (data, status, headers, config) {
				$("#showloader").css("display", "none");
				$scope.isFailed = true;
				$scope.getSVDetails(); 
			});
	}
	
	 /** This function is used to get drop down details for Load Code  **/
	$scope.getSVDetails = function() {
	var url = urlService.GET_DROP_DOWN_LIST.replace('dName', $scope.pagedc);
     url = url.replace('flag', 'SV' );
	 var res = $http.get(url, { headers: { 'x-api-key': sessionStorage.apikey } });
	 res.success(function (data, status, headers, config) {
				$("#showloader").css("display", "none");
				if (data.errorMessage) {
					$scope.isFailed = true;
					$scope.resmessage = data.errorMessage;
				} else if (data.resMessage) {
					$scope.isSuccess = true;
					$scope.resmessage = data.resMessage;
				} else {
					$scope.SVdropDownList = data;
					$("#showloader").css("display", "none");
				}
				$('.ui-grid-pager-control input').prop("disabled", true);
			});
			res.error(function (data, status, headers, config) {
				$("#showloader").css("display", "none");
				$scope.isFailed = true; 
			});
	}

	 /** This function is used to get drop down details for Search  **/
	$scope.getSearchRuleDetails = function() {
        var url = urlService.HOT_PICK_BATCH_GET_RULES.replace('dName', $scope.pagedc);
        url = url.replace('uName', sessionStorage.userName);
	 var res = $http.get(url, { headers: { 'x-api-key': sessionStorage.apikey } });
        res.success(function (data, status, headers, config) {
           // $("#showloader").css("display", "none");
            if (data.errorMessage) {
                $scope.isFailed = true;
                $scope.resmessage = data.errorMessage;
            } else if (data.resMessage) {
                $scope.isSuccess = true;
                $scope.resmessage = data.resMessage;
            } else {

                $scope.hotPickBatchId = data.hotPickBatchId;
                $scope.hotPickBatchDescription = data.hotPickBatchDescription;
                $scope.firstOperator = data.ruleOperOne;
                $scope.firstcolumn = data.ruleColOne;
                $scope.firstlogicalOperator = data.ruleLogicalOperOne;

                $scope.secondOperator = data.ruleOperTwo;
                $scope.secondcolumn = data.ruleColTwo;
                $scope.secondlogicalOperator = data.ruleLogicalOperTwo;

                $scope.thirdOperator = data.ruleOperThree;
                $scope.thirdcolumn = data.ruleColThree;
                $scope.thirdBrandName = data.ruleBrandName;


                $("#showloader").css("display", "none");
            }
            $('.ui-grid-pager-control input').prop("disabled", true);
        });
			res.error(function (data, status, headers, config) {
				$("#showloader").css("display", "none");
				$scope.isFailed = true;
				$scope.getLCDetails(); 
			});
	}

    //searching thorugh selection and input text

    $scope.addfield = function () {
        console.log($scope.inputs.length);
        //$scope.getHotPickBatchRules();
        if ($scope.inputs.length < 3) {
            $scope.showBrand = false;
            $scope.showOpertor = true;
            $scope.inputs.push({});
            if ($scope.inputs.length > 0) {
                $scope.disableRemoveRule = false;
            }
        }
        if ($scope.inputs.length > 2) {
            $scope.disableAddRule = true;
        }
        if ($scope.inputs.length == 3) {
            $scope.showBrand = true;
            $scope.showOpertor = false;
        }
        $scope.counter++;
        if ($scope.counter == 1) {
            $scope.firstRow = true;
			$scope.disableViewResults = true; 
        }
        if ($scope.counter == 2) {
            $scope.secondRow = true;
			$scope.disableViewResults = true; 
        }
        if ($scope.counter == 3) {
            $scope.thirdRow = true;
			$scope.disableViewResults = true; 
        }
        if ($scope.counter > 0) {
            $scope.disableRemoveRule = false;
        }

    };
	
    $scope.removefield = function () {
		$scope.isTableDtls = false;
        $scope.inputs.pop({});
        if ($scope.inputs.length < 1) {
            $scope.disableRemoveRule = true;
			
        }
        if ($scope.inputs.length < 3) {
            $scope.showBrand = false;
            $scope.disableAddRule = false;
            $scope.showOpertor = true;
        }

        if ($scope.inputs.length == 3) {
            $scope.showOpertor = false;
            $scope.showBrand = true;
            $scope.showComparison = true;
        }

        if ($scope.counter == 1) {
            $scope.firstRow = false;
            $scope.formData.firstcolvalue = "";
            $scope.formData.firstOpervalue = "";
            $scope.formData.firstCompValue = "";
			$scope.disableViewResults = true;
        }
        if ($scope.counter == 2) {

            $scope.secondRow = false;
            $scope.formData.secondcolvalue = "";
            $scope.formData.secondOpervalue = "";
            $scope.formData.secondCompValue = "";
            $scope.formData.firstlogvalue = "";
        }
        if ($scope.counter == 3) {

            $scope.thirdRow = false;
            $scope.formData.thirdcolvalue = "";
            $scope.formData.thirdOpervalue = "";
            $scope.formData.thirdCompValue = "";
            $scope.formData.secondlogValue = "";
            $scope.formData.thirdBrandvalue = "";
        }
		$scope.enableViewResults();
        $scope.counter--;

    };

		$scope.enableViewResults=function(){
		$scope.disableViewResults = true; 
		if($scope.firstRow == true && ($scope.secondRow ==false | $scope.secondRow ==undefined) && ($scope.thirdRow ==false | $scope.thirdRow ==undefined)){
			$scope.testVal = $scope.formData.firstcolvalue;
			if($scope.formData.firstcolvalue != null && $scope.formData.firstOpervalue !=null && $scope.formData.firstCompValue !=null){
				$scope.disableViewResults = false; 
				}
			}
		if($scope.firstRow == true && $scope.secondRow ==true && ($scope.thirdRow ==false | $scope.thirdRow ==undefined)){
			if($scope.formData.firstcolvalue !=null && $scope.formData.firstOpervalue !=null && $scope.formData.firstCompValue !=null && $scope.formData.secondcolvalue !=null && $scope.formData.secondOpervalue !=null && $scope.formData.secondCompValue !=null && $scope.formData.firstlogvalue !=null){
				$scope.disableViewResults = false; 
				}
			}
		if($scope.firstRow == true && $scope.secondRow ==true && $scope.thirdRow ==true){
			if($scope.formData.firstcolvalue !=null && $scope.formData.firstOpervalue !=null && $scope.formData.firstCompValue !=null && $scope.formData.secondcolvalue !=null && $scope.formData.secondOpervalue !=null && $scope.formData.secondCompValue !=null && $scope.formData.thirdcolvalue !=null && $scope.formData.thirdOpervalue !=null &&$scope.formData.thirdCompValue !=null && $scope.formData.thirdBrandvalue !=null && $scope.formData.secondlogValue !=null){
				$scope.disableViewResults = false; 
				}
			}			

		};
		
    $scope.firstOperChange = function (operatorName) {
        console.log(operatorName);
		$scope.enableViewResults();
        if (operatorName === 'firstOperator') {
            if ($scope.formData.firstOpervalue.indexOf('null') >= 0) {
                $scope.firstCompHide = true;
            }
            else {
                $scope.firstCompHide = false;
            }
        }
        else if (operatorName === 'secondOperator') {
            if ($scope.formData.secondOpervalue.indexOf('null') >= 0) {
                $scope.secondCompHide = true;
            }
            else {
                $scope.secondCompHide = false;
            }
        }
        else if (operatorName === 'thirdOperator') {
            if ($scope.formData.thirdOpervalue.indexOf('null') >= 0) {
                $scope.thirdCompHide = true;
            }
            else {
                $scope.thirdCompHide = false;
            }
        }
    };

$scope.submitPickRule = function(){
        $scope.isSuccess = false;
        $scope.isFailed = false;
        $scope.isEdit = true;
        $scope.isDelete = true;
        $scope.isMianpage = true;
        $scope.isEditdataSources = false;
        $scope.isEditSlotGroup = false;
        var firstval = $scope.formData.firstcolvalue;
        $scope.firstColumnValue = "";
        $scope.secondColumnValue = "";
        $scope.thirdColumnValue = "";
        $scope.firstColumnOrigValue = "";
        $scope.secondColumnOrigValue = "";
        $scope.thirdColumnOrigValue = "";
        $scope.disableTab = false;

  $("#showloader").css("display", "block");
  $scope.pageNo = $scope.pageNo ? $scope.pageNo : 1;
  $scope.pageSize = $scope.pageSize ? $scope.pageSize: $scope.gridOptionsOne.paginationPageSize;
  
          if ($scope.formData.firstcolvalue === "" || $scope.formData.firstcolvalue === undefined || $scope.formData.firstcolvalue === null) {
            console.log('The form data is empty');
        } else {
            $scope.firstColumnOrigValue = $scope.formData.firstcolvalue;
            $scope.formData.firstcolvalue = $scope.formData.firstcolvalue.split('(');
            $scope.firstColumnValue = $scope.formData.firstcolvalue[0];
        }
        if ($scope.formData.secondcolvalue === "" || $scope.formData.secondcolvalue === undefined || $scope.formData.secondcolvalue === null) {
            console.log('The form data is empty');
        } else {
            $scope.secondColumnOrigValue = $scope.formData.secondcolvalue;
            $scope.formData.secondcolvalue = $scope.formData.secondcolvalue.split('(');
            $scope.secondColumnValue = $scope.formData.secondcolvalue[0];
        }
        if ($scope.formData.thirdcolvalue === "" || $scope.formData.thirdcolvalue === undefined || $scope.formData.thirdcolvalue === null) {
            console.log('The form data is empty');
        } else {
            $scope.thirdColumnOrigValue = $scope.formData.thirdcolvalue
            $scope.formData.thirdcolvalue = $scope.formData.thirdcolvalue.split('(');
            $scope.thirdColumnValue = $scope.formData.thirdcolvalue[0];
        }
		
        var payload = {
            "dcName": $scope.pagedc,
            "userName": "Test",
            "insertFlag": "true",
            "hotPickBatchId": $scope.hotPickBatchId,
            "hotPickBatchDescription": $scope.formData.hotPickBatchDescription,
            "ruleColOne": $scope.firstColumnValue,
            "ruleOperOne": $scope.formData.firstOpervalue,
            "ruleCompValueOne": $scope.formData.firstCompValue,
            "ruleLogicalOperOne": $scope.formData.firstlogvalue,
            "ruleColTwo": $scope.secondColumnValue,
            "ruleOperTwo": $scope.formData.secondOpervalue,
            "ruleCompValueTwo": $scope.formData.secondCompValue,
            "ruleLogicalOperTwo": $scope.formData.secondlogValue,
            "ruleColThree": $scope.thirdColumnValue,
            "ruleOperThree": $scope.formData.thirdOpervalue,
            "ruleCompValueThree": $scope.formData.thirdCompValue,
            "ruleBrandName": $scope.formData.thirdBrandvalue,
            "pageNumber": $scope.pageNo,
            "pageSize": $scope.pageSize
        }		
  
  
        var res = $http.post(urlService.HOT_PICK_BATCH_GET_PICKTICKETS, payload, {
            headers: { 'x-api-key': sessionStorage.apikey }
        });
  
  res.success(function (data, status, headers, config) {
    $("#showloader").css("display", "none");
    if (data.errorMessage) {
      $scope.isFailed = true;
      $scope.resmessage = data.errorMessage;
    } else if (data.resMessage) {
      $scope.isSuccess = true;
      $scope.resmessage = data.resMessage;
    } else {
  
    $scope.gridOptionsOne.columnDefs = [
        { name: "tcOrderId", displayName: "Tc Order Id", enableCellEdit: false },
		{ name: "doStatus", displayName: "Do Status", enableCellEdit: false },
		
        //{ name: "dName", displayName: "D Name", enableCellEdit: false },
        { name: "dFacilityName", displayName: "Ship To", enableCellEdit: false },
		{ name: "poTypeAttr", displayName: "Bi Qualifier", enableCellEdit: false },
        //{ name: "orderPr", displayName: "Order Id", enableCellEdit: false },
       // { name: "extPurchaseOrder", displayName: "Ext Purchase Order", enableCellEdit: false },
        //{ name: "splInstrCode2", displayName: "Spl Instr Code2", enableCellEdit: false },
        { name: "totalNbrOfUnits", displayName: "Total Nbr Of Units", enableCellEdit: false },
        { name: "estLpn", displayName: "Est LPN", enableCellEdit: false },

    ];
      
      //$scope.isTableToshipunits = false;
      //$scope.isTableMarkets = false;
      //$scope.isTableMarked  = false;
      $scope.isTableDtls = true;
      $scope.gridOptionsOne.totalItems  = data.totalNoOfRecords;  
      $scope.gridOptionsOne.data = data.pageItems;

      if ($scope.gridOptionsOne.data > 10) {
        $scope.gridOptionsOne.enableVerticalScrollbar = true;
        $scope.gridOptionsOne.enableHorizontalScrollbar = 1;
      } else {
        $scope.gridOptionsOne.enableVerticalScrollbar = false;
        $scope.gridOptionsOne.enableHorizontalScrollbar = 1;
      }
    }
        $scope.formData.firstcolvalue = $scope.firstColumnOrigValue;
        $scope.formData.secondcolvalue = $scope.secondColumnOrigValue;
        $scope.formData.thirdcolvalue = $scope.thirdColumnOrigValue;	
  
  });
  res.error(function (data, status, headers, config) {
    $("#showloader").css("display", "none");
    $scope.isFailed = true;
    $scope.resmessage = "System failed. Please try again or contact WAALOS Support";

  });
};

		$scope.scrolldown = function () {
		
		$scope.updateScreen = false;
		document.body.scrollTop = 600;
		document.documentElement.scrollTop = 600;
		$scope.showRules = true;

	};
	$scope.scrollup = function () {
		$scope.showRules = false;
		$scope.updateScreen = true;		
		document.body.scrollTop = 0;
		document.documentElement.scrollTop = 0;
	};
	
	
	 /** This function is used to update Routing Buddy Details  **/
	$scope.updateRoutingDetails=function(){
		$scope.isSuccess = false;
         $scope.isFailed = false;
		 var str_array = ($scope.maxNbr.trim().replace(/\n/g, ",")).replace(/,+/g, ',').replace(/(^\s*,)|( ,\s*$)/g, '');
		var lastChar = str_array[str_array.length - 1];
		if (lastChar == ",") {
			newStr = str_array.substring(0, str_array.length - 1);
		} else {
			newStr = str_array;
		}
		newStr = newStr.split(",");
		newStr = newStr.filter(function (str) {//used to remove the empty spaces(like empty value)
			str = str.trim();
			if (str) {
				return /\S/.test(str);
			}
		});
		newStr = newStr.map(function (el) {//used to clear the spaces of each array element
			return el.trim();
		});		
	   $("#showloader").css("display", "block");
	   if($scope.loadCodeCheck && $scope.loadCodeList!='BR' && ($scope.loadComments=='' || $scope.loadComments==undefined)){
			$("#showloader").css("display", "none");
				$scope.isFailed = true;
				$scope.resmessage = "Please enter load comment";
	   }else if(($scope.pickupDateCheck) &&($scope.dt==''||$scope.dt==undefined)){
		   $("#showloader").css("display", "none");
		   $scope.isFailed = true;
		   $scope.resmessage = "Please select Pickup date or disable it";
	   }else if(($scope.deliveryDateCheck) && $scope.dcName != "OneWMS-TDC" && ($scope.dt2=='' || $scope.dt2==undefined)){
		   $("#showloader").css("display", "none");
		   $scope.isFailed = true;
		   $scope.resmessage = "Please select Pickup date or disable it";
	   }
	   else if($scope.pagedc.toLowerCase().indexOf("OneWMS") === -1 && $scope.filterFieldText.length > 20){
	
		   $scope.isFailed = true;
		   $scope.resmessage = "Maximum 20 Characters allowed in Filter Field";
		   
	   }  
	   else if (($scope.shipViaCheck) &&($scope.shipViaList==''||$scope.shipViaList==undefined)){
		   $("#showloader").css("display", "none");
		   $scope.isFailed = true;
		   $scope.resmessage = "Please select a valid shipVia or disable it";
		   
	   }
/* 	   	   else if(($scope.deliveryDateCheck) &&($scope.dt==''||$scope.dt2==undefined)){
		   $("#showloader").css("display", "none");
		   $scope.isFailed = true;
		   $scope.resmessage = "Please select Delivery date or disable it";
	   } */
	   else{
		    var loadComments=$scope.loadComments;
		   loadComments=loadComments.replace(/\n/g, "-");
		   var payload = {
			"dcName": $scope.pagedc,
			"orders": newStr,
            "shipAuthNoFlag": $scope.shipmentNbrCheck?'Y':'N',
            "shipAuthNo": $scope.shipmentNbr,
            "consolidatorNoFlag": $scope.consNbrCheck?'Y':'N',
            "consolidatorNo": $scope.consNbrList,
			"freightTermFlag": $scope.freightTermCheck?'Y':'N',
			"freightTerm": $scope.freightTermList,
			"billAccountNoFlag": $scope.billAccountCheck?'Y':'N',
			"billAccountNo": $scope.billAccountNo,
			"loadCodeFlag": $scope.loadCodeCheck?'Y':'N',
			"loadCode": $scope.loadCodeList, 
			"loadComment": loadComments,
			"filterFieldFlag": $scope.filterFieldCheck?'Y':'N',
			"filterField": $scope.filterFieldText,
			"pickupDateFlag":  $scope.pickupDateCheck?'Y':'N',
			"pickupDate": $scope.dt!=''?$scope.dt.getFullYear() + '-' + ('0' + ($scope.dt.getMonth() + 1)).slice(-2) + '-' + ('0' + $scope.dt
			.getDate()).slice(-2):'',
            "shipViaFlag": $scope.shipViaCheck?'Y':'N',
            "shipVia": $scope.shipViaList,				
			"inputType": $scope.inputtype,
			"deliveryDateFlag":  $scope.deliveryDateCheck?'Y':'N',
			"deliveryDate": $scope.dt2!=''?$scope.dt2.getFullYear() + '-' + ('0' + ($scope.dt2.getMonth() + 1)).slice(-2) + '-' + ('0' + $scope.dt2.getDate()).slice(-2)+' '+$scope.dt2.getHours()+':'+$scope.dt2.getMinutes():'',
			"mustReleaseDateFlag":  $scope.mustReleaseDateCheck?'Y':'N',
			"mustReleaseDate": $scope.dtmst!=''?$scope.dtmst.getFullYear() + '-' + ('0' + ($scope.dtmst.getMonth() + 1)).slice(-2) + '-' + ('0' + $scope.dtmst
			.getDate()).slice(-2):'',
			"exclFlag": $scope.exclCheck?'Y':'N',
			"vasRemovalFlag": $scope.removeVasCheck?'Y':'N',
			"userId": sessionStorage.userName
        };
	 
		 var res = $http.put(urlService.UPDATE_ROUTING_BUDDY_DETAILS, payload, {
            headers: { 'x-api-key': sessionStorage.apikey }
        });
         res.success(function(data, status, headers, config) {
            $("#showloader").css("display", "none");
            if (data.errorMessage) {
                $scope.isFailed = true;
                $scope.resmessage = data.errorMessage;
            } else {
                $scope.isSuccess = true;
                $scope.resmessage = data.resMessage;
            }
        });
        res.error(function(data, status, headers, config) {
            $("#showloader").css("display", "none");
            $scope.isFailed = true;
            $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
        });
	}
	}
	

    $scope.task = function(taskval) {
        $scope.taskval = taskval;


        if ($scope.taskval == "DN") {
            $scope.dnnumber = true;
            $scope.ponumber = false;
        }
        else if ($scope.taskval == "PO") {
            $scope.dnnumber = false;
            $scope.ponumber = true;
        }
		
    };
    //user favourites code starts
    $scope.isClicked = false;
    $scope.addToFavourate = function(isClicked) {
        $("#showloader").css("display", "block");
        if (typeof isClicked !== "boolean") {
            commonService.postServiceResponse(urlService.GET_FAVOURITES, { "username": sessionStorage.userName })
                .then(function(response) {
                    $("#showloader").css("display", "none");
                    _.each(response, function(val, key) {
                        if (val.funName == $scope.functionality && val.dcName == $scope.dcName) {
                            $scope.isClicked = true;
                        }
                    });
                }, function(error) {
                    $("#showloader").css("display", "none");
                    $scope.isClicked = false;
                });
            //$scope.isClicked = ;
        } else {
            if (!$scope.isClicked) {
                commonService.postServiceResponse(urlService.ADD_FAVOURITE, { "username": sessionStorage.userName, "dcName": $scope.dcName, "funName": $scope.functionality })
                    .then(function(response) {
                        $("#showloader").css("display", "none");
                        if (response.errorMessage) {
                            $scope.isFavouriteAdded = false;
                            $scope.isClicked = false;
                            $scope.$broadcast('showAlert', ['']);
                        } else {
                            $scope.isClicked = true;
                            $scope.isClicked = !isClicked;
                            $scope.isFavouriteAdded = true;
                            $scope.favouriteMsg = response.resMessage;
                            $scope.$broadcast('ClickedOnFavourate', [$scope.dcName, $scope.functionality, $scope.isClicked]);
                        }

                    }, function(error) {
                        $scope.isClicked = false;
                        $("#showloader").css("display", "none");
                    });
                $scope.isClicked = !isClicked;
            } else {
                $("#showloader").css("display", "none");
            }
        }

    };
    $scope.addToFavourate('load');
    //user favourites code ends		




}]);