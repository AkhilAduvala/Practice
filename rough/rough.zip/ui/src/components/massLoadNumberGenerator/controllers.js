var app = angular.module('MassLoadNumberGenerator', ['ngAnimate', 'ui.grid', 'ui.grid.autoResize']);

app.controller('MassLoadNumberGeneratorController', ['$scope', '$http', '$q', '$interval', '$timeout', 'urlService', 'commonService', function ($scope, $http, $q, $interval, $timeout, urlService, commonService) {
    $scope.isTable = false;
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $scope.isFailedload = false;
    $scope.disable = true;
    $scope.isClicked = false;
    $scope.pagefunctionality = $scope.functionality;
    $scope.pagedc = $scope.dcName;
    $scope.getShipVia = function () {
        //$scope.isSuccess = false;
        $scope.isFailed = false;
        $("#showloader").css("display", "block");
        var url = urlService.GET_ALL_SHIPVIA.replace('dName', $scope.dcName);//$scope.dcName
        url = url.replace('uName', sessionStorage.userName);

        var res = $http.get(url, {
            headers: { 'x-api-key': sessionStorage.apikey }
        });

        res.success(function (data, status, headers, config) {
            console.log(JSON.stringify(data));//pradeep
            if (data.errorMessage) {
                $scope.isFailed = true;
                $scope.resmessage = data.errorMessage;
                $("#showloader").css("display", "none");
            } else if (data.length > 0) {
                $scope.allShipVia = data;
                $scope.allShipVia.unshift("Ship Via NA");
                $scope.shipvia = $scope.allShipVia[0];
                $("#showloader").css("display", "none");
            }
        });
        res.error(function (data, status, headers, config) {
            $("#showloader").css("display", "none");
            $scope.isFailed = true;
            $scope.resmessage = "System failed. Please try again or contact WAALOS Support";

        });
    };
    $scope.getShipVia();

    $scope.selectShipVia = function () {
        document.getElementById('nextStep').innerHTML = '';
        document.getElementById('list').innerHTML = '';
        $scope.errorMessagesArray = [];
    };

    $("#showloader").css("display", "none");

    $scope.init = function () {
        // check if there is query in url
        // and fire search in case its value is not empty

        if ($scope.dcName != "CDC") {
            $scope.hidecdc = true;
            $scope.hideAll = false;
        }
        else {
            $scope.hidecdc = false;
            $scope.hideAll = true;
        }
    };

    $scope.gridOptions = {
        enableSorting: true,
        enableColumnMenus: false,
        enableHorizontalScrollbar: false

    };

    $scope.gridOptions.onRegisterApi = function (gridApi) {
        //set gridApi on scope
        $scope.gridApi = gridApi;
    };

    $scope.Massnumbervalid = function () {
        $scope.isSuccess = false;
        $scope.isFailed = false;
        $scope.isTable = false;
        var reg = /^[0-9\_]+$/;
        if ($scope.massnumber == '' || $scope.massnumber == null || $scope.massnumber == undefined || $scope.massnumber === 0 || $scope.massnumber > 50 || $scope.massnumber.length > 2 || !(reg.test($scope.massnumber))) {
            $scope.disable = true;
        } else {
            $scope.disable = false;
        }
    };

    $scope.getMassnumberdetails = function () {
        $scope.isSuccess = false;
        $scope.isFailed = false;
        $scope.resmessage = "";
        if ($scope.shipvia == 'Ship Via NA') {
            $scope.shipvia = '';
        }

        $("#showloader").css("display", "block");

        var dataObj = {
            "dcName": $scope.pagedc,
            "totalLoads": $scope.massnumber,
            "shipVia": $scope.shipvia,
            "trailerNbr": $scope.trailernumber
        };

        //var res = $http.post(urlService.GENERATE_MASS_LOAD, dataObj);
        var res = $http.post(urlService.GENERATE_MASS_LOAD, dataObj, {
            headers: { 'x-api-key': sessionStorage.apikey }
        });
        res.success(function (data, status, headers, config) {

            $("#showloader").css("display", "none");

            if ($scope.shipvia == '') {
                $scope.shipvia = 'Ship Via NA';
            }
            if (data.errorMessage) {
                //$("#showloader").css("display", "none");
                $scope.isFailed = true;
                $scope.resmessage = data.errorMessage;
                $scope.isTable = false;

            } else if (data.resMessage) {
                $scope.isSuccess = true;
                $scope.resmessage = data.resMessage;

                $scope.isTable = true;

                if ($scope.pagedc == "CDC") {
                    $scope.gridOptions.columnDefs = [

                        { name: 'loadnumber', displayName: 'Load Number', cellTooltip: true, headerTooltip: true },
                        { name: 'warehouse', displayName: 'Warehouse', cellTooltip: true, headerTooltip: true },
                        { name: 'shipVia', displayName: 'Ship Via', cellTooltip: true, headerTooltip: true },
                        { name: 'trailerNbr', displayName: 'Trailer', cellTooltip: true, headerTooltip: true },
                        { name: 'status_code', displayName: 'Status Code', cellTooltip: true, headerTooltip: true },
                        { name: 'created_by', displayName: 'Created By', cellTooltip: true, headerTooltip: true }

                    ];
                }
                else {
                    $scope.gridOptions.columnDefs = [

                        { name: 'loadnumber', displayName: 'Load Number', cellTooltip: true, headerTooltip: true },
                        { name: 'warehouse', displayName: 'Warehouse', cellTooltip: true, headerTooltip: true },
                        { name: 'status_code', displayName: 'Status Code', cellTooltip: true, headerTooltip: true },
                        { name: 'created_by', displayName: 'Created By', cellTooltip: true, headerTooltip: true }

                    ];
                }
                $scope.gridOptions.data = data.massloadData;
                if ($scope.gridOptions.data > 10) {
                    $scope.gridOptions.enableVerticalScrollbar = true;
                } else {
                    $scope.gridOptions.enableVerticalScrollbar = false;
                    $scope.gridOptions.enableHorizontalScrollbar = 0;
                }

            }

        });
        res.error(function (data, status, headers, config) {
            $("#showloader").css("display", "none");
            $scope.isFailed = true;
            $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
        });
    };

    //user favourites code starts 

    $scope.addToFavourate = function (isClicked) {
        $("#showloader").css("display", "block");
        if (typeof isClicked !== "boolean") {
            commonService.postServiceResponse(urlService.GET_FAVOURITES, { "username": sessionStorage.userName })
                .then(function (response) {
                    $("#showloader").css("display", "none");
                    _.each(response, function (val, key) {
                        if (val.funName == $scope.functionality && val.dcName == $scope.dcName) {
                            $scope.isClicked = true;
                        }
                    });
                }, function (error) {
                    $("#showloader").css("display", "none");
                    $scope.isClicked = false;
                });
            //$scope.isClicked = ;
        } else {
            if (!$scope.isClicked) {
                commonService.postServiceResponse(urlService.ADD_FAVOURITE, { "username": sessionStorage.userName, "dcName": $scope.dcName, "funName": $scope.functionality })
                    .then(function (response) {
                        $("#showloader").css("display", "none");
                        if (response.errorMessage) {
                            $scope.isFavouriteAdded = false;
                            $scope.isClicked = false;
                            $scope.$broadcast('showAlert', ['']);
                        } else {
                            $scope.isClicked = true;
                            $scope.isClicked = !isClicked;
                            $scope.isFavouriteAdded = true;
                            $scope.favouriteMsg = response.resMessage;
                            $scope.$broadcast('ClickedOnFavourate', [$scope.dcName, $scope.functionality, $scope.isClicked]);
                        }

                    }, function (error) {
                        $scope.isClicked = false;
                        $("#showloader").css("display", "none");
                    });
                $scope.isClicked = !isClicked;
            } else {
                $("#showloader").css("display", "none");
            }
        }

    };
    $scope.addToFavourate('load');
    //user favourites code ends
}]);
