
var app = angular.module('BudgetCapacity', ['ngAnimate', 'ui.grid', 'ui.grid.selection', 'ui.grid.edit', 'ui.grid.cellNav', 'ui.grid.validate', 'ui.grid.exporter']);

app.controller('BudgetCapacityController', ['$scope', '$http', '$q', '$interval', 'uiGridValidateService', '$timeout','urlService','uiGridConstants','commonService', 'uiGridExporterService', 'uiGridExporterConstants', function ($scope, $http, $q, $interval, uiGridValidateService, $timeout, urlService, uiGridConstants, commonService, uiGridExporterService, uiGridExporterConstants) {
    $scope.isTable = false;
    $scope.disable = true;
    $scope.isupdate = true;
    $scope.isExport = true;
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $scope.isClicked = false;
    $scope.isFieldValidate = false; //show validation error message
    $scope.pagefunctionality = $scope.functionality;
    $scope.pagedc = $scope.dcName;
    var selectedYear = "";
    var totalRows = 0;
    var isAdmin = "";
    $scope.editableRecords = [];
    $scope.isDataUpdated = false;

    $("#showloader").css("display", "none");

    $scope.getUserDetails = function(){
        var url = urlService.GET_USER_DETAILS.replace("dName",$scope.pagedc);
        url = url.replace('uName',sessionStorage.userName);
        var res = $http.get(url, {
            headers: {'x-api-key': sessionStorage.apikey} 
        });
        res.success(function (data, status, headers, config) {
          if (data.errorMessage) {
              console.log("From data errorMessage :: ",data);
              $scope.resmessage = data.errorMessage;   
          } else if(data.resMessage){
              console.log("From data resMessage :: ",data);
              $scope.resmessage = data.resMessage;
          }else{
            console.log("From data success :: ",data);
            $scope.userDetails = data;
            isAdmin = data.isAdmin;
          }
        });
        res.error(function (data, status, headers, config) {
            $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
        });  
    };
    $scope.getUserDetails();


    //var date = new Date("2019-01-18")
    Date.prototype.getWeek = function() {
      var onejan = new Date(this.getFullYear(), 0, 1);
      return Math.ceil((((this - onejan) / 86400000) + onejan.getDay() + 1) / 7);
    }
    var weekNumber = (new Date()).getWeek();
    console.log("current week :: ", weekNumber);
    
    var currentYear = new Date().getFullYear();
    $scope.budgetYears = [currentYear-1, currentYear, currentYear+1];
    $scope.selectBudgetYear = function(selectedBudgetYear) {
      selectedYear = selectedBudgetYear;
      if($scope.selectedBudgetYear) {
        $scope.disable = false;      
      } else {
        $scope.disable = true;
      }
    }


    $scope.gridOptions = {
        enableSorting: false,
        enableColumnMenus: false,
        enableHorizontalScrollbar: false,
        exporterExcelFilename: 'budgetCapacity.xlsx',
        exporterExcelLinkElement: angular.element(document.querySelectorAll(".custom-excel-link-location")),
        cellEditableCondition: function ($scope) {
          // here, we'll only allow active rows to be edited
            if(isAdmin === 'Y') {            
              if(selectedYear == currentYear-1) {
                  if ((weekNumber-5)<=0) {
                    if($scope.row.entity.week >= totalRows-(5-weekNumber)) {
                      return $scope.row.entity.week;
                    }
                  } else {
                      return false;
                  }
              } else if(selectedYear == currentYear) {
                  if ($scope.row.entity.week < (weekNumber-5) || $scope.row.entity.week > (weekNumber+5)) {
                      return false;
                  } else {
                      return $scope.row.entity.week;
                  }
              } else if(selectedYear == currentYear +1) {
                  if(weekNumber+5 > totalRows) {
                    if($scope.row.entity.week <= weekNumber+5-totalRows) {
                      return $scope.row.entity.week;
                    } 
                  }else {
                    return false;
                  }
              } else {
                return false;
              }
            } else {
              return false;
            }        
        }
    };

    /* =Validator for the text checking only.*/
    $scope.gridOptions.onRegisterApi = function (gridApi) {
      //set gridApi on scope
        $scope.gridApi = gridApi;
        gridApi.selection.on.rowSelectionChangedBatch($scope, function (rows) {
          $scope.isSuccess = false;
          $scope.isFailed = false;
          if ($scope.gridApi.selection.getSelectedRows().length == 0) {
            $scope.isupdate = true;
          } else {
            //$scope.isupdate = false;
            validateDataAndEnableUpdate();
          }
        });
        gridApi.selection.on.rowSelectionChanged($scope, function (row) {
          $scope.isSuccess = false;
          $scope.isFailed = false;
          if($scope.gridApi.selection.getSelectedRows().length === 0 && (row.entity.osdl === null || row.entity.nsdl === null || row.entity.udil === null)) {          
              $scope.isupdate = true;
          } else if ($scope.gridApi.selection.getSelectedRows().length > 0) {                
              if(row.entity.osdl === null && row.entity.nsdl === null && row.entity.udil === null) {          
                $scope.gridApi.selection.unSelectRow(row.entity);
                $scope.isupdate = false;
              } 
              else {
              //$scope.isupdate = true;
              validateDataAndEnableUpdate();
              //$scope.resmessage = "Please enter valid osdl, nsdl and udil data to save the updated record."
              } 
          }          
        });
        function validateDataAndEnableUpdate() {
          $timeout(function () {
            var found = $('.ui-grid-cell-contents');
            if (found.hasClass('invalid')) {
              $scope.$apply(function () {
                //$scope.isFieldValidate = true;
                $scope.isFailed = true;
                $scope.isupdate = true;
              });
            } else if ($scope.gridApi.selection.getSelectedRows().length === 0) {
              $scope.$apply(function () {
                $scope.isupdate = true;
              });
            } else {
              $scope.$apply(function () {
                //$scope.isFieldValidate = false;
                $scope.isFailed = false;
                //$scope.isupdate = false;
              });
            }
          });
        }
        // Just disabling update button while entering data on row input control.
        gridApi.edit.on.beginCellEdit($scope, function (rowEntity, colDef) {
          $scope.isSuccess = false;
          $scope.isFailed = false;
          $scope.$apply(function () {
            $scope.isDataUpdated = true;
            $scope.isupdate = true;
          });      
        });
        gridApi.edit.on.afterCellEdit($scope, function (rowEntity, colDef, newValue, oldValue) {
            $scope.isSuccess = false;
            $scope.isFailed = false;
            $scope.isFailedload = false;
            rowEntity.osdl = rowEntity.osdl ? parseInt(rowEntity.osdl) : null;
            rowEntity.nsdl = rowEntity.nsdl ? parseInt(rowEntity.nsdl) : null;
            rowEntity.udil = rowEntity.udil ? parseInt(rowEntity.udil) : null;
            if (newValue && newValue !== oldValue) {// To check old and new values same or not        
                if (newValue === "") {
                  rowEntity.totalBudget = "";
                } else if (+(newValue) == oldValue) {
                } else {
                  $scope.gridApi.selection.selectRow(rowEntity);
                }
                $timeout(function () {
                    var found = $('.ui-grid-cell-contents');
                    if (found.hasClass('invalid')) {
                        $scope.$apply(function () {
                        //$scope.isFieldValidate = true;
                        $scope.isFailed = true;
                        $scope.isupdate = true;
                        $scope.resmessage = "Min 1 and max 7 digits allowed,value should be greater than zero.";
                        });
                    } else if(found.hasClass('ui-grid-cell-contents-hidden')){
                        $scope.isupdate = true;                  
                    } else if((rowEntity.osdl === "" || rowEntity.osdl === null) || (rowEntity.nsdl === "" || rowEntity.nsdl === null) || (rowEntity.udil === "" || rowEntity.udil === null)) {
                        $scope.isupdate = true;
                        $scope.isFailed = true;
                        $scope.resmessage = "OSDL, NSDL and UDIL fields are mandatory.";
                    }/*else if($scope.gridApi.selection.getSelectedRows().length !== 0){
                        $scope.$apply(function () {
                        $scope.isupdate = false;
                        //$scope.isFieldValidate = false;
                        $scope.isFailed = false;
                        });
                    }*/else {
                        $scope.$apply(function () {
                            $scope.isFailed = false;
                            $scope.isupdate = false;                          
                            //$scope.gridApi.selection.selectRow(rowEntity);                       
                        });
                    }
                    rowEntity.totalBudget = rowEntity.osdl+rowEntity.nsdl+rowEntity.udil;
                    console.log("totalBudget  :: ",rowEntity.totalBudget);
                }, 100);
                
            } else if((newValue === "" || newValue === null) && (rowEntity.osdl || rowEntity.nsdl || rowEntity.udil)) {
                $scope.isupdate = true;
                $scope.isFailed = true;
                $scope.resmessage = "OSDL, NSDL and UDIL fields are mandatory.";
                $scope.gridApi.selection.selectRow(rowEntity);
                rowEntity.totalBudget = rowEntity.osdl+rowEntity.nsdl+rowEntity.udil;
                console.log("totalBudget  :: ",rowEntity.totalBudget)
            } else if($scope.gridApi.selection.getSelectedRows().length !== 0 || ((newValue === "" || newValue === null) && (rowEntity.osdl === "" || rowEntity.osdl === null) && (rowEntity.nsdl === "" || rowEntity.nsdl === null) && (rowEntity.udil === "" || rowEntity.udil === null))) {
                $scope.$apply(function () {
                  rowEntity.totalBudget = "";
                  $scope.resmessage = "";
                  $scope.isupdate = false;
                  $scope.isFailed = false;
                  //rowEntity.isSelected = false;
                  $scope.gridApi.selection.unSelectRow(rowEntity);
              });
            }       
            
            $scope.$apply();
        });
    };


    uiGridValidateService.setValidator('numberChecker',
      function (argument) {
        return function (newValue, oldValue, rowEntity, colDef) {
          if (!newValue) {
            return /^[1-9][0-9]{0,6}?$/.test(oldValue);
          } else if(oldValue) {
            if (!(/^[1-9][0-9]{0,6}?$/.test(oldValue))) {
              $scope.isupdate = true;
              $scope.isFailed = true;
              $scope.resmessage = "Only numbers and max 7 digits allowed,value should be greater than zero.";
              $scope.$apply(function () {
                $scope.gridOptions.enableRowSelection = false;
              });
            } else {
              $scope.isupdate = false;
              $scope.gridOptions.enableRowSelection = true;
            }
            return /^[1-9][0-9]{0,6}?$/.test(oldValue);
          } else {
            $scope.isupdate = false;
            $scope.isFailed = false;
            return true;
          }
        };
      },
      function (argument) {
        return 'Only numbers and max 7 digits allowed,value should be greater than zero.';
      }
    );

    $scope.gridOptions.isRowSelectable = function (row) {
    };

    $scope.saveChanges = function() {
        $("#budgetCapacityModal").modal('hide');
        $scope.isDataUpdated = false;
        $scope.saveUpdatedRecord();
    }
    $scope.discardChanges = function () {
        $("#budgetCapacityModal").modal('hide');
        $scope.isDataUpdated = false;
        $scope.getBudgetCapacityData();
    }

    $scope.getBudgetCapacityData = function () {
        $scope.resmessage = "";
        $scope.isSuccess = false;
        $scope.isFailed = false;
        $scope.isFieldValidate = false;
        if($scope.isDataUpdated && !$scope.isupdate) {
            $("#budgetCapacityModal").modal('show');
        } else {
            $("#showloader").css("display", "block");
            var url = urlService.BUDGET_CAPACITY_GET_DATA.replace('dName',$scope.pagedc);
            url = url.replace('uName',sessionStorage.userName);
            url = url.replace('bYear',$scope.selectedBudgetYear);
            var res = $http.get(url, {
                headers: {'x-api-key': sessionStorage.apikey}
            });	
            res.success(function (data, status, headers, config) {
                $("#showloader").css("display", "none");
                if (data.errorMessage) {
                    $scope.isTable = false;
                    $scope.isFailed = true;
                    $scope.resmessage = data.errorMessage;
                }
                else if(data.resMessage){
                    $scope.isTable = false;
                    $scope.isSuccess = true;
                    $scope.resmessage = data.resMessage;
                }
                else if(data.length === 0){
                    $scope.isTable = false;
                    $scope.isFailed = true;
                    $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
                }
                else {
                    $scope.isTable = true;
                    $scope.isupdate = true;
                    $scope.isExport = false;
                    $scope.gridOptions.columnDefs = [                
                        { name: 'year', displayName: 'Year', visible: true, enableCellEdit: false },
                        { name: 'week', displayName: 'Week', cellTooltip:true, headerTooltip: true, enableCellEdit: false },
                        { name: 'osdl', displayName: 'OSDL', cellTooltip:true, headerTooltip: true, enableCellEdit: true, validators: { numberChecker: true }, cellTemplate: 'ui-grid/cellTitleValidator' },
                        { name: 'nsdl', displayName: 'NSDL', cellTooltip:true, headerTooltip: true, enableCellEdit: true, validators: { numberChecker: true }, cellTemplate: 'ui-grid/cellTitleValidator' },
                        { name: 'udil', displayName: 'UDIL', cellTooltip:true, headerTooltip: true, enableCellEdit: true, validators: { numberChecker: true }, cellTemplate: 'ui-grid/cellTitleValidator' },
                        { name: 'totalBudget', displayName: 'Total Budget', cellTooltip:true, headerTooltip: true, enableCellEdit: false }                
                    ]; 
                    $scope.gridOptions.data = data;            
                    totalRows = data.length;
                    if(isAdmin === 'Y') {
                        angular.forEach(data, function(record){
                            if(selectedYear == currentYear-1) {
                              if ((weekNumber-5)<=0) {
                                if(record.week >= totalRows-(5-weekNumber)) {
                                  $scope.editableRecords.push(record);
                                }
                              } 
                            } else if(selectedYear == currentYear) {
                                if (record.week < (weekNumber-5) || record.week > (weekNumber+5)) {
                                    return false;
                                } else {
                                  $scope.editableRecords.push(record);
                                }
                            } else if(selectedYear == currentYear +1) {
                                if(weekNumber+5 > totalRows) {
                                  if(record.week <= weekNumber+5-totalRows) {
                                    $scope.editableRecords.push(record);
                                  } 
                                }
                            }
                        });
                    }
                    console.log("Total Number Of Rows :: ",totalRows);
                    if ($scope.gridOptions.data > 10) {
                        $scope.gridOptions.enableVerticalScrollbar = true;
                    } else {
                        $scope.gridOptions.enableVerticalScrollbar = false;
                        $scope.gridOptions.enableHorizontalScrollbar = 0;
                    }
                }      
            });
            res.error(function (data, status, headers, config) {
                $("#showloader").css("display", "none");
                $scope.isFailed = true;
                $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
            });
            $scope.disableinput(); 
        }   
    };

    $scope.disableinput= function(){
        setTimeout(function(){  $('.ui-grid-pager-control-input').attr( "disabled", true );  }, 2000);
    };

    $scope.saveUpdatedRecord = function () {
        $scope.resmessage = "";
        $scope.isSuccess = false;
        $scope.isFailed = false;
        $scope.isFailedload = false;
        $scope.isFieldValidate = false;
        $scope.isRecordFound = false;
		    $scope.isDataUpdated = false; 
        $("#showloader").css("display", "block");
        var postRecords = [];        
        angular.forEach($scope.gridApi.selection.getSelectedRows(), function (data, index) {
            if(data.osdl != null && data.nsdl != null && data.udil != null) {
                var record = {
                  "dcName": $scope.dcName,
                  "userName": sessionStorage.userName,
                  "year": data.year,
                  "week":data.week,
                  "osdl":data.osdl,
                  "nsdl":data.nsdl,
                  "udil":data.udil,
                  "totalBudget":data.totalBudget
                };
                          
                angular.forEach($scope.editableRecords, function(editableRecord){
                    if(editableRecord.week==data.week)
                    {
                        editableRecord=data;
                    }
                    if(editableRecord.week<data.week) {                      
                        if(editableRecord.osdl == null || editableRecord.nsdl == null || editableRecord.udil == null) {
                            $scope.isupdate = true;
                            $scope.isFailed = true;
                            $scope.resmessage = "Total/Partial line of previous week data missing."; 
                        }                              
                    }          
                    
              }); 
              if($scope.resmessage=="") {
                postRecords.push(record); 
              }                      
            } else {
                $scope.isupdate = true;
                $scope.isFailed = true;
                $scope.resmessage = "OSDL, NSDL and UDIL fields are mandatory.";
            }   
        });
        if($scope.resmessage == "") {
            var res = $http.post(urlService.BUDGET_CAPACITY_DATA_UPDATE, postRecords, {
            headers: {'x-api-key': sessionStorage.apikey}
            });
            res.success(function (data, status, headers, config) {
              $("#showloader").css("display", "none");
              if (data.errorMessage) {
                $scope.isFailed = true;
                $scope.resmessage = data.errorMessage;
              } 
              else {
                $scope.getBudgetCapacityData();
                $('.ui-grid-pager-control-input').attr( "disabled", true );
                $scope.isSuccess = true;
                $scope.resmessage = data.resMessage;
              }
            });
            res.error(function (data, status, headers, config) {
              $("#showloader").css("display", "none");
              $scope.isFailed = true;
              $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
            });
        } else {
          $("#showloader").css("display", "none");
          $scope.isupdate=true;
          $scope.isFailed=true;
          return $scope.resmessage;
        }
    };

    $scope.exportExcel = function() {
        if($scope.isDataUpdated && !$scope.isupdate) {
            $("#budgetCapacityModal").modal('show');
        } else {
            var grid = $scope.gridApi.grid;
            var rowTypes = uiGridExporterConstants.ALL;
            var colTypes = uiGridExporterConstants.ALL;
            uiGridExporterService.excelExport(grid, rowTypes, colTypes);
        }
    };
    
    //user favourites code start
    $scope.addToFavourate = function(isClicked){
        $("#showloader").css("display", "block");
        if(typeof isClicked !== "boolean"){
            commonService.postServiceResponse(urlService.GET_FAVOURITES,{"username": sessionStorage.userName})
            .then(function(response){
                $("#showloader").css("display", "none");
                _.each(response,function(val,key){
                  if(val.funName == $scope.functionality && val.dcName == $scope.dcName){
                    $scope.isClicked = true;      
                  }
                });
            },function(error){
                $("#showloader").css("display", "none");
                $scope.isClicked = false; 
            });
            //$scope.isClicked = ;
        }else{
            if(!$scope.isClicked){
                commonService.postServiceResponse(urlService.ADD_FAVOURITE,{"username": sessionStorage.userName,"dcName":$scope.dcName,"funName":$scope.functionality})
                .then(function(response){
                    $("#showloader").css("display", "none");
                    if(response.errorMessage){
                        $scope.isFavouriteAdded= false; 
                        $scope.isClicked = false;      
                        $scope.$broadcast('showAlert',['']);
                    }else{
                        $scope.isClicked = true;      
                        $scope.isClicked = !isClicked;
                        $scope.isFavouriteAdded= true; 
                        $scope.favouriteMsg = response.resMessage;
                        $scope.$broadcast('ClickedOnFavourate',[$scope.dcName,$scope.functionality,$scope.isClicked]);
                    }                  
                },function(error){
                    $scope.isClicked = false;
                    $("#showloader").css("display", "none");
                });
                $scope.isClicked = !isClicked;
            } else{
                $("#showloader").css("display", "none");
            }
        }    
    };
    $scope.addToFavourate('load');
    //user favourites code end
}]);
