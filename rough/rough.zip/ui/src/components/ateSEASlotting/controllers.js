var app = angular.module('AteSEASlotting', ['ui.bootstrap', 'ngTouch', 'ui.grid', 'ui.grid.selection', 'ui.grid.pagination','ui.grid.edit', 'ui.grid.autoResize', 'ui.grid.validate', 'ui.grid.exporter']);

app.controller('SeaSlottingCtrl', ['$scope', '$rootScope', '$http', '$q', '$interval', '$timeout', 'urlService', 'uiGridConstants', 'commonService','$window', function($scope, $rootScope, $http, $q, $interval, $timeout, urlService, uiGridConstants, commonService, $window) {

    $scope.dsReleaseGrid = false;

    $scope.dsReleaseGriddata = {
        enableColumnMenus: false,
        enableSorting: true,
        exporterMenuCsv: false,
        exporterMenuPdf: false,
        enableGridMenu: true,
        exporterExcelFilename: 'HKRelaseTask.xlsx',
        exporterExcelSheetName: 'Sheet1',
        gridMenuShowHideColumns: false,
        paginationPageSizes: [15, 25, 50, 100],
        paginationPageSize: 15,
        exporterMenuVisibleData: false,
        enableRowSelection: false, //we can remove it later no use  of this
        enableSelectAll: false, //we can remove it later no use  of this             
        enableCellEdit: false, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
        enableCellEditOnFocus: true // set any editable column to allow edit on focus

    }


    $scope.dsReleaseGriddata_PH = {
        enableColumnMenus: false,
        enableSorting: true,
        exporterMenuCsv: false,
        exporterMenuPdf: false,
        enableGridMenu: true,
        exporterExcelFilename: 'PHRelaseTask.xlsx',
        exporterExcelSheetName: 'Sheet1',
        gridMenuShowHideColumns: false,
        exporterMenuVisibleData: false,
        enableRowSelection: false, //we can remove it later no use  of this
        enableSelectAll: false, //we can remove it later no use  of this             
        enableCellEdit: false, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
        enableCellEditOnFocus: true // set any editable column to allow edit on focus

    }

    $scope.dsReleaseGriddata_SG = {
        enableColumnMenus: false,
        enableSorting: true,
        exporterMenuCsv: false,
        exporterMenuPdf: false,
        enableGridMenu: true,
        exporterExcelFilename: 'SGRelaseTask.xlsx',
        exporterExcelSheetName: 'Sheet1',
        gridMenuShowHideColumns: false,
        exporterMenuVisibleData: false,
        enableRowSelection: false, //we can remove it later no use  of this
        enableSelectAll: false, //we can remove it later no use  of this             
        enableCellEdit: false, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
        enableCellEditOnFocus: true // set any editable column to allow edit on focus

    }

    $scope.dsReleaseGriddata_TI = {
        enableColumnMenus: false,
        enableSorting: true,
        exporterMenuCsv: false,
        exporterMenuPdf: false,
        enableGridMenu: true,
        exporterExcelFilename: 'TWRelaseTask.xlsx',
        exporterExcelSheetName: 'Sheet1',
        gridMenuShowHideColumns: false,
        exporterMenuVisibleData: false,
        enableRowSelection: false, //we can remove it later no use  of this
        enableSelectAll: false, //we can remove it later no use  of this             
        enableCellEdit: false, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
        enableCellEditOnFocus: true // set any editable column to allow edit on focus

    }


    $scope.dsReleaseGriddata_TH = {
        enableColumnMenus: false,
        enableSorting: true,
        exporterMenuCsv: false,
        exporterMenuPdf: false,
        enableGridMenu: true,
        exporterExcelFilename: 'THRelaseTask.xlsx',
        exporterExcelSheetName: 'Sheet1',
        gridMenuShowHideColumns: false,
        exporterMenuVisibleData: false,
        enableRowSelection: false, //we can remove it later no use  of this
        enableSelectAll: false, //we can remove it later no use  of this             
        enableCellEdit: false, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
        enableCellEditOnFocus: true // set any editable column to allow edit on focus

    }


    /******************manualZones start*************************/
    $scope.isMianpage = true;
    $scope.locationUpdateFlag = true;
    $scope.manualZones = {};
    $scope.dsGrid = false;
    $scope.dsGridPanel = false;
    $scope.automaticZones = {};
    $scope.pagefunctionality = $scope.functionality;
    $scope.pagedc = $scope.dcName;

    $scope.forecastValues = {
        forecastFile: '',
        minCasesPerSku: '',
        maxCasesPerSku: '',
        available: '',
        filledLocations: '',
        sKUExcluded: '',
        sKUMoveLocation: '',
        locationsUtilised: '',
        locationsRemaining: '',
        locationsWentNegative: '',

    }


    $scope.radioboxSelection4 = 'CD';
    $scope.radioboxSelection9 = 'AS';
    $scope.radioboxSelection10 = '3';
    $scope.radioboxSelection11 = '3';
    $scope.radioboxSel4 = 'NS';
    $scope.groupA = 'A1';
    $scope.isDisabled = '01';
    //$scope.isSelected = true;

    $scope.selected = [];
    $scope.array_ = angular.copy($scope.array);

    $scope.list = [{
        "id": 1,
        "value": "Zone 1",
        "checked": false
    }, {
        "id": 2,
        "value": "Zone 2",
        "checked": false
    }, {
        "id": 3,
        "value": "Zone 3",
        "checked": false
    }];

    $scope.checkedOrNot = function (id, isChecked, index) {

        if (isChecked) {
        	var checkboxes = $("input[type='checkbox']"),
        	submitButt = $("input[type='submit']");
		    checkboxes.click(function() {
		        submitButt.attr("disabled", !checkboxes.is(":checked"));

		    });
            $scope.selected.push(id);
            submitButt.attr("disabled", !checkboxes.is(":checked"));
        } else {
            var _index = $scope.selected.indexOf(id);
            $scope.selected.splice(_index, 1);
        }
    };

    $scope.slottingOption_AS = function() {
        $scope.isDisabled111 = false;
        $scope.isDisabled = true;
        $scope.isDisabled = '01';
        $scope.isSelected = false;
        $('input:checkbox').removeAttr('checked');
    }


    $scope.slottingOption = function() {
        $scope.isDisabled111 = false;
        $scope.isDisabled = true;
        $scope.isDisabled = '01';
        $scope.isSelected = false;
        $('input:checkbox').removeAttr('checked');
    }
   
    $scope.newSlotOption = function() {
        $scope.isDisabled111 = true;
        $scope.isDisabled = true;
        $scope.isSelected = false;
        $('input:checkbox').removeAttr('checked');
    }

    $scope.locationFTW = function() {
        
        if($scope.radioboxSelection4 == 'NS') {
    		$scope.isDisabled111 = true;
        	$scope.isDisabled = true;
        	
    	} else if($scope.radioboxSelection4 == 'CD') {
    		$scope.isDisabled = true;
        	$scope.isDisabled111 = false;
        	$scope.isDisabled = '01';
        	$('input:checkbox').removeAttr('checked');
            
    	} else if ($scope.radioboxSelection4 == 'AS') {
    		$scope.isDisabled = true;
        	$scope.isDisabled111 = false;
        	$scope.isDisabled = '01';
        	$('input:checkbox').removeAttr('checked');
    	}
       
    }

    $scope.locationHWAPP = function() {
        
       if($scope.radioboxSelection4 == 'NS') {
    		$scope.isDisabled111 = true;
        	$scope.isDisabled = true;
        	$scope.isDisabled111 = '02';
    	}else if($scope.radioboxSelection4 == 'CD') {
    		$scope.isDisabled111 = true;
        	$scope.isDisabled = false;
        	$scope.isDisabled111 = '02';
        	$('input:checkbox').removeAttr('checked');
    	} else if ($scope.radioboxSelection4 == 'AS') {
    		$scope.isDisabled = false;
        	$scope.isDisabled111 = true;
        	$scope.isDisabled111 = '02';
        	$('input:checkbox').removeAttr('checked');
    	}
        
    }

    $scope.fnPostData = function() {

		var sel = $('input[type=checkbox]:checked').map(function(_, el) {
		    return $(el).val();
		}).get();

        var Notsel = !$('input[type=checkbox]:checked').map(function(_, el) {
           return $(el).val();
        }).get();

        $scope.resmessage = "";
        $scope.isSuccess = false;
        $scope.isFailed = false;
        $("#showloader").css("display", "block");

        $scope.selRadio = [1,2,3];

        var url = urlService.HK_ATE_SLOTTING.replace('dName', $scope.dcName); //$scope.pagedc
	    url = url.replace('uName', sessionStorage.userName);

        if(($scope.radioboxSelection4 == 'CD') && ($scope.isDisabled =='01') && (sel.length =='0')) {
            url = url.replace('uProdSelected', '01');
            url = url.replace('uSlotSelected', $scope.radioboxSelection4);
            url = url.replace('uZone', $scope.selRadio);
        } else if(($scope.radioboxSelection4 == 'CD') && ($scope.isDisabled111 =='02') && (sel.length =='0')) {
            url = url.replace('uProdSelected', '02');
            url = url.replace('uSlotSelected', $scope.radioboxSelection4);
            url = url.replace('uZone', $scope.selRadio);
        } else if(($scope.radioboxSelection4 == 'AS') && ($scope.isDisabled =='01') && (sel.length =='0')) {
            url = url.replace('uProdSelected', '01');
            url = url.replace('uSlotSelected', $scope.radioboxSelection4);
            url = url.replace('uZone', $scope.selRadio);
        } else if(($scope.radioboxSelection4 == 'AS') && ($scope.isDisabled111 =='02') && (sel.length =='0')) {
            url = url.replace('uProdSelected', '02');
            url = url.replace('uSlotSelected', $scope.radioboxSelection4);
            url = url.replace('uZone', $scope.selRadio);
        }

	    if (($scope.radioboxSelection4 == 'NS') && ($scope.isDisabled111 == '02')) {
	    	url = url.replace('uProdSelected', '02');
	    	url = url.replace('uSlotSelected', $scope.radioboxSelection4);
            url = url.replace('uZone', $scope.selRadio);
	    } else if(($scope.radioboxSelection4 == 'NS') && ($scope.isDisabled =='01')) {
	    	url = url.replace('uProdSelected', '01');
	    	url = url.replace('uSlotSelected', $scope.radioboxSelection4);
            url = url.replace('uZone', $scope.selRadio);
	    } else if(($scope.radioboxSelection4 == 'AS') && ($scope.isDisabled111 =='02')) {
	    	url = url.replace('uProdSelected', '02');
	    	url = url.replace('uSlotSelected', $scope.radioboxSelection4);
	    	url = url.replace('uZone', sel);
	    } else if(($scope.radioboxSelection4 == 'AS') && ($scope.isDisabled =='01')) {
	    	url = url.replace('uProdSelected', '01');
	    	url = url.replace('uSlotSelected', $scope.radioboxSelection4);
	    	url = url.replace('uZone', sel);
	    } else if(($scope.radioboxSelection4 == 'CD') && ($scope.isDisabled111 =='02')) {
	    	url = url.replace('uProdSelected', '02');
	    	url = url.replace('uSlotSelected', $scope.radioboxSelection4);
	    	url = url.replace('uZone', sel);
	    } else if(($scope.radioboxSelection4 == 'CD') && ($scope.isDisabled =='01')) {
	    	url = url.replace('uProdSelected', '01');
	    	url = url.replace('uSlotSelected', $scope.radioboxSelection4);
	    	url = url.replace('uZone', sel);
	    } 

	    url = url.replace('uProdSelected', $scope.isDisabled);
	    url = url.replace('uSlotSelected', $scope.radioboxSelection4);
	    var res = $http.post(url,null, {
	            headers: {
	                'x-api-key': sessionStorage.apikey
	            }
	    })
        .success(function(data) {
            $("#showloader").css("display", "none");
            
            if (data.errorMessage) {
                $scope.isFailed = true;
                $scope.resmessage = data.errorMessage;
            } else {

                $scope.isSuccess = true;
                $scope.resmessage = data.resMessage;
                $scope.data = data;
            }
        })
        .error(function(data) {
            $("#showloader").css("display", "none");
            $scope.isFailed = true;
            $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
        });
    };


    $scope.fnPostDataTW = function() {

        $scope.resmessage = "";
        $scope.isSuccess = false;
        $scope.isFailed = false;
        $("#showloader").css("display", "block");

        var url = urlService.TW_ATE_SLOTTING.replace('dName', $scope.dcName); //$scope.pagedc
	    url = url.replace('uName', sessionStorage.userName);

	    if(($scope.radioboxSel4 == 'CD') && (($("input[name=example4]:checked").val())=="A4")) {
	    	url = url.replace('uGroup', $scope.groupD);
	    	url = url.replace('uSlotSelected', $scope.radioboxSel4);
	    	$scope.groupD = 'A4';	

	    } else if(($scope.radioboxSel4 == 'CD') && (($("input[name=example4]:checked").val())=="A3")) {
	    	url = url.replace('uGroup', $scope.groupC);
	    	url = url.replace('uSlotSelected', $scope.radioboxSel4);
	    	$scope.groupC = 'A3';
	    	
	    } else if(($scope.radioboxSel4 == 'CD') && (($("input[name=example4]:checked").val())=="A2")) {
	    	url = url.replace('uGroup', $scope.groupB);
	    	url = url.replace('uSlotSelected', $scope.radioboxSel4);
	    	$scope.groupB = 'A2';
	    	
	    } else if(($scope.radioboxSel4 == 'CD') && (($("input[name=example4]:checked").val())=="A1")) {
	    	url = url.replace('uGroup', $scope.groupA);
	    	url = url.replace('uSlotSelected', $scope.radioboxSel4);
	    	$scope.groupA = 'A1';
	    }

	    if(($scope.radioboxSel4 == 'NS') && (($("input[name=example4]:checked").val())=="A4")) {
	    	url = url.replace('uGroup', $scope.groupD);
	    	url = url.replace('uSlotSelected', $scope.radioboxSel4);
	    	$scope.groupD = 'A4';

	    } else if(($scope.radioboxSel4 == 'NS') && (($("input[name=example4]:checked").val())=="A3")) {
	    	url = url.replace('uGroup', $scope.groupC);
	    	url = url.replace('uSlotSelected', $scope.radioboxSel4);
	    	$scope.groupC = 'A3';
	    	$('input[name=example4]:checked');
	    	
	    } else if (($scope.radioboxSel4 == 'NS') && (($("input[name=example4]:checked").val())=="A2")) {
	    	url = url.replace('uGroup', $scope.groupB);
	    	url = url.replace('uSlotSelected', $scope.radioboxSel4);
	    	$scope.groupB = 'A2';
	    	$('input[name=example4]:checked');
	    } else if(($scope.radioboxSel4 == 'NS') && (($("input[name=example4]:checked").val())=="A1")) {
	    	url = url.replace('uGroup', $scope.groupA);
	    	url = url.replace('uSlotSelected', $scope.radioboxSel4);
	    	$scope.groupA = 'A1';
	    	$('input[name=example4]:checked');
	    }

	    var res = $http.post(url,null, {
	            headers: {
	                'x-api-key': sessionStorage.apikey
	            }
	    })
        .success(function(data) {
            $("#showloader").css("display", "none");
            if (data.errorMessage) {
                $scope.isFailed = true;
                $scope.resmessage = data.errorMessage;
            } else {

            	$timeout(function(){
					$scope.isSuccess = true;
	                $scope.resmessage = data.resMessage;
				},0);
            }
        })
        .error(function(data) {
            $("#showloader").css("display", "none");
            $scope.isFailed = true;
            $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
        });
    };

    $scope.fnPostDataPH = function() {
        $scope.resmessage = "";
        $scope.isSuccess = false;
        $scope.isFailed = false;
        $("#showloader").css("display", "block");
	        var url = urlService.PH_ATE_SLOTTING.replace('dName', $scope.dcName); //$scope.pagedc
	        url = url.replace('uName', sessionStorage.userName);
	        var res = $http.post(url,null, {
	            headers: {
	                'x-api-key': sessionStorage.apikey
	            }
	        })
            .success(function(data) {
                $("#showloader").css("display", "none");
                $scope.fndataSources();
                if (data.errorMessage) {
                    $scope.isFailed = true;
                    $scope.resmessage = data.errorMessage;
                } else {
                    $scope.isSuccess = true;
                    $scope.resmessage = data.resMessage;

                }
            })
            .error(function(data) {
                $("#showloader").css("display", "none");
                $scope.isFailed = true;
                $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
            });
    };

   

    $scope.enableUpdate = function(val) {
        var len = $(".location_check:checked").length;
        if (len > 0) {
            $scope.locationUpdateFlag = false;
        } else {
            $scope.locationUpdateFlag = true;
        }
    }

    /******************manualZones end*************************/


    /******************zonesAutomaticLocking Start*******************************/
    $scope.gridOptions = {
        paginationPageSizes: [15, 25, 50, 100],
        paginationPageSize: 15,
        //useExternalPagination: true,
        enableColumnMenus: false,
        enableSorting: true,
        multiSelect: false,
        enableRowSelection: true, //we can remove it later no use  of this
        enableSelectAll: true, //we can remove it later no use  of this             
        enableCellEdit: true, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
        enableCellEditOnFocus: true // set any editable column to allow edit on focus

    };
    $scope.dsGridOptions = {
        paginationPageSizes: [15, 25, 50, 100],
        paginationPageSize: 15,
        //useExternalPagination: true,
        enableColumnMenus: false,
        enableSorting: true,
        multiSelect: false,
        enableRowSelection: true, //we can remove it later no use  of this
        enableSelectAll: true, //we can remove it later no use  of this             
        enableCellEdit: true, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
        enableCellEditOnFocus: true // set any editable column to allow edit on focus
    };


    $scope.dsReleaseGriddata.onRegisterApi = function(gridApi) {
        $scope.gridApi = gridApi;

        $scope.gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
            $scope.pageNo =  newPage;
            $scope.pageSize = pageSize;
        });
    };

    $scope.dsReleaseGriddata_PH.onRegisterApi = function(gridApi) {
        $scope.gridApi = gridApi;
    };

    $scope.dsReleaseGriddata_SG.onRegisterApi = function(gridApi) {
        $scope.gridApi = gridApi;
    };

    $scope.dsReleaseGriddata_TI.onRegisterApi = function(gridApi) {
        $scope.gridApi = gridApi;
    };

    $scope.dsReleaseGriddata_TH.onRegisterApi = function(gridApi) {
        $scope.gridApi = gridApi;
    };
    

    $scope.gridOptions.onRegisterApi = function(gridApi) {
        //set gridApi on scope
        $scope.gridApi = gridApi;

        gridApi.edit.on.afterCellEdit(null, function(rowEntity, colDef, newValue, oldValue) {
            $scope.isSuccessAZ = false;
            $scope.isFailedAZ = false;
            // if (rowEntity.locationsBlocked == 0 || rowEntity.locationsBlocked == "0" || (rowEntity.locationsBlocked == rowEntity.defaultValue)) {
            // 	rowEntity.locationsBlocked = oldValue;
            // 	$scope.numberValidation = true;
            // } else {
            // 	$scope.numberValidation = false;
            // }
        });
        gridApi.selection.on.rowSelectionChangedBatch($scope, function(row) {
            $scope.isSuccess = false;
            $scope.isFailed = false;
            var rowCount = $scope.gridApi.selection.getSelectedRows().length;
            //$scope.gridApi.selection.setMultiSelect(false);
            if (rowCount != 10 && row[0].isSelected) {
                $scope.isEdit = false;
                $scope.isDelete = false;
            } else {
                $scope.isEdit = true;
                $scope.isDelete = true;
            }

        });
        gridApi.selection.on.rowSelectionChanged($scope, function(row) {

            $scope.numberValidation = false;
            $scope.isSuccess = false;
            $scope.isFailed = false;
            //$scope.gridApi.selection.setMultiSelect(false);
            var rowCount = $scope.gridApi.selection.getSelectedRows().length;
            if (rowCount > 0 && rowCount != 10) {
                $scope.isEdit = false;
                $scope.isDelete = false;
            } else {
                $scope.isEdit = true;
                $scope.isDelete = true;
            }
        });
    };
    $scope.dsGridOptions.onRegisterApi = function(gridApi) {
        //set gridApi on scope
        $scope.gridApi = gridApi;
        gridApi.selection.on.rowSelectionChanged($scope, function(row) {
            $scope.datascourceTemplateID = row.entity.templateId;
            if (row.isSelected) {
                $scope.isEdit = false;
                $scope.isDelete = false;
            } else {
                $scope.isEdit = true;
                $scope.isDelete = true;
            }
        });
    };

    $scope.fndataSources = function() {
        $scope.tabClicked = 'ds';
        $scope.getZonesAutomaticLocationData(urlService.ATE_SLOTTING_SZ_GET_DATASOURCE_DETAILS, 'ds');
    }
    $scope.fnRejectList = function() {
        $scope.tabClicked = 'rj';
        $scope.getRejectLocationData(urlService.ATE_SLOTTING_REJECT_LIST, 'rj');
    }

    $scope.getRejectLocationData = function(tabUrl, type) {
        $scope.isSuccessAZ = false;
        $scope.isFailedAZ = false;
        $scope.isSuccess = false;
        $scope.isFailed = false;
        $scope.isEdit = true;
        $scope.isDelete = true;
        $("#showloader").css("display", "block");

        var url = tabUrl.replace('dName', $scope.dcName); //$scope.pagedc
        url = url.replace('uName', sessionStorage.userName);
        var res = $http.get(url, {
            headers: {
                'x-api-key': sessionStorage.apikey
            }
        });
        res.success(function(data, status, headers, config) {
            if (data.errorMessage) {
                $scope.isFailedAZ = true;
                $scope.resmessage = data.errorMessage;
            } else {
                var dcTab = $scope.dcName;
                if (dcTab == 'Philippines' || dcTab == 'Singapore' || dcTab == 'Thailand' || dcTab == 'Taiwan') {
                    $scope.dsGrid = true;
                    $scope.dsGridPanel = false;
                    $scope.dsGridOptions.columnDefs = [{
                            name: 'sno',
                            displayName: 'Serial Number',
                            enableCellEdit: false,
                            cellTooltip: true,
                            headerTooltip: true
                        },{
                            name: 'dsp_sku',
                            displayName: 'Display Sku',
                            width: 120,
                            enableCellEdit: false,
                            cellTooltip: true,
                            headerTooltip: true
                        },{
                            name: 'article',
                            displayName: 'Article',
                            enableCellEdit: false,
                            width: 150,
                            cellTooltip: true,
                            headerTooltip: true
                        },{
                            name: 'article_location',
                            displayName: 'Article Locs',
                            width: 200,
                            enableCellEdit: false,
                            cellTooltip: true,
                            headerTooltip: true
                        },{
                            name: 'comments',
                            displayName: 'Comments',
                            width: 200,
                            enableCellEdit: false,
                            cellTooltip: true,
                            headerTooltip: true
                        }
                    ];
                } else {
                    $scope.dsGrid = true;
                    $scope.dsGridPanel = false;
                    $scope.dsGridOptions.columnDefs = [{
                            name: 'sno',
                            displayName: 'Serial Number',
                            enableCellEdit: false,
                            cellTooltip: true,
                            headerTooltip: true
                            },{
                            name: 'dsp_sku',
                            displayName: 'Display Sku',
                            width: 120,
                            enableCellEdit: false,
                            cellTooltip: true,
                            headerTooltip: true
                        },{
                            name: 'article',
                            displayName: 'Article',
                            enableCellEdit: false,
                            width: 150,
                            cellTooltip: true,
                            headerTooltip: true
                        },{
                            name: 'article_location',
                            displayName: 'Article Locs',
                            width: 200,
                            enableCellEdit: false,
                            cellTooltip: true,
                            headerTooltip: true
                        },{
                            name: 'comments',
                            displayName: 'Comments',
                            width: 200,
                            enableCellEdit: false,
                            cellTooltip: true,
                            headerTooltip: true
                        }
                    ];

                }
                if (type == 'rj') {
                    $scope.dsGridPanel = false;
                    $scope.dsGridOptions.data = data;
                } else {
                    $scope.gridOptions.data = data;
                }
                $scope.gridOptions.cellEditableCondition = function($scope) {
                    if (($scope.row.entity.locationsBlocked != "0" || $scope.row.entity.locationsBlocked != 0) && ($scope.row.entity.locationsBlocked != $scope.row.entity.defaultValue)) {
                        return $scope.row.entity.locationsBlocked;
                    }
                }

                if ($scope.gridOptions.data > 10) {
                    $scope.gridOptions.enableVerticalScrollbar = true;
                    $scope.gridOptions.enableHorizontalScrollbar = 1;
                } else {
                    $scope.gridOptions.enableVerticalScrollbar = false;
                    $scope.gridOptions.enableHorizontalScrollbar = 1;
                }
            }
            $('.ui-grid-pager-control input').prop("disabled", true);
            $("#showloader").css("display", "none");
        });
        res.error(function(data, status, headers, config) {
            $scope.isTable = false;
            $scope.dsGrid = false
            $("#showloader").css("display", "none");
            $scope.isFailed = true;
            $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
        });
    };

    $scope.getZonesAutomaticLocationData = function(tabUrl, type) {
        $scope.isSuccess = false;
        $scope.isFailed = false;
        $scope.isEdit = true;
        $scope.isDelete = true;
        $("#showloader").css("display", "block");

        var url = tabUrl.replace('dName', $scope.dcName); //$scope.pagedc
        url = url.replace('uName', sessionStorage.userName);
        var res = $http.get(url, {
            headers: {
                'x-api-key': sessionStorage.apikey
            }
        });
        res.success(function(data, status, headers, config) {
            
            if (data.errorMessage) {
                $scope.isFailedAZ = true;
                $scope.resmessage = data.errorMessage;
            } else {
                var dcTab = $scope.dcName;
                if (dcTab == 'Philippines' || dcTab == 'Singapore' || dcTab == 'Thailand') {
                    $scope.dsGrid = true;
                    $scope.dsGridPanel = false;
 
                    $scope.dsGridOptions.columnDefs = [{
                            name: 'templateId',
                            displayName: 'Template Id',
                            width: 120,
                            enableCellEdit: false,
                            cellTooltip: true,
                            headerTooltip: true,
                            checkboxSelection: true,
                            headerCheckboxSelection: true
                        },
                        {
                            name: 'name',
                            displayName: 'Name',
                            enableCellEdit: false,
                            width: 150,
                            cellTooltip: true,
                            headerTooltip: true,
                            checkboxSelection: true
                        },
                        {
                            name: 'hasAssoc',
                            displayName: 'Has Slotting Association?',
                            width: 200,
                            enableCellEdit: false,
                            cellTooltip: true,
                            headerTooltip: true,
                            checkboxSelection: true
                        },
                        {
                            name: 'hasTasks',
                            displayName: 'Has Unreleased Tasks?',
                            width: 200,
                            enableCellEdit: false,
                            cellTooltip: true,
                            headerTooltip: true,
                            checkboxSelection: true
                        },
                        {
                            name: 'lastCompletionTime',
                            displayName: 'Last Completion Time',
                            width: 200,
                            enableCellEdit: false,
                            cellTooltip: true,
                            headerTooltip: true,
                            checkboxSelection: true
                        },
                        {
                            name: 'status',
                            displayName: 'Current Status',
                            width: 170,
                            enableCellEdit: false,
                            cellTooltip: true,
                            headerTooltip: true,
                            checkboxSelection: true
                        },
                        {
                            name: 'taskType',
                            displayName: 'Task Type',
                            width: 170,
                            enableCellEdit: false,
                            cellTooltip: true,
                            headerTooltip: true,
                            checkboxSelection: true
                        },
                        {
                            name: 'runaslot',
                            displayName: 'Run a Slot',
                            width: 120,
                            enableCellEdit: false,
                            cellTemplate: '<div class="ui-grid-cell-contents"  ng-click=\"grid.appScope.runSlot(grid, row)\"><a href="" id="foo">Run a Slot</a></div>',
                            checkboxSelection: true
                        },
                        {
                            name: 'releasetasks',
                            displayName: 'Release Tasks',
                            width: 170,
                            enableCellEdit: false,
                            cellTemplate: '<div class="ui-grid-cell-contents" ng-click=\"grid.appScope.releaseSlot(grid, row)\" ng-if="row.entity.lastCompletionTime != null"><a href="" class="">Release Tasks</a></div><div class="ui-grid-cell-contents" ng-if="row.entity.lastCompletionTime == null"></div>',
                            //cellTemplate: '<div class="ui-grid-cell-contents"  ng-click=\"grid.appScope.releaseSlot(grid, row)\" ng-if="row.entity.status != FINISHED"><a href="">Release Tasks</a></div>',
                            checkboxSelection: true
                        },
                        {
                            name: 'comments',
                            displayName: 'Comments',
                            width: 170,
                            enableCellEdit: false,
                            cellTooltip: true,
                            headerTooltip: true,
                            checkboxSelection: true
                        }

                    ];
                }  else if (dcTab == 'Taiwan') {
                    $scope.dsGrid = true;
                    $scope.dsGridPanel = false;
 
                    $scope.dsGridOptions.columnDefs = [{
                            name: 'templateId',
                            displayName: 'Template Id',
                            width: 120,
                            enableCellEdit: false,
                            cellTooltip: true,
                            headerTooltip: true,
                            checkboxSelection: true,
                            headerCheckboxSelection: true
                        },
                        {
                            name: 'name',
                            displayName: 'Name',
                            enableCellEdit: false,
                            width: 150,
                            cellTooltip: true,
                            headerTooltip: true,
                            checkboxSelection: true
                        },
                        {
                            name: 'hasAssoc',
                            displayName: 'Has Slotting Association?',
                            width: 200,
                            enableCellEdit: false,
                            cellTooltip: true,
                            headerTooltip: true,
                            checkboxSelection: true
                        },
                        {
                            name: 'hasTasks',
                            displayName: 'Has Unreleased Tasks?',
                            width: 200,
                            enableCellEdit: false,
                            cellTooltip: true,
                            headerTooltip: true,
                            checkboxSelection: true
                        },
                        {
                            name: 'lastCompletionTime',
                            displayName: 'Last Completion Time',
                            width: 200,
                            enableCellEdit: false,
                            cellTooltip: true,
                            headerTooltip: true,
                            checkboxSelection: true
                        },
                        {
                            name: 'status',
                            displayName: 'Current Status',
                            width: 170,
                            enableCellEdit: false,
                            cellTooltip: true,
                            headerTooltip: true,
                            checkboxSelection: true
                        },
                        {
                            name: 'taskType',
                            displayName: 'Task Type',
                            width: 170,
                            enableCellEdit: false,
                            cellTooltip: true,
                            headerTooltip: true,
                            checkboxSelection: true
                        },
                        {
                            name: 'zone',
                            displayName: 'Zone',
                            width: 170,
                            enableCellEdit: false,
                            cellTooltip: true,
                            headerTooltip: true,
                            checkboxSelection: true
                        },
                        {
                            name: 'runaslot',
                            displayName: 'Run a Slot',
                            width: 120,
                            enableCellEdit: false,
                            cellTemplate: '<div class="ui-grid-cell-contents"  ng-click=\"grid.appScope.runSlot(grid, row)\"><a href="" id="foo">Run a Slot</a></div>',
                            checkboxSelection: true
                        },
                        {
                            name: 'releasetasks',
                            displayName: 'Release Tasks',
                            width: 170,
                            enableCellEdit: false,
                            cellTemplate: '<div class="ui-grid-cell-contents" ng-click=\"grid.appScope.releaseSlot(grid, row)\" ng-if="row.entity.lastCompletionTime != null"><a href="" class="">Release Tasks</a></div><div class="ui-grid-cell-contents" ng-if="row.entity.lastCompletionTime == null"></div>',
                            //cellTemplate: '<div class="ui-grid-cell-contents"  ng-click=\"grid.appScope.releaseSlot(grid, row)\" ng-if="row.entity.status != FINISHED"><a href="">Release Tasks</a></div>',
                            checkboxSelection: true
                        },
                        {
                            name: 'comments',
                            displayName: 'Comments',
                            width: 170,
                            enableCellEdit: false,
                            cellTooltip: true,
                            headerTooltip: true,
                            checkboxSelection: true
                        }

                    ];
                } else {
                    $scope.dsGrid = true;
                    $scope.dsGridPanel = false;
                    $scope.dsGridOptions.columnDefs = [{
                            name: 'templateId',
                            displayName: 'Template Id',
                            width: 120,
                            enableCellEdit: false,
                            cellTooltip: true,
                            headerTooltip: true
                        },
                        {
                            name: 'name',
                            displayName: 'Name',
                            enableCellEdit: false,
                            width: 150,
                            cellTooltip: true,
                            headerTooltip: true
                        },
                        {
                            name: 'hasAssoc',
                            displayName: 'Has Slotting Association?',
                            width: 200,
                            enableCellEdit: false,
                            cellTooltip: true,
                            headerTooltip: true
                        },
                        {
                            name: 'hasTasks',
                            displayName: 'Has Unreleased Tasks?',
                            width: 200,
                            enableCellEdit: false,
                            cellTooltip: true,
                            headerTooltip: true
                        },
                        {
                            name: 'lastCompletionTime',
                            displayName: 'Last Completion Time',
                            width: 200,
                            enableCellEdit: false,
                            cellTooltip: true,
                            headerTooltip: true
                        },
                        {
                            name: 'status',
                            displayName: 'Current Status',
                            width: 170,
                            enableCellEdit: false,
                            cellTooltip: true,
                            headerTooltip: true
                        },
                        {
                            name: 'taskType',
                            displayName: 'Task Type',
                            width: 170,
                            enableCellEdit: false,
                            cellTooltip: true,
                            headerTooltip: true,
                            checkboxSelection: true
                        },
                        {
                            name: 'prodType',
                            displayName: 'Product Type',
                            width: 170,
                            enableCellEdit: false,
                            cellTooltip: true,
                            headerTooltip: true
                        },
                        {
                            name: 'zone',
                            displayName: 'Zone',
                            width: 170,
                            enableCellEdit: false,
                            cellTooltip: true,
                            headerTooltip: true
                        },
                        {
                            name: 'runaslot',
                            displayName: 'Run a Slot',
                            width: 120,
                            enableCellEdit: false,
                            cellTemplate: '<div class="ui-grid-cell-contents"  ng-click=\"grid.appScope.runSlot(grid, row)\"><a href="" id="foo">Run a Slot</a></div>'
                        },
                        {
                            name: 'releasetasks',
                            displayName: 'Release Tasks',
                            width: 170,
                            enableCellEdit: false,
                            //cellTemplate: '<div class="ui-grid-cell-contents"  ng-click=\"grid.appScope.releaseSlot(grid, row)\" ng-if="(row.entity.hasTasks != Y) && (row.entity.status == null)"><a href="">Release Tasks</a></div>',
                            //cellTemplate: '<div class="ui-grid-cell-contents"  ng-click=\"grid.appScope.releaseSlot(grid, row)\" ng-if="(row.entity.hasTasks != Y) && (row.entity.status == FINISHED)"><a href="">Release Tasks</a></div>',
                            //cellTemplate: '<div class="ui-grid-cell-contents"  ng-click=\"grid.appScope.releaseSlot(grid, row)\" ng-if="row.entity.lastCompletionTime == null"><a href="">Release Tasks</a></div>',
                            //cellTemplate: '<div class="ui-grid-cell-contents"  ng-click=\"grid.appScope.releaseSlot(grid, row)\" ng-if="(row.entity.hasTasks == Y) && (row.entity.lastCompletionTime == null)"><a href="">Release Tasks</a></div><div class="ui-grid-cell-contents"  ng-click=\"grid.appScope.releaseSlot(grid, row)\" ng-if="(row.entity.hasTasks == Y) && (row.entity.lastCompletionTime != null)"><a href="">Release Tasks</a></div>'
                            //cellTemplate: '<div class="ui-grid-cell-contents"  ng-click=\"grid.appScope.releaseSlot(grid, row)\" ng-if="(row.entity.hasTasks == Y) && (row.entity.lastCompletionTime != null)"><a href="" class="not-active">Release Tasks</a></div>'
                            cellTemplate: '<div class="ui-grid-cell-contents" ng-click=\"grid.appScope.releaseSlot(grid, row)\" ng-if="row.entity.lastCompletionTime != null"><a href="" class="">Release Tasks</a></div><div class="ui-grid-cell-contents" ng-if="row.entity.lastCompletionTime == null"></div>'
                        },
                        {
                            name: 'comments',
                            displayName: 'Comments',
                            width: 170,
                            enableCellEdit: false,
                            cellTooltip: true,
                            headerTooltip: true
                        }

                    ];

                }
                if (type == 'ds') {
                    $scope.dsGridPanel = false;
                    $scope.dsGridOptions.data = data;

                } else {
                    $scope.gridOptions.data = data;
                    console.log($scope.gridOptions.data);
                }
                $scope.gridOptions.cellEditableCondition = function($scope) {
                    if (($scope.row.entity.locationsBlocked != "0" || $scope.row.entity.locationsBlocked != 0) && ($scope.row.entity.locationsBlocked != $scope.row.entity.defaultValue)) {
                        return $scope.row.entity.locationsBlocked;
                    }
                }

                if ($scope.gridOptions.data > 10) {
                    $scope.gridOptions.enableVerticalScrollbar = true;
                    $scope.gridOptions.enableHorizontalScrollbar = 1;
                } else {
                    $scope.gridOptions.enableVerticalScrollbar = false;
                    $scope.gridOptions.enableHorizontalScrollbar = 1;
                }
            }
            $('.ui-grid-pager-control input').prop("disabled", true);
            $("#showloader").css("display", "none");
        });
        res.error(function(data, status, headers, config) {
            $scope.isTable = false;
            $scope.dsGrid = false
            $("#showloader").css("display", "none");
            $scope.isFailed = true;
            $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
        });
    };
    //function to get back to the datasource tab data
    $scope.goBack = function(type) {
        if (type == 'release') {
            $scope.isReleseTask = false;
            $scope.isMianpage = true;
            $scope.fndataSources();
        }
        $scope.dsGrid = true;
        $scope.dsGridPanel = false;
        $scope.dsReleaseGrid = false;
        $scope.isEdit = true;
        $scope.isDelete = true;

    }

    $scope.runSlot = function(grid, row) {
        if (grid) {
            $("#ateTJSlottingAlert").modal('show');
            $scope.runASlot = row;
        } else {
            $('#ateTJSlottingAlert').modal("hide");
            if ($scope.runASlot.entity.hasAssoc == 'Y') {
                $("#showloader").css("display", "block");
                var url = urlService.RUN_A_SLOT_SZ.replace('dName', $scope.dcName).replace('uName', sessionStorage.userName).replace('aSlot', 3);
                $http.get(url, {
                        headers: {
                            'x-api-key': sessionStorage.apikey
                        }
                    })
                    .success(function(data) {
                        if (data.errorMessage) {

                            $("#showloader").css("display", "none");
                            $scope.resmessage = data.errorMessage;
                            $scope.isFailed = true;
                            $scope.isSuccess = false;
                        } else if (data.resMessage) {
                            $("#showloader").css("display", "block");
                            setTimeout(function() {
                                $("#showloader").css("display", "none");
                                $scope.fndataSources();
                                $scope.resmessage = data.resMessage;
                                $scope.isFailed = false;
                                $scope.isSuccess = true;
                            }, 10000);


                        } else {
                            $("#showloader").css("display", "block");
                            setTimeout(function() {
                                $("#showloader").css("display", "none");
                            }, 10000);
                            $scope.fndataSources();
                            $scope.resmessage = data.resMessage;
                            $scope.isFailed = false;
                            $scope.isSuccess = true;
                            $("#showloader").css("display", "none");
                        }
                    }).error(function(data) {
                        $("#showloader").css("display", "none");
                        $scope.isFailed = true;
                        $scope.isSuccess = false;
                        $scope.resmessage = data;
                    })
            } else {
                return false;
            }
        }

    }
    $scope.releaseSlot = function(grid, row) {
        $scope.isFailed = false;
        $scope.isSuccess = false;
        if (row.entity.hasAssoc == 'Y') {
            $scope.dsGrid = false;
            $scope.dsGridPanel = false;
            $scope.isEdit = false;
            $scope.isDelete = true;
            $scope.dsReleaseGrid = true;
            $scope.isReleseTask = true;
            $scope.isMianpage = false;
        } else {
            return false;
        }
    }

    $scope.gridOptions.isRowSelectable = function(row) {
        if ($scope.tabClicked == 'za') {
            if (row.entity.locationsBlocked == 0 || row.entity.locationsBlocked == "0" || (row.entity.locationsBlocked == row.entity.defaultValue)) {
                return false;
            } else {
                return true;
            }
        }
    };
    $scope.dsGridOptions.isRowSelectable = function(row) {
        if (row.entity.hasAssoc == 'Y') {
            return true;
        } else {
            return false;
        }

    };

    $scope.fndataSources();
    $scope.slottype = {
        slottype: 'Deslot'
    }
    $scope.fnDsRelease = function(type) {
        $scope.isSuccess = false;
        $scope.isFailed = false;
        $scope.releaseGriddata = false;
        $("#showloader").css("display", "block");
        if (type == 'add') {
            var url = '';
            if ($scope.slottype.slottype == 'Deslot') {
                url = urlService.ADD_DESLOT_SZ.replace('dName', $scope.dcName).replace('uName', sessionStorage.userName);
                url = url.replace('slottype', $scope.slottype.slottype);
            } else {
                url = urlService.ADD_NEW_SLOT_SZ.replace('dName', $scope.dcName).replace('uName', sessionStorage.userName);
                url = url.replace('slottype', $scope.slottype.slottype);
            }
            $http.get(url, {
                    headers: {
                        'x-api-key': sessionStorage.apikey
                    }
                })
                .success(function(data) {

                    if (data.errorMessage) {
                        $scope.isSuccess = false;
                        $scope.isFailed = true;
                        $scope.resmessage = data.errorMessage;
                        $("#showloader").css("display", "none");
                        $scope.dsReleaseGriddata.data = [];
                        $scope.dsReleaseGriddata_PH.data = [];
                        $scope.dsReleaseGriddata_SG.data = [];
                        $scope.dsReleaseGriddata_TI.data = [];
                         $scope.dsReleaseGriddata_TH.data = [];
                        $scope.resmessage = data.errorMessage;
                    } else if (data.resMessage) {
                        $scope.isSuccess = true;
                        $scope.isFailed = false;
                        $scope.dsReleaseGriddata.data = [];
                        $scope.dsReleaseGriddata_PH.data = [];
                        $scope.dsReleaseGriddata_SG.data = [];
                        $scope.dsReleaseGriddata_TI.data = [];
                        $scope.dsReleaseGriddata_TH.data = [];
                        $scope.resmessage = data.resMessage;
                        $("#showloader").css("display", "none");

                    } else if($scope.dcName == 'HongKong'){
                        $scope.dsReleaseGriddata.columnDefs = [{
                                name: 'sno',
                                displayName: 'Serial Number',                                
                                enableCellEdit: false,
                                cellTooltip: true,
                                headerTooltip: true
                            },{
                                name: 'zone',
                                displayName: 'From Zone',
                                enableCellEdit: false,
                                cellTooltip: true,
                                headerTooltip: true
                            },
                            {
                                name: 'fromLocn',
                                displayName: 'From Location',
                                enableCellEdit: false,
                                cellTooltip: true,
                                headerTooltip: true
                            },
                            {
                                name: 'displaySKU',
                                displayName: 'Display SKU',
                                enableCellEdit: false,
                                cellTooltip: true,
                                headerTooltip: true
                            },
                            {
                                name: 'actualInventory',
                                displayName: 'Actual Inventory',
                                enableCellEdit: false,
                                cellTooltip: true,
                                headerTooltip: true
                            },
                            {
                                name: 'toZone',
                                displayName: 'To Zone',
                                enableCellEdit: false,
                                cellTooltip: true,
                                headerTooltip: true
                            },
                            {
                                name: 'toLocn',
                                displayName: 'To Location',
                                width: 130,
                                enableCellEdit: false,
                                cellTooltip: true,
                                headerTooltip: true
                            },
                            {
                                name: 'division',
                                displayName: 'Division',
                                width: 120,
                                enableCellEdit: false,
                                cellTooltip: true,
                                headerTooltip: true
                            }
                        ];
                        $scope.releaseGriddata = true;
                        $scope.releaseGrid = false;
                    
                        $scope.dsReleaseGriddata.data = data;

                        if ($scope.dsReleaseGriddata.data > 10) {
                            $scope.dsReleaseGriddata.enableVerticalScrollbar = true;
                            $scope.dsReleaseGriddata.enableHorizontalScrollbar = 1;
                        } else {
                            $scope.dsReleaseGriddata.enableVerticalScrollbar = false;
                            $scope.dsReleaseGriddata.enableHorizontalScrollbar = 1;
                        }

                    } else if($scope.dcName == 'Philippines'){
                        $scope.dsReleaseGriddata_PH.columnDefs = [{
                                name: 'sno',
                                displayName: 'Serial Number',                                
                                enableCellEdit: false,
                                cellTooltip: true,
                                headerTooltip: true
                            },{
                                name: 'fromZone',
                                displayName: 'From Zone',
                                enableCellEdit: false,
                                cellTooltip: true,
                                headerTooltip: true
                            },
                            {
                                name: 'fromLocn',
                                displayName: 'From Location',
                                enableCellEdit: false,
                                cellTooltip: true,
                                headerTooltip: true
                            },
                            {
                                name: 'displaySKU',
                                displayName: 'Display SKU',
                                enableCellEdit: false,
                                cellTooltip: true,
                                headerTooltip: true
                            },
                            {
                                name: 'actualInventory',
                                displayName: 'Actual Inventory',
                                enableCellEdit: false,
                                cellTooltip: true,
                                headerTooltip: true
                            },
                            {
                                name: 'toZone',
                                displayName: 'To Zone',
                                enableCellEdit: false,
                                cellTooltip: true,
                                headerTooltip: true
                            },
                            {
                                name: 'toLocn',
                                displayName: 'To Location',
                                width: 130,
                                enableCellEdit: false,
                                cellTooltip: true,
                                headerTooltip: true
                            },
                            {
                                name: 'division',
                                displayName: 'Division',
                                width: 120,
                                enableCellEdit: false,
                                cellTooltip: true,
                                headerTooltip: true
                            }
                        ];
                        $scope.releaseGriddata = true;
                        $scope.releaseGrid = false;
                    
                        $scope.dsReleaseGriddata_PH.data = data;

                        if ($scope.dsReleaseGriddata_PH.data > 10) {
                            $scope.dsReleaseGriddata_PH.enableVerticalScrollbar = true;
                            $scope.dsReleaseGriddata_PH.enableHorizontalScrollbar = 1;
                        } else {
                            $scope.dsReleaseGriddata_PH.enableVerticalScrollbar = false;
                            $scope.dsReleaseGriddata_PH.enableHorizontalScrollbar = 1;
                        }

                    } else if($scope.dcName == 'Singapore'){
                        $scope.dsReleaseGriddata_SG.columnDefs = [{
                                name: 'sno',
                                displayName: 'Serial Number',                                
                                enableCellEdit: false,
                                cellTooltip: true,
                                headerTooltip: true
                            },{
                                name: 'fromZone',
                                displayName: 'From Zone',
                                enableCellEdit: false,
                                cellTooltip: true,
                                headerTooltip: true
                            },{
                                name: 'fromLocn',
                                displayName: 'From Location',
                                enableCellEdit: false,
                                cellTooltip: true,
                                headerTooltip: true
                            },{
                                name: 'displaySKU',
                                displayName: 'Display SKU',
                                enableCellEdit: false,
                                cellTooltip: true,
                                headerTooltip: true
                            },{
                                name: 'actualInventory',
                                displayName: 'Actual Inventory',
                                enableCellEdit: false,
                                cellTooltip: true,
                                headerTooltip: true
                            },{
                                name: 'toZone',
                                displayName: 'To Zone',
                                enableCellEdit: false,
                                cellTooltip: true,
                                headerTooltip: true
                            },{
                                name: 'toLocn',
                                displayName: 'To Location',
                                width: 130,
                                enableCellEdit: false,
                                cellTooltip: true,
                                headerTooltip: true
                            },{
                                name: 'division',
                                displayName: 'Division',
                                width: 120,
                                enableCellEdit: false,
                                cellTooltip: true,
                                headerTooltip: true
                            }
                        ];
                        $scope.releaseGriddata = true;
                        $scope.releaseGrid = false;
                    
                        $scope.dsReleaseGriddata_SG.data = data;

                        if ($scope.dsReleaseGriddata_SG.data > 10) {
                            $scope.dsReleaseGriddata_SG.enableVerticalScrollbar = true;
                            $scope.dsReleaseGriddata_SG.enableHorizontalScrollbar = 1;
                        } else {
                            $scope.dsReleaseGriddata_SG.enableVerticalScrollbar = false;
                            $scope.dsReleaseGriddata_SG.enableHorizontalScrollbar = 1;
                        }

                    } else if($scope.dcName == 'Taiwan'){
                        $scope.dsReleaseGriddata_TI.columnDefs = [{
                                name: 'sno',
                                displayName: 'Serial Number',                                
                                enableCellEdit: false,
                                cellTooltip: true,
                                headerTooltip: true
                            },{
                                name: 'zone',
                                displayName: 'From Zone',
                                enableCellEdit: false,
                                cellTooltip: true,
                                headerTooltip: true
                            },
                            {
                                name: 'fromLocn',
                                displayName: 'From Location',
                                enableCellEdit: false,
                                cellTooltip: true,
                                headerTooltip: true
                            },
                            {
                                name: 'displaySKU',
                                displayName: 'Display SKU',
                                enableCellEdit: false,
                                cellTooltip: true,
                                headerTooltip: true
                            },
                            {
                                name: 'actualInventory',
                                displayName: 'Actual Inventory',
                                enableCellEdit: false,
                                cellTooltip: true,
                                headerTooltip: true
                            },
                            {
                                name: 'toZone',
                                displayName: 'To Zone',
                                enableCellEdit: false,
                                cellTooltip: true,
                                headerTooltip: true
                            },
                            {
                                name: 'toLocn',
                                displayName: 'To Location',
                                width: 130,
                                enableCellEdit: false,
                                cellTooltip: true,
                                headerTooltip: true
                            },
                            {
                                name: 'division',
                                displayName: 'Division',
                                width: 120,
                                enableCellEdit: false,
                                cellTooltip: true,
                                headerTooltip: true
                            }
                        ];
                        $scope.releaseGriddata = true;
                        $scope.releaseGrid = false;
                    
                        $scope.dsReleaseGriddata_TI.data = data;

                        if ($scope.dsReleaseGriddata_TI.data > 10) {
                            $scope.dsReleaseGriddata_TI.enableVerticalScrollbar = true;
                            $scope.dsReleaseGriddata_TI.enableHorizontalScrollbar = 1;
                        } else {
                            $scope.dsReleaseGriddata_TI.enableVerticalScrollbar = false;
                            $scope.dsReleaseGriddata_TI.enableHorizontalScrollbar = 1;
                        }

                    }else if($scope.dcName == 'Thailand'){
                        $scope.dsReleaseGriddata_TH.columnDefs = [{
                                name: 'sno',
                                displayName: 'Serial Number',                                
                                enableCellEdit: false,
                                cellTooltip: true,
                                headerTooltip: true
                            },{
                                name: 'fromZone',
                                displayName: 'From Zone',
                                enableCellEdit: false,
                                cellTooltip: true,
                                headerTooltip: true
                            },
                            {
                                name: 'fromLocn',
                                displayName: 'From Location',
                                enableCellEdit: false,
                                cellTooltip: true,
                                headerTooltip: true
                            },
                            {
                                name: 'displaySKU',
                                displayName: 'Display SKU',
                                enableCellEdit: false,
                                cellTooltip: true,
                                headerTooltip: true
                            },
                            {
                                name: 'actualInventory',
                                displayName: 'Actual Inventory',
                                enableCellEdit: false,
                                cellTooltip: true,
                                headerTooltip: true
                            },
                            {
                                name: 'toZone',
                                displayName: 'To Zone',
                                enableCellEdit: false,
                                cellTooltip: true,
                                headerTooltip: true
                            },
                            {
                                name: 'toLocn',
                                displayName: 'To Location',
                                width: 130,
                                enableCellEdit: false,
                                cellTooltip: true,
                                headerTooltip: true
                            },
                            {
                                name: 'division',
                                displayName: 'Division',
                                width: 120,
                                enableCellEdit: false,
                                cellTooltip: true,
                                headerTooltip: true
                            }
                        ];
                        $scope.releaseGriddata = true;
                        $scope.releaseGrid = false;
                    
                        $scope.dsReleaseGriddata_TH.data = data;

                        if ($scope.dsReleaseGriddata_TH.data > 10) {
                            $scope.dsReleaseGriddata_TH.enableVerticalScrollbar = true;
                            $scope.dsReleaseGriddata_TH.enableHorizontalScrollbar = 1;
                        } else {
                            $scope.dsReleaseGriddata_TH.enableVerticalScrollbar = false;
                            $scope.dsReleaseGriddata_TH.enableHorizontalScrollbar = 1;
                        }

                    }

                    $('.ui-grid-pager-control input').prop("disabled", true);
                    $(document).on("click", ".ui-grid-menu-button", function() {
                        $timeout(function() {
                            $('.fa-download').remove();
                            $('#menuitem-7 button[type="button"]').prepend('<i class="fa fa-download" aria-hidden="true" style="color: #c9c9c9;"></i>');
                        })
                        $timeout(function() {
                            console.clear();
                        }, 3000)
                    });
                    $("#showloader").css("display", "none");

                });
            $(document).on('click', 'body', function() {
                $timeout(function() {
                    console.clear();
                }, 1000);

            }).error(function(data) {
                $scope.isSuccess = false;
                $scope.isFailed = true;
                $scope.resmessage = data;
                $("#showloader").css("display", "none");
            })
        } else if (type == 'release') {

            var url = $scope.slottype.slottype == 'Deslot' ? urlService.DESLOT_RELEASE_SZ : urlService.NEW_SLOT_RELEASE_SZ;

            var data = {
                "dcName": $scope.dcName,
                "userName": sessionStorage.userName,
                "templateId": 80,
                "workType": $scope.slottype.slottype
            }
            $http.post(urlService.DESLOT_RELEASE_SZ, data, {
                    headers: {
                        'x-api-key': sessionStorage.apikey
                    }
                })
                .success(function(data) {
                    if (data.errorMessage) {
                        $("#showloader").css("display", "none");
                        $scope.isSuccess = false;
                        $scope.isFailed = true;
                        $scope.resmessage = data.errorMessage;
                    } else if (data.resMessage) {
                        $scope.resmessage = data.resMessage;
                        $scope.goBack('release');

                        $timeout(function() {

                            $scope.isSuccess = true;
                            $scope.isFailed = false;
                            $("#showloader").css("display", "none");
                        }, 2000);
                    } else {
                        $scope.resmessage = data.resMessage;
                        $scope.goBack('release');

                        $timeout(function() {

                            $scope.isSuccess = true;
                            $scope.isFailed = false;
                            $("#showloader").css("display", "none");
                        }, 2000);
                    }
                }).error(function(data) {
                    $("#showloader").css("display", "none");
                    $scope.isSuccess = false;
                    $scope.isFailed = true;
                    $scope.resmessage = data.errorMessage;
                })
        } else if (type == 'reset') {
            var url = urlService.RUN_A_SLOT_SZ.replace('dName', $scope.dcName).replace('uName', sessionStorage.userName);

            $http.get(url, {
                headers: {}
            }).success(function(data) {

                if (data.errorMessage) {
                    $scope.isSuccess = false;
                    $scope.isFailed = true;
                    $("#showloader").css("display", "none");
                    $scope.resmessage = data.errorMessage;
                } else if (data.resMessage) {
                    $scope.isSuccess = true;
                    $scope.isFailed = false;
                    $scope.resmessage = data.resMessage;
                    $("#showloader").css("display", "none");

                } else {
                    $scope.isSuccess = true;
                    $scope.isFailed = false;
                    $("#showloader").css("display", "none");
                }
            }).error(function(data) {
                $scope.isSuccess = false;
                $scope.isFailed = true;
                $scope.resmessage = data.errorMessage;
                $("#showloader").css("display", "none");
            })
        }
    }

    $scope.releaseGrid = true;
    $scope.resetRelase = function() {
        $scope.isSuccess = false;
        $scope.isFailed = false;
        $scope.slottype.slottype = 'Deslot';
        $scope.releaseGriddata = false;
        $scope.releaseGrid = true;
    }
    //user favourites code start
    $scope.isClicked = false;

    $scope.addToFavourate = function(isClicked) {
        $("#showloader").css("display", "block");
        if (typeof isClicked !== "boolean") {
            commonService.postServiceResponse(urlService.GET_FAVOURITES, {
                    "username": sessionStorage.userName
                })
                .then(function(response) {
                    $("#showloader").css("display", "none");
                    _.each(response, function(val, key) {
                        if (val.funName == $scope.functionality && val.dcName == $scope.dcName) {
                            $scope.isClicked = true;
                        }
                    })
                }, function(error) {
                    $("#showloader").css("display", "none");
                    $scope.isClicked = false;
                });
            //$scope.isClicked = ;
        } else {
            if (!$scope.isClicked) {
                commonService.postServiceResponse(urlService.ADD_FAVOURITE, {
                        "username": sessionStorage.userName,
                        "dcName": $scope.dcName,
                        "funName": $scope.functionality
                    })
                    .then(function(response) {
                        $("#showloader").css("display", "none");
                        if (response.errorMessage) {
                            $scope.isFavouriteAdded = false;
                            $scope.isClicked = false;
                            $scope.$broadcast('showAlert', ['']);
                        } else {
                            $scope.isClicked = true;
                            $scope.isClicked = !isClicked;
                            $scope.isFavouriteAdded = true;
                            $scope.favouriteMsg = response.resMessage;
                            $scope.$broadcast('ClickedOnFavourate', [$scope.dcName, $scope.functionality, $scope.isClicked]);
                        }

                    }, function(error) {
                        $scope.isClicked = false;
                        $("#showloader").css("display", "none");
                    });
                $scope.isClicked = !isClicked;
            } else {
                $("#showloader").css("display", "none");
            }
        }

    }
    $scope.addToFavourate('load');
    //user favourites code ends
}]);