var app = angular.module('STOLabelCreator');

app.controller('STOLabelCreatorController', ['$scope', '$http', '$q', '$interval', '$timeout','urlService','uiGridConstants','commonService', function ($scope, $http, $q, $interval, $timeout,urlService,uiGridConstants,commonService) {
  $scope.isSuccess = false;
  $scope.isFailed = false;
  $scope.disable = true;
  $scope.pagefunctionality = $scope.functionality;
  $scope.pagedc = $scope.dcName;
$("#carton-barcode").focus();
  $("#showloader").css("display", "none");
  /*var dp = {};
 if(JSON.parse(sessionStorage.loginData)){
 	$scope.printer = JSON.parse(sessionStorage.loginData).defaultPrinter.trim();
	dp.printerId = JSON.parse(sessionStorage.loginData).defaultPrinterId;
	dp.printerIp = JSON.parse(sessionStorage.loginData).defaultPrinter;
	dp.printerName = JSON.parse(sessionStorage.loginData).defaultPrinterName;
	$scope.printerPort = JSON.parse(sessionStorage.loginData).defaultPrinterPort;

 }  
	
	$scope.getPrinters = function(){
		var url = urlService.GET_PRINTER_LIST.replace("dName",$scope.pagedc);
		var res = $http.get(url, {
			//headers: {'x-api-key': sessionStorage.apikey} 
		});

		res.success(function (response, status, headers, config) {
			if (response.errorMessage) {
				$scope.isFailed = true;
				$scope.resmessage = data.errorMessage;
	  		}else if(response.length > 0){ 
				//response.unshift(dp);
				response = JSON.parse(JSON.stringify(response));
				$scope.printers = response;
				$scope.printer ? $scope.printer : ($scope.printer = response[0].printerIp);
				//$scope.printerPort ? $scope.printerPort : ($scope.printerPort = response[0].printerPort);
			}else{
				//$scope.printers = [dp];	
			}
		});
		res.error(function (responce, status, headers, config) {
			$scope.isFailed = true;
			$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
		});  
	}
	$scope.getPrinters();*/

      /** This function is used to get the printers based on the dc name  **/
  $scope.getdefaultPrinter = function(){
    var url = urlService.DEFAULT_PRINTERS.replace("dName",$scope.pagedc);
    url = url.replace('uName',sessionStorage.userName);
    var res = $http.get(url, {
     // headers: {'x-api-key': sessionStorage.apikey} 
    });

    res.success(function (data, status, headers, config) {
      if (data.errorMessage) {
       // $scope.isFailed = true;
       // $scope.resmessage = data.errorMessage;
		 $scope.getPrinterList();
        }else if(data.resMessage){
         // $scope.isSuccess = true;
        //  $scope.resmessage = data.resMessage;
		   $scope.getPrinterList();
        }else{
          $scope.defaultprinter = data;
        $scope.printerip = data[0].printerIp;
        $scope.getPrinterList();
        }
    });
    res.error(function (data, status, headers, config) {
     // $scope.isFailed = true;
     // $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
	$scope.getPrinterList();

    });  
  };
  $scope.getdefaultPrinter();

  $scope.getPrinterList = function(){
    var url = urlService.PRINTER_LIST.replace("dName",$scope.pagedc);
    url = url.replace('uName',sessionStorage.userName);
    var res = $http.get(url, {
      //headers: {'x-api-key': sessionStorage.apikey} 
    });

    res.success(function (data, status, headers, config) {
      if (data.errorMessage) {
        $scope.isFailed = true;
        $scope.resmessage = data.errorMessage;
        }else if(data.resMessage){
          $scope.isSuccess = true;
          $scope.resmessage = data.resMessage;
        }else{
          $scope.printerslist = data;
          
          for (var i = 0; i < $scope.printerslist.length; i++) {
            if($scope.printerip){
              if ($scope.printerslist[i].printerIp == $scope.printerip) {
                $scope.printer = $scope.printerslist[i];
                break;
              }
            }else{
              $scope.printer = $scope.printerslist[0];
            }
          }
        }
    });
    res.error(function (responce, status, headers, config) {
      $scope.isFailed = true;
      $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
    });  
  };



/**
	This function is used to clear the success/ failure mesages, as well as enable/ disable the button based on the condition
**/
  $scope.checkCartonBarCode = function(){
	   $scope.isSuccess = false;
	 $scope.isFailed = false;
	  if($scope.cartonBarCode && $scope.printer){
		$scope.disable = false;  
	  }else{
		  $scope.disable = true;
	  }
  };


/**
	This function is used to call, when user press Enter button from the keyboard
**/
  $('#carton-barcode').keyup(function (e){
    if($scope.cartonBarCode && $scope.printer && e.keyCode == 13){
	$scope.disable = false;
        $scope.printSTOLabelCreator();
    }
  });
  /**
	This function is used to print by sending the required data to backend
**/
  $scope.printSTOLabelCreator = function(){
	//console.log($scope.cartonBarCode);
	$scope.isSuccess = false;
	  $scope.isFailed = false;
	$("#showloader").css("display", "block");
	var payload = {
		"printerIp":$scope.printer.printerIp,
		"printerPort":$scope.printer.printerPort,
		"cartonNumber":$scope.cartonBarCode,
		"dcName":$scope.pagedc,
		"userName":sessionStorage.userName
	};
	var res = $http.post(urlService.STO_LABEL_PRINT,payload, {
		headers: {'x-api-key': sessionStorage.apikey} 
	});
	res.success(function (data, status, headers, config) {
	  $("#showloader").css("display", "none");
	  if (data.errorMessage) {
		
		$scope.isFailed = true;
		$scope.resmessage = data.errorMessage;
	  } else {
		$scope.cartonBarCode = "";
		$("#carton-barcode").focus();
		$scope.isSuccess = true;
		$scope.resmessage =data.resMessage;		
	  }
	});
	res.error(function (data, status, headers, config) {
	  $("#showloader").css("display", "none");
		$scope.isFailed = true;
		$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
	});
  };
//user favourites code start
$scope.isClicked = false;

$scope.addToFavourate = function(isClicked){
    $("#showloader").css("display", "block");
     if(typeof isClicked !== "boolean"){
      commonService.postServiceResponse(urlService.GET_FAVOURITES,{"username": sessionStorage.userName})
        .then(function(response){
          $("#showloader").css("display", "none");
            _.each(response,function(val,key){
              if(val.funName == $scope.functionality && val.dcName == $scope.dcName){
                $scope.isClicked = true;      
              }
            });
        },function(error){
          $("#showloader").css("display", "none");
          $scope.isClicked = false; 
        });
        //$scope.isClicked = ;
     }else{
      if(!$scope.isClicked){
        commonService.postServiceResponse(urlService.ADD_FAVOURITE,{"username": sessionStorage.userName,"dcName":$scope.dcName,"funName":$scope.functionality})
        .then(function(response){
          $("#showloader").css("display", "none");
          if(response.errorMessage){
            $scope.isFavouriteAdded= false; 
            $scope.isClicked = false;      
            $scope.$broadcast('showAlert',['']);
          }else{
            $scope.isClicked = true;      
            $scope.isClicked = !isClicked;
            $scope.isFavouriteAdded= true; 
            $scope.favouriteMsg = response.resMessage;
          $scope.$broadcast('ClickedOnFavourate',[$scope.dcName,$scope.functionality,$scope.isClicked]);
          }
            
        },function(error){
          $scope.isClicked = false;
          $("#showloader").css("display", "none");
        });
        $scope.isClicked = !isClicked;
      }else{
        $("#showloader").css("display", "none");
      }
     }
    
  };
  $scope.addToFavourate('load');
  //user favourites code ends

}]);


