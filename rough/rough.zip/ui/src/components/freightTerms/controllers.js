var app = angular.module('FreightTerms');

app.controller('FreightTermsController', ['$scope', '$http', '$q', '$interval', '$timeout', 'urlService', 'uiGridConstants', 'commonService', function($scope, $http, $q, $interval, $timeout, urlService, uiGridConstants, commonService) {
    $scope.showDNNumbers = true;
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $scope.disable = true;
    $scope.pagefunctionality = $scope.functionality;
    $scope.pagedc = $scope.dcName;
    $scope.billingNumber = true;
    $scope.billingMethod = false;
    $scope.taskval = 'BN';
	$scope.updatefreight=false;


    /**
  This function is used to change the disable value to false. Based on this update button will enable.
  **/
    $scope.validateorderNbr = function(taskval) {
        $scope.disable = false;
        $scope.resmessage = "";

        var reg = /^[0-9\_ ]+$/;

        if (taskval == "BN") {
            if ($scope.orderNbr == "" || $scope.orderNbr == undefined || $scope.billAccountNbr == "") {

                $scope.disable = true;
            }
        }
        if (taskval == 'BM') {
            if ($scope.orderNbr == "" || $scope.orderNbr == undefined || $scope.codedescription == "CODEID | Description") {
                $scope.disable = true;
            }
            // return false;
        }
		
		 if (taskval == 'UF') {
            if ($scope.freightNbr == "" || $scope.freightNbr == undefined || $scope.shipmentNbr == ""||$scope.shipmentNbr == undefined) {
                $scope.disable = true;
            }
            // return false;
        }
    };




    $scope.task = function(taskval) {
        $scope.taskval = taskval;


        if ($scope.taskval == "BN" && $scope.pagedc == 'BDC') {
            $scope.billingNumber = true;
            $scope.billingMethod = false;
			$scope.updatefreight=false;
        }
        else if ($scope.taskval == "BM" && $scope.pagedc == 'BDC') {
            $scope.billingNumber = false;
            $scope.billingMethod = true;
			$scope.updatefreight=false;
        }else if ($scope.taskval == "UF" && $scope.pagedc == 'BDC') {
            $scope.billingNumber = false;
            $scope.billingMethod = false;
			$scope.updatefreight=true;
        }
    };

    $scope.getCodeDescription = function() {
        //$scope.isSuccess = false;
        $scope.isFailed = false;
        $("#showloader").css("display", "block");
        var url = urlService.GET_ALL_CODE_DESCRIPTION.replace('dName', $scope.dcName);//$scope.dcName
        url = url.replace('uName', sessionStorage.userName);

        var res = $http.get(url, {
            headers: { 'x-api-key': sessionStorage.apikey }
        });

        res.success(function(data, status, headers, config) {
            console.log(JSON.stringify(data));//pradeep
            if (data.errorMessage) {
                $scope.isFailed = true;
                $scope.resmessage = data.errorMessage;
                $("#showloader").css("display", "none");
            } else if (data.length > 0) {
                $scope.allCodeDescription = data;
                $scope.allCodeDescription.unshift("CODEID | Description");
                $scope.codedescription = $scope.allCodeDescription[0];//data[0];

                $("#showloader").css("display", "none");
            }
        });
        res.error(function(data, status, headers, config) {
            $("#showloader").css("display", "none");
            $scope.isFailed = true;
            $scope.resmessage = "System failed. Please try again or contact WAALOS Support";

        });
    };
    $scope.getCodeDescription();

    $scope.selectCodeDescription = function() {

        if ($scope.codedescription == 'CODEID | Description' && $scope.orderNbr != "" || $scope.orderNbr == undefined) {
            $scope.disable = true;
        }
        else {
            $scope.disable = false;
        }

    };

    /** This function is used to update the FreightTerms **/
    $scope.updateFreightTerms = function() {
        $scope.isSuccess = false;
        $scope.isFailed = false;
		
		if($scope.taskval == 'UF')
		{
			$scope.orderNbr=$scope.shipmentNbr;
			$scope.billAccountNbr=$scope.freightNbr;
		}

        var newStr = [];
        var str_array = ($scope.orderNbr.trim().replace(/\n/g, ",")).replace(/,+/g, ',').replace(/(^\s*,)|( ,\s*$)/g, '');
        var lastChar = str_array[str_array.length - 1];
        if (lastChar == ",") {
            newStr = str_array.substring(0, str_array.length - 1);
        } else {
            newStr = str_array;
        }
        if ((newStr.match(/,/g) || []).length > 99) {
            $scope.isFailed = true;
            $scope.resmessage = "Maximum 100 orders are allowed";
            return false;
        }
        newStr = newStr.split(",");
        newStr = newStr.filter(function(str) {//used to remove the empty spaces(like empty value)
            return /\S/.test(str);
        });
        $scope.ord = [];
        newStr.map(function(el) {//used to clear the spaces of each array element
            $scope.ord.push(el.trim());
        });


        $("#showloader").css("display", "block");
        var payload = {
            "action": $scope.taskval,
            "orders": $scope.ord,
            "dcName": $scope.pagedc,
            "userName": sessionStorage.userName,
            "billAccountNbr": $scope.billAccountNbr,
            "codeDescription": $scope.codedescription
        };
        var res = $http.put(urlService.UPDATE_FREIGHT_TERMS, payload, {
            headers: { 'x-api-key': sessionStorage.apikey }
        });
        res.success(function(data, status, headers, config) {
            $("#showloader").css("display", "none");
            if (data.errorMessage) {
                $scope.isFailed = true;
                $scope.resmessage = data.errorMessage;
            } else {
                $scope.isSuccess = true;
                $scope.resmessage = data.resMessage;
            }
        });
        res.error(function(data, status, headers, config) {
            $("#showloader").css("display", "none");
            $scope.isFailed = true;
            $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
        });
    };



    //user favourites code starts
    $scope.isClicked = false;
    $scope.addToFavourate = function(isClicked) {
        $("#showloader").css("display", "block");
        if (typeof isClicked !== "boolean") {
            commonService.postServiceResponse(urlService.GET_FAVOURITES, { "username": sessionStorage.userName })
                .then(function(response) {
                    $("#showloader").css("display", "none");
                    _.each(response, function(val, key) {
                        if (val.funName == $scope.functionality && val.dcName == $scope.dcName) {
                            $scope.isClicked = true;
                        }
                    });
                }, function(error) {
                    $("#showloader").css("display", "none");
                    $scope.isClicked = false;
                });
            //$scope.isClicked = ;
        } else {
            if (!$scope.isClicked) {
                commonService.postServiceResponse(urlService.ADD_FAVOURITE, { "username": sessionStorage.userName, "dcName": $scope.dcName, "funName": $scope.functionality })
                    .then(function(response) {
                        $("#showloader").css("display", "none");
                        if (response.errorMessage) {
                            $scope.isFavouriteAdded = false;
                            $scope.isClicked = false;
                            $scope.$broadcast('showAlert', ['']);
                        } else {
                            $scope.isClicked = true;
                            $scope.isClicked = !isClicked;
                            $scope.isFavouriteAdded = true;
                            $scope.favouriteMsg = response.resMessage;
                            $scope.$broadcast('ClickedOnFavourate', [$scope.dcName, $scope.functionality, $scope.isClicked]);
                        }

                    }, function(error) {
                        $scope.isClicked = false;
                        $("#showloader").css("display", "none");
                    });
                $scope.isClicked = !isClicked;
            } else {
                $("#showloader").css("display", "none");
            }
        }

    };
    $scope.addToFavourate('load');
    //user favourites code ends		




}]);