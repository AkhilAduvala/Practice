var app = angular.module('AutomatedSlotting', ['ui.bootstrap', 'ngTouch', 'ui.grid', 'ui.grid.selection', 'ui.grid.edit', 'ui.grid.autoResize', 'ui.grid.validate', 'ui.grid.exporter']);
app.directive('numbersOnly', function() {
    return {
        require: 'ngModel',
        link: function(scope, element, attr, ngModelCtrl) {
            function fromUser(text) {
                if (text) {
                    var transformedInput = text.replace(/[^0-9]/g, '');

                    if (transformedInput !== text) {
                        ngModelCtrl.$setViewValue(transformedInput);
                        ngModelCtrl.$render();
                    }
                    return transformedInput;
                }
                return undefined;
            }
            ngModelCtrl.$parsers.push(fromUser);
        }
    };
});

app.controller('AutomatedSlottingCtrl', ['$scope', '$http', '$q', '$interval', '$timeout', 'urlService', 'uiGridConstants', 'commonService', function($scope, $http, $q, $interval, $timeout, urlService, uiGridConstants, commonService) {
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $scope.isEdit = true;
    $scope.isDelete = true;
    $scope.isDeleted = false;
    $scope.isEditdataSources = false;
    $scope.isEditSlotGroup = false;
    $scope.isTablerptkrl = false;
    $scope.pagefunctionality = $scope.functionality;
    $scope.pagedc = $scope.dcName;
    $scope.isLowerGrid = false;
    $scope.reqExchangeDto = [];
    $scope.resmessage_runaslot = '';
    $scope.values = {
        "grpName": '',
        "forFileLocn": '',
        "orderFuture": '',
        "orderPast": '',
        "asnFuture": '',
        "asnPast": '',
        "forcastfile": '',
        "filetype": '',
        "int2remove": '',
        "openOrder": '',
        "orderStateCode": '',
        "orderMinStatCode": '',
        "asnInfoLst": '',
        "useAsns": '',
        "volOrFix": '',
        "fixedCase": '',
        "maxAllowed": '',
        "skuMovement": '',
        "skumovesvalue": '',
        "groupPriority": '',
        "slotType": '',
        "zoneType": '',
        "slottingType": '',
        "slotTypeReg": '',
        "kitType": '',
        "userType": '',
        "daysTillSlot": '',
        "deslotToRevVal": '',
        "intraZone": '',
        "reslotZone": '',
        "reslotZonesGroup": '',
        "reslotZoneIndex": '',
        "reslotZoneIndex_1": '',
        'zoneTypeIndex': '',
        "releaseData": '',
        "newLogicals": '',
        "dspNumber": ''

    };

    $scope.isDatarelease = false;
    $scope.slottingsetupNameFlag = false;
    $scope.forcastFileLocationFlag = false;
    $scope.orderFutureFlag = false;
    $scope.orderPastFlag = false;
    $scope.asnFutureFlag = false;
    $scope.asnPastFlag = false;
    $scope.zonesGridData = [];
    //$scope.values.volOrFix = false;
    //$scope.values.volOrFix = 'Fixed';
     $scope.values.reslotZones = "";
     $scope.values.reslotZoneIndex = "";
     $scope.values.volOrFix = null;
     $scope.values.fixedCase = "";
	 $scope.priorityGridData = [];

    $scope.gridOptionsLower = {
        enableColumnMenus: false,
        exporterMenuCsv: false,
        exporterMenuPdf: false,
        enableGridMenu: true,
        exporterExcelSheetName: 'Sheet1',
        exporterExcelFilename: 'DisplaySKU_list.xlsx',
        gridMenuShowHideColumns: false,
        exporterMenuVisibleData: false,
        enableSorting: true,
    };


    $scope.gridOptionsLowerSearch = {
        enableColumnMenus: false,
        enableSorting: true,
    };



    $scope.gridOptions = {
        enableColumnMenus: false,
        enableSorting: true,
        multiSelect: false,
        enableRowSelection: true, //we can remove it later no use  of this
        enableSelectAll: true, //we can remove it later no use  of this             
        enableCellEdit: false, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
        enableCellEditOnFocus: true // set any editable column to allow edit on focus
    };

	$scope.dsReleaseGriddata = {
        enableColumnMenus: false,
        enableSorting: true,
        exporterMenuCsv: false,
        exporterMenuPdf: false,
        enableGridMenu: true,
        exporterExcelFilename: 'SZReleaseTask.xlsx',
        exporterExcelSheetName: 'Sheet1',
        gridMenuShowHideColumns: false,
        paginationPageSizes: [15, 25, 50, 100],
        paginationPageSize: 15,
        exporterMenuVisibleData: false,
        enableRowSelection: false, //we can remove it later no use  of this
        enableSelectAll: false, //we can remove it later no use  of this             
        enableCellEdit: false, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
        enableCellEditOnFocus: true // set any editable column to allow edit on focus

    }
    $scope.dsReleaseGriddata.onRegisterApi = function(gridApi) {
        $scope.gridApi = gridApi;

        $scope.gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
            $scope.pageNo =  newPage;
            $scope.pageSize = pageSize;
        });
    };
    /*    $scope.gridOptions.onRegisterApi = function(gridApi) {
            //set gridApi on scope
            $scope.gridApi = gridApi;


            gridApi.selection.on.rowSelectionChanged($scope, function(rows) {
                $scope.isSuccess = false;
                $scope.isFailed = false;

                if ($scope.gridApi.selection.getSelectedRows().length > 0) {
                    $scope.isEdit = false;
                    $scope.isDelete = false;
                } else {
                    $scope.isEdit = true;
                    $scope.isDelete = true;

                }
            });
        };*/

    //sloting group

    $scope.gridOptionsSlotgroup = {
        enableColumnMenus: false,
        enableSorting: true,
        multiSelect: false,
        enableRowSelection: true, //we can remove it later no use  of this
        enableSelectAll: true, //we can remove it later no use  of this             
        enableCellEdit: false, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
        enableCellEditOnFocus: true // set any editable column to allow edit on focus
    };

    $scope.gridOptionsSlotgroup.onRegisterApi = function(gridApi) {
        //set gridApi on scope
        $scope.gridApi = gridApi;

        gridApi.selection.on.rowSelectionChanged($scope, function(row) {
            $scope.isSuccesszone = false;
            $scope.isFailedzone = false;
            $scope.selectedRowToSlotEdit = {
                "slotGrp": row.entity.grpAttr,
                "dcName": $scope.pagedc,
                "userName": sessionStorage.userName,
                "colRules": row.entity.hasRules
            };

            if (row.isSelected) {
                $scope.isEdit = false;
            } else {
                $scope.isEdit = true;
            }
        });

    };


    //get data source

    $scope.gridOptionsDataSource = {
        enableColumnMenus: false,
        enableSorting: true,
        multiSelect: false,
        enableRowSelection: true, //we can remove it later no use  of this
        enableSelectAll: true, //we can remove it later no use  of this             
        enableCellEdit: false, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
        enableCellEditOnFocus: true, // set any editable column to allow edit on focus
        cellEditableCondition: function($scope) {
            debugger;
            if ($scope.row.entity.hasAssoc == "Y") {
                $scope.releaseTaskbutton = true;
            } else {
                $scope.releaseTaskbutton = false;
            }
        }

    };


    $scope.gridOptionsDataSource.onRegisterApi = function(gridApi) {
        //set gridApi on scope
        $scope.gridApi = gridApi;
        $scope.isSuccess = false;
        $scope.isFailed = false;
        gridApi.selection.on.rowSelectionChanged($scope, function(row) {

            $scope.selectedRowSourcedata = {
                "grptype": row.entity.grpType,
                "dcName": $scope.pagedc,
                "userName": sessionStorage.userName
            };
            if (row.isSelected) {
                $scope.isEdit = false;
                $scope.isDelete = false;
            } else {
                $scope.isEdit = true;
                $scope.isDelete = true;
            }
        });
    };


    $scope.gridOptionsDataSource.isRowSelectable = function(row) {
        
    };


    // SKU Exclusion
    $scope.gridOptionsSku = {
        enableColumnMenus: false,
        enableSorting: true,
        multiSelect: false,
        exporterMenuCsv: false,
        exporterMenuPdf: false,
        enableGridMenu: true,
        exporterExcelSheetName: 'Sheet1',
        exporterExcelFilename: 'Dsiplay_SKU.xlsx',
        gridMenuShowHideColumns: false,
        exporterMenuVisibleData: false,
        enableVerticalScrollbar: false,
        enableRowSelection: true, //we can remove it later no use  of this
        enableSelectAll: true, //we can remove it later no use  of this             
        enableCellEdit: false, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
        enableCellEditOnFocus: true // set any editable column to allow edit on focus
    };


    $scope.gridOptionsSku.onRegisterApi = function(gridApi) {
        //set gridApi on scope
        $scope.gridApi = gridApi;
        $scope.isSuccess = false;
        $scope.isFailed = false;
        gridApi.selection.on.rowSelectionChanged($scope, function(row) {

            $scope.selectedRowdspSKU = {
                "dspsku": row.entity.dspSku,
                "dcName": $scope.pagedc,
                "userName": sessionStorage.userName
            };
            if (row.isSelected) {

                $scope.isDeleted = false;
            } else {

                $scope.isDeleted = true;
            }
        });
    };


    //Zone options

    $scope.gridOptionsZone = {
        enableColumnMenus: false,
        enableSorting: true,
        multiSelect: false,
        enableHorizontalScrollbar: true,
        enableRowSelection: true, //we can remove it later no use  of this
        enableSelectAll: true, //we can remove it later no use  of this             
        enableCellEdit: false, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
        enableCellEditOnFocus: true // set any editable column to allow edit on focus
    };
    $scope.gridOptionsZone.onRegisterApi = function(gridApi) {
        //set gridApi on scope

        $scope.gridApi = gridApi;

        $scope.isSuccesszone = false;
        $scope.isFailedzone = false;


        gridApi.selection.on.rowSelectionChanged($scope, function(row) {
            $scope.isSuccesszone = false;
            $scope.isFailedzone = false;
            $scope.selectedRowToDelete = {
                "zoneId": row.entity.zone,
                "hasWorkGrpAssociation": row.entity.hasWorkGrpAssociation,
                "dcName": $scope.pagedc,
                "userName": sessionStorage.userName
            };
            if (row.isSelected) {
                $scope.isDeleteZone = false;
            } else {
                $scope.isDeleteZone = true;
            }
        });

    };


    //Zone prob type options zone

    $scope.gridOptionsZoneProb = {
        enableColumnMenus: false,
        enableCellEdit: true,
        enableSorting: true,
        multiSelect: true,
        enableRowSelection: true, //we can remove it later no use  of this
        enableSelectAll: true, //we can remove it later no use  of this   
        enableVerticalScrollbar: false
    };
    $scope.gridOptionsZoneProb.onRegisterApi = function(gridApi) {

        $scope.gridApi = gridApi;

        $scope.isSuccessprob = false;
        $scope.isFailedprob = false;

        gridApi.selection.on.rowSelectionChanged($scope, function(row) {
            $scope.isSuccessprob = false;
            $scope.isFailedprob = false;

            if ($scope.gridApi.selection.getSelectedRows().length > 0) {

                $scope.isSaveProb = false;
            } else {
                $scope.isSaveProb = true;
            }


        });

        gridApi.selection.on.rowSelectionChangedBatch($scope, function(rows) {
            $scope.isSuccessprob = false;
            $scope.isFailedprob = false;
            if ($scope.gridApi.selection.getSelectedRows().length > 0) {

                $scope.isSaveProb = false;
            } else {
                $scope.isSaveProb = true;
            }
        });

        gridApi.edit.on.afterCellEdit($scope, function(rowEntity, colDef, newValue, oldValue) {

            if (newValue != oldValue || newValue !== oldValue) { // To check old and new values same or not
                if (newValue == "") {

                } else if (+(newValue) == oldValue) {

                } else {
                    $scope.gridApi.selection.selectRow(rowEntity);
                }
            }
        });
    };

    var fileInput = document.getElementById("uploadFile");

    $scope.uploadchange = function(evt){
        
        if (evt.value.length == 0) {


        } else {

            $scope.excelErrors = false;
            $scope.isFailedload = false;
            $scope.excelReadErrors = false;
            $scope.isFailed = false;
            document.getElementById('list').innerHTML = '';
            document.getElementById('nextStep').innerHTML = '';
            $scope.errorMessagesArray = [];

            fileExtension = evt.value.substr((evt.value.lastIndexOf('.') + 1));

            if (fileExtension == "xls") {
                $scope.isFailed = true;
                $scope.resmessage = "Please save this xls file into xlsx format and try again to Choose File";
                return false;
            }


            if (evt.value.indexOf(".xlsx") < 0) {
                $scope.isFailed = true;
                $scope.resmessage = "Please choose only XLSX file";
                return false;
            }


            var dcName = $scope.dcName;
            var userName = sessionStorage.userName;
            var files = evt.files;
            var fileval = $("input[type='file']").val();
            var output = [];
            if (fileval == '' || fileval == undefined || fileval == null) {
                document.getElementById('list').innerHTML = '';
                document.getElementById('nextStep').innerHTML = '';
                $scope.disable = false;
            } else {
                $("#showloader").css("display", "block");
                var uploadUrl = urlService.ATE_SLOTTING_UPLD_FRCST;
                for (var i = 0, f; f = files[i]; i++) {
                    output.push('<li><strong>', escape(f.name), '</strong> was choosen successfully</li>');
                    localStorage.setItem("choosenFile", files[i]);
                    var file = files[i];
                    var fd = new FormData();
                    fd.append('dcName', dcName);
                    fd.append('userName', userName);
                    fd.append('grpType', 96);
                    fd.append('file', file);
                    if (files[i].size < 1024 * 1024 * 10) {
                        $http.post(uploadUrl, fd, {
                            transformRequest: angular.identity,
                            headers: { 'Content-Type': undefined,'x-api-key': sessionStorage.apikey }
                        })

                            .success(function (response) {
                                if (response.lotId) {
                                    
                                    $scope.lotId = response.lotId;
                                    if (response.totalCount === response.errorCount) {
                                        $scope.disableDownload = false;
                                        $scope.disable = true;
                                        document.getElementById('nextStep').innerHTML = response.errorCount + ' ' + 'Out of' + ' ' + response.totalCount + ' ' + 'records are invalid';
                                        $scope.errorMessagesArray = response.errorDtoLst;
                                        $("#showloader").css("display", "none");
                                        $scope.dataSources();
                                    } else {
                                        if(response.errorCount === 0){$scope.disableDownload = true;}else{$scope.disableDownload = false;}
                                        $scope.disable = false;
                                        document.getElementById('list').innerHTML = response.successCount + ' ' + 'Out of' + ' ' + response.totalCount + ' ' + 'records are valid';
                                        $scope.errorMessagesArray = response.errorDtoLst;
                                        $("#showloader").css("display", "none");
                                        $scope.dataSources();
                                    }
                                } else if (response.errorMessage) {
                                    $scope.disableDownload = true;
                                    $scope.disable = true;
                                    $scope.excelReadErrors = true;
                                    $scope.excelReadError = response;

                                    $("#showloader").css("display", "none");
                                } else {

                                    $scope.disable = true;
                                    $scope.excelErrorsData = response;
                                    $scope.excelErrors = true;
                                    $("#showloader").css("display", "none");

                                }
                            })
                            .error(function (err) {
                                $("#showloader").css("display", "none");
                                $scope.isFailedload = true;
                                $scope.errorMessagesArray = [];
                            });
                    } else {
                        $("#showloader").css("display", "none");
                        $scope.isFailed = true;
                        $scope.resmessage = "File size should not exceed 10MB";
                        $scope.errorMessagesArray = [];
                    }

                }
            }
        }
    };

    $scope.uploadclick =  function(){ 

        var input = document.getElementById("uploadFile");

        if (input.value.length == 0) {

        } else if (input.value.length > 0) {
            input.value = null;
            input.value = '';
            input.type = '';
            input.type = 'file';
            document.getElementById("uploadFile").value = null;
        }
    }

    //Get Data Source
    $scope.dataSources = function() {
        $scope.isSuccess = false;
        $scope.isFailed = false;
        $scope.isEdit = true;
        $scope.isDelete = true;
        $scope.isMianpage = true;
        $scope.isEditdataSources = false;
        $scope.isEditSlotGroup = false;

        $("#showloader").css("display", "block");

        var url = urlService.ATE_SLOTTING_SZ_DS.replace('dName', $scope.pagedc);
        url = url.replace('uName', sessionStorage.userName);

        //var res = $http.get("datasource.json");

        var res = $http.get(url, {
            headers: {
                'x-api-key': sessionStorage.apikey
            }
        });

        res.success(function(data, status, headers, config) {
            $("#showloader").css("display", "none");
            if (data.errorMessage) {
                $scope.isFailed = true;
                $scope.resmessage = data.errorMessage;
            } else if (data.resMessage) {
                $scope.isSuccess = true;
                $scope.resmessage = data.resMessage;
            } else {

                $scope.gridOptionsDataSource.columnDefs = [{
                        name: 'grpType',
                        displayName: 'Template ID',
                        width: 120,
                        enableCellEdit: false,
                        sort: {
                            direction: uiGridConstants.ASC,
                            priority: 1
                        },
                        cellTooltip: true,
                        headerTooltip: true
                    },
                    {
                        name: 'grpName',
                        displayName: 'Name',
                        width: 150,
                        enableCellEdit: false,
                        cellTooltip: true,
                        headerTooltip: true
                    },
                    {
                        name: 'hasAssoc',
                        displayName: 'Has Slotting Association',
                        width: 200,
                        enableCellEdit: false,
                        cellTooltip: true,
                        headerTooltip: true
                    },
                    {
                        name: 'hasTask',
                        displayName: 'Has Unreleased Tasks',
                        width: 200,
                        enableCellEdit: false,
                        cellTooltip: true,
                        headerTooltip: true
                    },
                    {
                        name: 'lastRun',
                        displayName: 'Last Completion Time',
                        width: 200,
                        enableCellEdit: false,
                        cellTooltip: true,
                        headerTooltip: true
                    },
                    {
                        name: 'statusDescription',
                        displayName: 'Current Status',
                        width: 200,
                        enableCellEdit: false,
                        cellTooltip: true,
                        headerTooltip: true
                    },
                    {
                        name: 'runaslot',
                        displayName: 'Run a Slot',
                        width: 200,
                        cellTemplate: '<div class="ui-grid-cell-contents" ng-click="grid.appScope.runAslot(grid, row)"><a >Run a Slot</a></div>'
                    },
                    {
                        name: 'releasetasks',
                        displayName: 'Release Task',
                        width: 120,
                        //cellTemplate: '<div class="ui-grid-cell-contents" ng-click="grid.appScope.releaseTask(grid, row)"><a>Release Tasks</a></div>'
						cellTemplate: '<div class="ui-grid-cell-contents" ng-click=\"grid.appScope.releaseSlot(grid, row)\" ng-if="grid.appScope.releaseTaskShow(row)"><a href="" class="">Release Tasks</a></div><div class="ui-grid-cell-contents" ng-if="!grid.appScope.releaseTaskShow(row)">Release Tasks</div>'  
                    }

                ];
                $scope.isTable = true;
                $scope.isMianpage = true;
                $scope.gridOptionsDataSource.data = data;
                $scope.foreCaste = $scope.gridOptionsDataSource.data[0].statusCode;

                if ($scope.gridOptionsDataSource.data > 10) {
                    $scope.gridOptionsDataSource.enableVerticalScrollbar = true;
                    $scope.gridOptionsDataSource.enableHorizontalScrollbar = 1;
                } else {
                    $scope.gridOptionsDataSource.enableVerticalScrollbar = false;
                    $scope.gridOptionsDataSource.enableHorizontalScrollbar = 1;
                }
            }
            $('.ui-grid-pager-control input').prop("disabled", true);
        });
        res.error(function(data, status, headers, config) {
            $("#showloader").css("display", "none");
            $scope.isFailed = true;
            $scope.resmessage = "System failed. Please try again or contact WAALOS Support";

        });
    };
    $scope.dataSources();

    var asnFuture = "";
    var asnPast = "";
    var asnInfoLst = "";
    var orderFuture = "";
    var orderPast = "";
    var orderStatCode = "";
    var orderMinStatCode = "";
	
	
	 $scope.releaseSlot = function(grid, row) {
            $scope.dsGrid = false;
            $scope.dsGridPanel = false;
            $scope.isEdit = false;
            $scope.isDelete = true;
            $scope.dsReleaseGrid = true;
            $scope.isReleseTask = true;
            $scope.isMianpage = false;
            $scope.relesedata = ["DESLOT", "RESLOT", "NEWSLOT"];
            $scope.values.releaseData = $scope.relesedata[0];
    }
	
	$scope.releaseTaskShow = function(row) {
        var flag = row.entity.hasTask == "Y";
        return flag;
    }

    //GET SLOT GROUPS

    var slotgropNames = [];
    $scope.slotGroups = function() {
        slotgropNames = [];
        $scope.isSave = false;
        $scope.isFailed = false;
        $scope.isSuccess = false;
        $("#showloader").css("display", "block");

        var url = urlService.ATE_SLOTTING_SJ_SLOTTING_GROUPS_GET_SZ1.replace('dName', $scope.pagedc);
        url = url.replace('uName', sessionStorage.userName);
        url = url.replace('gType', 96);

        //var res = $http.get("data_sz1.json");

        var res = $http.get(url, {
            headers: {
                'x-api-key': sessionStorage.apikey
            }
        });

        res.success(function(data, status, headers, config) {
            $("#showloader").css("display", "none");

            if (data.errorMessage) {
                $scope.isFailed = true;
                $scope.resmessage = data.errorMessage;
            } else if (data.resMessage) {
                $scope.isSuccess = true;
                $scope.resmessage = data.resMessage;
            } else {
                $scope.isEditdataSources = true;
                $scope.isMianpage = false;

                $scope.gridOptionsSlotgroup.columnDefs = [{
                        name: 'grpAttr',
                        displayName: 'Zone',
                        width: 150,
                        enableCellEdit: false,
                        cellTooltip: true,
                        headerTooltip: true
                    },
                    {
                        name: 'priority',
                        displayName: 'Group Priority',
                        width: 200,
                        enableCellEdit: false,
                        cellTooltip: true,
                        headerTooltip: true
                    },
                    {
                        name: 'zoneType',
                        displayName: 'Zone Type',
                        width: 150,
                        enableCellEdit: false,
                        cellTooltip: true,
                        headerTooltip: true
                    },
                    {
                        name: 'totLocns',
                        displayName: 'Total Location',
                        width: 200,
                        enableCellEdit: false,
                        cellTooltip: true,
                        headerTooltip: true
                    },
                    {
                        name: 'distZones',
                        displayName: 'Work Group Count',
                        width: 180,
                        enableCellEdit: false,
                        cellTooltip: true,
                        headerTooltip: true
                    },
                    {
                        name: 'hasRules',
                        displayName: 'Rules Completed',
                        width: 200,
                        enableCellEdit: false,
                        cellTooltip: true,
                        headerTooltip: true
                    },
                    {
                        name: 'prodTypes',
                        displayName: 'Prod Types',
                        width: 250,
                        enableCellEdit: false,
                        cellTooltip: true,
                        headerTooltip: true
                    }
                ];

                for (i = 0; i < data.length; i++) {
                    slotgropNames.push(data[i].grpAttr);
                }

                $scope.gridOptionsSlotgroup.data = data;

                if ($scope.gridOptionsSlotgroup.data > 10) {
                    $scope.gridOptionsSlotgroup.enableVerticalScrollbar = true;
                    $scope.gridOptionsSlotgroup.enableHorizontalScrollbar = 1;
                } else {
                    $scope.gridOptionsSlotgroup.enableVerticalScrollbar = false;
                    $scope.gridOptionsSlotgroup.enableHorizontalScrollbar = 1;
                }

            }

        });
        res.error(function(data, status, headers, config) {
            $("#showloader").css("display", "none");
            $scope.isFailed = true;
            $scope.resmessage = "System failed. Please try again or contact WAALOS Support";

        });
    };


    //back to data source 

    $scope.backSource = function() {
        $scope.isEditdataSources = false;
        $scope.isMianpage = true;
        $scope.isEditSlotGroup = false;
        $scope.isSuccess = false;
        $scope.isFailed = false;
        $scope.isEdit = true;
        $scope.isDelete = true;
        $scope.isTablerptkrl = false;
        $scope.isReleseTask = false;
        $scope.dataSources();
        $scope.reqExchangeDto = [];

    };

    $scope.backSloting = function() {
        $scope.isEditdataSources = true;
        $scope.isMianpage = false;
        $scope.isEditSlotGroup = false;
        $scope.isSuccess = false;
        $scope.isFailed = false;
        $scope.isEdit = true;
        $scope.isDelete = true;
        $scope.isTablerptkrl = false;
        $scope.slotGroups();

    };


    //Reset data source

    $scope.reset = function() {
        $scope.isSuccess = false;
        $scope.isFailed = false;
        $scope.isEdit = true;
        $scope.isDelete = true;
        $scope.isMianpage = true;
        $scope.isEditdataSources = false;
        $scope.isEditSlotGroup = false;

        $("#showloader").css("display", "block");
        var dataObj = {
            "dcName": $scope.pagedc,
            "userName": sessionStorage.userName
        };

        var res = $http.put(urlService.ATE_SLOTTING_SJ_RESET_DATASOURCES, dataObj, {
            headers: {
                'x-api-key': sessionStorage.apikey
            }
        });

        res.success(function(data, status, headers, config) {
            $("#showloader").css("display", "none");
            if (data.errorMessage) {
                $scope.isFailed = true;
                $scope.resmessage = data.errorMessage;
            } else if (data.resMessage) {

                $("#resetModal").modal('show');

                $scope.resmessagereset = data.resMessage;
            }

        });
        res.error(function(data, status, headers, config) {
            $("#showloader").css("display", "none");
            $scope.isFailed = true;
            $scope.resmessage = "System failed. Please try again or contact WAALOS Support";

        });
    };

    //function to seperate the keys and values from json as Object.values is not supproted in IE
    function convertJsontoArray(values) {
        var keyValues = {
            'keys': [],
            'values': []
        };

        if (values.length) {
            _.each(values, function(val, key) {
                _.each(val, function(val, key) {
                    keyValues.keys.push(key);
                    keyValues.values.push(val);
                });
            });
        } else {
            _.each(values, function(val, key) {
                keyValues.keys.push(key);
                keyValues.values.push(val);
            });
        }

        return keyValues;
    }

    $scope.zones = function() {
        $scope.Zonedata();
    };

    //zone data
    $scope.Zonedata = function() {
        $scope.isSuccesszone = false;
        $scope.isFailedzone = false;
        $scope.isDeleteZone = true;
        $scope.isSaveProb = true;
        $scope.zonesGridData =[];
		$scope.isFailedprob = false;


        $("#showloader").css("display", "block");

        var url = urlService.ATE_SLOTTING_SZ1_ZONE.replace('dName', $scope.pagedc);
        url = url.replace('uName', sessionStorage.userName);

        //var res = $http.get("Conf_zone.json");
        var res = $http.get(url, {
            headers: {
                'x-api-key': sessionStorage.apikey
            }
        });

        res.success(function(data, status, headers, config) {

            $("#showloader").css("display", "none");

            if (data.errorMessage) {
                $scope.isFailed = true;
                $scope.resmessagezone = data.errorMessage;
            } else if (data.resMessage) {
                $scope.isSuccesszone = true;
                $scope.resmessagezone = data.resMessage;
            } else {


                $scope.gridOptionsZone.columnDefs = [{
                        name: 'zone',
                        displayName: 'Zone',
                        enableCellEdit: false,
                        cellTooltip: true,
                        headerTooltip: true
                    },
                    {
                        name: 'hasWorkGrpAssociation',
                        width: 200,
                        displayName: 'Associated To Work Group',
                        enableCellEdit: false,
                        cellTooltip: true,
                        headerTooltip: true
                    },
                    {
                        name: 'workGroup',
                        displayName: 'Work Group',
                        enableCellEdit: false,
                        cellTooltip: true,
                        headerTooltip: true
                    },

                ];
                $scope.isTable = true;

                $scope.gridOptionsZone.data = data;
                _.each($scope.gridOptionsZone.data, function(val, key) {
                    $scope.zonesGridData.push(val.workGroup);
                });

                if ($scope.gridOptionsZone.data > 10) {
                    $scope.gridOptionsZone.enableVerticalScrollbar = true;
                    $scope.gridOptionsZone.enableHorizontalScrollbar = true;
                } else {
                    $scope.gridOptionsZone.enableVerticalScrollbar = false;
                    $scope.gridOptionsZone.enableHorizontalScrollbar = true;
                }
            }

        });
        res.error(function(data, status, headers, config) {
            $("#showloader").css("display", "none");
            $scope.isFailedzone = true;
            $scope.resmessagezone = "System failed. Please try again or contact WAALOS Support";

        });
    };

    $scope.thresValueChange = function() {
        var inputThresValue = document.getElementById('InputValue').value;
        if (inputThresValue ==""){
            $scope.isThres = true;
            $scope.isThresHold = "Please configure threshold value";
        } else {
             $scope.isThres = false;
             $scope.isThresHold = '';
        }
    }
    //zone data
    $scope.getThresHoldValue = function() {
        $scope.isSuccesszone = false;
        $scope.isFailedzone = false;
        $scope.isDeleteZone = true;
        $scope.isSaveProb = true;
		$scope.isFailedprob = false;


        $("#showloader").css("display", "block");

        var url = urlService.ATE_SLOTTING_SZ1_GETDATA.replace('dName', $scope.pagedc);
        url = url.replace('uName', sessionStorage.userName);

        //var res = $http.get("Conf_zone.json");
        var res = $http.get(url, {
            headers: {
                'x-api-key': sessionStorage.apikey
            }
        });

        res.success(function(data, status, headers, config) {

            $("#showloader").css("display", "none");

            $scope.thresHold = data;

            if (data.resCode) {
                $scope.isFailedthres = true;
                $scope.resmessagethres = data.resMessage;
                $scope.thresHold = '';
            } else if (data.resMessage) {
                $scope.isSuccessthres = true;
                $scope.resmessagethres = data.resCode;
            }

        });
        res.error(function(data, status, headers, config) {
            $("#showloader").css("display", "none");
            $scope.isFailedzone = true;
            $scope.resmessagezone = "System failed. Please try again or contact WAALOS Support";

        });
    };

    $scope.saveThresholdValue = function() {
        var thresValue = document.getElementById("InputValue").value;
        $scope.resmessageprob = "";
        $scope.isSuccessprob = false;
        $scope.isFailedprob = false;

        $("#showloader").css("display", "block");

        var url = urlService.ATE_SLOTTING_SZ_THRESHOLD_DATA_UPDATE.replace('dName', $scope.dcName);
        url = url.replace('uName', sessionStorage.userName);
        url = url.replace('uThres', thresValue);

        var res = $http.put(url,null, {
            headers: {
                'x-api-key': sessionStorage.apikey
            }
        });

        res.success(function(data, status, headers, config) {
            $("#showloader").css("display", "none");
            if (data.errorMessage) {
                $scope.isFailedprob = true;
                $scope.resmessageprob = data.errorMessage;
                /*$timeout(function () {
                    $scope.isFailedprob = false;
                }, 2000);*/

            } else if (data.resMessage) {
                $scope.Zonedata();
                $scope.isSuccessprob = true;
                $scope.resmessageprob = data.resMessage;
                /*$timeout(function () {
                    $scope.isSuccessprob = false;
                }, 2000);*/
            }
        });
        res.error(function(data, status, headers, config) {
            $("#showloader").css("display", "none");
            $scope.isFailedprob = true;
            $scope.resmessageprob = "System failed. Please try again or contact WAALOS Support";
        });
    };


    //Delete Zone
    $scope.zoneDelete = function() {
        $scope.resmessagezone = "";
        $scope.isSuccesszone = false;
        $scope.isFailedzone = false;

        $("#showloader").css("display", "block");


        var url = urlService.ATE_SLOTTING_SZ_ZONE_DELETE.replace('dName', $scope.pagedc);
        url = url.replace('uName', sessionStorage.userName);
        url = url.replace('zoneid', $scope.selectedRowToDelete.zoneId);
        if ($scope.selectedRowToDelete.hasWorkGrpAssociation == "N") {
            $scope.isFailedzone = true;
            $scope.resmessagezone = "No Work Group(s) to be deleted for the selected zone";
            $("#showloader").css("display", "none");
            return false;
        } else {
            var res = $http.delete(url, {
                headers: {
                    'x-api-key': sessionStorage.apikey
                }
            });

            res.success(function(data, status, headers, config) {
                $("#showloader").css("display", "none");
                if (data.errorMessage) {
                    $scope.isFailedzone = true;
                    $scope.resmessagezone = data.errorMessage;

                } else if (data.resMessage) {
                    $scope.Zonedata();
                    $scope.isSuccesszone = true;
                    $scope.resmessagezone = data.resMessage;
                }
            });
        }
        res.error(function(data, status, headers, config) {
            $("#showloader").css("display", "none");
            $scope.isFailedzone = true;
            $scope.resmessagezone = "System failed. Please try again or contact WAALOS Support";
        });
    };

    //Add Zone
    $scope.addZone = function() {
        $scope.resmessagezone = "";
        $scope.isSuccesszone = false;
        $scope.isFailedzone = false;

        $("#zoneModal").modal('hide');

        $("#showloader").css("display", "block");

        var postData = {
            "zone": $scope.ZoneName,
            "dcName": $scope.pagedc,
            "userName": sessionStorage.userName
        };
        //var res = $http.get("add_zone.json");

        var res = $http.post(urlService.ATE_SLOTTING_SZ1_ZONE_ADD, postData, {
            headers: {
                'x-api-key': sessionStorage.apikey
            }
        });
        res.success(function(data, status, headers, config) {
            $("#showloader").css("display", "none");
            if (data.errorMessage) {
                $scope.isFailedzone = true;
                $scope.resmessagezone = data.errorMessage;

            } else if (data.resMessage) {
                $scope.Zonedata();
                $scope.isSuccesszone = true;
                $scope.resmessagezone = data.resMessage;
            }
        });
        res.error(function(data, status, headers, config) {
            $("#showloader").css("display", "none");
            $scope.isFailedzone = true;
            $scope.resmessagezone = "System failed. Please try again or contact WAALOS Support";
        });

        $scope.ZoneName = undefined;
        $scope.Zone_error = false;
    };


    $scope.ChangeZone = function() {
        if ($scope.ZoneName == "") {
            $scope.Zone_error = false;
        } else {
            $scope.Zone_error = true;
        }
    };

    $scope.calcelZone = function() {
        $scope.ZoneName = undefined;
        $scope.Zone_error = false;
    };
    //Associte
    $scope.zoneAssocate = function(row) {

        $scope.isMultiSelect = false;
        $scope.resmessagezone = "";
        $scope.isSuccesszone = false;
        $scope.isFailedzone = false;

        $("#showloader").css("display", "block");


        var url = urlService.ATE_SLOTTING_SZ1_ZONE_ASSOCATE.replace('dName', $scope.pagedc);
        url = url.replace('uName', sessionStorage.userName);
        //url = url.replace('zoneid', 123);
        url = url.replace('zoneid', $scope.selectedRowToDelete.zoneId);

        //var res = $http.get("getAssociate.json");
        var res = $http.get(url, {
            headers: {
                'x-api-key': sessionStorage.apikey
            }
        });

        res.success(function(data, status, headers, config) {

            $("#showloader").css("display", "none");
            if (data.errorMessage) {
                $scope.isFailedzone = true;
                $scope.resmessagezone = data.errorMessage;

            } else if (data.resMessage) {
                $scope.isSuccesszone = true;
                $scope.resmessagezone = data.resMessage;
            } else {

                $scope.updatedDCS = [];

                $("#associateModel").modal('show');
                $scope.workgroups = [];
               /* if (data.checkedAisles.length > 0) {
                    if (data.checkedAisles[0].workGrp == "ALL") {
                        $scope.all = true;
                    } else {
                        $scope.all = false;
                    }
                } else {
                    $scope.all = false;
                }
*/

                //debugger;
                _.each(data.getAssociateZonesDtoLst, function(val, key) {
                    $scope.workgroups.push(val.workGrp);
                });
                // if(data.checkedAisles.workGrp == null){
                //  $scope.checkedVlaues = [];
                // }else{
                //  $scope.checkedVlaues = data.checkedAisles.length > 0 ? data.checkedAisles[0].workGrp.split(',') : undefined;
                // }
                $scope.checkedVlaues = [];
                //difference of total zones and associated zones 
               // $scope.checkedVlaues = [];
                var wrkGrpArr = $scope.workgroups;
                var zoneGridArr = $scope.zonesGridData;
                var differenceZones = [];
                //difference of total zones and associated zones 
                jQuery.grep(wrkGrpArr, function(el) {
                    if (jQuery.inArray(el, zoneGridArr) == -1) differenceZones.push(el);
                });

                if (data.checkedAisles.length > 1) {
                    _.each(data.checkedAisles, function(val, key) {
                        $scope.checkedVlaues.push(val.workGrp);
                    });
                } else {
                    $scope.checkedVlaues = data.checkedAisles.length > 0 ? data.checkedAisles[0].workGrp.split(',') : '';
                }
                //pushing the checked values to the difference of zones                       
                var diffPush = differenceZones.push(...$scope.checkedVlaues);
                if(diffPush == 0)
                {
                    $scope.isMultiSelect = true;  
                }
                if (!$scope.checkedVlaues) {
                    _.each(differenceZones, function(Dval, Dkey) {
                        $scope.updatedDCS.push({
                            'name': Dval,
                            'isChecked': false
                        });

                    });
                    $scope.isCheck = false;
                    $scope.checkedVlaues = [''];
                } else {
                    _.each(differenceZones, function(Dval, Dkey) {
                        if (differenceZones.indexOf($scope.checkedVlaues[Dkey]) > -1) {
                            $scope.updatedDCS.push({
                                'name': $scope.checkedVlaues[Dkey],
                                'isChecked': true
                            });
                            $scope.isCheck = false;
                        } 
                            var duplicateValues = [];
                            _.each($scope.updatedDCS, function(val, key) {
                                duplicateValues.push(val.name);
                            });
                            if (duplicateValues.indexOf(Dval) < 0) {
                                $scope.updatedDCS.push({
                                    'name': Dval,
                                    'isChecked': false
                                });
                            }
                    });
                }

            }
        });
        res.error(function(data, status, headers, config) {
            $("#showloader").css("display", "none");
            $scope.isFailedzone = true;
            $scope.resmessagezone = "System failed. Please try again or contact WAALOS Support";
        });
    };

    //check list
    $scope.checkedlistass = function() {

        var workgroup_list = [];
        for (var key in $scope.updatedDCS) {
            if ($scope.updatedDCS.hasOwnProperty(key)) {
                if ($scope.updatedDCS[key].isChecked == true) {
                    workgroup_list.push($scope.updatedDCS[key].name);

                }
            }
        }

        /*if ($scope.all) {
            workgroup_list = [];
        }*/

        $scope.resmessagezone = "";
        $scope.isSuccesszone = false;
        $scope.isFailedzone = false;

        $("#showloader").css("display", "block");

        var workGroupAssociation = null;
        if(workgroup_list.length == 0){
            workGroupAssociation: "N";
        }else{
            workGroupAssociation = $scope.selectedRowToDelete.hasWorkGrpAssociation;
        }
        var postData = {

            "zone": $scope.selectedRowToDelete.zoneId,
            "hasWorkGrpAssociation": workGroupAssociation,
            "workGroup": workgroup_list.join(),
            "dcName": $scope.selectedRowToDelete.dcName,
            "userName": $scope.selectedRowToDelete.userName

            };

        //var res = $http.get("1.json");

        var res = $http.put(urlService.ATE_SLOTTING_SZ_ZONE_ASSOCATE_UPDATE, postData, {
            headers: {
                'x-api-key': sessionStorage.apikey
            }
        });
        res.success(function(data, status, headers, config) {
            $("#showloader").css("display", "none");
            if (data.errorMessage) {
                $scope.isFailedzone = true;
                $scope.resmessagezone = data.errorMessage;

            } else if (data.resMessage) {
                $scope.Zonedata();
                $scope.isSuccesszone = true;
                $scope.resmessagezone = data.resMessage;
            }
        });
        res.error(function(data, status, headers, config) {
            $("#showloader").css("display", "none");
            $scope.isFailedzone = true;
            $scope.resmessagezone = "System failed. Please try again or contact WAALOS Support";
        });



    };

    $scope.assCheckedValues = function(wrkGrpAll) {
        var checkedBooleanValues = [];
        for (var key in $scope.updatedDCS) {
            if ($scope.updatedDCS.hasOwnProperty(key) && $scope.updatedDCS[key].isChecked == true) {
                checkedBooleanValues.push($scope.updatedDCS[key].isChecked);
            }
        }
        //$scope.isMultiSelect = checkedBooleanValues.length >1?true:false;

        if (wrkGrpAll == 'check') {
            var booleanValues = [];

            for (var key in $scope.workgroupsData) {
                if ($scope.workgroupsData.hasOwnProperty(key)) {
                    booleanValues.push($scope.workgroupsData[key].isChecked);
                }
            }

            $scope.isCheck = booleanValues.indexOf(true) > -1 ? true : false;
            $scope.wrkGrpAll = booleanValues.indexOf(true) > -1 ? false : true;
        } /*else if (typeof wrkGrpAll == "boolean") {
            $scope.wrkGrpAll = !wrkGrpAll;

            _.each($scope.workgroupsData, function(val, key) {
                val.isChecked = false;
            });

        } else if (wrkGrpAll == 'all') {

            _.each($scope.updatedDCS, function(val, key) {
                val.isChecked = false;
            });
            $scope.all = !$scope.all;
        }*/ else {
            var booleanValues = [];

            for (var key in $scope.updatedDCS) {
                if ($scope.updatedDCS.hasOwnProperty(key)) {
                    booleanValues.push($scope.updatedDCS[key].isChecked);
                }
            }

            $scope.isCheck = booleanValues.indexOf(true) > -1 ? true : false;
           // $scope.all = booleanValues.indexOf(true) > -1 ? false : true;
        }
    };

    $scope.changeSku = function() {
        if ($scope.displaySku == "") {
            $scope.Sku_error = false;
        } else {
            $scope.Sku_error = true;
        }
    };
    $scope.cancelSku = function() {
        $scope.displaySku = undefined;
        $scope.Sku_error = false;
    };

    // delete sku
    $scope.deleteSku = function() {

        $scope.resmessage = "";
        $scope.isSuccess = false;
        $scope.isFailed = false;
        $scope.isDeleted = true;

        $("#showloader").css("display", "block");
        var sku = $scope.selectedRowdspSKU.dspsku;
        var skuNum = sku.replace(" ", "");

        var url = urlService.ATE_SLOTTING_SJ_DELETE_SKU.replace('dName', $scope.pagedc);
        url = url.replace('uName', sessionStorage.userName);
        url = url.replace('gType', $scope.grptype);
        url = url.replace('skuid', $scope.selectedRowdspSKU.dspsku);

        var res = $http.delete(url, {
            headers: {
                'x-api-key': sessionStorage.apikey
            }
        });

        res.success(function(data, status, headers, config) {
            $("#showloader").css("display", "none");
            if (data.errorMessage) {
                $scope.isFailed = true;
                $scope.resmessage = data.errorMessage;

            } else if (data.resMessage) {
                $scope.getSkuExclusion();
                $scope.isSuccess = true;
                $scope.resmessage = data.resMessage;
                $scope.isDeleted = true;
            }
        });
        res.error(function(data, status, headers, config) {
            $("#showloader").css("display", "none");
            $scope.isFailed = true;
            $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
        });
    };

    var fixedCaseValue = "";

    //sloting grop edit
    $scope.editSlotingGroups = function() {
        // $scope.Volume = false;
        $scope.isItemGroupClicked = false;
        $scope.isSave = false;
        $scope.isFailed = false;
        $scope.isSuccess = false;
		$scope.priorityGridData = [];
		$scope.groupPriorityFlag = false;
        $scope.groupPriorityFlagNew = false;
        $scope.fixedCaseFlag = false;
        $scope.daysTillSlotFlag = false;
        $scope.deslotToRevValFlag = false;

        $("#showloader").css("display", "block");

        var url = urlService.ATE_SLOTTING_SZ1_SLOTTING_GROUPS_EDIT.replace('dName', $scope.pagedc);
        url = url.replace('uName', sessionStorage.userName);
        url = url.replace('gType', 96);
        //url = url.replace('grpAttr', 'D1APP');
        url = url.replace('gtpAttr', $scope.selectedRowToSlotEdit.slotGrp);

        $scope.grpAttrValue = $scope.selectedRowToSlotEdit.slotGrp;
        //$scope.grpAttrValue = 'D1APP';
		
		
		_.each($scope.gridOptionsSlotgroup.data, function(val, key) {
						   if( $scope.grpAttrValue != val.grpAttr)
							$scope.priorityGridData.push(val.priority);
						});
        //var res = $http.get("data.json");
        var res = $http.get(url, {
            headers: {
                'x-api-key': sessionStorage.apikey
            }
        });


        res.success(function(data, status, headers, config) {

            $("#showloader").css("display", "none");

            if (data.errorMessage) {
                $scope.isFailed = true;
                $scope.resmessage = data.errorMessage;
            } else if (data.resMessage) {
                $scope.isSuccess = true;
                $scope.resmessage = data.resMessage;
            } else {
                $scope.useridVal = data.userId;
                $scope.isEditdataSources = false;
                $scope.isMianpage = false;
                $scope.isEditSlotGroup = true;
                $scope.sataCode = data.statCode;
                $scope.needDereslot = data.needDereslot;
                //Location

                if (data.noOfCases == 0 || data.noOfCases == null || data.noOfCases == 'None') {
                    $scope.values.volOrFix = 'Volume';
                    $scope.isFixed = true;
                    $scope.values.noOfCases = "0";
                } else {
                    $scope.values.volOrFix = 'Fixed';
                    $scope.isFixed = false;
                    $scope.values.fixedCase = data.noOfCases;
                    fixedCaseValue = data.noOfCases;

                }
                $scope.values.maxAllowed = data.pctFull;

                $scope.values.skuMovement = data.lockInPlace;
                $scope.skumoves = ["0-SKUs Both In and Out", "1-Only SKUs Out", "2-Only SKUs In", "3-Locked-No SKUs In or Out"];

                if (data.spillOrder == "") {
                    $scope.groupPriorityFlag = true;
                    $scope.isSave = true;
                } else {
                    $scope.values.groupPriority = data.priority;
                }

                //$scope.reslotZonesGroups = slotgropNames;
                //$scope.values.reslotZoneIndex_1 = $scope.reslotZonesGroups.indexOf(data.grpAttr);

                $scope.values.zoneType = data.zoneType;
                $scope.slottingTypes = ["Dynamic", "Static", "Piogeon", "Flow1", "Flow2"];
                $scope.values.zoneTypeIndex = $scope.slottingTypes.indexOf(data.zoneType);


                if (data.allowKitBreak == '0') {
                    $scope.kitbreak = true;
                    $scope.kitbreakVal = "0";
                } else {
                    $scope.kitbreak = false;
                    $scope.kitbreakVal = "1";
                }

                $scope.userTypeVal = data.kitUserType;
                $scope.usertypes = ["# of Bays - NOT WORKING", "# of Positions an article is allowed to span"];
                //slotgropNames     

                $scope.values.bayPosn = data.kitValue;

                if (data.kitType == 2) {
                    $scope.isKit = false;
                } else {
                    $scope.isKit = true;
                }

                if (data.deslotToReserve == '0') {
                    $scope.dslotRes = true;
                    $scope.isdeslot = true;
                    $scope.deslotToReserve = 0;
                } else {
                    $scope.dslotRes = false;
                    $scope.isdeslot = false;
                    $scope.deslotToReserve = 1;
                }

                if (data.deslotZero == '0') {
                    $scope.dslotInv = false;
                    $scope.dslotInvVal = "0";
                } else {

                    $scope.dslotInv = true;
                    $scope.dslotInvVal = "1";
                }
                $scope.values.daysTillSlot = data.daysTillSlot;
                $scope.values.reSlotToResVal = data.reSlotToResVal;
                if (data.reslotLimits == "") {
                    $scope.values.intraZone = 0;
                } else {
                    $scope.values.intraZone = data.reslotLimits;
                }
                //seasonYr prodSubGroups saBusSeg
                // $scope.reslotZones = "";
                $scope.reslotZones = slotgropNames;
                $scope.values.reslotZoneIndex = $scope.reslotZones.indexOf(data.reSlotSeasonGrpAttr);



                $scope.reslotZonesGroups = slotgropNames;
                $scope.values.reslotZoneIndex_1 = $scope.reslotZonesGroups.indexOf(data.reSlotInvGrpAttr);
                //$scope.reslotZonesGroups = "";


                $scope.prodtypes = "";
                $scope.prodgroup = "";
                $scope.carton = "";
                $scope.putwytype = "";
                $scope.seasonyr = "";
                $scope.prodsubgroups = "";
                $scope.sabusinesssegments = "";

                if (data.prodTypes == null || data.prodTypes == "") {
                    $scope.prodTypes = "";
                    $scope.prodtypes = " ";
                } else {

                    $scope.prodTypes = data.prodTypes.replace(/['"]+/g, '').split(',');
                    $scope.prodtypes = data.prodTypes;
                }

                if (data.prodGroups == null || data.prodGroups == "") {
                    $scope.prodGroups = "";
                    $scope.prodgroup = " ";
                } else {

                    $scope.prodGroups = data.prodGroups.replace(/['"]+/g, '').split(',');
                    $scope.prodgroup = data.prodGroups;
                }

                if (data.cartonTypes == null || data.cartonTypes == "") {
                    $scope.cartonTypes = "";
                    $scope.carton = " ";
                } else {

                    $scope.cartonTypes = data.cartonTypes.replace(/['"]+/g, '').split(',');
                    $scope.carton = data.cartonTypes;
                }

                if (data.putwyTypes == null || data.putwyTypes == "") {
                    $scope.putwyTypes = "";
                    $scope.putwytype = " ";
                } else {

                    $scope.putwyTypes = data.putwyTypes.replace(/['"]+/g, '').split(',');
                    $scope.putwytype = data.putwyTypes;
                }

                if (data.seasonYr == null || data.seasonYr == "") {
                    $scope.seasonYr = "";
                    $scope.seasonyr = " ";
                } else {

                    $scope.seasonYr = data.seasonYr.replace(/['"]+/g, '').split(',');
                    $scope.seasonyr = data.seasonYr;
                }

                if (data.prodSubGroups == null || data.prodSubGroups == "") {
                    $scope.prodSubGroups = "";
                    $scope.prodgubgroups = " ";
                } else {

                    $scope.prodSubGroups = data.prodSubGroups.replace(/['"]+/g, '').split(',');
                    $scope.prodgubgroups = data.prodSubGroups;
                }

                if (data.saBusinessSegments == null || data.saBusinessSegments == "") {
                    $scope.saBusinessSegments = "";
                    $scope.sabusinesssegments = " ";
                } else {

                    $scope.saBusinessSegments = data.saBusinessSegments.replace(/['"]+/g, '').split(',');
                    $scope.sabusinesssegments = data.saBusinessSegments;
                }
                if($scope.selectedRowToSlotEdit.colRules == 'N')
                {
                    $scope.isSave = true;
                }

                $scope.saveValues = {
                    "prodTypes": $scope.prodtypes,
                    "prodGroups": $scope.prodgroup,
                    "cartonTypes": $scope.carton,
                    "putwyTypes": $scope.putwytype,
                    "seasonYr": $scope.seasonyr,
                    "prodSubGroups": $scope.prodsubgroups,
                    "saBusinessSegments": $scope.sabusinesssegments
                };


            }
        });
        res.error(function(data, status, headers, config) {
            $("#showloader").css("display", "none");
            $scope.isFailedprob = true;
            $scope.resmessageprob = "System failed. Please try again or contact WAALOS Support";

        });
    };

    $scope.locationChange = function(s) {
        if (s == 'Volume') {
            $scope.values.volOrFix = 'Volume';
            $scope.isFixed = true;
            $scope.values.fixedCase = 0;

        } else {
            $scope.values.volOrFix = 'Fixed';
            $scope.isFixed = false;
            $scope.values.fixedCase = fixedCaseValue;


        }
    };

/*    $scope.fixedCaseValidation = function() {

        var numbers = /^[0-9]+$/;
        if ($scope.values.fixedCase == "" || $scope.values.fixedCase == null || !($scope.values.fixedCase.match(numbers))) {
            $scope.fixedCaseFlag = true;
            $scope.isSave = true;
        } else {
            $scope.fixedCaseFlag = false;
            $scope.isSave = false;
        }
    }*/

    $scope.kitBrealChange = function(kitbreak) {
        if (kitbreak == true) {
            $scope.kitbreakVal = "0";
        } else {
            $scope.kitbreakVal = "1";
        }
    };

    $scope.dslotInvChange = function(dslotInv) {
        if (dslotInv == true) {
            $scope.dslotInvVal = "1";
        } else {
            $scope.dslotInvVal = "0";
        }
    };

    $scope.maxAllowedValue = function() {

        var numbers = /^[0-9]+$/;
        if ($scope.values.maxAllowed == "" || !($scope.values.maxAllowed.match(numbers)) || $scope.values.maxAllowed == null || $scope.values.maxAllowed > 100) {
            $scope.maxValueFlag = true;
            $scope.isSave = true;
        } else {
            $scope.maxValueFlag = false;
            $scope.isSave = false;
        }

    };

    $scope.groupPriorityValue = function() {
        var numbers = /^[0-9]+$/;
		var priorityArr = $scope.priorityGridData;
		var groupPrio =  $scope.values.groupPriority;
        var priorityCheck =  _.includes(priorityArr, groupPrio);
        if(priorityCheck)
			{
				$scope.groupPriorityFlagNew = true;
				$scope.groupPriorityFlag = false;
				$scope.isSave = true;
			}
		else
		{
			if ($scope.values.groupPriority == "" || !($scope.values.groupPriority.match(numbers)) || $scope.values.groupPriority <= 0) {
				$scope.groupPriorityFlag = true;
				$scope.groupPriorityFlagNew = false;
				$scope.isSave = true;
			} else {
				$scope.groupPriorityFlag = false;
				$scope.groupPriorityFlagNew = false;
				$scope.isSave = false;
			}
		}
    };

    $scope.bayPosnChange = function() {
        var numbers = /^[0-9]+$/;
        if ($scope.values.bayPosn == "" || !($scope.values.bayPosn.match(numbers))) {
            $scope.bayPosnFlag = true;
            $scope.isSave = true;
        } else {
            $scope.bayPosnFlag = false;
            $scope.isSave = false;
        }
    };

    $scope.changedaysTillSlot = function() {
        var numbers = /^[0-9]+$/;
        if ($scope.values.daysTillSlot == "" || !($scope.values.daysTillSlot.match(numbers))) {
            $scope.daysTillSlotFlag = true;
            $scope.isSave = true;
        } else {
            $scope.daysTillSlotFlag = false;
            $scope.isSave = false;
        }
    };

    $scope.changedslotToRevVal = function() {
        var numbers = /^[0-9]+$/;
        if ($scope.values.reSlotToResVal == "" || !($scope.values.reSlotToResVal.match(numbers))) {
            $scope.deslotToRevValFlag = true;
            $scope.isSave = true;
        } else {
            $scope.deslotToRevValFlag = false;
            $scope.isSave = false;
        }
    };

    $scope.kitChange = function(val) {
        if (val == 2) {
            $scope.isKit = false;
        } else {
            $scope.isKit = true;
        }
    };
    $scope.dSlotRes = function(dslot) {

        if (dslot == true) {
            $scope.isdeslot = true;
            $scope.deslotToReserve = 0;
        } else {
            $scope.isdeslot = false;
            $scope.deslotToReserve = 1;
        }
    };

    $scope.intraZoneChange = function() {
        var numbers = /^[0-9]+$/;
        if ($scope.values.intraZone == "") {
            $scope.values.intraZone = "0";
        }
        if ($scope.values.intraZone == "" || !($scope.values.intraZone.match(numbers))) {
            $scope.intraZoneFlag = true;
            $scope.isSave = true;
        } else {
            $scope.intraZoneFlag = false;
            $scope.isSave = false;
        }
    };




    $scope.itemGroups = function() {
        $scope.isItemGroupClicked = true;
        $scope.isSave = false;
        $scope.isFailed = false;
        $scope.isSuccess = false;

        $("#showloader").css("display", "block");

        var url = urlService.ATE_SLOTTING_SZ1_ITEM_GROUP.replace('dName', $scope.pagedc);
        url = url.replace('uName', sessionStorage.userName);

        //var res = $http.get("item_group.json");

        var res = $http.get(url, {
            headers: {
                'x-api-key': sessionStorage.apikey
            }
        });

        res.success(function(data, status, headers, config) {

            $("#showloader").css("display", "none");

            if (data.errorMessage) {
                $scope.isFailed = true;
                $scope.resmessage = data.errorMessage;
            } else if (data.resMessage) {
                $scope.isSuccess = true;
                $scope.resmessage = data.resMessage;
            } else {

                if (data.productTypes != null || data.productTypes[0].codeDesc != null || data.productTypes[0].codeId != null) {
                    //Product Type
                    $scope.producttypes = [];

                    _.each(data.productTypes, function (val, key) {
                        if(val.codeId != null && val.codeDesc != null ){
                        $scope.producttypes.push({ 'codeId': val.codeId, 'codeDesc': val.codeDesc, 'isChecked': false });
                        }
                    });

                    _.each($scope.prodTypes, function (val, key) {

                        var arr = _.find($scope.producttypes, function (item) {
                            return item.codeId == val;
                        });
                        arr['isChecked'] = true;
                        $scope.producttypes = _.reject($scope.producttypes, function (item) {
                            return item.codeId == val;

                        });
                        $scope.producttypes.push(arr);
                        $scope.producttypes.sort(function (a, b) {
                            return parseInt(a.codeId) - parseInt(b.codeId);
                        });

                    });
                }

            }
        });
        res.error(function(data, status, headers, config) {
            $("#showloader").css("display", "none");
            $scope.isFailed = true;
            $scope.resmessage = "System failed. Please try again or contact WAALOS Support";

        });
    };




    $scope.saveSloting = function() {

        $scope.resmessage = "";
        $scope.isSuccess = false;
        $scope.isFailed = false;
        $scope.isDelete = false;
        $("#showloader").css("display", "block");

        var fixedCaseCheck = angular.isUndefined($scope.values.fixedCase);
        if(fixedCaseCheck == true ){
            $scope.values.fixedCase = "";
        }
        if ($scope.values.intraZone == "") {
            $scope.values.intraZone = "0";
        }
        var saveProductValues = "";
        if ($scope.producttypes) {
            _.each($scope.producttypes, function(val, key) {
                if (val.isChecked) {
                    saveProductValues += "'" + val.codeId + "'" + ",";
                }
            });
            saveProductValues = saveProductValues.slice(0, -1);
        }


        var saveProductGroupValues = "";
        if ($scope.productgroups) {
            _.each($scope.productgroups, function(val, key) {
                if (val.isChecked) {
                    saveProductGroupValues += "'" + val.codeId + "'" + ",";
                }
            });
            saveProductGroupValues = saveProductGroupValues.slice(0, -1);
        }

        var saveCartonTypes = "";
        if ($scope.cartontypes) {
            _.each($scope.cartontypes, function(val, key) {
                if (val.isChecked) {
                    saveCartonTypes += "'" + val.cartonType + "'" + ",";
                }
            });
            saveCartonTypes = saveCartonTypes.slice(0, -1);
        }

        var savePutawayTypes = "";

        if ($scope.putawaytypes) {
            _.each($scope.putawaytypes, function(val, key) {
                if (val.isChecked) {
                    savePutawayTypes += "'" + val.codeId + "-" + val.codeDesc + "'" + ",";
                }
            });
            savePutawayTypes = savePutawayTypes.slice(0, -1);
        }

        var saveProductSubGroups = "";

        if ($scope.putawaytypes) {
            _.each($scope.productsubgroups, function(val, key) {
                if (val.isChecked) {
                    saveProductSubGroups += "'" + val.codeId + "'" + ",";
                }
            });
            saveProductSubGroups = saveProductSubGroups.slice(0, -1);
        }


        var saveSaBusinessSegments = "";

        if ($scope.sabusinessswegments) {
            _.each($scope.sabusinessswegments, function(val, key) {
                if (val.isChecked) {
                    saveSaBusinessSegments += "'" + val.codeId + "'" + ",";
                }
            });
            saveSaBusinessSegments = saveSaBusinessSegments.slice(0, -1);
        }

        var saveSeasonYrs = "";

        if ($scope.seasonyears) {
            _.each($scope.seasonyears, function(val, key) {
                if (val.isChecked) {
                    saveSeasonYrs += "'" + val.miscAlpha2 + "'" + ",";
                }
            });
            saveSeasonYrs = saveSeasonYrs.slice(0, -1);
        }

        var postData = {
            "dcName": $scope.pagedc,
            "userName": sessionStorage.userName,
            "grpType": $scope.grptype,
            "grpAttr": $scope.grpAttrValue,
            "userId": $scope.useridVal,
            "grpType": 96,
            "daysTillSlot": $scope.values.daysTillSlot,
            "priority": $scope.values.groupPriority,
            //"deslotToReserve": $scope.deslotToReserve.toString(),
            "reSlotToResVal": $scope.values.reSlotToResVal,
            "reSlotInvGrpAttr": $scope.values.reslotZonesGroup,
            "reSlotSeasonGrpAttr": $scope.values.reslotZone,
            "prodTypes": $scope.isItemGroupClicked ? saveProductValues : $scope.saveValues.prodTypes.replace(/'/g, ""),
            "zoneType": $scope.values.slottingType,
            "noOfCases": $scope.values.fixedCase

        };

        //var res = $http.get("expand.json");

        var res = $http.put(urlService.ATE_SLOTTING_SZ1_UPDATE_GROUP, postData, {
            headers: {
                'x-api-key': sessionStorage.apikey
            }
        });



        res.success(function(data, status, headers, config) {
            $("#showloader").css("display", "none");
            if (data.errorMessage) {
                $scope.isFailed = true;
                $scope.resmessage = data.errorMessage;

            } else if (data.resMessage) {
                $scope.editSlotingGroups();
                $scope.isSuccess = true;
                $scope.resmessage = data.resMessage;
            }
        });
        res.error(function(data, status, headers, config) {
            $("#showloader").css("display", "none");
            $scope.isFailed = true;
            $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
        });
    };

    //release task
    $scope.releaseTask = function(grid, row) {

        $scope.dsLotId = $scope.gridOptionsDataSource.data[0].lotId;

        if (row.entity.hasTask == 'N') {
            $scope.isSuccess = true;
            $scope.resmessage = "Release Tasks cannot be accessed as Unreleased Tasks flag is 'N'";
            return false;
        }
        $scope.isSuccess = false;
        $scope.isFailed = false;
        $scope.isLowerGrid = false;
        $scope.gridData = grid;
        $scope.rowData = row;
        $scope.reqExchangeDto = [];
        $("#showloader").css("display", "block");
        var url = urlService.ATE_SLOTTING_SZ1_RELESE_TASK.replace('dName', $scope.pagedc);
        url = url.replace('uName', sessionStorage.userName);
        url = url.replace('gType', row.entity.grpType);
        $scope.gType = row.entity.grpType;
        url = url.replace('ulotid', $scope.dsLotId);
        //var res = $http.get("release_task.json");
         var res = $http.get(url, {
            headers: {
                'x-api-key': sessionStorage.apikey
            }
        });

        res.success(function(data, status, headers, config) {
            $("#showloader").css("display", "none");
            if (data.errorMessage) {
                $scope.isFailed = true;
                $scope.resmessage = data.errorMessage;
            } else if (data.resMessage) {
                $scope.isSuccess = true;
                $scope.resmessage = data.resMessage;
            } else {



                $scope.gridOptions.columnDefs = [{
                        name: 'grpAttr',
                        displayName: 'Work Zones',
                        enableCellEdit: false,
                        cellTooltip: true,
                        headerTooltip: true
                    },
					 {
                        name: 'priority',
                        displayName: 'Group Priority',
                        width: 120,
                        enableCellEdit: false,
                        cellTooltip: true,
                        headerTooltip: true
                    },
                    {
                        name: 'deslotCntl',
                        displayName: 'Deslot',
                        enableCellEdit: false,
                        cellTooltip: true,
                        headerTooltip: true
                    },
                    {
                        name: 'reslotOpenCnt',
                        displayName: 'Reslots In',
                        enableCellEdit: false,
                        cellTooltip: true,
                        headerTooltip: true
                    },
                    {
                        name: 'reslotCnt',
                        displayName: 'Reslots Out',
                        enableCellEdit: false,
                        cellTooltip: true,
                        headerTooltip: true
                    },
                    {
                        name: 'newslotCnt',
                        displayName: 'New Slots',
                        enableCellEdit: false,
                        cellTooltip: true,
                        headerTooltip: true
                    },
                    {
                        name: 'totalCnt',
                        displayName: 'Total Locns',
                        enableCellEdit: false,
                        cellTooltip: true,
                        headerTooltip: true
                    }
                ];

                $scope.isReleseTask = true;
                $scope.isMianpage = false;
                $scope.gridOptions.data = data.getTotalReleaseCntDtoLst;

                if ($scope.gridOptions.data > 10) {
                    $scope.gridOptions.enableVerticalScrollbar = true;
                    $scope.gridOptions.enableHorizontalScrollbar = 1;
                } else {
                    $scope.gridOptions.enableVerticalScrollbar = false;
                    $scope.gridOptions.enableHorizontalScrollbar = 1;
                }

                $scope.workZoneList = data.workZonesLst;
                $scope.workZoneList.unshift({
                    grpAttr: "*Any*"
                })
                $scope.values.newLogicals = $scope.workZoneList[0];

                $scope.relesedata = ["Deslot", "Reslot (Open slots)", "Reslot", "New Slots (Open slots)", "New Slots"];
                $scope.values.releaseData = $scope.relesedata[0];
            }

        });
        res.error(function(data, status, headers, config) {
            $("#showloader").css("display", "none");
            $scope.isFailed = true;
            $scope.resmessage = "System failed. Please try again or contact WAALOS Support";

        });
    };

	$scope.fnDsRelease = function(type) {
        $scope.isSuccess = false;
        $scope.isFailed = false;
        $scope.releaseGriddata = false;
        $scope.dsLotId = $scope.gridOptionsDataSource.data[0].lotId;
        $("#showloader").css("display", "block");
        if (type == 'add') {
            var url = '';          
                url = urlService.ATE_SLOTTING_SZ1_ADD_TASK.replace('dName', $scope.dcName).replace('uName', sessionStorage.userName);
                url = url.replace('wrktype',$scope.values.releaseData);
                url = url.replace('ulotid',  $scope.dsLotId);
          
            var res = $http.get(url, {
                    headers: {
                        'x-api-key': sessionStorage.apikey
                    }
                });
               // var res = $http.get('AddData.json');
                res.success(function(data) {
					 var newData = data.map(function(json, index) {
                     json.rowNum = index +1;
                      return json;
                     });  
                     data  = newData;

                    if (data.errorMessage) {
                        $scope.isSuccess = false;
                        $scope.isFailed = true;
                        $scope.resmessage = data.errorMessage;
                        $("#showloader").css("display", "none");
                        $scope.dsReleaseGriddata.data = [];
                        $scope.resmessage = data.errorMessage;
                    } else if (data.resMessage) {
                        $scope.isSuccess = true;
                        $scope.isFailed = false;
                        $scope.dsReleaseGriddata.data = [];
                        $scope.resmessage = data.resMessage;
                        $("#showloader").css("display", "none");

                    } else if($scope.dcName == 'Suzhou'){
                         $scope.dsReleaseGriddata.columnDefs = [{
                                name: 'rowNum',
                                displayName: 'Serial Number',
                                enableCellEdit: false,
                                cellTooltip: true,
                                headerTooltip: true,
                                cellTemplate: '<div class="ui-grid-cell-contents">{{grid.renderContainers.body.visibleRowCache.indexOf(row) + 1}}</div>'
                            },
                             {
                                name: 'fromZone',
                                displayName: 'From Zone',
                                enableCellEdit: false,
                                cellTooltip: true,
                                headerTooltip: true
                            },
                             {
                                name: 'fromLocnId',
                                displayName: 'From Location',
                                enableCellEdit: false,
                                cellTooltip: true,
                                headerTooltip: true
                            },
                            {
                                name: 'dspSku',
                                displayName: 'Display SKU',
                                enableCellEdit: false,
                                cellTooltip: true,
                                headerTooltip: true
                            },
                           
                            {
                                name: 'toLocnId',
                                displayName: 'To Location',
                                enableCellEdit: false,
                                cellTooltip: true,
                                headerTooltip: true
                            },
                            {
                                name: 'zoneType',
                                displayName: 'To Zone Type',
                                enableCellEdit: false,
                                cellTooltip: true,
                                headerTooltip: true
                            },
                            {
                                name: 'zoneValue',
                                displayName: 'To Zone Value',
                                width: 130,
                                enableCellEdit: false,
                                cellTooltip: true,
                                headerTooltip: true
                            },
                            {
                                name: 'slottingType',
                                displayName: 'Slotting Type',
                                width: 120,
                                enableCellEdit: false,
                                cellTooltip: true,
                                headerTooltip: true
                            },
                             {
                                name: 'quantity',
                                displayName: 'Actual Inventory Quantity',
                                enableCellEdit: false,
                                cellTooltip: true,
                                headerTooltip: true
                            },
                             {
                                name: 'division',
                                displayName: 'Prod Type',
                                enableCellEdit: false,
                                cellTooltip: true,
                                headerTooltip: true
                            }                           
                        ];
                        $scope.releaseGriddata = true;
                        $scope.releaseGrid = false;
                    
                        $scope.dsReleaseGriddata.data = data;

                        if ($scope.dsReleaseGriddata.data > 10) {
                            $scope.dsReleaseGriddata.enableVerticalScrollbar = true;
                            $scope.dsReleaseGriddata.enableHorizontalScrollbar = 1;
                        } else {
                            $scope.dsReleaseGriddata.enableVerticalScrollbar = false;
                            $scope.dsReleaseGriddata.enableHorizontalScrollbar = 1;
                        }

                    }

                    $('.ui-grid-pager-control input').prop("disabled", true);
                    $(document).on("click", ".ui-grid-menu-button", function() {
                        $timeout(function() {
                            $('.fa-download').remove();
                            $('#menuitem-7 button[type="button"]').prepend('<i class="fa fa-download" aria-hidden="true" style="color: #c9c9c9;"></i>');
                        })
                        $timeout(function() {
                            console.clear();
                        }, 3000)
                    });
                    $("#showloader").css("display", "none");

                });
            $(document).on('click', 'body', function() {
                $timeout(function() {
                    console.clear();
                }, 1000);

            });
            res.error(function(data) {
                $scope.isSuccess = false;
                $scope.isFailed = true;
                $scope.resmessage = data;
                $("#showloader").css("display", "none");
            })
        } else if (type == 'release') {
            url = urlService.ATE_SLOTTING_SZ1_RELEASE_TASK.replace('dName', $scope.dcName).replace('uName', sessionStorage.userName);
                url = url.replace('wrktype',$scope.values.releaseData);
                 url = url.replace('ulotid',  $scope.dsLotId);
                      var res = $http.get(url, {
            headers: {
                'x-api-key': sessionStorage.apikey
            }
        });
                res.success(function(data) {
                    if (data.errorMessage) {
                        $("#showloader").css("display", "none");
                        $scope.isSuccess = false;
                        $scope.isFailed = true;
                        $scope.resmessage = data.errorMessage;
                    } else if (data.resMessage) {
                        $scope.resmessage = data.resMessage;
                        $scope.goBack('release');

                        $timeout(function() {

                            $scope.isSuccess = true;
                            $scope.isFailed = false;
                            $("#showloader").css("display", "none");
                        }, 2000);
                    } else {
                        $scope.resmessage = data.resMessage;
                        $scope.goBack('release');

                        $timeout(function() {

                            $scope.isSuccess = true;
                            $scope.isFailed = false;
                            $("#showloader").css("display", "none");
                        }, 2000);
                    }
                }).error(function(data) {
                    $("#showloader").css("display", "none");
                    $scope.isSuccess = false;
                    $scope.isFailed = true;
                    $scope.resmessage = data.errorMessage;
                })
        } 
    }

 $scope.resetRelase = function() {
        $scope.isSuccess = false;
        $scope.isFailed = false;
        $scope.values.releaseData = 'DESLOT';
        $scope.releaseGriddata = false;
        $scope.releaseGrid = true;
    }

 //function to get back to the datasource tab data
    $scope.goBack = function(type) {
        if (type == 'release') {
            $scope.isReleseTask = false;
            $scope.isMianpage = true;
            $scope.dataSources();

        }
        $scope.dsGrid = true;
        $scope.dsGridPanel = false;
        $scope.dsReleaseGrid = false;
        $scope.isEdit = true;
        $scope.isDelete = true;

    }


    $scope.addWorkZones = function() {
        $scope.isSuccess = false;
        $scope.isFailed = false;
        if ($scope.values.newLogicals.grpAttr == "*Any*") {
            var grptypeData = ' ';
        } else {
            grptypeData = $scope.values.newLogicals.grpAttr
        }
        $("#showloader").css("display", "block");
        var url = urlService.ATE_SLOTTING_SJ_RELESE_TASK_ADD.replace('dName', $scope.pagedc);
        url = url.replace('uName', sessionStorage.userName);
        url = url.replace('gType', $scope.gType);
        url = url.replace('gAttr', grptypeData);


        var res = $http.get(url, {
            headers: {
                'x-api-key': sessionStorage.apikey
            }
        });

        res.success(function(data, status, headers, config) {
            $("#showloader").css("display", "none");
            if (data.errorMessage) {
                $scope.isFailed = true;
                $scope.resmessage = data.errorMessage;
            } else if (data.resMessage) {
                $scope.isSuccess = true;
                $scope.resmessage = data.resMessage;
            } else {
                if ($scope.values.newLogicals.grpAttr == "*Any*") {
                    $scope.wrkGrpAll = true;
                } else {
                    $scope.wrkGrpAll = false;
                }

                $scope.updatedVAL = [];
                $("#releaseModel").modal('show');
                $scope.workgroupsData = [];
                _.each(data, function(Dval, Dkey) {
                    $scope.workgroupsData.push({
                        'name': Dval.aisles,
                        'isChecked': false
                    });
                });

            }
        });
        res.error(function(data, status, headers, config) {
            $("#showloader").css("display", "none");
            $scope.isFailed = true;
            $scope.resmessage = "System failed. Please try again or contact WAALOS Support";

        });
    };

    $scope.lowerGrid = function() {

        $scope.isSuccessCancel = false;
        $scope.isFailedCancel = false;
        $scope.skubutton = true;
        $scope.values.dspNumber = " ";
        $("#showloader").css("display", "block");



        var workgroup_list = "";

        if ($scope.workgroupsData.length == 0 && $scope.wrkGrpAll != true) {
            $scope.isFailed = true;
            $scope.resmessage = "Please select at least one value";
            $("#showloader").css("display", "none");
            return false;

        }
        for (var key in $scope.workgroupsData) {
            if ($scope.workgroupsData.hasOwnProperty(key)) {
                if ($scope.workgroupsData[key].isChecked == true) {
                    workgroup_list += $scope.workgroupsData[key].name + ",";

                }
            }
        }
        workgroup_list = workgroup_list.slice(0, -1);

        if ($scope.wrkGrpAll) {
            workgroup_list = "";
        }

        if (workgroup_list == "") {
            workgroup_list = "";

        }


        if ($scope.values.newLogicals.grpAttr == "*Any*") {
            var grptypeData = "";
        } else {
            grptypeData = $scope.values.newLogicals.grpAttr
        }
        if ($scope.reqExchangeDto == undefined) {
            $scope.reqExchangeDto = [];
            $scope.reqExchangeDto.push({
                "grpType": $scope.gType,
                "wrkZone": grptypeData,
                "wrkType": $scope.values.releaseData,
                "aisles": workgroup_list
            });

        } else {
            $scope.reqExchangeDto.push({
                "grpType": $scope.gType,
                "wrkZone": grptypeData,
                "wrkType": $scope.values.releaseData,
                "aisles": workgroup_list
            });
            //$scope.reqExchangeDto.dataValues.push({ "grpType": $scope.gType, "wrkZone":  $scope.values.newLogicals.grpAttr, "wrkType": $scope.values.releaseData, "aisles": workgroup_list });
        }

        var dataObj = {
            "dcName": $scope.pagedc,
            "userName": sessionStorage.userName,
            "reqExchangeDto": $scope.reqExchangeDto,
            "getReleaseTasksLstDto": null,
            "getLeftGridTasksDto": null

        };
        var url = urlService.ATE_SLOTTING_SJ_RELESE_TASK_LOWERGRID;
        var res = $http.post(url, dataObj, {
            headers: {
                'x-api-key': sessionStorage.apikey
            }
        });


        $scope.workgropData = workgroup_list;


        res.success(function(data, status, headers, config) {
            $("#showloader").css("display", "none");
            if (data.errorMessage) {
                $scope.isFailedCancel = true;
                $scope.resmessageCancel = data.errorMessage;
            } else if (data.resMessage) {
                $scope.isSuccessCancel = true;
                $scope.resmessageCancel = data.resMessage;
            } else {
                $scope.reqExchangeDto = data.reqExchangeDto;


                if (data.getReleaseTasksLstDto.length == 0) {
                    $scope.isLowerGrid = false;
                    $scope.isSuccessCancel = true;
                    $scope.resmessageCancel = "No Record(s) Found";
                    $scope.releaseButton = true;
                    $scope.gridOptionsLower.data = "";
                    $scope.gridOptionsLower.data = [];

                } else {
                    $scope.isLowerGrid = true;
                    $scope.releaseButton = false;
                    $scope.gridOptionsLower.data = data.getReleaseTasksLstDto;
                    $scope.gridOptionsLower.columnDefs = [
                        /*{ name: 'cancel', displayName: 'Cancel', width: 100, enableCellEdit: false, cellTooltip: true, headerTooltip: true, cellTemplate: '<div class="ui-grid-cell-contents" ng-click="grid.appScope.cancelTask(grid, row)"><a>Cancel</a></div>' },*/
                        {
                            name: 'seq',
                            field: 'name',
                            width: 100,
                            cellTemplate: '<div class="ui-grid-cell-contents">{{grid.renderContainers.body.visibleRowCache.indexOf(row)+1}}</div>'
                        },
                        {
                            name: 'fromZone',
                            displayName: 'From Zone',
                            width: 120,
                            enableCellEdit: false,
                            cellTooltip: true,
                            headerTooltip: true
                        },
                        {
                            name: 'fromLocn',
                            displayName: 'From Locn',
                            width: 120,
                            enableCellEdit: false,
                            cellTooltip: true,
                            headerTooltip: true
                        },
                        {
                            name: 'dispalySku',
                            displayName: 'Display SKU',
                            width: 130,
                            enableCellEdit: false,
                            cellTooltip: true,
                            headerTooltip: true
                        },
                        {
                            name: 'actlInventory',
                            displayName: 'Actl Inventory',
                            width: 150,
                            enableCellEdit: false,
                            cellTooltip: true,
                            headerTooltip: true
                        },
                        {
                            name: 'toZone',
                            displayName: 'To Zone',
                            width: 100,
                            enableCellEdit: false,
                            cellTooltip: true,
                            headerTooltip: true
                        },
                        {
                            name: 'toLocn',
                            displayName: 'To Locn',
                            width: 100,
                            enableCellEdit: false,
                            cellTooltip: true,
                            headerTooltip: true
                        },
                        {
                            name: 'batch',
                            displayName: 'Batch Id',
                            width: 100,
                            enableCellEdit: false,
                            cellTooltip: true,
                            headerTooltip: true
                        },
                        {
                            name: 'stepValue',
                            displayName: 'Batch Step',
                            width: 120,
                            enableCellEdit: false,
                            cellTooltip: true,
                            headerTooltip: true
                        },
                        {
                            name: 'nullValue',
                            displayName: 'Std Case Qty',
                            width: 120,
                            enableCellEdit: false,
                            cellTooltip: true,
                            headerTooltip: true
                        },
                        {
                            name: 'nullVal1',
                            displayName: 'Tot. Cases',
                            width: 120,
                            enableCellEdit: false,
                            cellTooltip: true,
                            headerTooltip: true
                        },
                        {
                            name: 'prodType',
                            displayName: 'Division',
                            width: 100,
                            enableCellEdit: false,
                            cellTooltip: true,
                            headerTooltip: true
                        },
                        {
                            name: 'locnPick',
                            displayName: 'Locn Pick Seq',
                            width: 140,
                            enableCellEdit: false,
                            cellTooltip: true,
                            headerTooltip: true
                        }

                    ];
                }
                $scope.isLowerGrid = true;
                $scope.isLowerGridtable = true;
                $scope.isLowerGridSearchtable = false;
                if ($scope.gridOptionsLower.data.length != 0) {
                    $scope.isDatarelease = true;
                } else {
                    $scope.isDatarelease = false;
                }



                if ($scope.values.newLogicals.grpAttr == "*Any*") {
                    if ($scope.values.releaseData == "Reslot (Open slots)" || $scope.values.releaseData == "Reslot") {

                        var ateSzReleaseCntDtoData = [];
                        _.each($scope.gridOptions.data, function(val, key) {
                            var insertdata = true;

                            for (var i = 0; i < data.resltReleaseCntDto.length; i++) {

                                if ($scope.gridOptions.data[key].grpAttr == data.resltReleaseCntDto[i].grpAttr) {
                                    ateSzReleaseCntDtoData.push({
                                        grpAttr: data.resltReleaseCntDto[i].grpAttr,
                                        slotCntl: data.resltReleaseCntDto[i].slotCntl
                                    });
                                    var insertdata = false;
                                }
                            }
                            if (insertdata) {
                                ateSzReleaseCntDtoData.push({
                                    grpAttr: $scope.gridOptions.data[key].grpAttr,
                                    slotCntl: null
                                });
                            }

                        });
                        var j = 0;

                        _.each($scope.gridOptions.data, function(val, key) {
                            var temp = false;
                            for (var i = 0; i < ateSzReleaseCntDtoData.length; i++) {

                                if (val.grpAttr == ateSzReleaseCntDtoData[i].grpAttr) {
                                    $scope.gridOptions.data[key].reslotOpenCnt = ateSzReleaseCntDtoData[j].slotCntl;
                                    i = ateSzReleaseCntDtoData.length;
                                    temp = true;
                                }



                            }
                            if (temp) {
                                j += 1;
                            }

                        });

                        var ateSzReleaseCntDtoDataout = [];
                        _.each($scope.gridOptions.data, function(val, key) {
                            var insertdataout = true;

                            for (var i = 0; i < data.ateSzReleaseCntDto.length; i++) {

                                if ($scope.gridOptions.data[key].grpAttr == data.ateSzReleaseCntDto[i].grpAttr) {
                                    ateSzReleaseCntDtoDataout.push({
                                        grpAttr: data.ateSzReleaseCntDto[i].grpAttr,
                                        slotCntl: data.ateSzReleaseCntDto[i].slotCntl
                                    });
                                    var insertdataout = false;
                                }
                            }
                            if (insertdataout) {
                                ateSzReleaseCntDtoDataout.push({
                                    grpAttr: $scope.gridOptions.data[key].grpAttr,
                                    slotCntl: null
                                });
                            }

                        });
                        var k = 0;

                        _.each($scope.gridOptions.data, function(val, key) {
                            var tempout = false;
                            for (var i = 0; i < ateSzReleaseCntDtoDataout.length; i++) {

                                if (val.grpAttr == ateSzReleaseCntDtoDataout[i].grpAttr) {
                                    $scope.gridOptions.data[key].reslotCnt = ateSzReleaseCntDtoDataout[k].slotCntl;
                                    i = ateSzReleaseCntDtoDataout.length;
                                    tempout = true;
                                }



                            }
                            if (tempout) {
                                k += 1;
                            }

                        });




                    } else {
                        var ateSzReleaseCntDtoData = [];
                        _.each($scope.gridOptions.data, function(val, key) {
                            var insertdata = true;

                            for (var i = 0; i < data.ateSzReleaseCntDto.length; i++) {

                                if ($scope.gridOptions.data[key].grpAttr == data.ateSzReleaseCntDto[i].grpAttr) {
                                    ateSzReleaseCntDtoData.push({
                                        grpAttr: data.ateSzReleaseCntDto[i].grpAttr,
                                        slotCntl: data.ateSzReleaseCntDto[i].slotCntl
                                    });
                                    var insertdata = false;
                                }
                            }
                            if (insertdata) {
                                ateSzReleaseCntDtoData.push({
                                    grpAttr: $scope.gridOptions.data[key].grpAttr,
                                    slotCntl: null
                                });
                            }

                        });

                        if (data.ateSzReleaseCntDto.length != 0) {

                            var j = 0;

                            _.each($scope.gridOptions.data, function(val, key) {
                                var temp = false;
                                for (var i = 0; i < ateSzReleaseCntDtoData.length; i++) {
                                    if ($scope.values.releaseData == "Deslot") {
                                        if (val.grpAttr == ateSzReleaseCntDtoData[i].grpAttr) {
                                            $scope.gridOptions.data[key].deslotCntl = ateSzReleaseCntDtoData[j].slotCntl;
                                            i = ateSzReleaseCntDtoData.length;
                                            temp = true;
                                        }
                                    } else if ($scope.values.releaseData == "Reslot (Open slots)") {
                                        if (val.grpAttr == ateSzReleaseCntDtoData[i].grpAttr) {
                                            $scope.gridOptions.data[key].reslotCnt = ateSzReleaseCntDtoData[j].slotCntl;
                                            i = ateSzReleaseCntDtoData.length;
                                            temp = true;
                                        }
                                    } else if ($scope.values.releaseData == "Reslot") {
                                        if (val.grpAttr == ateSzReleaseCntDtoData[i].grpAttr) {
                                            $scope.gridOptions.data[key].reslotOpenCnt = ateSzReleaseCntDtoData[j].slotCntl;
                                            i = ateSzReleaseCntDtoData.length;
                                            temp = true;
                                        }
                                    } else if ($scope.values.releaseData == "New Slots (Open slots)" || $scope.values.releaseData == "New Slots") {
                                        if (val.grpAttr == ateSzReleaseCntDtoData[i].grpAttr) {
                                            $scope.gridOptions.data[key].newslotCnt = ateSzReleaseCntDtoData[j].slotCntl;
                                            i = ateSzReleaseCntDtoData.length;
                                            temp = true;
                                        }
                                    }


                                }
                                if (temp) {
                                    j += 1;
                                }

                            });
                        }
                    }
                } else if (data.resltReleaseCntDto != null) {

                    var ateSzReleaseCntDtoData = [];
                    _.each($scope.gridOptions.data, function(val, key) {
                        var insertdata = true;

                        for (var i = 0; i < data.resltReleaseCntDto.length; i++) {

                            if ($scope.gridOptions.data[key].grpAttr == data.resltReleaseCntDto[i].grpAttr) {
                                ateSzReleaseCntDtoData.push({
                                    grpAttr: data.resltReleaseCntDto[i].grpAttr,
                                    slotCntl: data.resltReleaseCntDto[i].slotCntl
                                });
                                var insertdata = false;
                            }
                        }
                        if (insertdata) {
                            ateSzReleaseCntDtoData.push({
                                grpAttr: $scope.gridOptions.data[key].grpAttr,
                                slotCntl: null
                            });
                        }

                    });
                    var j = 0;

                    _.each($scope.gridOptions.data, function(val, key) {
                        var temp = false;
                        for (var i = 0; i < ateSzReleaseCntDtoData.length; i++) {

                            if (val.grpAttr == ateSzReleaseCntDtoData[i].grpAttr) {
                                $scope.gridOptions.data[key].reslotOpenCnt = ateSzReleaseCntDtoData[j].slotCntl;
                                i = ateSzReleaseCntDtoData.length;
                                temp = true;
                            }



                        }
                        if (temp) {
                            j += 1;
                        }

                    });

                    _.each($scope.gridOptions.data, function(val, key) {
                        for (var i = 0; i < data.ateSzReleaseCntDto.length; i++) {
                            if (data.ateSzReleaseCntDto[i].grpAttr == val.grpAttr) {

                                if ($scope.values.releaseData == "Reslot" || $scope.values.releaseData == "Reslot (Open slots)") {
                                    $scope.gridOptions.data[key].reslotCnt = data.ateSzReleaseCntDto[i].slotCntl;
                                }
                            }
                        }

                    });



                } else {

                    if (data.ateSzReleaseCntDto.length != 0) {
                        _.each($scope.gridOptions.data, function(val, key) {
                            for (var i = 0; i < data.ateSzReleaseCntDto.length; i++) {
                                if (data.ateSzReleaseCntDto[i].grpAttr == val.grpAttr) {
                                    if ($scope.values.releaseData == "Deslot") {
                                        $scope.gridOptions.data[key].deslotCntl = data.ateSzReleaseCntDto[i].slotCntl;
                                    }
                                    if ($scope.values.releaseData == "Reslot (Open slots") {
                                        $scope.gridOptions.data[key].reslotOpenCnt = data.ateSzReleaseCntDto[i].slotCntl;
                                    }
                                    if ($scope.values.releaseData == "Reslot") {
                                        $scope.gridOptions.data[key].reslotCnt = data.ateSzReleaseCntDto[i].slotCntl;
                                    }
                                    if ($scope.values.releaseData == "New Slots (Open slots)" || $scope.values.releaseData == "New Slots") {
                                        $scope.gridOptions.data[key].newslotCnt = data.ateSzReleaseCntDto[i].slotCntl;
                                    }




                                }

                            }


                        });
                    }

                }



                if ($scope.gridOptionsLower.data > 10) {
                    $scope.gridOptionsLower.enableVerticalScrollbar = true;
                    $scope.gridOptionsLower.enableHorizontalScrollbar = 1;
                } else {
                    $scope.gridOptionsLower.enableVerticalScrollbar = false;
                    $scope.gridOptionsLower.enableHorizontalScrollbar = 1;
                }
            }

        });
        res.error(function(data, status, headers, config) {
            $("#showloader").css("display", "none");
            $scope.isFailedCancel = true;
            $scope.resmessageCancel = "System failed. Please try again or contact WAALOS Support";

        });

    };

    $scope.backtorelease = function() {
        $scope.isLowerGrid = true;
        $scope.isLowerGridtable = true;
        $scope.isLowerGridSearchtable = false;
    }



    $scope.updateLowergrid = function(noRecords) {
        $scope.isFailedCancel = false;
        $scope.isSuccessCancel = false;
        $scope.isLowerGridtable = false;
        $("#showloader").css("display", "block");

        $scope.gridOptionsLowerSearch.data = "";

        var url = urlService.ATE_SLOTTING_SJ_RELESE_TASK_LOWERGRID_SEARCH.replace('dName', $scope.pagedc);
        url = url.replace('uName', sessionStorage.userName);
        url = url.replace('gType', $scope.gType);
        url = url.replace('gAttr', $scope.values.newLogicals.grpAttr);
        url = url.replace('WTypr', $scope.values.releaseData);
        url = url.replace('ailas', $scope.workgropData);
        url = url.replace('dspNum', $scope.values.dspNumber);
        url = decodeURI(url);


        var res = $http.get(url, {
            headers: {
                'x-api-key': sessionStorage.apikey
            }
        });

        res.success(function(data, status, headers, config) {
            $("#showloader").css("display", "none");
            if (data.errorMessage) {
                $scope.isFailedCancel = true;
                $scope.resmessageCancel = data.errorMessage;
            } else if (data.resMessage) {
                $scope.isSuccessCancel = true;
                $scope.resmessageCancel = data.resMessage;
            } else {

                $scope.gridOptionsLowerSearch.columnDefs = [
                    /*{ name: 'cancel', displayName: 'Cancel', width: 100, enableCellEdit: false, cellTooltip: true, headerTooltip: true, cellTemplate: '<div class="ui-grid-cell-contents" ng-click="grid.appScope.cancelTask(grid, row)"><a>Cancel</a></div>' },*/

                    {
                        name: 'fromZone',
                        displayName: 'From Zone',
                        width: 100,
                        enableCellEdit: false,
                        cellTooltip: true,
                        headerTooltip: true
                    },
                    {
                        name: 'fromLocn',
                        displayName: 'From Locn',
                        width: 100,
                        enableCellEdit: false,
                        cellTooltip: true,
                        headerTooltip: true
                    },
                    {
                        name: 'dispalySku',
                        displayName: 'Display SKU',
                        width: 130,
                        enableCellEdit: false,
                        cellTooltip: true,
                        headerTooltip: true
                    },
                    {
                        name: 'actlInventory',
                        displayName: 'Actl Inventory',
                        width: 100,
                        enableCellEdit: false,
                        cellTooltip: true,
                        headerTooltip: true
                    },
                    {
                        name: 'toZone',
                        displayName: 'To Zone',
                        width: 100,
                        enableCellEdit: false,
                        cellTooltip: true,
                        headerTooltip: true
                    },
                    {
                        name: 'toLocn',
                        displayName: 'To Locn',
                        width: 100,
                        enableCellEdit: false,
                        cellTooltip: true,
                        headerTooltip: true
                    },
                    {
                        name: 'batch',
                        displayName: 'Batch',
                        width: 100,
                        enableCellEdit: false,
                        cellTooltip: true,
                        headerTooltip: true
                    },
                    {
                        name: 'stepValue',
                        displayName: 'Step Value',
                        width: 100,
                        enableCellEdit: false,
                        cellTooltip: true,
                        headerTooltip: true
                    },
                    {
                        name: 'nullValue',
                        displayName: 'Null Value',
                        width: 100,
                        enableCellEdit: false,
                        cellTooltip: true,
                        headerTooltip: true
                    },
                    {
                        name: 'nullVal1',
                        displayName: 'Null Val1',
                        width: 100,
                        enableCellEdit: false,
                        cellTooltip: true,
                        headerTooltip: true
                    },
                    {
                        name: 'prodType',
                        displayName: 'Prod Type',
                        width: 100,
                        enableCellEdit: false,
                        cellTooltip: true,
                        headerTooltip: true
                    },
                    {
                        name: 'locnPick',
                        displayName: 'Locn Pick',
                        width: 100,
                        enableCellEdit: false,
                        cellTooltip: true,
                        headerTooltip: true
                    }

                ];
                $scope.isLowerGridSearchtable = true;

                $scope.gridOptionsLowerSearch.data = data;


                if ($scope.gridOptionsLowerSearch.data > 10) {
                    $scope.gridOptionsLowerSearch.enableVerticalScrollbar = true;
                    $scope.gridOptionsLowerSearch.enableHorizontalScrollbar = 1;
                } else {
                    $scope.gridOptionsLowerSearch.enableVerticalScrollbar = false;
                    $scope.gridOptionsLowerSearch.enableHorizontalScrollbar = 1;
                }


            }

        });
        res.error(function(data, status, headers, config) {
            $("#showloader").css("display", "none");
            $scope.isFailedCancel = true;
            $scope.resmessageCancel = "System failed. Please try again or contact WAALOS Support";

        });


    };


    $scope.skubutton = true;
    $scope.displaySkuValidation = function() {
        if ($scope.values.dspNumber == null || $scope.values.dspNumber == undefined || $scope.values.dspNumber.length == 0) {
            $scope.skubutton = true;
        } else {
            $scope.skubutton = false;
        }
    };

    $scope.cancelTask = function(grid, row) {
        $scope.isFailedCancel = false;
        $scope.isSuccessCancel = false;

        if (grid) {
            $("#CancelModal").modal('show');
            $scope.cancellingData = row;
        } else {
            $("#showloader").css("display", "block");
            var postData = {
                "dcName": $scope.pagedc,
                "userName": sessionStorage.userName,
                "fromZone": $scope.cancellingData.entity.fromZone,
                "fromLocn": $scope.cancellingData.entity.fromLocn,
                "dispalySku": $scope.cancellingData.entity.dispalySku,
                "actlInventory": $scope.cancellingData.entity.actlInventory,
                "toZone": $scope.cancellingData.entity.toZone,
                "toLocn": $scope.cancellingData.entity.toLocn,
                "batch": $scope.cancellingData.entity.batch,
                "stepValue": $scope.cancellingData.entity.stepValue,
                "nullValue": $scope.cancellingData.entity.nullValue,
                "nullVal1": $scope.cancellingData.entity.nullVal1,
                "prodType": $scope.cancellingData.entity.prodType,
                "locnPick": $scope.cancellingData.entity.locnPick

            };
            var res = $http.put(urlService.ATE_SLOTTING_SJ_RELESE_TASK_CANCEL, postData, {
                headers: {
                    'x-api-key': sessionStorage.apikey
                }
            });

            res.success(function(data, status, headers, config) {
                $("#showloader").css("display", "none");

                if (data.errorMessage) {
                    $scope.isFailedCancel = true;
                    $scope.resmessageCancel = data.errorMessage;

                } else if (data.resMessage) {
                    $scope.isSuccessCancel = true;
                    $scope.resmessageCancel = data.resMessage;

                }
            });
            res.error(function(data, status, headers, config) {
                $("#showloader").css("display", "none");
                $scope.isFailedCancel = true;
                $scope.resmessageCancel = "System failed. Please try again or contact WAALOS Support";

            });

        }

    };

  /*  $scope.runAslot = function(grid, row) {
        $scope.isFailed = false;
        $scope.isFailed = false;
        if (grid) {
            $("#runaslotModel").modal('show');

            $scope.runASlot = row;
        } else {
            $("#showloader").css("display", "block");
            var url = urlService.ATE_SLOTTING_RUN_A_SLOT.replace('dName', $scope.dcName).replace('uName', sessionStorage.userName).replace('ulotid', $scope.runASlot.entity.lotId);
            url = url.replace('gType', $scope.runASlot.entity.grpType);

            var res = $http.post(url,null, {
                headers: {
                    'x-api-key': sessionStorage.apikey
                }
            });

            res.success(function(data, status, headers, config) {
                $("#showloader").css("display", "none");

                if (data.errorMessage) {
                    $scope.isFailed = true;
                    $scope.resmessage = data.errorMessage;

                } else if (data.resMessage) {
                    $("#showloader").css("display", "block");
                    setTimeout(function() {
                        $("#showloader").css("display", "none");
                        $scope.dataSources();
                        $scope.isSuccess = true;
                        $scope.resmessage = data.resMessage;
                    }, 10000);

                }
            });
            res.error(function(data, status, headers, config) {
                $("#showloader").css("display", "none");
                $scope.isFailed = true;
                $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
            });
        }
    };*/

    $scope.runAslot = function(grid, row) {

        $scope.dsLotId = $scope.gridOptionsDataSource.data[0].lotId;
        $scope.isFailed = false;
        $scope.isFailed = false;
        var url = urlService.ATE_SLOTTING_SZ1_DYNAMIC_DETAILS.replace('dName', $scope.pagedc);
        url = url.replace('uName', sessionStorage.userName);
        url = url.replace('ulotid', $scope.dsLotId);
        //var res = $http.get("expand.json");
        var res = $http.get(url, {
                  headers: {
                      'x-api-key': sessionStorage.apikey
                  }
        });
        res.success(function(data, status, headers, config) {
            $("#showloader").css("display", "none");
            if (data.enoughDynamicLocns == true) {
                $scope.resmessage_runaslot = '';
                $("#showloader").css("display", "block");
                var url = urlService.ATE_SLOTTING_RUN_A_SLOT.replace('dName', $scope.dcName).replace('uName', sessionStorage.userName).replace('ulotid', $scope.dsLotId);
                url = url.replace('gType', 96);

                var res = $http.post(url, null, {
                    headers: {
                        'x-api-key': sessionStorage.apikey
                    }
                });

                res.success(function(data, status, headers, config) {
                    $("#showloader").css("display", "none");
                    if (data.errorMessage) {
                        $scope.isFailed = true;
                        $scope.resmessage = data.errorMessage;
                    } else if (data.resMessage) {
                        $("#showloader").css("display", "block");
                        setTimeout(function() {
                            $("#showloader").css("display", "none");
                            $scope.dataSources();
                            $scope.isSuccess = true;
                            $scope.resmessage = data.resMessage;
                            $(".container-message").css("display", "none");
                        }, 10000);
                    }
                });
                res.error(function(data, status, headers, config) {
                    $("#showloader").css("display", "none");
                    $scope.isFailed = true;
                    $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
                });
            } else {
                $scope.resmessage_runaslot = 'Not Enough Dynamic Location Available';
                if (grid) {
                    $("#runaslotModel").modal('show');
                    $scope.runASlot = row;
                } else {
                    $("#showloader").css("display", "block");
                    var url = urlService.ATE_SLOTTING_RUN_A_SLOT.replace('dName', $scope.dcName).replace('uName', sessionStorage.userName).replace('ulotid', $scope.dsLotId);
                    url = url.replace('gType', 96);
                    var res = $http.post(url, null, {
                        headers: {
                            'x-api-key': sessionStorage.apikey
                        }
                    });
                    res.success(function(data, status, headers, config) {
                        $("#showloader").css("display", "none");
                        if (data.errorMessage) {
                            $scope.isFailed = true;
                            $scope.resmessage = data.errorMessage;

                        } else if (data.resMessage) {
                            $("#showloader").css("display", "block");
                            setTimeout(function() {
                                $("#showloader").css("display", "none");
                                $scope.dataSources();
                                $scope.isSuccess = true;
                                $scope.resmessage = data.resMessage;
                                $(".container-message").css("display", "none");
                            }, 10000);
                        }
                    });
                    res.error(function(data, status, headers, config) {
                        $("#showloader").css("display", "none");
                        $scope.isFailed = true;
                        $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
                    });
                }
            }
        });
        res.error(function(data, status, headers, config) {
            $("#showloader").css("display", "none");
            $scope.isFailed = true;
            $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
        });
    };

    $scope.fnRejectList = function() {

        $scope.dsLotId = $scope.gridOptionsDataSource.data[0].lotId;
        
        $scope.isSuccesszone = false;
        $scope.isFailedzone = false;
        $scope.isDeleteZone = true;
        $scope.isSaveProb = true;
        
        $("#showloader").css("display", "block");
        var url = urlService.ATE_SLOTTING_SZ_REJECT_LIST.replace('dName', $scope.pagedc);
        url = url.replace('uName', sessionStorage.userName);
        url = url.replace('ulotid',$scope.dsLotId);
        var res = $http.get(url, {
            headers: {
                'x-api-key': sessionStorage.apikey
            }
        });
        res.success(function(data) {
            angular.forEach(data, function(value, index){
                  console.log(value.lotId);
            });
            $("#showloader").css("display", "none");
            $scope.rejectData = data;
        });
        res.error(function(data, status, headers, config) {
            $("#showloader").css("display", "none");
            $scope.isFailedzone = true;
            $scope.resmessagezone = "System failed. Please try again or contact WAALOS Support";

        });
    };

    $scope.release = function() {

        $scope.isFailed = false;
        $scope.isFailed = false;
        $("#showloader").css("display", "block");

        var postData = {
            "dcName": $scope.pagedc,
            "username": sessionStorage.userName,
            "grpType": $scope.gType,
            "wrkType": $scope.values.releaseData,
            "wrkZone": $scope.values.newLogicals.grpAttr,
            "aisles": $scope.workgropData
        };

        var res = $http.put(urlService.ATE_SLOTTING_SJ_RELESE, postData, {
            headers: {
                'x-api-key': sessionStorage.apikey
            }
        });

        res.success(function(data, status, headers, config) {
            $("#showloader").css("display", "none");

            if (data.errorMessage) {
                $scope.isFailed = true;
                $scope.resmessage = data.errorMessage;

            } else if (data.resMessage) {

                $scope.backSource();
                $timeout(function() {
                    $scope.isSuccess = true;
                    $scope.resmessage = data.resMessage;
                }, 2000);




            }
        });
        res.error(function(data, status, headers, config) {
            $("#showloader").css("display", "none");
            $scope.isFailed = true;
            $scope.resmessage = "System failed. Please try again or contact WAALOS Support";

        });
    };

    //user favourites code start
    $scope.isClicked = false;
    $scope.addToFavourate = function(isClicked) {
        $("#showloader").css("display", "block");
        if (typeof isClicked !== "boolean") {
            commonService.postServiceResponse(urlService.GET_FAVOURITES, {
                    "username": sessionStorage.userName
                })
                .then(function(response) {
                    $("#showloader").css("display", "none");
                    _.each(response, function(val, key) {
                        if (val.funName == $scope.functionality && val.dcName == $scope.dcName) {
                            $scope.isClicked = true;
                        }
                    })
                }, function(error) {
                    $("#showloader").css("display", "none");
                    $scope.isClicked = false;
                });
            //$scope.isClicked = ;
        } else {
            if (!$scope.isClicked) {
                commonService.postServiceResponse(urlService.ADD_FAVOURITE, {
                        "username": sessionStorage.userName,
                        "dcName": $scope.dcName,
                        "funName": $scope.functionality
                    })
                    .then(function(response) {
                        $("#showloader").css("display", "none");
                        if (response.errorMessage) {
                            $scope.isFavouriteAdded = false;
                            $scope.isClicked = false;
                            $scope.$broadcast('showAlert', ['']);
                        } else {
                            $scope.isClicked = true;
                            $scope.isClicked = !isClicked;
                            $scope.isFavouriteAdded = true;
                            $scope.favouriteMsg = response.resMessage;
                            $scope.$broadcast('ClickedOnFavourate', [$scope.dcName, $scope.functionality, $scope.isClicked]);
                        }

                    }, function(error) {
                        $scope.isClicked = false;
                        $("#showloader").css("display", "none");
                    });
                $scope.isClicked = !isClicked;
            } else {
                $("#showloader").css("display", "none");
            }
        }

    }
    $scope.addToFavourate('load');
}]);
