var app = angular.module('PalletCountEstimator');

app.controller('PalletCountEstimatorController', ['$scope', '$http', '$q', '$interval', '$timeout','urlService','uiGridConstants','commonService', function ($scope, $http, $q, $interval, $timeout,urlService,uiGridConstants,commonService) {
  $scope.isSuccess = false;
  $scope.isFailed = false;
  $scope.isEmpty = false;
  $scope.dataList = [];
  $scope.disable = true;
  $scope.loadNumberError = false;
  $scope.pagefunctionality = $scope.functionality;
  $scope.pagedc = $scope.dcName;
  $scope.resmessage = "";
  //loadNumberRe = /^([\d]+[ ,]){0,999}([\d]+){1}$/;
$("#Load-Number").focus();
// $("#Pallet-Height").focus();
  $("#showloader").css("display", "none");


/**
	This function is used to call, when user press Enter button from the keyboard
**/
  $('#Load-Number','#Pallet-Height').keyup(function (e){
    if($scope.loadNumber && $scope.palletHeight && e.keyCode == 13){
	$scope.disable = false;
        $scope.palletCountEstimator();
    }
  });
  /**
	This function is used to estimate by sending the required data to backend
**/
  $scope.palletCountEstimator = function(){
	if($scope.form.$valid){
	$scope.isSuccess = false;
	$scope.isFailed = false;
	$("#showloader").css("display", "block");
  var loadNumbers = $scope.loadNumber.split(/[ ,]/g);
	var payload = {
		"palletHeight": $scope.palletHeight,
		"loadNumber":loadNumbers,
		"dcName":$scope.pagedc,
		"userName":sessionStorage.userName
	};
	console.log(payload);
	var res = $http.post(urlService.PALLET_COUNT_ESTIMATOR,payload, {
		headers: {'x-api-key': sessionStorage.apikey} 
	});
	res.success(function (data, status, headers, config) {
	  $("#showloader").css("display", "none");
      $scope.dataList = data;
	  $scope.isSuccess = true;
	  if(!$scope.dataList.length){
		$scope.resmessage = "Cannot fetch Data for given Load Number(s) ";
		$scope.isEmpty = true;
	  }
	});
	res.error(function (data, status, headers, config) {
	  $("#showloader").css("display", "none");
		$scope.isFailed = true;
		$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
	});
	 }else{
		$scope.form.loadNumber.$setTouched(true);
		$scope.form.palletHeight.$setTouched(true);
	}
  };
//user favourites code start
$scope.isClicked = false;

$scope.addToFavourate = function(isClicked){
    $("#showloader").css("display", "block");
     if(typeof isClicked !== "boolean"){
      commonService.postServiceResponse(urlService.GET_FAVOURITES,{"username": sessionStorage.userName})
        .then(function(response){
          $("#showloader").css("display", "none");
            _.each(response,function(val,key){
              if(val.funName == $scope.functionality && val.dcName == $scope.dcName){
                $scope.isClicked = true;      
              }
            });
        },function(error){
          $("#showloader").css("display", "none");
          $scope.isClicked = false; 
        });
        //$scope.isClicked = ;
     }else{
      if(!$scope.isClicked){
        commonService.postServiceResponse(urlService.ADD_FAVOURITE,{"username": sessionStorage.userName,"dcName":$scope.dcName,"funName":$scope.functionality})
        .then(function(response){
          $("#showloader").css("display", "none");
          if(response.errorMessage){
            $scope.isFavouriteAdded= false; 
            $scope.isClicked = false;      
            $scope.$broadcast('showAlert',['']);
          }else{
            $scope.isClicked = true;      
            $scope.isClicked = !isClicked;
            $scope.isFavouriteAdded= true; 
            $scope.favouriteMsg = response.resMessage;
          $scope.$broadcast('ClickedOnFavourate',[$scope.dcName,$scope.functionality,$scope.isClicked]);
          }
            
        },function(error){
          $scope.isClicked = false;
          $("#showloader").css("display", "none");
        });
        $scope.isClicked = !isClicked;
      }else{
        $("#showloader").css("display", "none");
      }
     }
    
  };
  $scope.addToFavourate('load');
  //user favourites code ends

}]);


