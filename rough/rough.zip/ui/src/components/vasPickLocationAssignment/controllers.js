var app = angular.module('VasPickLocationAssignment', ['ngAnimate', 'ui.grid', 'ui.grid.selection', 'ui.grid.edit', 'ui.grid.cellNav', 'ui.grid.validate', 'ui.grid.exporter']);

app.controller('VasPickLocationAssignmentController', ['$scope', '$http', '$q', '$interval', 'uiGridValidateService', '$timeout', 'urlService', 'uiGridConstants', 'commonService', 'uiGridExporterService', 'uiGridExporterConstants', function ($scope, $http, $q, $interval, uiGridValidateService, $timeout, urlService, uiGridConstants, commonService, uiGridExporterService, uiGridExporterConstants) {
	var pr = this;
	$scope.pagefunctionality = $scope.functionality;
	$scope.pagedc = $scope.dcName;
	pr.isClicked = false;
	$scope.selectedInventory = [];
	$scope.pickTickets = [];
	$scope.users = [];
	$scope.waveStatCode = [];
	$scope.allocType = [];
	$scope.previousWaveStatCode = [];
	$scope.previousAllocType = [];
	$scope.preWaveNbr;
	$scope.pickWaveAllocType = '';
	$scope.preVasZoneAllocType = '';
	$scope.noOfCases;
	$scope.emptyLocations;
	$scope.warehouseZone;
	$scope.hideclr=true;



	$scope.clearCache = function () {
		$scope.formData.prewaveNbr = "";
		$scope.formData.pickWaveAlloctionType = "";
		$scope.formData.preVasZone = "";
		$scope.formData.noOfCases = "";
		$scope.formData.emptyLocations = "";
		$scope.formData.warehouseZone = "";
		$scope.isFailed = false;
        $scope.isSuccess = false;

	};


	$scope.clearFile = function () {
        $scope.isFailed = false;
        $scope.isSuccess = false;
	};
	
	$scope.getPreWaveDtls = function ($event) {
		$scope.isSuccess = false;
		$scope.isFailed = false;
		$scope.isEdit = true;
		$scope.isDelete = true;
		$scope.isMianpage = true;
		$scope.isEditdataSources = false;
		$scope.isEditSlotGroup = false;
		var keyCode = $event.which || $event.keyCode;
		//$scope.pagedc = 'US1';
		if (keyCode === 13) {
			var url = urlService.VAS_PICK_GET_DTLS.replace('dName', $scope.pagedc);
			url = url.replace('uName', sessionStorage.userName);
			url = url.replace('wNumber', $scope.formData.prewaveNbr);
			var res = $http.get(url, { headers: { 'x-api-key': sessionStorage.apikey } });

			res.success(function (data, status, headers, config) {
				$("#showloader").css("display", "none");
				if (data.errorMessage) {
					$scope.isFailed = true;
					$scope.resmessage = data.errorMessage;
				} else if (data.resMessage) {
					$scope.isSuccess = true;
					$scope.resmessage = data.resMessage;
				} else {
					$scope.formData.pickWaveAlloctionType = data.vasPickAllocationTypeDto[0].waveStatCode;
					$scope.formData.preVasZone = data.vasPickPreVasZoneDto[0].waveParam;
					$("#showloader").css("display", "none");
				}
				$('.ui-grid-pager-control input').prop("disabled", true);
			});
			res.error(function (data, status, headers, config) {
				$("#showloader").css("display", "none");
				$scope.isFailed = true;
			});
		};
	}

	$scope.assignLocations = function (value) {
		var validationsuccess = 'true';
		$scope.isFailed = 'false';
		var caseMsg = '';
		var emptyLocMsg = '';
		if (!($scope.formData.noOfCases >= 1)) {
			$scope.isFailed = true;
			caseMsg = "1)Cases Per Location should be greater than or equal to one                                                     \n";
		}
		if (!($scope.formData.emptyLocations >= 0)) {
			$scope.isFailed = true;
			emptyLocMsg = "2)Empty locations should be greater than or equal to zero";
		}
		if ($scope.isFailed === 'false') {
			$scope.isFailed = false;
			$scope.assign(value);
		} else {
			$scope.resmessage = caseMsg + ' ' + emptyLocMsg;
		}
	}

	$scope.assign = function (value) {
		$scope.isSuccess = false;
		$scope.isFailed = false;
		$("#showloader").css("display", "block");

		var payload = {
			"dcName": $scope.pagedc,
			"userName": sessionStorage.userName,
			"prewaveAllocType": $scope.formData.pickWaveAlloctionType,
			"preVasZone": $scope.formData.preVasZone,
			"warehouseZone": $scope.formData.warehouseZone,
			"prewaveNbr": $scope.formData.prewaveNbr,
			"emptyLocnBeforeAssignment": $scope.formData.emptyLocations,
			"noOfCasesBeforeAllocation": $scope.formData.noOfCases,
			"allocTypeAccept": value
		}

		var res = $http.post(urlService.VAS_PICK_ASSIGN, payload, {
			headers: { 'x-api-key': sessionStorage.apikey }
		});
		res.success(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			if (data.errorMessage) {
				$scope.isFailed = true;

				if (data.errorMessage.indexOf('Zones not the same') >= 0) {
					$("#addModel").modal('show');
				} else {
					$scope.resmessage = data.errorMessage;
					$("#addModel").modal('hide');
				}

			} else {
				$scope.isSuccess = true; 
				$scope.resmessage = data.resMessage;
			}
			$("#showloader").css("display", "none");
			$('.ui-grid-pager-control input').prop("disabled", true);

		});
		res.error(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			$scope.isFailed = true;
			$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
		});
	}
}]);
