var app = angular.module('UserProfile', []);

app.controller('UserProfileController', ['$scope', '$http', '$q', '$interval', '$timeout', 'urlService', 'uiGridConstants', 'commonService', function ($scope, $http, $q, $interval, $timeout, urlService, uiGridConstants, commonService) {

  $scope.isSuccess = false;
  $scope.isFailed = false;

  $scope.userLogin = sessionStorage.userName;
  $scope.firstName = sessionStorage.fName;
  $scope.lastName = sessionStorage.lName;
  $scope.emailAddress = sessionStorage.emailId;
  $scope.userGroup = sessionStorage.ugName;


  $scope.printerlist = function () {
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $("#showloader").css("display", "block");

    var url = urlService.USER_PROFILE_PRINTERS.replace('uName', $scope.userLogin);

    var res = $http.get(url, {
      // headers: {'x-api-key': sessionStorage.apikey}
    });

    res.success(function (data, status, headers, config) {

      $("#showloader").css("display", "none");

      if (data.errorMessage) {
        $scope.isTable = false;
        $scope.isFailed = true;
        $scope.resmessage = data.errorMessage;
      }
      else if (data.resMessage) {
        $scope.isTable = false;
        $scope.isSuccess = true;
        $scope.resmessage = data.resMessage;
      }

      else {
        $scope.printerslist = data;
        $scope.printer = $scope.printerslist[0];


      }

    });

    res.error(function (data, status, headers, config) {
      $("#showloader").css("display", "none");
      $scope.isFailed = true;
      $scope.resmessage = "System failed. Please try again or contact WAALOS Support";

    });

  };
  $scope.printerlist();

  $scope.saveData = function () {
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $("#showloader").css("display", "block");

    var postData = {
      "userId": $scope.userLogin,
      "dcName": $scope.printer.printerDcName,


      "printerId": $scope.printer.printerId

    };

    var res = $http.post(urlService.USER_PROFILE_SAVE_PRINTER, postData, {
      // headers: {'x-api-key': sessionStorage.apikey}
    });


    res.success(function (data, status, headers, config) {
      $("#showloader").css("display", "none");

      if (data.errorMessage) {
        $scope.isFailed = true;
        $scope.resmessage = data.errorMessage;
      }
      else if (data.resMessage) {
        $scope.isSuccess = true;
        $scope.resmessage = data.resMessage;
      }


    });

    res.error(function (data, status, headers, config) {

      $("#showloader").css("display", "none");
      $scope.isFailed = true;
      $scope.resmessage = "System failed. Please try again or contact WAALOS Support";

    });
  };


}]);
