var myApp = angular.module('PickByDate',['ui.bootstrap', 'ui.grid.expandable','ngTouch', 'ui.grid', 'ui.grid.selection', 'ui.grid.edit', 'ui.grid.autoResize', 'ui.grid.validate', 'ui.grid.exporter']);


myApp.directive('fileModel', ['$parse', function ($parse) {
	return {
		restrict: 'A',
		link: function (scope, element, attrs) {
			var model = $parse(attrs.fileModel);
			var modelSetter = model.assign;

			element.bind('change', function () {
				scope.$apply(function () {
					modelSetter(scope, element[0].files[0]);
				});
			});
		}
	};
}]);

myApp.service('fileUpload3', ['$http', function ($http) {

	this.uploadFileToUrl = function (dcName, userName, file, lotId, uploadUrl, $scope) {
		$("#showloader").css("display", "block");
		document.getElementById('list').innerHTML = '';
		document.getElementById('nextStep').innerHTML = '';
		var fd = new FormData();
		fd.append('dcName', dcName);
		fd.append('userName', userName);

		fd.append('lotId', lotId);

		$http.post(uploadUrl, fd, {
			transformRequest: angular.identity,
			headers: { 'Content-Type': undefined,'x-api-key': sessionStorage.apikey }
		})

			.success(function (response) {
				document.getElementById('list').innerHTML = '';
				document.getElementById('nextStep').innerHTML = '';
				$("#showloader").css("display", "none");
				if (response.errorMessage) {
					$scope.uploadError = response.errorMessage;
				} else {
					document.getElementById('list').innerHTML = response.resMessage;
					$scope.disable = true;
					$scope.errorMessagesArray = [];


				}
			})

			.error(function (error) {
				$("#showloader").css("display", "none");
				$scope.isFailedload = true;
				document.getElementById('list').innerHTML = '';
				document.getElementById('nextStep').innerHTML = '';
				$scope.errorMessagesArray = [];
			});
	};
}]);

  myApp.controller('PickByDateController', ['$scope', '$rootScope','$http', '$q', '$window', 'fileUpload3','$interval', '$timeout','urlService','uiGridConstants','commonService', function ($scope, $rootScope,$http, $q, $window, fileUpload3,$interval, $timeout,urlService,uiGridConstants,commonService) {

  $scope.isSuccess = false;
  $scope.isFailed = false;
  $scope.pagefunctionality = $scope.functionality;
  $scope.pagedc = $scope.dcName;
  $scope.isDisable = true;
  $("#showloader").css("display", "none");
  $scope.isFilters = false;
  $scope.isTabresult = true;

	$scope.disable = true;
	$scope.disableDownload = true;
	$scope.lotId = "";
	$scope.isFailedload = false;
	$scope.isClicked = false;
	$scope.uploadFile3 = function () {
		$("#showloader").css("display", "block");
		var file = $scope.myFile;
		var dcName = $rootScope.dcName;
		var userName = sessionStorage.userName;
		var lotId = $scope.lotId;
		var uploadUrl = urlService.PICK_BY_DATE_LOADER_UPLOAD_FILE;
		fileUpload3.uploadFileToUrl(dcName, userName, file, lotId, uploadUrl, $scope);
	};



	$scope.clearFile = function () {
		$scope.isFailed = false;
		$scope.excelReadErrors = false;
		$scope.excelErrors = false;
		document.getElementById('list').innerHTML = '';
		document.getElementById('nextStep').innerHTML = '';
		$scope.errorMessagesArray = [];
    $scope.disableDownload = true;
    $scope.uploadError = false;
    
	};


	var fileInput = document.getElementById("uploadFile");
	$scope.uploadchange = function(evt){
		
		if (evt.value.length == 0) {


		} else {
			$scope.isFailed = false;
			$scope.excelErrors = false;
			$scope.isFailedload = false;
      $scope.excelReadErrors = false;
      $scope.uploadError = false;
			$scope.isFailed = false;
			document.getElementById('list').innerHTML = '';
			document.getElementById('nextStep').innerHTML = '';
			$scope.errorMessagesArray = [];

			fileExtension = evt.value.substr((evt.value.lastIndexOf('.') + 1));

			if (fileExtension == "xls") {
				$scope.isFailed = true;
				$scope.resmessage = "Please save this xls file into xlsx format and try again to Choose File";
				return false;
			}


			if (evt.value.indexOf(".xlsx") < 0) {
				$scope.isFailed = true;
				$scope.resmessage = "Please choose only XLSX file";
				return false;
			}


			var dcName = $scope.dcName;
			var userName = sessionStorage.userName;
			var files = evt.files;
			var fileval = $("input[type='file']").val();
			var output = [];
			if (fileval == '' || fileval == undefined || fileval == null) {
				document.getElementById('list').innerHTML = '';
				document.getElementById('nextStep').innerHTML = '';
				$scope.disable = false;
			} else {
				$("#showloader").css("display", "block");
        var uploadUrl = urlService.PICK_BY_DATE_LOADER_CHOOSE_FILE;
				for (var i = 0, f; f = files[i]; i++) {
					output.push('<li><strong>', escape(f.name), '</strong> was choosen successfully</li>');
					localStorage.setItem("choosenFile", files[i]);
					var file = files[i];
					var fd = new FormData();
					fd.append('dcName', dcName);
					fd.append('userName', userName);
					fd.append('file', file);
					if (files[i].size < 1024 * 1024 * 10) {
						$http.post(uploadUrl, fd, {
							transformRequest: angular.identity,
							headers: { 'Content-Type': undefined,'x-api-key': sessionStorage.apikey }
						})

							.success(function (response) {
								if (response.lotId) {
									$scope.lotId = response.lotId;
									if (response.totalCount === response.errorCount) {
										$scope.disableDownload = false;
										$scope.disable = true;
										document.getElementById('nextStep').innerHTML = response.errorCount + ' ' + 'Out of' + ' ' + response.totalCount + ' ' + 'records are invalid';
										$scope.errorMessagesArray = response.errorDtoLst;
										$("#showloader").css("display", "none");
									} else {
										if(response.errorCount === 0){$scope.disableDownload = true;}else{$scope.disableDownload = false;}
										$scope.disable = false;
										document.getElementById('list').innerHTML = response.successCount + ' ' + 'Out of' + ' ' + response.totalCount + ' ' + 'records are valid -Please Proceed to Upload';
										$scope.errorMessagesArray = response.errorDtoLst;
										$("#showloader").css("display", "none");
									}
								} else if (response.errorMessage) {
									$scope.disableDownload = true;
									$scope.disable = true;
									$scope.excelReadErrors = true;
									$scope.excelReadError = response;

									$("#showloader").css("display", "none");
								} else {

									$scope.disable = true;
									$scope.excelErrorsData = response;
									$scope.excelErrors = true;
									$("#showloader").css("display", "none");

								}
							})
							.error(function (err) {
								$("#showloader").css("display", "none");
								$scope.isFailedload = true;
								$scope.errorMessagesArray = [];
							});
					} else {
						$("#showloader").css("display", "none");
						$scope.isFailed = true;
						$scope.resmessage = "File size should not exceed 10MB";
						$scope.errorMessagesArray = [];
					}

				}
			}
		}
	};

	$scope.uploadclick =  function(){ 

		var input = document.getElementById("uploadFile");

		if (input.value.length == 0) {

		} else if (input.value.length > 0) {
			input.value = null;
	        input.value = '';
			input.type = '';
			input.type = 'file';
			document.getElementById("uploadFile").value = null;
		}
  };
  

  $scope.downloadExcel = function() {
    $scope.isFailed = false;
    $("#showloader").css("display", "block");
    var url;
     url = urlService.PICKBYDATE_DOWNLOAD_ERRORS.replace('LID',$scope.lotId);
  
  
  $http({
      method: 'GET',
      url: url,
      headers: {				
        'Content-type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'x-api-key': sessionStorage.apikey
      },
      responseType: 'arraybuffer'
    })
  .success( function(data, status, headers) {
  
  $("#showloader").css("display", "none");
  
    if(data.byteLength == 55){
        $scope.isFailed = true;
          $('#alert-box').modal('show');
  
  
          }else if(data.byteLength == 98){
      $scope.isFailed = true;
      $scope.resmessage = "Error in Downloading Excel file";
      return;
    }else{
      
      var octetStreamMime = 'application/octet-stream';
      var success = false;
  
      // Get the headers
      headers = headers();
      var blob;
      // Get the filename from the x-filename header or default to "download.bin"
      var filename = headers['x-filename'] || 'PickbyDate_Loader_Error.xlsx';
  
      // Determine the content type from the header or default to "application/octet-stream"
      var contentType = headers['content-type'] || octetStreamMime;
  
      try
      {
        // Try using msSaveBlob if supported
        console.log("Trying saveBlob method ...");
         blob = new Blob([data], { type: contentType });
        if(navigator.msSaveBlob)
          navigator.msSaveBlob(blob, filename);
        else {
          // Try using other saveBlob implementations, if available
          var saveBlob = navigator.webkitSaveBlob || navigator.mozSaveBlob || navigator.saveBlob;
          if(saveBlob === undefined) throw "Not supported";
          saveBlob(blob, filename);
        }
        console.log("saveBlob succeeded");
        success = true;
      } catch(ex)
      {
        console.log("saveBlob method failed with the following exception:");
        console.log(ex);
      }
  
      if(!success)
      {
        // Get the blob url creator
        var urlCreator = window.URL || window.webkitURL || window.mozURL || window.msURL;
        if(urlCreator)
        {
          // Try to use a download link
          var link = document.createElement('a');
          if('download' in link)
          {
            // Try to simulate a click
            try
            {
              // Prepare a blob URL
              console.log("Trying download link method with simulated click ...");
               blob = new Blob([data], { type: contentType });
               url = urlCreator.createObjectURL(blob);
              link.setAttribute('href', url);
  
              // Set the download attribute (Supported in Chrome 14+ / Firefox 20+)
              link.setAttribute("download", filename);
  
              // Simulate clicking the download link
              var event = document.createEvent('MouseEvents');
              event.initMouseEvent('click', true, true, window, 1, 0, 0, 0, 0, false, false, false, false, 0, null);
              link.dispatchEvent(event);
              console.log("Download link method with simulated click succeeded");
              success = true;
  
            } catch(ex) {
              console.log("Download link method with simulated click failed with the following exception:");
              console.log(ex);
            }
          }
  
          if(!success)
          {
            // Fallback to window.location method
            try
            {
              // Prepare a blob URL
              // Use application/octet-stream when using window.location to force download
              console.log("Trying download link method with window.location ...");
               blob = new Blob([data], { type: octetStreamMime });
               url = urlCreator.createObjectURL(blob);
              window.location = url;
              console.log("Download link method with window.location succeeded");
              success = true;
            } catch(ex) {
              console.log("Download link method with window.location failed with the following exception:");
              console.log(ex);
            }
          }
  
        }
      }
  
      if(!success)
      {
        // Fallback to window.open method
        console.log("No methods worked for saving the arraybuffer, using last resort window.open");
        window.open(rowData.pathName, '_blank', '');
      }
    }
  })
  .error(function(data, status, config) {
  
    console.log("Request failed with status: " + status);
  $("#showloader").css("display", "none");
    // Optionally write the error out to scope
    //$scope.errorDetails = "Request failed with status: " + status;
  $scope.isFailed = true;
      $scope.resmessage = "Error in downloading Excel File";
  
  });
  };


  $scope.valuestoupdate = true;
  $scope.gridOptionsFilterData = {
		enableColumnMenus: false,
		enableSorting: true,
		multiSelect: false,
		enableRowSelection: true,//we can remove it later no use  of this
		enableSelectAll: true,//we can remove it later no use  of this             
		enableCellEdit: false, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
    enableCellEditOnFocus: true,// set any editable column to allow edit on focus
    expandableRowTemplate: 'components/pickByDate/views/expandableRowTemplate.html',
    expandableRowHeight: 320,
    //subGridVariable will be available in subGrid scope
    expandableRowScope: {
      subGridVariable: 'subGridScopeVariable'
    }
  };
  
  
  $scope.gridOptionsFilterData.onRegisterApi = function(gridApi){
    $scope.gridApi = gridApi;
  };



  $scope.gridOptionsToshipunitsData = {
		enableColumnMenus: false,
		enableSorting: true,
		enableCellEdit: false, 
    enableCellEditOnFocus: true,
  };

  $scope.gridOptionsToshipunitsData.onRegisterApi = function(gridApi){
    $scope.gridApi = gridApi;
    gridApi.selection.on.rowSelectionChanged($scope, function (row) {
  });
  };

  $scope.gridOptionsMarkedunits = {
    paginationPageSizes: [15, 25, 50, 100],
    paginationPageSize: 15,
    useExternalPagination: true,
		enableColumnMenus: false,
		enableSorting: true,
		enableCellEdit: false, 
    enableCellEditOnFocus: true,
  };

  $scope.gridOptionsMarkedunits.onRegisterApi = function (gridApi) {
    
        //set gridApi on scope
        $scope.gridApi = gridApi;
    
        $scope.gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
          $scope.pageNo =  newPage;
          $scope.pageSize = pageSize;
          $scope.markedUnits();
       });
      };

  $scope.gridOptionsShipedunits = {
    paginationPageSizes: [15, 25, 50, 100],
    paginationPageSize: 15,
    useExternalPagination: true,
		enableColumnMenus: false,
		enableSorting: true,
		enableCellEdit: false, 
    enableCellEditOnFocus: true,
  };

  $scope.gridOptionsShipedunits.onRegisterApi = function (gridApi) {
    
        //set gridApi on scope
        $scope.gridApi = gridApi;
    
        $scope.gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
          $scope.pageNo =  newPage;
          $scope.pageSize = pageSize;
          $scope.shipedUnits();
       });
      };


  $scope.gridOptions = {

		enableColumnMenus: false,
		enableSorting: true,
		enableCellEdit: false, 
    enableCellEditOnFocus: true,
  };
 // $scope.expandAllRows = function() {
    //$scope.gridApi.expandable.expandAllRows();
  //};

  //$scope.collapseAllRows = function() {
   // $scope.gridApi.expandable.collapseAllRows();
  //};

  //$scope.toggleExpandAllBtn = function() {
  //  $scope.gridOptionsFilterData.showExpandAllButton = !$scope.gridOptionsFilterData.showExpandAllButton;
  //}


  $scope.gridOptionsFilterDatainner = {
    paginationPageSizes: [15, 25, 50, 100],
    paginationPageSize: 15,
    useExternalPagination: true,
    enableColumnMenus: false,
    //enableSorting: true,
    enableCellEditOnFocus: true,
    
  };

  $scope.gridOptionsFilterDatainner.onRegisterApi = function (gridApi) {
    //set gridApi on scope
    $scope.gridApi = gridApi;

    $scope.gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
      $scope.pageNo =  newPage;
      $scope.pageSize = pageSize;
      $scope.threeUnits();
   });

   gridApi.selection.on.rowSelectionChangedBatch($scope, function (rows) {
    $scope.isSuccess = false;
    $scope.isFailed = false;
    if ($scope.gridApi.selection.getSelectedRows().length == 0) {
      $scope.valuestoupdate = true;
    } else {
      $scope.valuestoupdate = false;
   
    }
  });

  gridApi.selection.on.rowSelectionChanged($scope, function (row) {
    $scope.isSuccess = false;
    $scope.isFailed = false;
    if ($scope.gridApi.selection.getSelectedRows().length > 0) {
      $scope.valuestoupdate = false;
       } else {
      $scope.valuestoupdate = true;
     
    }
  });

  };

  $scope.prepacks = [];
  $scope.prodtypes= [];
  $scope.statcodes= [];
  $scope.codetypes= [];
  $scope.shiptocountries= [];
  $scope.marketsValues= [];
  $scope.clearFilter = false;
	//Get Data Source
	$scope.filterData = function () {
		$scope.isSuccess = false;
		$scope.isFailed = false;

		$("#showloader").css("display", "block");
		var url = urlService.PICKBY_DATE_GET_FILTERS_GRID;

  var marketsVal = [];
  if ($scope.marketsValues) {
    _.each($scope.marketsValues, function (val, key) {
      if (val.isChecked == true) {
        marketsVal.push(val.market);
      }
    });
  }
  
  var shiptoConty = [];
  if ($scope.shiptocountries) {
    _.each($scope.shiptocountries, function (val, key) {
      if (val.isChecked == true) {
        shiptoConty.push(val.ship);
      } 
    });
  }
  
  var codeTypes = [];
  if ($scope.codetypes) {
    _.each($scope.codetypes, function (val, key) {
      if (val.isChecked == true) {
        codeTypes.push(val.code);
      } 
    });
  }
  
  var statCodes = [];
  if ($scope.statcodes) {
    _.each($scope.statcodes, function (val, key) {
      if (val.isChecked == true) {
        statCodes.push(val.code);
      }
    });
   if(statCodes[0] == "10" && statCodes[1] == undefined ){
    statCodes.push("15");
   }
  }
  
  var prodTypes = [];
  if ($scope.prodtypes) {
    _.each($scope.prodtypes, function (val, key) {
      if (val.isChecked == true) {
        prodTypes.push(val.prob);
      } 
    });
  }
  
  var prePacks = [];
  if ($scope.prepacks) {
    _.each($scope.prepacks, function (val, key) {
      if (val.isChecked == true) {
        prePacks.push(val.pack);
      }
    });  
  }
  
  var postObject ={
    "markets": marketsVal,
    "shipToCountries":shiptoConty,
    "codeTypes": codeTypes,
    "statCodes": statCodes,
    "prodTypes":prodTypes,
    "prepack":prePacks,
    "dcName":  $scope.pagedc,
    "userName":sessionStorage.userName
  };
  var res = $http.post(url, postObject, {
    headers: {'x-api-key': sessionStorage.apikey}
 });


		res.success(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			if (data.errorMessage) {
				$scope.isFailed = true;
				$scope.resmessage = data.errorMessage;
			} else if (data.resMessage) {
				$scope.isSuccess = true;
				$scope.resmessage = data.resMessage;
			} else {
        $scope.records = data;
        $scope.clearFilter = false;
        $scope.isTable = true;

  
     	postRecords=[];
  
      _.each(data, function (val, key) {
       var records = {
         "pktType":val.pktType,
         "<3Pkts":val.pastPkts,
         "<3Units":val.pastUnits,
        
  
       };
      var recordsdata = [];
      for(var i = 0; i<val.pickByDateCurDateDtoLst.length; i++){
        var dateFormat = val.pickByDateCurDateDtoLst[i].date;
        var secondKeyName = dateFormat+ 'Pkts';
        var fristKeyName = dateFormat + 'Units';
        records[secondKeyName] = val.pickByDateCurDateDtoLst[i].currPkts;
        records[fristKeyName] = val.pickByDateCurDateDtoLst[i].currUnits;
        
      }
      records[">5Pkts"]=val.futurePkts;
      records[">5Units"]=val.futureUnits;
      records["stoPkts"]=val.stoPkts;
      records["stoUnits"]=val.stoUnits;
      
       postRecords.push(records);
      });
      $scope.gridOptionsFilterData.data =postRecords;
    $scope.gridOptionsFilterData.columnDefs = [];
            var width = "";
          _.each(postRecords, function (value, key) {
            var length =Object.keys(postRecords[0]).length;
            if ($scope.gridOptionsFilterData.columnDefs.length != length) {
              for (var i = 0; i < Object.keys(value).length; i++) {
  
                //regular expression to provide spaces at camel case notation and capitalize first letter in the word
                 var displayName = Object.keys(value)[i]
              .replace(/\w\S*/g, function (txt) {
                  return txt.charAt(0).toUpperCase() + txt.substr(1);
                 }).replace(/\s/g, "").replace(/([A-Z])/g, ' $1').trim();
              
                  
                 
                  if(displayName == "Pkt Type" ||  displayName == "Sto Units" || displayName == "Sto Pkts"){
                    $scope.gridOptionsFilterData.columnDefs.push({ name: Object.keys(value)[i], displayName: displayName, enableCellEdit: false,width:120 });
                  }else if(displayName == "<3 Units" || displayName == "<3 Pkts"){
                    $scope.gridOptionsFilterData.columnDefs.push({ name: Object.keys(value)[i], displayName: displayName, enableCellEdit: false,width:80,cellTemplate:  '<div class="ui-grid-cell-contents" ng-click="grid.appScope.threeUnits(grid, row,col)"><a href="javascript:void(0)">{{COL_FIELD}}</a></div>' });
                  }else if(displayName == ">5 Units" || displayName == ">5 Pkts"){
                    $scope.gridOptionsFilterData.columnDefs.push({ name: Object.keys(value)[i], displayName: displayName, enableCellEdit: false,width:80,cellTemplate:  '<div class="ui-grid-cell-contents" ng-click="grid.appScope.fiveUnits(grid, row,col)"><a href="javascript:void(0)">{{COL_FIELD}}</a></div>' });
                  }else{
                    $scope.gridOptionsFilterData.columnDefs.push({ name: Object.keys(value)[i], displayName: displayName, enableCellEdit: false,width:150,cellTemplate:  '<div class="ui-grid-cell-contents" ng-click="grid.appScope.byDate(grid, row,col)"><a href="javascript:void(0)">{{COL_FIELD}}</a></div>' });
                  }
                
              }
            }
             
          });

				if ($scope.gridOptionsFilterData.data > 10) {
					$scope.gridOptionsFilterData.enableVerticalScrollbar = true;
					$scope.gridOptionsFilterData.enableHorizontalScrollbar = 1;
				} else {
					$scope.gridOptionsFilterData.enableVerticalScrollbar = false;
					$scope.gridOptionsFilterData.enableHorizontalScrollbar = 1;
        }
       // setTimeout(function(){  $scope.expandAllRows(); }, 1000);
       
      }
    
			$('.ui-grid-pager-control input').prop("disabled", true);
		});
		res.error(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			$scope.isFailed = true;
			$scope.resmessage = "System failed. Please try again or contact WAALOS Support";

		});
  };
  

  $scope.filterData();
$scope.alloption ={
  marketAll:false,
  shiptocountriesAll:false,
  codetypesAll:false,
  statcodesAll:false,
  prodtypesAll:false,
  prepacksAll:false,
};



  $scope.allMarketvalues = function(){
    if($scope.alloption.marketAll == true){
        _.each($scope.marketsValues, function (val, key) {
       if(val.isChecked == false){
        val.isChecked = true;
       }
        });

      
    }else{
      _.each($scope.marketsValues, function (val, key) {
        if(val.isChecked == true){
         val.isChecked = false;
        }
       
         });
         $scope.isDisable = true;
   }
   $scope.checkedValues();
  };

  $scope.allshiptocountriesvalues = function(){
    if($scope.alloption.shiptocountriesAll == true){
        _.each($scope.shiptocountries, function (val, key) {
       if(val.isChecked == false){
        val.isChecked = true;
       }
        });
    
      
    }else{
      _.each($scope.shiptocountries, function (val, key) {
        if(val.isChecked == true){
         val.isChecked = false;
        }
       
         });
         $scope.isDisable = true;
      }
      $scope.checkedValues();
  };

  $scope.allstatcodesvalues = function(){
    if($scope.alloption.statcodesAll == true){
        _.each($scope.statcodes, function (val, key) {
       if(val.isChecked == false){
        val.isChecked = true;
       }
        });
    
      
    }else{
      _.each($scope.statcodes, function (val, key) {
        if(val.isChecked == true){
         val.isChecked = false;
        }
       
         });
         $scope.isDisable = true;
      }
      $scope.checkedValues();
  };

  $scope.allprodtypesvalues = function(){
    if($scope.alloption.prodtypesAll == true){
        _.each($scope.prodtypes, function (val, key) {
       if(val.isChecked == false){
        val.isChecked = true;
       }
        });
    
      
    }else{
      _.each($scope.prodtypes, function (val, key) {
        if(val.isChecked == true){
         val.isChecked = false;
        }
       
         });
         $scope.isDisable = true;
      }
      $scope.checkedValues();
  };



  $scope.allcodetypesvalues = function(){
    if($scope.alloption.codetypesAll == true){
        _.each($scope.codetypes, function (val, key) {
       if(val.isChecked == false){
        val.isChecked = true;
       }
        });
    
      
    }else{
      _.each($scope.codetypes, function (val, key) {
        if(val.isChecked == true){
         val.isChecked = false;
        }
       
         });
         $scope.isDisable = true;
      }
      $scope.checkedValues();
  };


  $scope.allprepacksvalues = function(){
    if($scope.alloption.prepacksAll == true){
        _.each($scope.prepacks, function (val, key) {
       if(val.isChecked == false){
        val.isChecked = true;
       }
        });
    
      
    }else{
      _.each($scope.prepacks, function (val, key) {
        if(val.isChecked == true){
         val.isChecked = false;
        }
       
         });
         $scope.isDisable = true;
      }
      $scope.checkedValues();
  };

  $scope.clearFlters = function(){
    $scope.prepacks = [];
    $scope.prodtypes= [];
    $scope.statcodes= [];
    $scope.codetypes= [];
    $scope.shiptocountries= [];
    $scope.marketsValues= [];
    $scope.filterData();
  };

$scope.threeUnits = function(grid, row,col){
	$scope.isSuccess = false;
  $scope.isFailed = false;


  
var url = urlService.PICKBY_DATE_POST_FILTERS_GRID;
var marketsVal = [];
if ($scope.marketsValues) {
  _.each($scope.marketsValues, function (val, key) {
    if (val.isChecked == true) {
      marketsVal.push(val.market);
    }
  });
}

var shiptoConty = [];
if ($scope.shiptocountries) {
  _.each($scope.shiptocountries, function (val, key) {
    if (val.isChecked == true) {
      shiptoConty.push(val.ship);
    } 
  });
}

var codeTypes = [];
if ($scope.codetypes) {
  _.each($scope.codetypes, function (val, key) {
    if (val.isChecked == true) {
      codeTypes.push(val.code);
    } 
  });
}

var statCodes = [];
if ($scope.statcodes) {
  _.each($scope.statcodes, function (val, key) {
    if (val.isChecked == true) {
      statCodes.push(val.code);
    }
  });
 if(statCodes[0] == "10" && statCodes[1] == undefined ){
  statCodes.push("15");
 }
}

var prodTypes = [];
if ($scope.prodtypes) {
  _.each($scope.prodtypes, function (val, key) {
    if (val.isChecked == true) {
      prodTypes.push(val.prob);
    } 
  });
}

var prePacks = [];
if ($scope.prepacks) {
  _.each($scope.prepacks, function (val, key) {
    if (val.isChecked == true) {
      prePacks.push(val.pack);
    }
  });  
}

$scope.pageNo = $scope.pageNo ? $scope.pageNo : 1;
$scope.pageSize = $scope.pageSize ? $scope.pageSize: $scope.gridOptionsFilterDatainner.paginationPageSize;

if(row && col.field == "<3Units"){
  if(row.entity["<3Units"] != '0' ){
    $scope.orderType = row.entity.pktType;
  }
  else{
    $scope.isFailed = true;
    $scope.resmessage = 'Please select non-zero values';
    return false;
  }
}

  if(row && col.field == "<3Pkts"){
    if(row.entity["<3Pkts"] != '0' ){
      $scope.orderType = row.entity.pktType;
    }
    else{
      $scope.isFailed = true;
      $scope.resmessage = 'Please select non-zero values';
      return false;
    }
 }
$("#showloader").css("display", "block");
var postObject ={
  
    "orderType" : $scope.orderType,
    "pickByDate" : "",  
    "lessThn3days" : "Y",  
    "grtrThn5days" : "", 
    "pageSize" : $scope.pageSize,
    "pageNumber" : $scope.pageNo,       
    "pickByDateFilterDto" : {
      "markets": marketsVal,
      "shipToCountries":shiptoConty,
      "codeTypes": codeTypes,
      "statCodes": statCodes,
      "prodTypes":prodTypes,
      "prepack":prePacks,
      "dcName":  $scope.pagedc,
      "userName":sessionStorage.userName
    }   



};
var res = $http.post(url, postObject, {
  headers: {'x-api-key': sessionStorage.apikey}
});

res.success(function (data, status, headers, config) {
  $("#showloader").css("display", "none");

  if (data.errorMessage) {
    $scope.isFailed = true;
    $scope.resmessage = data.errorMessage;
  } else if (data.resMessage) {
    $scope.isSuccess = true;
    $scope.resmessage = data.resMessage;
  } else {
   

    $scope.gridOptionsFilterDatainner.columnDefs  = [    
    
      { name: 'pkts', displayName: 'pkts', width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true, type: 'number'},
      { name: 'distinctSkus', displayName: 'distinctSkus', width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true, type: 'number'},
      { name: 'pktQty', displayName: 'pktQty', width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true, type: 'number'},
      { name: 'int2Cases', displayName: 'int2Cases',  width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true, type: 'number'},
      { name: 'int2Units', displayName: 'int2Units',width: 150,  enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true, type: 'number'},
      { name: 'int1Units', displayName: 'int1Units',width: 150,  enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true, type: 'number'},
      { name: 'ftw', displayName: 'ftw', width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true, type: 'number'},
      { name: 'app', displayName: 'app',width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true, type: 'number'},
      { name: 'equ', displayName: 'equ',width: 150,  enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true, type: 'number'},
      { name: 'hotpick', displayName: 'hotpick',width: 150,  enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true, type: 'number'},
      { name: 'fastMover', displayName: 'fastMover', width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true, type: 'number'},
      { name: 'pbd', displayName: 'pbd',width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true, type: 'number'},
      { name: 'rdd', displayName: 'rdd', width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true, type: 'number'},
      { name: 'pgi', displayName: 'pgi', width: 150,  enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true, type: 'number'},
      { name: 'bid', displayName: 'bid',width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true},
      { name: 'marked', displayName: 'marked',width: 150,  enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true},
      { name: 'prepack', displayName: 'prepack', width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true},
      { name: 'shipWaveNbr', displayName: 'shipWaveNbr', width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true},
      { name: 'shippedTo', displayName: 'shippedTo',width: 150,  enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true, type: 'number'},
      { name: 'shippedToName', displayName: 'shippedToName',width: 150,  enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true},
      { name: 'shippedToAdd1', displayName: 'shippedToAdd1', width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true},
      { name: 'shippedToAdd2', displayName: 'shippedToAdd2',width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true},
      { name: 'shippedToAdd3', displayName: 'shippedToAdd3',width: 150,  enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true},
      { name: 'shippedToCity', displayName: 'shippedToCity', width: 150,  enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true},
      { name: 'shippedToState', displayName: 'shippedToState', width: 150, enableCellEdit: false, cellTooltip: true,  headerTooltip: true},
      { name: 'shippedToZip', displayName: 'shippedToZip',width: 150,  enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: false },
      { name: 'shippedToCntry', displayName: 'shippedToCntry', width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true},
      { name: 'soldTo', displayName: 'soldTo',width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip:true,enableSorting: true, type: 'number'},
      { name: 'soldToName', displayName: 'soldToName',width: 150,  enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true},
      { name: 'soldToAdd1', displayName: 'soldToAdd1', width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip: true ,enableSorting: true},
      { name: 'soldToAdd2', displayName: 'soldToAdd2',width: 150,  enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true},
      { name: 'soldToAdd3', displayName: 'soldToAdd3',width: 150,  enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true},
      { name: 'soldToCity', displayName: 'soldToCity',width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true},
      { name: 'soldToState', displayName: 'soldToState',width: 150,  enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true},
      { name: 'soldToZip', displayName: 'soldToZip',width: 150,  enableCellEdit: false, cellTooltip: true,enableSorting: true},
      { name: 'soldToCntry', displayName: 'soldToCntry',width: 150,  enableCellEdit: false, cellTooltip: true,enableSorting: true}
    ];

    $scope.isTable = false;
    $scope.isTbaleinner = true;
    $scope.gridOptionsFilterDatainner.totalItems  = data.totalNoOfRecords;
    $scope.gridOptionsFilterDatainner.data = data.pageItems;

    if ($scope.gridOptionsFilterDatainner.data > 10) {
      $scope.gridOptionsFilterDatainner.enableVerticalScrollbar = true;
      $scope.gridOptionsFilterDatainner.enableHorizontalScrollbar = 1;
    } else {
      $scope.gridOptionsFilterDatainner.enableVerticalScrollbar = false;
      $scope.gridOptionsFilterDatainner.enableHorizontalScrollbar = 1;
    }
 
   
  }

  if(row){$scope.gridOptionsFilterDatainner.paginationCurrentPage  = 1;}
  setTimeout(function(){  $('.ui-grid-pager-control-input').attr( "disabled", true );  }, 2000);
 

});
res.error(function (data, status, headers, config) {
  $("#showloader").css("display", "none");
  $scope.isFailed = true;
  $scope.resmessage = "System failed. Please try again or contact WAALOS Support";

});

};



$scope.fiveUnits = function(grid, row, col){
	$scope.isSuccess = false;
  $scope.isFailed = false;

 
var url = urlService.PICKBY_DATE_POST_FILTERS_GRID;
var marketsVal = [];
if ($scope.marketsValues) {
  _.each($scope.marketsValues, function (val, key) {
    if (val.isChecked == true) {
      marketsVal.push(val.market);
    }
  });
}

var shiptoConty = [];
if ($scope.shiptocountries) {
  _.each($scope.shiptocountries, function (val, key) {
    if (val.isChecked == true) {
      shiptoConty.push(val.ship);
    } 
  });
}

var codeTypes = [];
if ($scope.codetypes) {
  _.each($scope.codetypes, function (val, key) {
    if (val.isChecked == true) {
      codeTypes.push(val.code);
    } 
  });
}

var statCodes = [];
if ($scope.statcodes) {
  _.each($scope.statcodes, function (val, key) {
    if (val.isChecked == true) {
      statCodes.push(val.code);
    }
  });
 if(statCodes[0] == "10" && statCodes[1] == undefined ){
  statCodes.push("15");
 }
}

var prodTypes = [];
if ($scope.prodtypes) {
  _.each($scope.prodtypes, function (val, key) {
    if (val.isChecked == true) {
      prodTypes.push(val.prob);
    } 
  });
}

var prePacks = [];
if ($scope.prepacks) {
  _.each($scope.prepacks, function (val, key) {
    if (val.isChecked == true) {
      prePacks.push(val.pack);
    }
  });  
}

$scope.pageNo = $scope.pageNo ? $scope.pageNo : 1;
$scope.pageSize = $scope.pageSize ? $scope.pageSize: $scope.gridOptionsFilterDatainner.paginationPageSize;

if(row && col.field == ">5Units"){
  if(row.entity[">5Units"] != '0' ){
    $scope.orderType = row.entity.pktType;
  }
  else{
    $scope.isFailed = true;
    $scope.resmessage = 'Please select non-zero values';
    return false;
  }
}

  if(row && col.field == ">5Pkts"){
    if(row.entity[">5Pkts"] != '0' ){
      $scope.orderType = row.entity.pktType;
    }
    else{
      $scope.isFailed = true;
      $scope.resmessage = 'Please select non-zero values';
      return false;
    }
 }
$("#showloader").css("display", "block");


var postObject ={
  
    "orderType" : $scope.orderType,
    "pickByDate" : "",  
    "lessThn3days" : "",  
    "grtrThn5days" : "Y", 
    "pageSize" : $scope.pageSize,
    "pageNumber" : $scope.pageNo,       
    "pickByDateFilterDto" : {
      "markets": marketsVal,
      "shipToCountries":shiptoConty,
      "codeTypes": codeTypes,
      "statCodes": statCodes,
      "prodTypes":prodTypes,
      "prepack":prePacks,
      "dcName":  $scope.pagedc,
      "userName":sessionStorage.userName
    }   



};
var res = $http.post(url, postObject, {
  headers: {'x-api-key': sessionStorage.apikey}
});

res.success(function (data, status, headers, config) {
  $("#showloader").css("display", "none");

  if (data.errorMessage) {
    $scope.isFailed = true;
    $scope.resmessage = data.errorMessage;
  } else if (data.resMessage) {
    $scope.isSuccess = true;
    $scope.resmessage = data.resMessage;
  } else {
   

    $scope.gridOptionsFilterDatainner.columnDefs  = [    
          { name: 'pkts', displayName: 'pkts', width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true, type: 'number'},
      { name: 'distinctSkus', displayName: 'distinctSkus', width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true, type: 'number'},
      { name: 'pktQty', displayName: 'pktQty', width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true, type: 'number'},
      { name: 'int2Cases', displayName: 'int2Cases',  width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true, type: 'number'},
      { name: 'int2Units', displayName: 'int2Units',width: 150,  enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true, type: 'number'},
      { name: 'int1Units', displayName: 'int1Units',width: 150,  enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true, type: 'number'},
      { name: 'ftw', displayName: 'ftw', width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true, type: 'number'},
      { name: 'app', displayName: 'app',width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true, type: 'number'},
      { name: 'equ', displayName: 'equ',width: 150,  enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true, type: 'number'},
      { name: 'hotpick', displayName: 'hotpick',width: 150,  enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true, type: 'number'},
      { name: 'fastMover', displayName: 'fastMover', width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true, type: 'number'},
      { name: 'pbd', displayName: 'pbd',width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true, type: 'number'},
      { name: 'rdd', displayName: 'rdd', width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true, type: 'number'},
      { name: 'pgi', displayName: 'pgi', width: 150,  enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true, type: 'number'},
      { name: 'bid', displayName: 'bid',width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true},
      { name: 'marked', displayName: 'marked',width: 150,  enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true},
      { name: 'prepack', displayName: 'prepack', width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true},
      { name: 'shipWaveNbr', displayName: 'shipWaveNbr', width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true},
      { name: 'shippedTo', displayName: 'shippedTo',width: 150,  enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true, type: 'number'},
      { name: 'shippedToName', displayName: 'shippedToName',width: 150,  enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true},
      { name: 'shippedToAdd1', displayName: 'shippedToAdd1', width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true},
      { name: 'shippedToAdd2', displayName: 'shippedToAdd2',width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true},
      { name: 'shippedToAdd3', displayName: 'shippedToAdd3',width: 150,  enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true},
      { name: 'shippedToCity', displayName: 'shippedToCity', width: 150,  enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true},
      { name: 'shippedToState', displayName: 'shippedToState', width: 150, enableCellEdit: false, cellTooltip: true,  headerTooltip: true},
      { name: 'shippedToZip', displayName: 'shippedToZip',width: 150,  enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: false },
      { name: 'shippedToCntry', displayName: 'shippedToCntry', width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true},
      { name: 'soldTo', displayName: 'soldTo',width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip:true,enableSorting: true, type: 'number'},
      { name: 'soldToName', displayName: 'soldToName',width: 150,  enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true},
      { name: 'soldToAdd1', displayName: 'soldToAdd1', width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip: true ,enableSorting: true},
      { name: 'soldToAdd2', displayName: 'soldToAdd2',width: 150,  enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true},
      { name: 'soldToAdd3', displayName: 'soldToAdd3',width: 150,  enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true},
      { name: 'soldToCity', displayName: 'soldToCity',width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true},
      { name: 'soldToState', displayName: 'soldToState',width: 150,  enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true},
      { name: 'soldToZip', displayName: 'soldToZip',width: 150,  enableCellEdit: false, cellTooltip: true,enableSorting: true},
      { name: 'soldToCntry', displayName: 'soldToCntry',width: 150,  enableCellEdit: false, cellTooltip: true,enableSorting: true}
    ];

    $scope.isTable = false;
    $scope.isTbaleinner = true;
    $scope.gridOptionsFilterDatainner.totalItems  = data.totalNoOfRecords;
    $scope.gridOptionsFilterDatainner.data = data.pageItems;

    if ($scope.gridOptionsFilterDatainner.data > 10) {
      $scope.gridOptionsFilterDatainner.enableVerticalScrollbar = true;
      $scope.gridOptionsFilterDatainner.enableHorizontalScrollbar = 1;
    } else {
      $scope.gridOptionsFilterDatainner.enableVerticalScrollbar = false;
      $scope.gridOptionsFilterDatainner.enableHorizontalScrollbar = 1;
    }
 
   
  }

 
  if(row){$scope.gridOptionsFilterDatainner.paginationCurrentPage  = 1;}
  setTimeout(function(){  $('.ui-grid-pager-control-input').attr( "disabled", true );  }, 2000);
  

});
res.error(function (data, status, headers, config) {
  $("#showloader").css("display", "none");
  $scope.isFailed = true;
  $scope.resmessage = "System failed. Please try again or contact WAALOS Support";

});

};




$scope.byDate = function(grid, row, col){
	$scope.isSuccess = false;
  $scope.isFailed = false;

var url = urlService.PICKBY_DATE_POST_FILTERS_GRID;
var marketsVal = [];
if ($scope.marketsValues) {
  _.each($scope.marketsValues, function (val, key) {
    if (val.isChecked == true) {
      marketsVal.push(val.market);
    }
  });
}

var shiptoConty = [];
if ($scope.shiptocountries) {
  _.each($scope.shiptocountries, function (val, key) {
    if (val.isChecked == true) {
      shiptoConty.push(val.ship);
    } 
  });
}

var codeTypes = [];
if ($scope.codetypes) {
  _.each($scope.codetypes, function (val, key) {
    if (val.isChecked == true) {
      codeTypes.push(val.code);
    } 
  });
}

var statCodes = [];
if ($scope.statcodes) {
  _.each($scope.statcodes, function (val, key) {
    if (val.isChecked == true) {
      statCodes.push(val.code);
    }
  });
 if(statCodes[0] == "10" && statCodes[1] == undefined ){
  statCodes.push("15");
 }
}

var prodTypes = [];
if ($scope.prodtypes) {
  _.each($scope.prodtypes, function (val, key) {
    if (val.isChecked == true) {
      prodTypes.push(val.prob);
    } 
  });
}

var prePacks = [];
if ($scope.prepacks) {
  _.each($scope.prepacks, function (val, key) {
    if (val.isChecked == true) {
      prePacks.push(val.pack);
    }
  });  
}

$scope.pageNo = $scope.pageNo ? $scope.pageNo : 1;
$scope.pageSize = $scope.pageSize ? $scope.pageSize: $scope.gridOptionsFilterDatainner.paginationPageSize;

if(row && col.field.indexOf("Units") > 0){
  if(row.entity[col.field] != '0' ){
    $scope.orderTypeparent = row.entity.pktType;
    $scope.pickByDate = col.field.substring(0, 10);
  }
  else{
    $scope.isFailed = true;
    $scope.resmessage = 'Please select non-zero values';
    return false;
  }
}

  if(row && col.field.indexOf("Pkts") > 0){
    if(row.entity[col.field] != '0' ){
      $scope.orderTypeparent = row.entity.pktType;
      $scope.pickByDate = col.field.substring(0, 10);
    }
    else{
      $scope.isFailed = true;
      $scope.resmessage = 'Please select non-zero values';
      return false;
    }
 }
$("#showloader").css("display", "block");


var postObject ={
  
    "orderType" : $scope.orderTypeparent,
    "pickByDate" : $scope.pickByDate,  
    "lessThn3days" : "",   
    "grtrThn5days" : "", 
    "pageSize" : $scope.pageSize,
    "pageNumber" : $scope.pageNo,       
    "pickByDateFilterDto" : {
      "markets": marketsVal,
      "shipToCountries":shiptoConty,
      "codeTypes": codeTypes,
      "statCodes": statCodes,
      "prodTypes":prodTypes,
      "prepack":prePacks,
      "dcName":  $scope.pagedc,
      "userName":sessionStorage.userName
    }   



};
var res = $http.post(url, postObject, {
  headers: {'x-api-key': sessionStorage.apikey}
});

res.success(function (data, status, headers, config) {
  $("#showloader").css("display", "none");

  if (data.errorMessage) {
    $scope.isFailed = true;
    $scope.resmessage = data.errorMessage;
  } else if (data.resMessage) {
    $scope.isSuccess = true;
    $scope.resmessage = data.resMessage;
  } else {
   

    $scope.gridOptionsFilterDatainner.columnDefs  = [    
      { name: 'pkts', displayName: 'pkts', width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true, type: 'number'},
      { name: 'distinctSkus', displayName: 'distinctSkus', width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true, type: 'number'},
      { name: 'pktQty', displayName: 'pktQty', width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true, type: 'number'},
      { name: 'int2Cases', displayName: 'int2Cases',  width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true, type: 'number'},
      { name: 'int2Units', displayName: 'int2Units',width: 150,  enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true, type: 'number'},
      { name: 'int1Units', displayName: 'int1Units',width: 150,  enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true, type: 'number'},
      { name: 'ftw', displayName: 'ftw', width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true, type: 'number'},
      { name: 'app', displayName: 'app',width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true, type: 'number'},
      { name: 'equ', displayName: 'equ',width: 150,  enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true, type: 'number'},
      { name: 'hotpick', displayName: 'hotpick',width: 150,  enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true, type: 'number'},
      { name: 'fastMover', displayName: 'fastMover', width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true, type: 'number'},
      { name: 'pbd', displayName: 'pbd',width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true, type: 'number'},
      { name: 'rdd', displayName: 'rdd', width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true, type: 'number'},
      { name: 'pgi', displayName: 'pgi', width: 150,  enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true, type: 'number'},
      { name: 'bid', displayName: 'bid',width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true},
      { name: 'marked', displayName: 'marked',width: 150,  enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true},
      { name: 'prepack', displayName: 'prepack', width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true},
      { name: 'shipWaveNbr', displayName: 'shipWaveNbr', width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true},
      { name: 'shippedTo', displayName: 'shippedTo',width: 150,  enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true, type: 'number'},
      { name: 'shippedToName', displayName: 'shippedToName',width: 150,  enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true},
      { name: 'shippedToAdd1', displayName: 'shippedToAdd1', width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true},
      { name: 'shippedToAdd2', displayName: 'shippedToAdd2',width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true},
      { name: 'shippedToAdd3', displayName: 'shippedToAdd3',width: 150,  enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true},
      { name: 'shippedToCity', displayName: 'shippedToCity', width: 150,  enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true},
      { name: 'shippedToState', displayName: 'shippedToState', width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip: true},
      { name: 'shippedToZip', displayName: 'shippedToZip',width: 150,  enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: false },
      { name: 'shippedToCntry', displayName: 'shippedToCntry', width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true},
      { name: 'soldTo', displayName: 'soldTo',width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip:true,enableSorting: true, type: 'number'},
      { name: 'soldToName', displayName: 'soldToName',width: 150,  enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true},
      { name: 'soldToAdd1', displayName: 'soldToAdd1', width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip: true ,enableSorting: true},
      { name: 'soldToAdd2', displayName: 'soldToAdd2',width: 150,  enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true},
      { name: 'soldToAdd3', displayName: 'soldToAdd3',width: 150,  enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true},
      { name: 'soldToCity', displayName: 'soldToCity',width: 150, enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true},
      { name: 'soldToState', displayName: 'soldToState',width: 150,  enableCellEdit: false, cellTooltip: true, headerTooltip: true,enableSorting: true},
      { name: 'soldToZip', displayName: 'soldToZip',width: 150,  enableCellEdit: false, cellTooltip: true,enableSorting: true},
      { name: 'soldToCntry', displayName: 'soldToCntry',width: 150,  enableCellEdit: false, cellTooltip: true,enableSorting: true}
    ];

    $scope.isTable = false;
    $scope.isTbaleinner = true;
    $scope.gridOptionsFilterDatainner.totalItems  = data.totalNoOfRecords;
    $scope.gridOptionsFilterDatainner.data = data.pageItems;

    if ($scope.gridOptionsFilterDatainner.data > 10) {
      $scope.gridOptionsFilterDatainner.enableVerticalScrollbar = true;
      $scope.gridOptionsFilterDatainner.enableHorizontalScrollbar = 1;
    } else {
      $scope.gridOptionsFilterDatainner.enableVerticalScrollbar = false;
      $scope.gridOptionsFilterDatainner.enableHorizontalScrollbar = 1;
    }
 
   
  }

 
  if(row){$scope.gridOptionsFilterDatainner.paginationCurrentPage  = 1;}
  setTimeout(function(){  $('.ui-grid-pager-control-input').attr( "disabled", true );  }, 2000);
  

});
res.error(function (data, status, headers, config) {
  $("#showloader").css("display", "none");
  $scope.isFailed = true;
  $scope.resmessage = "System failed. Please try again or contact WAALOS Support";

});


};



$scope.backtomaintab = function(){
  $scope.isSuccess = false;
  $scope.isFailed = false;
  $scope.isTable = true;
  $scope.isTbaleinner = false;
};

$scope.markedUnits = function(){
	$scope.isSuccess = false;
  $scope.isFailed = false;

  $("#showloader").css("display", "block");
  $scope.pageNo = $scope.pageNo ? $scope.pageNo : 1;
  $scope.pageSize = $scope.pageSize ? $scope.pageSize: $scope.gridOptionsMarkedunits.paginationPageSize;
	var url = urlService.PICKBY_DATE_GET_MARKED_UNITS.replace('dName', $scope.pagedc);
  url = url.replace('uName', sessionStorage.userName);
  url = url.replace('pNumber',$scope.pageNo);
  url = url.replace('pSize',$scope.pageSize);
  var res = $http.get(url, { headers: { 'x-api-key': sessionStorage.apikey } });
  
  res.success(function (data, status, headers, config) {
    $("#showloader").css("display", "none");
    if (data.errorMessage) {
      $scope.isFailed = true;
      $scope.resmessage = data.errorMessage;
    } else if (data.resMessage) {
      $scope.isSuccess = true;
      $scope.resmessage = data.resMessage;
    } else {
  
      $scope.gridOptionsMarkedunits.columnDefs = [
        { name: 'market', displayName: 'Market', enableCellEdit: false, cellTooltip: true, headerTooltip: true },
        { name: 'orderType', displayName: 'Order Type', enableCellEdit: false, cellTooltip: true, headerTooltip: true },
        { name: 'pktsCount', displayName: 'Pkts Count', enableCellEdit: false, cellTooltip: true, headerTooltip: true },
        { name: 'int2Cases', displayName: 'Int2 Cases', enableCellEdit: false, cellTooltip: true, headerTooltip: true },
        { name: 'int2Units', displayName: 'Int2 Units', enableCellEdit: false, cellTooltip: true, headerTooltip: true },
        { name: 'int1Units', displayName: 'Int1 Units', enableCellEdit: false, cellTooltip: true, headerTooltip: true },
        { name: 'ftw', displayName: 'FTW', enableCellEdit: false, cellTooltip: true, headerTooltip: true },
        { name: 'app', displayName: 'APP', enableCellEdit: false, cellTooltip: true, headerTooltip: true },
        { name: 'equ', displayName: 'EQY', enableCellEdit: false, cellTooltip: true, headerTooltip: true }
              
      ];
      
      $scope.isTableToshipunits = false;
      $scope.isTableMarkets = false;
      $scope.isTableMarked  = true;
      $scope.gridOptionsMarkedunits.totalItems  = data.totalNoOfRecords;  
      $scope.gridOptionsMarkedunits.data = data.pageItems;

      if ($scope.gridOptionsMarkedunits.data > 10) {
        $scope.gridOptionsMarkedunits.enableVerticalScrollbar = true;
        $scope.gridOptionsMarkedunits.enableHorizontalScrollbar = 1;
      } else {
        $scope.gridOptionsMarkedunits.enableVerticalScrollbar = false;
        $scope.gridOptionsMarkedunits.enableHorizontalScrollbar = 1;
      }
    }
  
  });
  res.error(function (data, status, headers, config) {
    $("#showloader").css("display", "none");
    $scope.isFailed = true;
    $scope.resmessage = "System failed. Please try again or contact WAALOS Support";

  });
};

$scope.mainTab = function(){
	$scope.isSuccess = false;
  $scope.isFailed = false;
};

$scope.shipedUnits = function(){
	$scope.isSuccess = false;
  $scope.isFailed = false;

  $("#showloader").css("display", "block");
  $scope.pageNo = $scope.pageNo ? $scope.pageNo : 1;
  $scope.pageSize = $scope.pageSize ? $scope.pageSize: $scope.gridOptionsShipedunits.paginationPageSize;
	var url = urlService.PICKBY_DATE_GET_SHIPED_UNITS.replace('dName', $scope.pagedc);
  url = url.replace('uName', sessionStorage.userName);
  url = url.replace('pNumber',$scope.pageNo);
  url = url.replace('pSize',$scope.pageSize);
  var res = $http.get(url, { headers: { 'x-api-key': sessionStorage.apikey } });
  
  res.success(function (data, status, headers, config) {
    $("#showloader").css("display", "none");
    if (data.errorMessage) {
      $scope.isFailed = true;
      $scope.resmessage = data.errorMessage;
    } else if (data.resMessage) {
      $scope.isSuccess = true;
      $scope.resmessage = data.resMessage;
    } else {
  
      $scope.gridOptionsShipedunits.columnDefs = [
        { name: 'market', displayName: 'Market', enableCellEdit: false, cellTooltip: true, headerTooltip: true },
        { name: 'totalToShip', displayName: 'Total To Ship', enableCellEdit: false, cellTooltip: true, headerTooltip: true },
        { name: 'totalUnwaved', displayName: 'Total Unwaved', enableCellEdit: false, cellTooltip: true, headerTooltip: true },
        { name: 'totalInProgress', displayName: 'Total In Progress', enableCellEdit: false, cellTooltip: true, headerTooltip: true },
        { name: 'nonVasUnwaved', displayName: 'Non Vas Unwaved', enableCellEdit: false, cellTooltip: true, headerTooltip: true },
        { name: 'nonVasInProgress', displayName: 'Non Vas In Progres', enableCellEdit: false, cellTooltip: true, headerTooltip: true },
        { name: 'vasStandard', displayName: 'Vas Standard', enableCellEdit: false, cellTooltip: true, headerTooltip: true },
        { name: 'int2Cases', displayName: 'Int2 Cases', enableCellEdit: false, cellTooltip: true, headerTooltip: true },
        { name: 'int2Units', displayName: 'Int2 Units', enableCellEdit: false, cellTooltip: true, headerTooltip: true },
        { name: 'int1Units', displayName: 'Int1 Units', enableCellEdit: false, cellTooltip: true, headerTooltip: true },
        { name: 'ftw', displayName: 'FTW', enableCellEdit: false, cellTooltip: true, headerTooltip: true },
        { name: 'app', displayName: 'APP', enableCellEdit: false, cellTooltip: true, headerTooltip: true },
        { name: 'equ', displayName: 'EQY', enableCellEdit: false, cellTooltip: true, headerTooltip: true }
              
      ];
      
      $scope.isTableToshipunits = false;
      $scope.isTableMarkets = false;
      $scope.isTableMarked  = false;
      $scope.isTableShiped = true;
      $scope.gridOptionsShipedunits.totalItems  = data.totalNoOfRecords;  
      $scope.gridOptionsShipedunits.data = data.pageItems;

      if ($scope.gridOptionsShipedunits.data > 10) {
        $scope.gridOptionsShipedunits.enableVerticalScrollbar = true;
        $scope.gridOptionsShipedunits.enableHorizontalScrollbar = 1;
      } else {
        $scope.gridOptionsShipedunits.enableVerticalScrollbar = false;
        $scope.gridOptionsShipedunits.enableHorizontalScrollbar = 1;
      }
    }
  
  });
  res.error(function (data, status, headers, config) {
    $("#showloader").css("display", "none");
    $scope.isFailed = true;
    $scope.resmessage = "System failed. Please try again or contact WAALOS Support";

  });
};

$scope.toShipunits = function(){
	$scope.isSuccess = false;
  $scope.isFailed = false;

  $("#showloader").css("display", "block");

	var url = urlService.PICKBY_DATE_GET_TOSHIP_UNITS.replace('dName', $scope.pagedc);
  url = url.replace('uName', sessionStorage.userName);
  var res = $http.get(url, { headers: { 'x-api-key': sessionStorage.apikey } });
  
  res.success(function (data, status, headers, config) {
    $("#showloader").css("display", "none");
    if (data.errorMessage) {
      $scope.isFailed = true;
      $scope.resmessage = data.errorMessage;
    } else if (data.resMessage) {
      $scope.isSuccess = true;
      $scope.resmessage = data.resMessage;
    } else {
  
      $scope.gridOptionsToshipunitsData.columnDefs = [
        { name: 'market', displayName: 'Market', enableCellEdit: false, cellTooltip: true,cellTemplate: '<div class="ui-grid-cell-contents" ng-click="grid.appScope.marketData(grid, row)"><a href="javascript:void(0)">{{COL_FIELD}}</a></div>', headerTooltip: true },
        { name: 'unitsToShip', displayName: 'Units To Ship', enableCellEdit: false, cellTooltip: true, headerTooltip: true },
              
      ];
      
      $scope.isTableToshipunits = true;
      $scope.isTableMarkets = false;
      $scope.gridOptionsToshipunitsData.data = data;

      if ($scope.gridOptionsToshipunitsData.data > 10) {
        $scope.gridOptionsToshipunitsData.enableVerticalScrollbar = true;
        $scope.gridOptionsToshipunitsData.enableHorizontalScrollbar = 1;
      } else {
        $scope.gridOptionsToshipunitsData.enableVerticalScrollbar = false;
        $scope.gridOptionsToshipunitsData.enableHorizontalScrollbar = 1;
      }
    }
  
  });
  res.error(function (data, status, headers, config) {
    $("#showloader").css("display", "none");
    $scope.isFailed = true;
    $scope.resmessage = "System failed. Please try again or contact WAALOS Support";

  });
};

$scope.marketData = function (grid, row) {
	$scope.isSuccess = false;
  $scope.isFailed = false;

  $("#showloader").css("display", "block");

	var url = urlService.PICKBY_DATE_GET_MARKETS.replace('dName', $scope.pagedc);
  url = url.replace('uName', sessionStorage.userName);
  url = url.replace('marKet', row.entity.market);
  var res = $http.get(url, { headers: { 'x-api-key': sessionStorage.apikey } });
  
  res.success(function (data, status, headers, config) {
    $("#showloader").css("display", "none");
    if (data.errorMessage) {
      $scope.isFailed = true;
      $scope.resmessage = data.errorMessage;
    } else if (data.resMessage) {
      $scope.isSuccess = true;
      $scope.resmessage = data.resMessage;
    } else {
  
      $scope.gridOptions.columnDefs = [
        { name: 'country', displayName: 'Market', enableCellEdit: false, cellTooltip: true,headerTooltip: true },
        { name: 'unitsToShip', displayName: 'Units To Ship', enableCellEdit: false, cellTooltip: true, headerTooltip: true },
              
      ];
      
      $scope.isTableToshipunits = false;
      $scope.isTableMarkets = true;
      $scope.gridOptions.data = data;

      if ($scope.gridOptions.data > 10) {
        $scope.gridOptions.enableVerticalScrollbar = true;
        $scope.gridOptions.enableHorizontalScrollbar = 1;
      } else {
        $scope.gridOptions.enableVerticalScrollbar = false;
        $scope.gridOptions.enableHorizontalScrollbar = 1;
      }
    }
  
  });
  res.error(function (data, status, headers, config) {
    $("#showloader").css("display", "none");
    $scope.isFailed = true;
    $scope.resmessage = "System failed. Please try again or contact WAALOS Support";

  });
};

$scope.backtoMarket = function(){
  $scope.isTableToshipunits = true;
  $scope.isTableMarkets = false;
};

$scope.getFilters = function(){
  $scope.isSuccess = false;
  $scope.isFailed = false;
  $("#showloader").css("display", "block");
  var url = urlService.PICKBY_DATE_GET_FILTERS_DATA.replace('dName',$scope.pagedc);
  url = url.replace('uName',sessionStorage.userName);

var res = $http.get(url, { headers: { 'x-api-key': sessionStorage.apikey } });
  res.success(function (data, status, headers, config) {
    $("#showloader").css("display", "none");
    if (data.errorMessage) {
      $scope.isFailedload = true;
      $scope.resmessage = data.errorMessage;

    } else if (data.resmessage) {
      $scope.isSuccess = true;
      $scope.resmessage = data.errorMessage;

    } else {

      if (data.markets != null || data.markets != []) {
        //markets values
        $scope.marketsValues = [];
        _.each(data.markets, function (val) {
          $scope.marketsValues.push({ 'market': val,  'isChecked': false });
       });
       
      }

      if(data.shipToCountries != null || data.shipToCountries != []){
        //shipToCountries values
        $scope.shiptocountries = [];
        _.each(data.shipToCountries, function (val) {
          $scope.shiptocountries.push({ 'ship': val,  'isChecked': false });
        });
      }

      if(data.codeTypes != null || data.codeTypes != []){
        //codeTypes values
        $scope.codetypes = [];
        _.each(data.codeTypes, function (val) {
          $scope.codetypes.push({ 'code': val,  'isChecked': false });
        });
      }

      if(data.statCodes != null || data.statCodes != []){
        //codeTypes values
        $scope.statcodes = [];
        _.each(data.statCodes, function (val) {
          $scope.statcodes.push({ 'code': val,  'isChecked': false });
        });
      }  


      if(data.prodTypes != null || data.prodTypes != []){
        //codeTypes values
        $scope.prodtypes = [];
        _.each(data.prodTypes, function (val) {
          $scope.prodtypes.push({ 'prob': val,  'isChecked': false });
        });
      } 

      if(data.prepack != null || data.prepack != []){
        //codeTypes values
        $scope.prepacks = [];
        $scope.prepacks.push({ 'pack': "No Prepack",  'isChecked': false });
        _.each(data.prepack, function (val) {
          $scope.prepacks.push({ 'pack': val,  'isChecked': false });
        });
       
      } 

    }
  });
  res.error(function (data, status, headers, config) {
    $("#showloader").css("display", "none");
    $scope.isFailed = true;
    $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
  });
};

//$scope.getFilters();

$scope.applyFilters = function(){
  $scope.isSuccess = false;
  $scope.isFailed = false;

var marketsVal = [];
if ($scope.marketsValues) {
  _.each($scope.marketsValues, function (val, key) {
    if (val.isChecked == true) {
      marketsVal.push(val.market);
    }
  });
}

var shiptoConty = [];
if ($scope.shiptocountries) {
  _.each($scope.shiptocountries, function (val, key) {
    if (val.isChecked == true) {
      shiptoConty.push(val.ship);
    } 
  });
}

var codeTypes = [];
if ($scope.codetypes) {
  _.each($scope.codetypes, function (val, key) {
    if (val.isChecked == true) {
      codeTypes.push(val.code);
    } 
  });
}

var statCodes = [];
if ($scope.statcodes) {
  _.each($scope.statcodes, function (val, key) {
    if (val.isChecked == true) {
      statCodes.push(val.code);
    }
  });
 if(statCodes[0] == "10" && statCodes[1] == undefined ){
  statCodes.push("15");
 }
}

var prodTypes = [];
if ($scope.prodtypes) {
  _.each($scope.prodtypes, function (val, key) {
    if (val.isChecked == true) {
      prodTypes.push(val.prob);
    } 
  });
}

var prePacks = [];
if ($scope.prepacks) {
  _.each($scope.prepacks, function (val, key) {
    if (val.isChecked == true) {
      prePacks.push(val.pack);
    }
  });  
}




var url = urlService.PICKBY_DATE_GET_FILTERS_GRID;

  var postObject ={
    "markets": marketsVal,
    "shipToCountries":shiptoConty,
    "codeTypes": codeTypes,
    "statCodes": statCodes,
    "prodTypes":prodTypes,
    "prepack":prePacks,
    "dcName":  $scope.pagedc,
    "userName":sessionStorage.userName
  };
  var res = $http.post(url, postObject, {
    headers: {'x-api-key': sessionStorage.apikey}
 });
		res.success(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			if (data.errorMessage) {
				$scope.isFailed = true;
				$scope.resmessage = data.errorMessage;
			} else if (data.resMessage) {
				$scope.isSuccess = true;
				$scope.resmessage = data.resMessage;
			} else {
        $scope.records = data;
        $scope.clearFilter = true;
        $scope.isTable = true;
        $scope.isFilters = false;
        $scope.isTabresult = true;

         
     	postRecords=[];
       
           _.each(data, function (val, key) {
            var records = {
              "pktType":val.pktType,
              "<3Units":val.pastUnits,
              "<3Pkts":val.pastPkts,
       
            };
           var recordsdata = [];
           for(var i = 0; i<val.pickByDateCurDateDtoLst.length; i++){
             var dateFormat = val.pickByDateCurDateDtoLst[i].date;
             var fristKeyName = dateFormat + 'Units';
             var secondKeyName = dateFormat+ 'Pkts';
             records[fristKeyName] = val.pickByDateCurDateDtoLst[i].currUnits;
             records[secondKeyName] = val.pickByDateCurDateDtoLst[i].currPkts;
           }
           records[">5Units"]=val.futureUnits;
           records[">5Pkts"]=val.futurePkts;
           records["stoUnits"]=val.stoUnits;
           records["stoPkts"]=val.stoPkts;
            postRecords.push(records);
           });
           $scope.gridOptionsFilterData.data =postRecords;
         $scope.gridOptionsFilterData.columnDefs = [];
                 var width = "";
               _.each(postRecords, function (value, key) {
                 var length =Object.keys(postRecords[0]).length;
                 if ($scope.gridOptionsFilterData.columnDefs.length != length) {
                   for (var i = 0; i < Object.keys(value).length; i++) {
       
                     //regular expression to provide spaces at camel case notation and capitalize first letter in the word
                      var displayName = Object.keys(value)[i]
                   .replace(/\w\S*/g, function (txt) {
                       return txt.charAt(0).toUpperCase() + txt.substr(1);
                      }).replace(/\s/g, "").replace(/([A-Z])/g, ' $1').trim();
                   
                       
                      
                       if(displayName == "Pkt Type" ||  displayName == "Sto Units" || displayName == "Sto Pkts"){
                         $scope.gridOptionsFilterData.columnDefs.push({ name: Object.keys(value)[i], displayName: displayName, enableCellEdit: false,width:120 });
                       }else if(displayName == "<3 Units" || displayName == "<3 Pkts"){
                         $scope.gridOptionsFilterData.columnDefs.push({ name: Object.keys(value)[i], displayName: displayName, enableCellEdit: false,width:80,cellTemplate:  '<div class="ui-grid-cell-contents" ng-click="grid.appScope.threeUnits(grid, row,col)"><a href="javascript:void(0)">{{COL_FIELD}}</a></div>' });
                       }else if(displayName == ">5 Units" || displayName == ">5 Pkts"){
                         $scope.gridOptionsFilterData.columnDefs.push({ name: Object.keys(value)[i], displayName: displayName, enableCellEdit: false,width:80,cellTemplate:  '<div class="ui-grid-cell-contents" ng-click="grid.appScope.fiveUnits(grid, row,col)"><a href="javascript:void(0)">{{COL_FIELD}}</a></div>' });
                       }else{
                         $scope.gridOptionsFilterData.columnDefs.push({ name: Object.keys(value)[i], displayName: displayName, enableCellEdit: false,width:150,cellTemplate:  '<div class="ui-grid-cell-contents" ng-click="grid.appScope.byDate(grid, row,col)"><a href="javascript:void(0)">{{COL_FIELD}}</a></div>' });
                       }
                     
                   }
                 }
                  
               });

				if ($scope.gridOptionsFilterData.data > 10) {
					$scope.gridOptionsFilterData.enableVerticalScrollbar = true;
					$scope.gridOptionsFilterData.enableHorizontalScrollbar = 1;
				} else {
					$scope.gridOptionsFilterData.enableVerticalScrollbar = false;
					$scope.gridOptionsFilterData.enableHorizontalScrollbar = 1;
        }
       
       // setTimeout(function(){  $scope.expandAllRows(); }, 1000);
       
      }
    
			$('.ui-grid-pager-control input').prop("disabled", true);
		});
		res.error(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			$scope.isFailed = true;
			$scope.resmessage = "System failed. Please try again or contact WAALOS Support";

		});

};


$scope.checkedValues = function(){

  var marketsVal = [];
  if ($scope.marketsValues) {
    var count = 0;
    _.each($scope.marketsValues, function (val, key) {
      if(val.isChecked == false){
        $scope.alloption.marketAll  = false;
       }else{
         count++;
       }
    });
    if(count == $scope.marketsValues.length){
      $scope.alloption.marketAll  = true;
     
    }
    _.each($scope.marketsValues, function (val, key) {
      if (val.isChecked == true) {
        marketsVal.push(val.market);
      }
    });
  }
  
  var shiptoConty = [];
  if ($scope.shiptocountries) {
    _.each($scope.shiptocountries, function (val, key) {
      if (val.isChecked == true) {
        shiptoConty.push(val.ship);
      } 
    });
   }
  
  var codeTypes = [];
  if ($scope.codetypes) {
    _.each($scope.codetypes, function (val, key) {
      if (val.isChecked == true) {
        codeTypes.push(val.code);
      } 
    });
    }
  
  var statCodes = [];
  if ($scope.statcodes) {
    _.each($scope.statcodes, function (val, key) {
      if (val.isChecked == true) {
        statCodes.push(val.code);
      }
    });
   
  }
  
  var prodTypes = [];
  if ($scope.prodtypes) {
    _.each($scope.prodtypes, function (val, key) {
      if (val.isChecked == true) {
        prodTypes.push(val.prob);
      } 
    });
   
  }
  
  var prePacks = [];
  if ($scope.prepacks) {
    _.each($scope.prepacks, function (val, key) {
      if (val.isChecked == true) {
        prePacks.push(val.pack);
      }
    }); 
   
  }

  if(marketsVal.length > 0 || shiptoConty.length > 0 || codeTypes.length > 0 
    || statCodes.length > 0 || prodTypes.length > 0 || prePacks.length > 0
    || $scope.alloption.marketAll == true ||  $scope.alloption.shiptocountriesAll == true 
    || $scope.alloption.codetypesAll == true ||  $scope.alloption.statcodesAll == true
    || $scope.alloption.prodtypesAll == true || $scope.alloption.prepacksAll == true ){
    $scope.isDisable = false;
  }else{
    $scope.isDisable = true;
  } 

    };


$scope.backFilters = function(){
  $scope.isSuccess = false;
  $scope.isFailed = false;
  $scope.isFilters = true;
  $scope.isTabresult = false;
  $scope.getFilters();

};

$scope.backTabs = function(){
  $scope.isSuccess = false;
  $scope.isFailed = false;
  $scope.isFilters = false;
  $scope.isTabresult = true;
  $scope.filterData();

};

$scope.values = {
  futuredays:"",
  checkedpre: false,
  checkedbook:false
};
$scope.disable = false;
$scope.codesData = ["Active Only"];
$scope.newLogicals = $scope.codesData[0];

$scope.maskMark = function(){
  $scope.isSuccess = false;
  $scope.isFailed = false;
  $("#showloader").css("display", "block");
  
  var url = urlService.PICKBY_DATE_POST_MASK_MARK;
  
  var postObject = {
    "actionType" : "",
    "dcName" : $scope.pagedc,
    "userName" : sessionStorage.userName,
    "futureDays":$scope.values.futuredays,
    "prepackFltr":$scope.values.checkedpre,
    "bookingFltr":$scope.values.checkedbook

  };
    var res = $http.put(url, postObject, {
      headers: {'x-api-key': sessionStorage.apikey}
   });
      res.success(function (data, status, headers, config) {
        $("#showloader").css("display", "none");
        if (data.errorMessage) {
          $scope.isFailed = true;
          $scope.resmessage = data.errorMessage;
        } else if (data.resMessage) {
          $scope.isSuccess = true;
          $scope.resmessage = data.resMessage;
        } 
      
      });
      res.error(function (data, status, headers, config) {
        $("#showloader").css("display", "none");
        $scope.isFailed = true;
        $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
  
      });

};



$scope.futuredayscal = function(val){
  
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $scope.resmessage = "";
   if(val !=null){
    if (isNaN(val) || val==undefined) {
      $scope.isFailed = true;
      $scope.resmessage = "Please enter only numaric values";
      $scope.disable = true;
      }else{
      $scope.disable = false;
      $scope.isFailed = false;
      $scope.resmessage = "";
    }
  }
if(val != undefined){
    if(val == "" || val == null){
      $scope.disable = false;
      $scope.isFailed = false;
      $scope.resmessage = "";
    }
  }

  };

$scope.clearSets = function(){


  $scope.isSuccess = false;
  $scope.isFailed = false;
  $("#showloader").css("display", "block");
  
  var url = urlService.PICKBY_DATE_POST_CLEAR_SETS;
  
  var postObject = {
    "userName" : sessionStorage.userName,
    "dcName" : $scope.pagedc,
    "pkts":[]
 };
    var res = $http.put(url, postObject, {
      headers: {'x-api-key': sessionStorage.apikey}
   });
      res.success(function (data, status, headers, config) {
        $("#showloader").css("display", "none");
        if (data.errorMessage) {
          $scope.isFailed = true;
          $scope.resmessage = data.errorMessage;
        } else if (data.resMessage) {
          $scope.isSuccess = true;
          $scope.resmessage = data.resMessage;
        } 
      
      });
      res.error(function (data, status, headers, config) {
        $("#showloader").css("display", "none");
        $scope.isFailed = true;
        $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
  
      });

};


$scope.update = function(){
  
  
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $("#showloader").css("display", "block");
    
    var url = urlService.PICK_BY_DATE_UPDATE;
    
   

   var postRecords = [];
   angular.forEach($scope.gridApi.selection.getSelectedRows(), function (data, index) {
    
     postRecords.push(data.pkts);
   });
   var records = {
    "userName": sessionStorage.userName,
    "dcName": $scope.pagedc,
     "pkts": postRecords.map(Number)
  };
      var res = $http.put(url, records, {
        headers: {'x-api-key': sessionStorage.apikey}
     });
        res.success(function (data, status, headers, config) {
          $("#showloader").css("display", "none");
          if (data.errorMessage) {
            $scope.isFailed = true;
            $scope.resmessage = data.errorMessage;
          } else if (data.resMessage) {
            $scope.gridApi.selection.clearSelectedRows();
            $scope.isSuccess = true;
            $scope.resmessage = data.resMessage;
          
          } 
        
        });
        res.error(function (data, status, headers, config) {
          $("#showloader").css("display", "none");
          $scope.isFailed = true;
          $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
    
        });
  
  };
 
//user favourites code starts
$scope.isClicked = false;
$scope.addToFavourate = function(isClicked){
  $("#showloader").css("display", "block");
   if(typeof isClicked !== "boolean"){
    commonService.postServiceResponse(urlService.GET_FAVOURITES,{"username": sessionStorage.userName})
      .then(function(response){
        $("#showloader").css("display", "none");
          _.each(response,function(val,key){
            if(val.funName == $scope.functionality && val.dcName == $scope.dcName){
              $scope.isClicked = true;      
            }
          });
      },function(error){
        $("#showloader").css("display", "none");
        $scope.isClicked = false; 
      });
   }else{
    if(!$scope.isClicked){
      commonService.postServiceResponse(urlService.ADD_FAVOURITE,{"username": sessionStorage.userName,"dcName":$scope.dcName,"funName":$scope.functionality})
      .then(function(response){
        $("#showloader").css("display", "none");
        if(response.errorMessage){
          $scope.isFavouriteAdded= false; 
          $scope.isClicked = false;      
          $scope.$broadcast('showAlert',['']);
        }else{
          $scope.isClicked = true;      
          $scope.isClicked = !isClicked;
          $scope.isFavouriteAdded= true; 
          $scope.favouriteMsg = response.resMessage;
        $scope.$broadcast('ClickedOnFavourate',[$scope.dcName,$scope.functionality,$scope.isClicked]);
        }
          
      },function(error){
        $scope.isClicked = false;
        $("#showloader").css("display", "none");
      });
      $scope.isClicked = !isClicked;
    }else{
      $("#showloader").css("display", "none");
    }
   }
  
};
$scope.addToFavourate('load');
//user favourites code ends
}]);


