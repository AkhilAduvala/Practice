
var app = angular.module('ArticleDimension', ['ngAnimate', 'ui.grid', 'ui.grid.selection',  'ui.grid.pagination', 'ui.grid.edit']);

app.controller('ArticleDimensionCtrl', ['$scope', '$http', '$q', '$interval', 'uiGridValidateService', '$timeout','urlService','uiGridConstants','commonService', function ($scope, $http, $q, $interval, uiGridValidateService, $timeout,urlService,uiGridConstants,commonService) {
  
  $scope.isTable = false;
  $scope.disable = true;
  $scope.isSuccess = false;
  $scope.isFailed = false;
  $scope.isClicked = false;
  $scope.isCopy = true;
  $scope.isFieldValidate = false; 
  $scope.pagefunctionality = $scope.functionality;
  $scope.pagedc = $scope.dcName;
  $scope.copybutton = true;

  $("#showloader").css("display", "none");

  $scope.gridOptions = {
    paginationPageSizes: [15, 25, 50, 100],
    paginationPageSize: 15,
    enableSorting: true,
    useExternalPagination: true,
    enableColumnMenus: false,
     enableHorizontalScrollbar: false,
  };
  $scope.gridOptions.onRegisterApi = function (gridApi) {
    //set gridApi on scope
    $scope.gridApi = gridApi;

    $scope.gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
      $scope.pageNo =  newPage;
      $scope.pageSize = pageSize;
      if( $scope.source){
        $scope.getArticleDimensionData($scope.source);
        
      }else{ 
        $scope.getArticleDimensionData($scope.val);
      }
     
   });
  };

  // Validation airticle number
  $scope.airticlevalid = function () {
    $scope.isSuccess = false;
    $scope.isFailed = false;
    var reg = /^[0-9a-zA-Z\_ ]+$/;
    if($scope.airticleNum == undefined || $scope.airticleNum  == "") {
      $scope.disable = true; $scope.isFailed = false;
    }else if($scope.airticleNum == undefined || $scope.airticleNum == 32 || !(reg.test($scope.airticleNum))){
      $scope.disable = true;

$scope.isFailed = true;
 $scope.resmessage = "Please enter a valid data";
    }else {
     $scope.disable = false;
    }
  };

 // onenter Validation airticle number
  $scope.skuNum = function($event){

    var keyCode = $event.which || $event.keyCode;
    var reg = /^[0-9a-zA-Z\_ ]+$/;
    if($event.currentTarget.value.length > 2 && keyCode === 13 && $event.currentTarget.value != undefined && $event.currentTarget.value != "" &&  $event.currentTarget.value != 32 && (reg.test($event.currentTarget.value))){
      $scope.disable = false;
      $scope.getArticleDimensionData();
    }
if(keyCode === 13){
if($event.currentTarget.value == "" || $event.currentTarget.value.length < 2 || $event.currentTarget.value == undefined || $event.currentTarget.value == 32 || !(reg.test($event.currentTarget.value))){
      $scope.disable = true;
$scope.isFailed = true;
 $scope.resmessage = "Please enter a valid data";
    }
}

  };

  $scope.getArticleDimensionData = function (distArticleNum) {

    $scope.resmessage = "";
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $scope.isFieldValidate = false;
    $("#showloader").css("display", "block");
    $scope.pageNo = $scope.pageNo ? $scope.pageNo : 1;
    $scope.pageSize = $scope.pageSize ? $scope.pageSize: $scope.gridOptions.paginationPageSize;
    $scope.source = $scope.airticleNum; 

     var url = urlService.SEARCH_ARTICLE_DIMENSIONS.replace('dName',$scope.pagedc);
     url = url.replace('uName',sessionStorage.userName);
     url = url.replace('pNumber',$scope.pageNo);
     url = url.replace('pSize',$scope.pageSize);
     if(distArticleNum != undefined){
      url = url.replace('aiticleNum',distArticleNum.trim());
     }else{
      url = url.replace('aiticleNum',$scope.airticleNum.trim());
     }
     
     var res = $http.get(url, {
      headers: {'x-api-key': sessionStorage.apikey}
     });
  
    res.success(function (data, status, headers, config) {

      $("#showloader").css("display", "none");

      if (data.errorMessage) {
        $scope.isTable = false;
        $scope.isFailed = true;
        $scope.resmessage = data.errorMessage;
      }
      else if(data.resMessage){
        $scope.isTable = false;
        $scope.isSuccess = true;
        $scope.resmessage = data.resMessage;
      }
      else if(data.length === 0){
        $scope.isTable = false;
        $scope.isFailed = true;
        $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
      }
      else {
        $scope.isTable = true;
        $scope.isCopy = false;

        $scope.gridOptions.columnDefs = [
          { name: 'dspSku', displayName: 'Display SKU',visible: true,width: 120 },
          { name: 'unitLen', displayName: 'Unit Length', cellTooltip: true, headerTooltip: true ,width: 120  },
          { name: 'unitHgt', displayName: 'Unit Height',cellTooltip: true, headerTooltip: true,width: 120 },
          { name: 'unitWdt', displayName: 'Unit Width', cellTooltip: true, headerTooltip: true,width: 120 },
          { name: 'unitWgt', displayName: 'Unit Weight', cellTooltip: true, headerTooltip: true,width: 120 },
          { name: 'unitVol', displayName: 'Unit Volume', cellTooltip: true, headerTooltip: true ,width: 120},
          { name: 'stdCaseHgt', displayName: 'STD Case Height', cellTooltip: true, headerTooltip: true,width: 150 },
          { name: 'stdCaseLen', displayName: 'STD Case Length', cellTooltip: true, headerTooltip: true,width: 150 },
          { name: 'stdCaseWdt', displayName: 'STD Case Width', cellTooltip: true, headerTooltip: true,width: 150 },
          { name: 'stdCaseWgt', displayName: 'STD Case Weight', cellTooltip: true, headerTooltip: true,width: 150 },
          { name: 'stdCaseVol', displayName: 'STD Case Volume ', cellTooltip: true, headerTooltip: true,width: 150 },
          { name: 'stdCaseQty', displayName: 'STD Case Quantity', cellTooltip: true, headerTooltip: true,width: 170 }

        ];

        $scope.gridOptions.totalItems  = data.totalNoOfRecords;  
        $scope.gridOptions.data = data.pageItems;

        if ($scope.gridOptions.data.length > 10) {
          $scope.gridOptions.enableVerticalScrollbar = 1;
          $scope.gridOptions.enableHorizontalScrollbar = 1;
        } else {
          $scope.gridOptions.enableVerticalScrollbar = 0;
          $scope.gridOptions.enableHorizontalScrollbar = 1;
        }
         }

         if($scope.airticle == "" && distArticleNum != undefined){
          $scope.isCopy = true;
          document.getElementById("iscopy").setAttribute("disabled", "disabled");
          }
      
    });

    res.error(function (data, status, headers, config) {
      $("#showloader").css("display", "none");
      $scope.isFailed = true;
      $scope.resmessage = "System failed. Please try again or contact WAALOS Support";

    });
    $scope.disableinput();
    
  };

  //Source Article number (popup) validation
$scope.checkValidation = function(){
  $scope.val = $scope.airticle;
  var reg = /^[0-9a-zA-Z\_ ]+$/;
  if ($scope.val.length < 2 || $scope.val.length > 7 || $scope.val == '' || $scope.val == null || $scope.val == undefined || $scope.val == 32 || !(reg.test($scope.val))) {
    $scope.copybutton = true;
  }else if($scope.source == $scope.val){ $scope.copybutton = true;}
else {
    $scope.copybutton = false;
  }
};

//Reset the values in popup
$scope.copy = function(){
  $scope.airticle = "";
  $scope.copybutton = true;
}

//Updates Source Result
  $scope.copyResult = function () {

    $("#copyModel").modal('hide');
    $scope.resmessage = "";
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $scope.isFailedload = false;
    $scope.isFieldValidate = false;

    $("#showloader").css("display", "block");
    var dataObj = {
        "referenceSku":$scope.source,
        "newSku":$scope.val,
        "dcName":$scope.dcName,
        "userName":sessionStorage.userName
    };

    var url = urlService.COPY_ARTICLE_DIMENSIONS;
    var res = $http.put(url, dataObj, {
       headers: {'x-api-key': sessionStorage.apikey}    });

      res.success(function (data, status, headers, config) {
      $("#showloader").css("display", "none");

      if (data.errorMessage) {
        $scope.isTable = false;
        $scope.isFailed = true;
        $scope.resmessage = data.errorMessage;
      }
      else if(data.resMessage){
        $scope.source  = "";
        $scope.airticleNum = "";
        $scope.disable = true;
        $scope.airticle = "";
        $scope.copybutton = true;
        if($scope.airticle == ""){
          $scope.isCopy = true;
          document.getElementById("iscopy").setAttribute("disabled", "disabled");
          }
        $scope.getArticleDimensionData($scope.val);
        $scope.isTable = true;
        $scope.isSuccess = true;
        $scope.resmessage = data.resMessage;
   
      }
    
            
    });

    res.error(function (data, status, headers, config) {
      $("#showloader").css("display", "none");
      $scope.isFailed = true;
      $scope.resmessage = "System failed. Please try again or contact WAALOS Support";

    });
   // $scope.disableinput();
    
  };

  $scope.disableinput= function(){
    setTimeout(function(){  $('.ui-grid-pager-control-input').attr( "disabled", true );  }, 2000);
  
  }

	//user favourites code start
	$scope.isClicked = false;
	$scope.addToFavourate = function (isClicked) {
		$("#showloader").css("display", "block");
		if (typeof isClicked !== "boolean") {
			commonService.postServiceResponse(urlService.GET_FAVOURITES, { "username": sessionStorage.userName })
				.then(function (response) {
					$("#showloader").css("display", "none");
					_.each(response, function (val, key) {
						if (val.funName == $scope.functionality && val.dcName == $scope.dcName) {
							$scope.isClicked = true;
						}
					});
				}, function (error) {
					$("#showloader").css("display", "none");
					$scope.isClicked = false;
				});
		} else {
			if (!$scope.isClicked) {
				commonService.postServiceResponse(urlService.ADD_FAVOURITE, { "username": sessionStorage.userName, "dcName": $scope.dcName, "funName": $scope.functionality })
					.then(function (response) {
						$("#showloader").css("display", "none");
						if (response.errorMessage) {
							$scope.isFavouriteAdded = false;
							$scope.isClicked = false;
							$scope.$broadcast('showAlert', ['']);
						} else {
							$scope.isClicked = true;
							$scope.isClicked = !isClicked;
							$scope.isFavouriteAdded = true;
							$scope.favouriteMsg = response.resMessage;
							$scope.$broadcast('ClickedOnFavourate', [$scope.dcName, $scope.functionality, $scope.isClicked]);
						}

					}, function (error) {
						$scope.isClicked = false;
						$("#showloader").css("display", "none");
					});
				$scope.isClicked = !isClicked;
			} else {
				$("#showloader").css("display", "none");
			}
		}
	};
	$scope.addToFavourate('load');
	//user favourites code ends
}]);

