var myApp = angular.module('ItemBulkUpdateLoader');
$("#showloader").css("display", "none");
myApp.directive('fileModel', ['$parse', function ($parse) {
	return {
		restrict: 'A',
		link: function (scope, element, attrs) {
			var model = $parse(attrs.fileModel);
			var modelSetter = model.assign;

			element.bind('change', function () {
				scope.$apply(function () {
					modelSetter(scope, element[0].files[0]);
				});
			});
		}
	};
}]);

myApp.service('fileUpload2', ['$http', function ($http) {
	
	this.uploadFileToUrl = function (dcName, userName, file, lotId, uploadUrl, $scope) {
		$("#showloader").css("display", "block");
		document.getElementById('list').innerHTML = '';
		document.getElementById('nextStep').innerHTML = '';
		var fd = new FormData();
		fd.append('dcName', dcName);
		fd.append('userName', userName);

		fd.append('lotId', lotId);

		$http.post(uploadUrl, fd, {
			transformRequest: angular.identity,
			headers: { 'Content-Type': undefined,'x-api-key': sessionStorage.apikey }
		})

			.success(function (response) {
				document.getElementById('list').innerHTML = '';
				document.getElementById('nextStep').innerHTML = '';
				$("#showloader").css("display", "none");
				if (response.errorMessage) {
					$scope.uploadError = response.errorMessage;
				} else {
					document.getElementById('list').innerHTML = response.resMessage;
					$scope.disable = true;
					$scope.errorMessagesArray = [];


				}
			})

			.error(function (error) {
				$("#showloader").css("display", "none");
				$scope.isFailedload = true;
				document.getElementById('list').innerHTML = '';
				document.getElementById('nextStep').innerHTML = '';
				$scope.errorMessagesArray = [];
			});
	};
}]);
myApp.controller('ItemBulkUpdateLoaderController', ['$scope', '$rootScope', '$http', '$window', 'fileUpload2', 'urlService','commonService', function ($scope, $rootScope, $http, $window, fileUpload2, urlService,commonService) {
	$("#showloader").css("display", "none");
	$scope.disable = true;
	$scope.disableDownload = true;
	$scope.pagefunctionality = $scope.functionality;
	$scope.pagedc = $scope.dcName;
	$scope.lotId = "";
	$scope.isClicked = false;
	$scope.isFailedload = false;
	$scope.profileLoad = function () {
		var file = $scope.myFile;
		var dcName = $rootScope.dcName;
		var userName = sessionStorage.userName;
		var lotId = $scope.lotId;
		var uploadUrl = urlService.ITEM_BULK_UPDATE_UPLOAD_UPLOADFILE;
		fileUpload2.uploadFileToUrl(dcName, userName, file, lotId, uploadUrl, $scope);
	};

	$scope.clearFile = function () {
		$scope.isFailed = false;
		$scope.excelReadErrors = false;
		$scope.excelErrors = false;
		document.getElementById('list').innerHTML = '';
		document.getElementById('nextStep').innerHTML = '';
		$scope.errorMessagesArray = [];
		$scope.disableDownload = true;
	};
	
	var fileInput = document.getElementById("uploadFile");
	$scope.uploadchange = function(evt){
		
		if (evt.value.length == 0) {


		} else {

			$scope.excelErrors = false;
			$scope.isFailedload = false;
			$scope.excelReadErrors = false;
			$scope.isFailed = false;
			document.getElementById('list').innerHTML = '';
			document.getElementById('nextStep').innerHTML = '';
			$scope.errorMessagesArray = [];

			fileExtension = evt.value.substr((evt.value.lastIndexOf('.') + 1));

			if (fileExtension == "xls") {
				$scope.isFailed = true;
				$scope.resmessage = "Please save this xls file into xlsx format and try again to Choose File";
				return false;
			}


			if (evt.value.indexOf(".xlsx") < 0) {
				$scope.isFailed = true;
				$scope.resmessage = "Please choose only XLSX file";
				return false;
			}


			var dcName = $scope.dcName;
			var userName = sessionStorage.userName;
			var files = evt.files;
			var fileval = $("input[type='file']").val();
			var output = [];
			if (fileval == '' || fileval == undefined || fileval == null) {
				document.getElementById('list').innerHTML = '';
				document.getElementById('nextStep').innerHTML = '';
				$scope.disable = false;
			} else {
				$("#showloader").css("display", "block");
				var uploadUrl = urlService.ITEM_BULK_UPDATE_UPLOAD_CHOOSEFILE;
				for (var i = 0, f; f = files[i]; i++) {
					output.push('<li><strong>', escape(f.name), '</strong> was choosen successfully</li>');
					localStorage.setItem("choosenFile", files[i]);
					var file = files[i];
					var fd = new FormData();
					fd.append('dcName', dcName);
					fd.append('userName', userName);
					fd.append('file', file);
					if (files[i].size < 1024 * 1024 * 10) {
						$http.post(uploadUrl, fd, {
							transformRequest: angular.identity,
							headers: { 'Content-Type': undefined,'x-api-key': sessionStorage.apikey }
						})

							.success(function (response) {
								if (response.lotId) {
									$scope.lotId = response.lotId;
									if (response.totalCount === response.errorCount) {
										$scope.disableDownload = false;
										$scope.disable = true;
										document.getElementById('nextStep').innerHTML = response.errorCount + ' ' + 'Out of' + ' ' + response.totalCount + ' ' + 'records are invalid';
										$scope.errorMessagesArray = response.errorDtoLst;
										$("#showloader").css("display", "none");
									} else {
										if(response.errorCount === 0){$scope.disableDownload = true;}else{$scope.disableDownload = false;}
										$scope.disable = false;
										document.getElementById('list').innerHTML = response.successCount + ' ' + 'Out of' + ' ' + response.totalCount + ' ' + 'records are valid -Please Proceed to Upload';
										$scope.errorMessagesArray = response.errorDtoLst;
										$("#showloader").css("display", "none");
									}
								} else if (response.errorMessage) {
									$scope.disableDownload = true;
									$scope.disable = true;
									$scope.excelReadErrors = true;
									$scope.excelReadError = response;

									$("#showloader").css("display", "none");
								} else {

									$scope.disable = true;
									$scope.excelErrorsData = response;
									$scope.excelErrors = true;
									$("#showloader").css("display", "none");

								}
							})
							.error(function (err) {
								$("#showloader").css("display", "none");
								$scope.isFailedload = true;
								$scope.errorMessagesArray = [];
							});
					} else {
						$("#showloader").css("display", "none");
						$scope.isFailed = true;
						$scope.resmessage = "File size should not exceed 10MB";
						$scope.errorMessagesArray = [];
					}

				}
			}
		}
	};

	$scope.uploadclick =  function(){ 

		var input = document.getElementById("uploadFile");

		if (input.value.length == 0) {

		} else if (input.value.length > 0) {
			input.value = null;
	        input.value = '';
			input.type = '';
			input.type = 'file';
			document.getElementById("uploadFile").value = null;
		}
	};

	//user favourites code starts
	$scope.addToFavourate = function(isClicked){
		$("#showloader").css("display", "block");
		 if(typeof isClicked !== "boolean"){
		  commonService.postServiceResponse(urlService.GET_FAVOURITES,{"username": sessionStorage.userName})
			.then(function(response){
			  $("#showloader").css("display", "none");
				_.each(response,function(val,key){
				  if(val.funName == $scope.functionality && val.dcName == $scope.dcName){
					$scope.isClicked = true;      
				  }
				});
			},function(error){
			  $("#showloader").css("display", "none");
			  $scope.isClicked = false; 
			});
			//$scope.isClicked = ;
		 }else{
		  if(!$scope.isClicked){
			commonService.postServiceResponse(urlService.ADD_FAVOURITE,{"username": sessionStorage.userName,"dcName":$scope.dcName,"funName":$scope.functionality})
			.then(function(response){
			  $("#showloader").css("display", "none");
			  if(response.errorMessage){
				$scope.isFavouriteAdded= false; 
				$scope.isClicked = false;      
				$scope.$broadcast('showAlert',['']);
			  }else{
				$scope.isClicked = true;      
				$scope.isClicked = !isClicked;
				$scope.isFavouriteAdded= true; 
				$scope.favouriteMsg = response.resMessage;
			  $scope.$broadcast('ClickedOnFavourate',[$scope.dcName,$scope.functionality,$scope.isClicked]);
			  }
				
			},function(error){
			  $scope.isClicked = false;
			  $("#showloader").css("display", "none");
			});
			$scope.isClicked = !isClicked;
		  }else{
			$("#showloader").css("display", "none");
		  }
		 }
		
	  };

	  $scope.addToFavourate('load');
	  //user favourites code ends

	  $scope.downloadExcel = function() {
		$scope.isFailed = false;
		$("#showloader").css("display", "block");
		var url;
		 url = urlService.ITEM_BULK_UPDATE_DOWNLOAD_ERRORS.replace('LID',$scope.lotId);

	
	$http({
			method: 'GET',
			url: url,
			headers: {				
				'Content-type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'x-api-key': sessionStorage.apikey
			},
			responseType: 'arraybuffer'
		})
	.success( function(data, status, headers) {
	
	$("#showloader").css("display", "none");
	
		if(data.byteLength == 55){
				$scope.isFailed = true;
				  $('#alert-box').modal('show');
	
	
				  }else if(data.byteLength == 98){
			$scope.isFailed = true;
			$scope.resmessage = "Error in Downloading Excel file";
			return;
		}else{
			
			var octetStreamMime = 'application/octet-stream';
			var success = false;
	
			// Get the headers
			headers = headers();
	        var blob;
			// Get the filename from the x-filename header or default to "download.bin"
			var filename = headers['x-filename'] || 'Item_Bulk_Update_Loader_Error.xlsx';
	
			// Determine the content type from the header or default to "application/octet-stream"
			var contentType = headers['content-type'] || octetStreamMime;
	
			try
			{
				// Try using msSaveBlob if supported
				console.log("Trying saveBlob method ...");
				 blob = new Blob([data], { type: contentType });
				if(navigator.msSaveBlob)
					navigator.msSaveBlob(blob, filename);
				else {
					// Try using other saveBlob implementations, if available
					var saveBlob = navigator.webkitSaveBlob || navigator.mozSaveBlob || navigator.saveBlob;
					if(saveBlob === undefined) throw "Not supported";
					saveBlob(blob, filename);
				}
				console.log("saveBlob succeeded");
				success = true;
			} catch(ex)
			{
				console.log("saveBlob method failed with the following exception:");
				console.log(ex);
			}
	
			if(!success)
			{
				// Get the blob url creator
				var urlCreator = window.URL || window.webkitURL || window.mozURL || window.msURL;
				if(urlCreator)
				{
					// Try to use a download link
					var link = document.createElement('a');
					if('download' in link)
					{
						// Try to simulate a click
						try
						{
							// Prepare a blob URL
							console.log("Trying download link method with simulated click ...");
							 blob = new Blob([data], { type: contentType });
							 url = urlCreator.createObjectURL(blob);
							link.setAttribute('href', url);
	
							// Set the download attribute (Supported in Chrome 14+ / Firefox 20+)
							link.setAttribute("download", filename);
	
							// Simulate clicking the download link
							var event = document.createEvent('MouseEvents');
							event.initMouseEvent('click', true, true, window, 1, 0, 0, 0, 0, false, false, false, false, 0, null);
							link.dispatchEvent(event);
							console.log("Download link method with simulated click succeeded");
							success = true;
	
						} catch(ex) {
							console.log("Download link method with simulated click failed with the following exception:");
							console.log(ex);
						}
					}
	
					if(!success)
					{
						// Fallback to window.location method
						try
						{
							// Prepare a blob URL
							// Use application/octet-stream when using window.location to force download
							console.log("Trying download link method with window.location ...");
							 blob = new Blob([data], { type: octetStreamMime });
							 url = urlCreator.createObjectURL(blob);
							window.location = url;
							console.log("Download link method with window.location succeeded");
							success = true;
						} catch(ex) {
							console.log("Download link method with window.location failed with the following exception:");
							console.log(ex);
						}
					}
	
				}
			}
	
			if(!success)
			{
				// Fallback to window.open method
				console.log("No methods worked for saving the arraybuffer, using last resort window.open");
				window.open(rowData.pathName, '_blank', '');
			}
		}
	})
	.error(function(data, status, config) {
	
		console.log("Request failed with status: " + status);
	$("#showloader").css("display", "none");
		// Optionally write the error out to scope
		//$scope.errorDetails = "Request failed with status: " + status;
	$scope.isFailed = true;
			$scope.resmessage = "Error in downloading Excel File";
	
	});
	};
}]);
