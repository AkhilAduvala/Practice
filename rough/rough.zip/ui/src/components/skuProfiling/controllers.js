var app = angular.module('SKUProfiling');

app.controller('SKUProfilingController', ['$scope', '$http', '$q', '$interval', '$timeout','urlService','uiGridConstants','commonService', function ($scope, $http, $q, $interval, $timeout,urlService,uiGridConstants,commonService) {
 // $scope.showDNNumbers = true;
  $scope.isSuccess = false;
  $scope.isFailed = false;
  $scope.disable = true;
  $scope.pagefunctionality = $scope.functionality;
  $scope.pagedc = $scope.dcName;
  $scope.type = "NonSortable";
  //$scope.dnNumbers = "";
  $("#showloader").css("display", "none");
  
  /**
  This function is used to change the 'showDNNumbers' value true/false based on the selected radio button.
  Based on the selected value, The Textarea is displayed(true), otherwise hide(false).
  **/
  $scope.getStyles = function(fun){
	$scope.styles = "";
	 $scope.isSuccess = false;
	 $scope.isFailed = false;
	$scope.disable = true;
	$scope.validateStyles();
  };

  /**
	This function is used to change the disable value to false. Based on this update button will enable.
  **/
  $scope.validateStyles = function(styles){
	  $scope.isSuccess = false;
	 $scope.isFailed = false;
	  if($scope.styles){
		  $scope.disable = false;
	  }else{
		  $scope.disable = true; 
	  }
  };
  
  
  $scope.resetData = function(){
	$scope.styles = "";
	$scope.isSuccess = false;
	$scope.isFailed = false;
	$scope.disable = true; 
  $scope.type = "NonSortable";	
  };
  
  /** This function is used to update the WaveBuddy **/
  $scope.updateWaveBuddy = function(type){
	  $scope.isSuccess = false;
	  $scope.isFailed = false;
	  var newStr = [];
	  //debugger;
		var str_array = ($scope.styles.trim().replace(/\n/g, ",")).replace(/,+/g, ',').replace(/(^\s*,)|( ,\s*$)/g, '');
		var lastChar = str_array[str_array.length - 1];
		if (lastChar == ",") {
			newStr = str_array.substring(0, str_array.length - 1);
		}else {
			newStr = str_array;
		}
		/*if ((newStr.match(/,/g) || []).length > 99) {
			$scope.isFailed = true;
			$scope.resmessage = "Maximum 100 DN Numbers are allowed";
			return false;
		}*/
		newStr = newStr.split(",");
		/*newStr = newStr.filter(function(str) {//used to remove the empty spaces(like empty value)
			str = str.trim();
			if(str){
				return /\S/.test(str);
			}
		});
		newStr = newStr.map(function(el){//used to clear the spaces of each array element
			return el.trim();
		});*/
		newStr = newStr.filter(function(str) {//used to remove the empty spaces(like empty value)
			return /\S/.test(str);
		});
		var dna = [];
		newStr.map(function(el){//used to clear the spaces of each array element
			dna.push(el.trim());
		});
	 
	  
	$("#showloader").css("display", "block");
	var payload = {
		"type":$scope.type,
		"styleLst":dna,
		"dcName":$scope.pagedc,
		"userName":sessionStorage.userName,
                "sqlArgumentOne":"",
                "sqlArgumentTwo":""
	}; 

	var res = $http.put(urlService.UPDATE_SKU_PROFILING,payload, {
		headers: {'x-api-key': sessionStorage.apikey} 
	});
	res.success(function (data, status, headers, config) {
	  $("#showloader").css("display", "none");
	  if (data.errorMessage) {
		$scope.isFailed = true;
		$scope.resmessage = data.errorMessage;
	  } else {
		$scope.isSuccess = true;
		$scope.resmessage =data.resMessage;		
	  }
	});
	res.error(function (data, status, headers, config) {
	  $("#showloader").css("display", "none");
		$scope.isFailed = true;
		$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
	});
  };

//user favourites code starts
$scope.isClicked = false;
$scope.addToFavourate = function(isClicked){
  $("#showloader").css("display", "block");
   if(typeof isClicked !== "boolean"){
    commonService.postServiceResponse(urlService.GET_FAVOURITES,{"username": sessionStorage.userName})
      .then(function(response){
        $("#showloader").css("display", "none");
          _.each(response,function(val,key){
            if(val.funName == $scope.functionality && val.dcName == $scope.dcName){
              $scope.isClicked = true;      
            }
          });
      },function(error){
        $("#showloader").css("display", "none");
        $scope.isClicked = false; 
      });
      //$scope.isClicked = ;
   }else{
    if(!$scope.isClicked){
      commonService.postServiceResponse(urlService.ADD_FAVOURITE,{"username": sessionStorage.userName,"dcName":$scope.dcName,"funName":$scope.functionality})
      .then(function(response){
        $("#showloader").css("display", "none");
        if(response.errorMessage){
          $scope.isFavouriteAdded= false; 
          $scope.isClicked = false;      
          $scope.$broadcast('showAlert',['']);
        }else{
          $scope.isClicked = true;      
          $scope.isClicked = !isClicked;
          $scope.isFavouriteAdded= true; 
          $scope.favouriteMsg = response.resMessage;
        $scope.$broadcast('ClickedOnFavourate',[$scope.dcName,$scope.functionality,$scope.isClicked]);
        }
          
      },function(error){
        $scope.isClicked = false;
        $("#showloader").css("display", "none");
      });
      $scope.isClicked = !isClicked;
    }else{
      $("#showloader").css("display", "none");
    }
   }
  
};
$scope.addToFavourate('load');
//user favourites code ends
}]);


