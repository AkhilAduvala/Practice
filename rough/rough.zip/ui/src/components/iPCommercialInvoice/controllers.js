var app = angular.module('CommercialInvoice', ['ngTouch', 'ui.grid.autoResize', 'ui.grid', 'ui.grid.selection','ui.grid.resizeColumns','ui.grid.pagination']);

app.controller('CommercialInvoiceController', ['$scope', '$http', '$q', '$interval', '$timeout', 'urlService', 'uiGridConstants','commonService', function ($scope, $http, $q, $interval, $timeout, urlService, uiGridConstants,commonService) {
	$scope.isTable = false;
	$scope.disable = true;
	//$scope.isUpdate = true;
	$scope.isSuccess = false;
	$scope.isFailed = false;
	$scope.isClicked = false;
	$scope.invoiceData = true; //to enable 2 textboxes
	$scope.isSubmit = true; //to enable "Submit to IP and Print BOL" button
	$scope.pagefunctionality = $scope.functionality;
	$scope.pagedc = $scope.dcName;
	$scope.shipmentDetails = [];
	$("#showloader").css("display", "none");

	$scope.validateShipmentNumber = function () {
		$scope.isFailed = false;
		$scope.isSuccess = false;
		if ($scope.shipmentNumber) {
			$scope.disable = false;
		} else {
			$scope.disable = true;
		}
	};

	
	$scope.checkNumber = function(){
		$scope.isFailed = false;
		$scope.isSuccess = false;
		if ($scope.trailerNumber || $scope.sealNumber) {
			$scope.isSubmit = false;
		} else {
			$scope.isSubmit = true;
		}		
	};
	
	
	$scope.clearData = function(){
		$scope.shipmentNumber = "";
		$scope.trailerNumber = "";
		$scope.sealNumber = "";
		$scope.isTable = false;
		$scope.disable = true;
		$scope.isSuccess = false;
		$scope.isFailed = false;
		$scope.isClicked = false;
		$scope.invoiceData = true;
		$scope.isSubmit = true;
		$scope.gridOptions.data = [];
		$scope.shipmentDetails = [];
	};
	
	
	$scope.gridOptions = {
		paginationPageSizes: [15, 25, 50, 100],
		paginationPageSize: 15,
		 useExternalPagination: true,
		enableColumnMenus: false,
		enableSorting: true,
		enableRowSelection: true,//we can remove it later no use  of this
		enableSelectAll: true,//we can remove it later no use  of this             
		enableCellEdit: false, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
		//enableCellEditOnFocus: true, // set any editable column to allow edit on focus
		enableColumnResizing: true,
		enableHorizontalScrollbar:true
	};

	$scope.gridOptions.onRegisterApi = function (gridApi) {
		$scope.gridApi = gridApi;

		/*gridApi.selection.on.rowSelectionChangedBatch($scope, function (rows) {
			$scope.isSuccess = false;
			$scope.isFailed = false;
			if ($scope.gridApi.selection.getSelectedRows().length == 0) {
				$scope.isUpdate = true;
			} else {
				$scope.isUpdate = false;
			}
		});

		gridApi.selection.on.rowSelectionChanged($scope, function (row) {
			$scope.isSuccess = false;
			$scope.isFailed = false;
			if ($scope.gridApi.selection.getSelectedRows().length > 0) {
				$scope.isUpdate = false;
			} else {
				$scope.isUpdate = true;
			}
		});*/
		
		$scope.gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
			$scope.pageNo = newPage;
			$scope.pageSize = pageSize;
			$scope.getShipmentData(true);
		});
	};

	

	
	$scope.getShipmentData = function(flag){
		$scope.isSuccess = false;
		$scope.isFailed = false;
		$scope.isTable = false;
		$scope.invoiceData = true; 
		$scope.isSubmit = true;
		$scope.fetch = flag;
		$scope.resmessage = "";
		$scope.pageNo = $scope.pageNo ? $scope.pageNo : 1;
		$scope.pageSize = $scope.pageSize ? $scope.pageSize : $scope.gridOptions.paginationPageSize;
		
		var str_array = ($scope.shipmentNumber.trim().replace(/\n/g, ",")).replace(/,+/g, ',').replace(/(^\s*,)|( ,\s*$)/g, '');
		var lastChar = str_array[str_array.length - 1];
		if (lastChar == ",") {
			newStr = str_array.substring(0, str_array.length - 1);
		}else {
			newStr = str_array;
		}
		if ((newStr.match(/,/g) || []).length > 99) {
			$scope.isFailed = true;
			$scope.resmessage = "Maximum 100 DN Numbers are allowed";
			return false;
		}
		newStr = newStr.split(",");
		newStr = newStr.filter(function(str) {//used to remove the empty spaces(like empty value)
			str = str.trim();
			if(str){
				return /\S/.test(str);
			}
		});
		newStr = newStr.map(function(el){//used to clear the spaces of each array element
			return el.trim();
		});
		
		if($scope.shipmentDetails.length > 0){
			newStr = newStr.concat($scope.shipmentDetails);
		}
		newStr = newStr.filter(function(item, pos) {
			return newStr.indexOf(item) == pos;
		});
		$("#showloader").css("display", "block");
		var url = urlService.CHECK_SHIPMENTS; 
   		url = url.replace('dName',"BDC");
    	url = url.replace('uName',sessionStorage.userName);
    	url = url.replace('pNumber',$scope.pageNo);
		url = url.replace('pSize',$scope.pageSize);
		url = url.replace('sList',newStr ? newStr : []);
		if(flag){
			url = url.replace('pFlag',true);
		}else{
			url = url.replace('pFlag',false);
		}
   		var headers = {	headers: {'x-api-key': sessionStorage.apikey}  };
   		commonService.getServiceResponse(url,headers)
		//commonService.getServiceResponse("data.json")
		  .then(
				   function(d) {
					   $scope.gridOptions.columnDefs = [
							{ name: 'shipNbr', displayName: 'Ship Nbr', enableCellEdit: false,cellTooltip: true, 
							headerTooltip: true,  },
							{ name: 'assignedShipVia', displayName: 'Assigned Ship Via', enableCellEdit: false, cellTooltip: true, headerTooltip: true,  },
							{ name: 'address', displayName: 'Address', enableCellEdit: false, cellTooltip: true, headerTooltip: true, visibility: false,},
							{ name: 'bol', displayName: 'BOL', enableCellEdit: false, cellTooltip: true, headerTooltip: true,  },
							{ name: 'city', displayName: 'City', enableCellEdit: false, cellTooltip: true, headerTooltip: true },
							{ name: 'state', displayName: 'State', enableCellEdit: false, cellTooltip: true, headerTooltip: true, },
							{ name: 'status', displayName: 'Status', enableCellEdit: false,  cellTooltip: true, headerTooltip: true, },
							{ name: 'stopLocnName', displayName: 'Stop Locn Name', enableCellEdit: false,  cellTooltip: true, headerTooltip: true, },
						];
					  
					   if(d.validShipDetailsDtoPg){// to handle check shipments response
						   $scope.shipmentDetails = d.validShipments;
						   if(d.validShipDetailsDtoPg.pageItems){
							 if(d.validShipDetailsDtoPg.pageItems.length > 0){
							   $scope.isTable = true;
							  $scope.invoiceData = false;
							  $scope.trailerNumber = "";
							  $scope.sealNumber = "";
							   $("#showloader").css("display", "none");
							   $scope.gridOptions.data = d.validShipDetailsDtoPg.pageItems;
							    $scope.gridOptions.totalItems  = d.validShipDetailsDtoPg.totalNoOfRecords;
							 }else{
								 $scope.isSuccess = true;
								 $scope.resmessage = "No Record(s) found";
							 }
						   }
						 if ($scope.gridOptions.data > 10) {
							$scope.gridOptions.enableVerticalScrollbar = true;
							
						} else {
							$scope.gridOptions.enableVerticalScrollbar = false;
							$scope.gridOptions.enableHorizontalScrollbar = 1;
						}
					   }else if(d.resMessage){
						   $scope.isSuccess = true;
						   $scope.resmessage = d.resMessage; 
						   $("#showloader").css("display", "none");
					   }else{
						  $scope.isFailed = true;
						  $scope.resmessage = d.errorMessage; 
						  $("#showloader").css("display", "none");
					   }
				   },
					function(errResponse){
						
						$scope.isFailed = true;
						 $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
						 $("#showloader").css("display", "none");
					}
			   );
	  };
	

	$scope.submitShipmentData = function () {
		$scope.errorMessage = "";
		$scope.resmessage = "";
		$scope.isSuccess = false;
		$scope.isFailed = false;
		$scope.isUpdate = false;
		
		var payload = {  
		"userName":sessionStorage.userName,
	        "dcName":"BDC",
		"trailerNbr":$scope.trailerNumber,
		"sealNbr":$scope.sealNumber,
		"validShipments":$scope.shipmentDetails,
		"validShipDetailsDtoLst":$scope.gridOptions.data
		};

		$("#showloader").css("display", "block");
		var url = urlService.UPDATE_SHIPMENTS;
                var headers = {	headers: {'x-api-key': sessionStorage.apikey}  };

		commonService.putServiceResponse(url,payload,headers)
		  .then(
			   function(d) {
					  $("#showloader").css("display", "none");
					   if(d.updateStatus == "success"){
						  $scope.isSuccess = true;
						  $scope.resmessage = d.resMessage;
						  if(d.validShipDetailsDtoPg){
							  if(d.validShipDetailsDtoPg.pageItems){
								$scope.gridOptions.data = d.validShipDetailsDtoPg.pageItems;
								$scope.gridOptions.totalItems  = d.validShipDetailsDtoPg.totalNoOfRecords;  
							  }
						  }
					   }else if(d.updateStatus == "failure"){
						 $scope.isFailed = true;
						  $scope.resmessage = d.resMessage;

                                                          if(d.validShipDetailsDtoPg){
							  if(d.validShipDetailsDtoPg.pageItems){
								$scope.gridOptions.data = d.validShipDetailsDtoPg.pageItems;
								$scope.gridOptions.totalItems  = d.validShipDetailsDtoPg.totalNoOfRecords;  
							  }
						  }

}
					   
                                           else{
					       $scope.isFailed = true;
					       $scope.resmessage = d.errorMessage;
					   }
					 
				   //}
				},
				function(errResponse){
					$scope.isFailed = true;
					 $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
					 $("#showloader").css("display", "none");
				}
			);
	};

	

	//user favourites code starts
	$scope.addToFavourate = function(isClicked){
		$("#showloader").css("display", "block");
		 if(typeof isClicked !== "boolean"){
		  commonService.postServiceResponse(urlService.GET_FAVOURITES,{"username": sessionStorage.userName})
			.then(function(response){
			  $("#showloader").css("display", "none");
				_.each(response,function(val,key){
				  if(val.funName == $scope.functionality && val.dcName == $scope.dcName){
					$scope.isClicked = true;      
				  }
				});
			},function(error){
			  $("#showloader").css("display", "none");
			  $scope.isClicked = false; 
			});
			//$scope.isClicked = ;
		 }else{
		  if(!$scope.isClicked){
			commonService.postServiceResponse(urlService.ADD_FAVOURITE,{"username": sessionStorage.userName,"dcName":$scope.dcName,"funName":$scope.functionality})
			.then(function(response){
			  $("#showloader").css("display", "none");
			  if(response.errorMessage){
				$scope.isFavouriteAdded= false; 
				$scope.isClicked = false;      
				$scope.$broadcast('showAlert',['']);
			  }else{
				$scope.isClicked = true;      
				$scope.isClicked = !isClicked;
				$scope.isFavouriteAdded= true; 
				$scope.favouriteMsg = response.resMessage;
			  $scope.$broadcast('ClickedOnFavourate',[$scope.dcName,$scope.functionality,$scope.isClicked]);
			  }
				
			},function(error){
			  $scope.isClicked = false;
			  $("#showloader").css("display", "none");
			});
			$scope.isClicked = !isClicked;
		  }else{
			$("#showloader").css("display", "none");
		  }
		 }
		
	  };
	  $scope.addToFavourate('load');
	  //user favourites code ends
}]);
