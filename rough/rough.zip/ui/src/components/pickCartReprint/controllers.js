var app = angular.module('PickCartReprint');

app.controller('PickCartReprintController', ['$scope', '$http', '$q', '$interval', '$timeout','urlService','uiGridConstants','commonService', function ($scope, $http, $q, $interval, $timeout,urlService,uiGridConstants,commonService) {
  $scope.isSuccess = false;
  $scope.isFailed = false;
  $scope.disable = true;
  $scope.pagefunctionality = $scope.functionality;
  $scope.pagedc = $scope.dcName;
  $("#pkrt-nbr").focus();
  $("#showloader").css("display", "none");

$scope.getdefaultPrinter = function(){
		var url = urlService.DEFAULT_PRINTERS.replace("dName",$scope.pagedc);
		url = url.replace('uName',sessionStorage.userName);
		var res = $http.get(url, {
		  //headers: {'x-api-key': sessionStorage.apikey} 
		});

		res.success(function (data, status, headers, config) {
		  if (data.errorMessage) {
			//$scope.isFailed = true;
			//$scope.resmessage = data.errorMessage;
			$scope.getPrinterList();
			}else if(data.resMessage){
			//  $scope.isSuccess = true;
			//  $scope.resmessage = data.resMessage;
			  $scope.getPrinterList();
			}else{
				$scope.defaultprinter = data;
				$scope.printerip = data[0].printerIp;
				$scope.getPrinterList();
			}
		});
		res.error(function (data, status, headers, config) {
		//  $scope.isFailed = true;
		//  $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
		  $scope.getPrinterList();
		});  
  };
  $scope.getdefaultPrinter();

  $scope.getPrinterList = function(){
    var url = urlService.PRINTER_LIST.replace("dName",$scope.pagedc);
    url = url.replace('uName',sessionStorage.userName);
    var res = $http.get(url, {
      //headers: {'x-api-key': sessionStorage.apikey} 
    });

    res.success(function (data, status, headers, config) {
      if (data.errorMessage) {
        $scope.isFailed = true;
        $scope.resmessage = data.errorMessage;
        }else if(data.resMessage){
          $scope.isSuccess = true;
          $scope.resmessage = data.resMessage;
        }else{
          $scope.printerslist = data;
          
          for (var i = 0; i < $scope.printerslist.length; i++) {
            if($scope.printerip){
              if ($scope.printerslist[i].printerIp == $scope.printerip) {
                $scope.printer = $scope.printerslist[i];
                break;
              }
            }else{
              $scope.printer = $scope.printerslist[0];
            }
          }
        }
    });
    res.error(function (responce, status, headers, config) {
      $scope.isFailed = true;
      $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
    });  
  };

  $scope.checkPickCartNumber = function(){
	   $scope.isSuccess = false;
	 $scope.isFailed = false;
	  if($scope.pickCartNumber && $scope.printer){
		$scope.disable = false;  
	  }else{
		  $scope.disable = true;
	  }
  };

  
  $('#pkrt-nbr').keyup(function (e){
    if($scope.pickCartNumber && $scope.printer && e.keyCode == 13){
	$scope.disable = false;
        $scope.printPickCartNumber();
    }
  });

  $scope.printPickCartNumber = function(){
	//console.log($scope.pickCartNumber);
	$scope.isSuccess = false;
	  $scope.isFailed = false;
	$("#showloader").css("display", "block");
	var payload = {
		"printerIp":$scope.printer.printerIp,
		"printerPort":$scope.printer.printerPort,
		"cartNumber":$scope.pickCartNumber,
		"dcName":$scope.pagedc,
		"userName":sessionStorage.userName
	};
	
	
	var res = $http.put(urlService.PICKCART_REPRINT,payload, {
		headers: {'x-api-key': sessionStorage.apikey} 
	});
	res.success(function (data, status, headers, config) {
	  $("#showloader").css("display", "none");
	  if (data.errorMessage) {
		$scope.isFailed = true;
		$scope.resmessage = data.errorMessage;
	  } else {
		$("#pkrt-nbr").focus();
		$scope.pickCartNumber = "";
		$scope.isSuccess = true;
		$scope.resmessage =data.resMessage;		
	  }
	});
	res.error(function (data, status, headers, config) {
	  $("#showloader").css("display", "none");
		$scope.isFailed = true;
		$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
	});
  };
//user favourites code starts
$scope.isClicked = false;
$scope.addToFavourate = function(isClicked){
  $("#showloader").css("display", "block");
   if(typeof isClicked !== "boolean"){
    commonService.postServiceResponse(urlService.GET_FAVOURITES,{"username": sessionStorage.userName})
      .then(function(response){
        $("#showloader").css("display", "none");
          _.each(response,function(val,key){
            if(val.funName == $scope.functionality && val.dcName == $scope.dcName){
              $scope.isClicked = true;      
            }
          });
      },function(error){
        $("#showloader").css("display", "none");
        $scope.isClicked = false; 
      });
      //$scope.isClicked = ;
   }else{
    if(!$scope.isClicked){
      commonService.postServiceResponse(urlService.ADD_FAVOURITE,{"username": sessionStorage.userName,"dcName":$scope.dcName,"funName":$scope.functionality})
      .then(function(response){
        $("#showloader").css("display", "none");
        if(response.errorMessage){
          $scope.isFavouriteAdded= false; 
          $scope.isClicked = false;      
          $scope.$broadcast('showAlert',['']);
        }else{
          $scope.isClicked = true;      
          $scope.isClicked = !isClicked;
          $scope.isFavouriteAdded= true; 
          $scope.favouriteMsg = response.resMessage;
        $scope.$broadcast('ClickedOnFavourate',[$scope.dcName,$scope.functionality,$scope.isClicked]);
        }
          
      },function(error){
        $scope.isClicked = false;
        $("#showloader").css("display", "none");
      });
      $scope.isClicked = !isClicked;
    }else{
      $("#showloader").css("display", "none");
    }
   }
  
};
 $scope.addToFavourate('load');
//user favourites code ends
}]);


