var app = angular.module('ResubmitMessage');

app.controller('ResubmitMessageController', ['$scope', '$http', '$q', '$interval', '$timeout', 'urlService', 'uiGridConstants', 'commonService', function($scope, $http, $q, $interval, $timeout, urlService, uiGridConstants, commonService) {
    $scope.showDNNumbers = true;
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $scope.disable = true;
    $scope.disable1 = true;
    $scope.disable2 = true;
	$scope.disable3 = true;
    $scope.pagefunctionality = $scope.functionality;
    $scope.pagedc = $scope.dcName;
    $scope.decant = true;
    $scope.noTarget = false;
	$scope.message7710 = false;
    $scope.taskval = 'D';

    /**
  This function is used to change the disable value to false. Based on this update button will enable.
  **/
    $scope.validatelpnNbrD = function(taskval) {
        $scope.disable1 = false;
	$scope.disable2 = true;
        $scope.resmessage = "";
	
        var reg = /^[0-9\_ ]+$/;

        if (taskval == "D") {
            if ($scope.lpnNbr == "" || $scope.lpnNbr == undefined ) {

                $scope.disable1 = true;
            }
        }		
		 if (taskval == 'NT') {
            if ($scope.lpnNbr == "" || $scope.lpnNbr == undefined ) {
                $scope.disable2 = true;
            }
            // return false;
        }
		if (taskval == 'LA') {
            if ($scope.lpnNbr == "" || $scope.lpnNbr == undefined ) {
                $scope.disable3 = true;
            }
            // return false;
        }
    };

   $scope.validatelpnNbrNT = function(taskval) {
        $scope.disable1 = true
	$scope.disable2 = false
	$scope.disable3 = false
        $scope.resmessage = "";
	
        var reg = /^[0-9\_ ]+$/;

        if (taskval == "D") {
            if ($scope.lpnNbr == "" || $scope.lpnNbr == undefined ) {

                $scope.disable1 = true;
            }
        }		
		 if (taskval == 'NT') {
            if ($scope.lpnNbr == "" || $scope.lpnNbr == undefined ) {
                $scope.disable2 = true;
            }
            // return false;
        }
		if (taskval == 'LA') {
            if ($scope.lpnNbr == "" || $scope.lpnNbr == undefined ) {
                $scope.disable3 = true;
            }
            // return false;
        }
    };

  $scope.resetData = function(){
	  $scope.lpnNbr = "";
	$scope.disable1 = true;
  	$scope.disable2 = true;
	$scope.disable3 = true;
  };	
	


    $scope.task = function(taskval) {
        $scope.taskval = taskval;


        if ($scope.taskval == "D" && $scope.pagedc == 'DTC') {
            $scope.decant = true;
            $scope.noTarget = false;
			$scope.message7710 = false;
	    $scope.lpnNbr = "";
        }
        else if ($scope.taskval == "NT" && $scope.pagedc == 'DTC') {
            $scope.decant = false;
            $scope.noTarget = true;
			$scope.message7710 = false;
	    $scope.lpnNbr = "";
        }
		else if ($scope.taskval == "LA" && $scope.pagedc == 'DTC') {
            $scope.decant = false;
            $scope.noTarget = false;
			$scope.message7710 = true;
	    $scope.lpnNbr = "";
        }
		
    };
	
	$scope.lpnValidation = function () {
        $scope.resmessage = "";
        $scope.isSuccess = false;
        $scope.isFailed = false;

            $("#showloader").css("display", "block");
            var url = urlService.OLPN_DATA.replace('olpnlpnnumber',$scope.lpnNbr);
			url = url.replace('dcname',$scope.pagedc);
            var res = $http.get(url, {
                headers: {'x-api-key': sessionStorage.apikey}
            });	
            res.success(function (data, status, headers, config) {
                $("#showloader").css("display", "none");
                if (data.errorMessage) {
                    $scope.isFailed = true;
					if(data.errorMessage== "Carton is already packed. Please validate. \n")
					{
						$scope.resmessage = data.errorMessage;
					}
					else{
                    $scope.resmessage1 = data.errorMessage;
					$("#saveModel").modal();
					}
                }
                else{
                    $scope.isSuccess = true;
                    $scope.resmessage1 = data.resMessage;
					$("#saveModel").modal();
                }
            });
            res.error(function (data, status, headers, config) {
                $("#showloader").css("display", "none");
                $scope.isFailed = true;
                $scope.resmessage1 = "System failed. Please try again or contact WAALOS Support";
            });
            $scope.disableinput(); 
          
    };

	
	
    
    /** This function is used to update the FreightTerms **/
    $scope.resubmitMessage = function() {
        $scope.isSuccess = false;
        $scope.isFailed = false;
		
        $("#showloader").css("display", "block");
        var payload = {
            "messageType": $scope.taskval,
            "lpn": $scope.lpnNbr,
            "dcName": $scope.pagedc,
            "userName": sessionStorage.userName
        };
        var res = $http.put(urlService.RESUBMIT_MESSAGE, payload, {
            headers: { 'x-api-key': sessionStorage.apikey }
        });
        res.success(function(data, status, headers, config) {
            $("#showloader").css("display", "none");
            if (data.errorMessage) {
                $scope.isFailed = true;
                $scope.resmessage = data.errorMessage;
				$scope.resetData();
            } else {
                $scope.isSuccess = true;
				$scope.resmessage = data.resMessage;
				$scope.resetData();
            }
        });
        res.error(function(data, status, headers, config) {
            $("#showloader").css("display", "none");
            $scope.isFailed = true;
            $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
        });
    };



    //user favourites code starts
    $scope.isClicked = false;
    $scope.addToFavourate = function(isClicked) {
        $("#showloader").css("display", "block");
        if (typeof isClicked !== "boolean") {
            commonService.postServiceResponse(urlService.GET_FAVOURITES, { "username": sessionStorage.userName })
                .then(function(response) {
                    $("#showloader").css("display", "none");
                    _.each(response, function(val, key) {
                        if (val.funName == $scope.functionality && val.dcName == $scope.dcName) {
                            $scope.isClicked = true;
                        }
                    });
                }, function(error) {
                    $("#showloader").css("display", "none");
                    $scope.isClicked = false;
                });
            //$scope.isClicked = ;
        } else {
            if (!$scope.isClicked) {
                commonService.postServiceResponse(urlService.ADD_FAVOURITE, { "username": sessionStorage.userName, "dcName": $scope.dcName, "funName": $scope.functionality })
                    .then(function(response) {
                        $("#showloader").css("display", "none");
                        if (response.errorMessage) {
                            $scope.isFavouriteAdded = false;
                            $scope.isClicked = false;
                            $scope.$broadcast('showAlert', ['']);
                        } else {
                            $scope.isClicked = true;
                            $scope.isClicked = !isClicked;
                            $scope.isFavouriteAdded = true;
                            $scope.favouriteMsg = response.resMessage;
                            $scope.$broadcast('ClickedOnFavourate', [$scope.dcName, $scope.functionality, $scope.isClicked]);
                        }

                    }, function(error) {
                        $scope.isClicked = false;
                        $("#showloader").css("display", "none");
                    });
                $scope.isClicked = !isClicked;
            } else {
                $("#showloader").css("display", "none");
            }
        }

    };
    $scope.addToFavourate('load');
    //user favourites code ends		




}]);