var app = angular.module('WcswmInventorysync', ['ui.bootstrap', 'ngTouch', 'ui.grid', 'ui.grid.selection', 'ui.grid.pagination', 'ui.grid.exporter']);

app.controller('WcswmInventorysyncCtrl', ['$scope', '$http', '$q', '$interval', '$timeout', 'urlService', 'uiGridConstants','commonService', function ($scope, $http, $q, $interval, $timeout, urlService, uiGridConstants,commonService) {
	$scope.isSuccess = false;
	$scope.isFailed = false;
	$scope.isMianpage = true;
	$scope.isClicked = false;
	$scope.syncAllActive = true;
	$scope.syncAllReverse = true;
	$scope.isEdit = true; 
	$scope.pagefunctionality = $scope.functionality;
	$scope.pagedc = $scope.dcName;

	$scope.gridOptions = {
		enableColumnMenus: false,
		enableSorting: true,
		multiSelect: false,
		exporterMenuCsv: false,
		exporterMenuPdf: false,
		enableGridMenu: true,
		exporterExcelSheetName: 'Sheet1',
		exporterExcelFilename: 'inventorysync.xlsx',
		gridMenuShowHideColumns: false,
		exporterMenuVisibleData: false,
		enableRowSelection: true,//we can remove it later no use  of this
		enableSelectAll: true,//we can remove it later no use  of this             
		enableCellEdit: false, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
		enableCellEditOnFocus: true // set any editable column to allow edit on focus
	};

 
	$scope.gridOptions.onRegisterApi = function (gridApi) {
		//set gridApi on scope
		$scope.gridApi = gridApi;
	};
	//function to check if the transaction are more than 10 and showing confirm pop up to proceed
	$scope.editDataSources = function (synctype) {
		$("#showloader").css("display", "block");
		$scope.isTable1 = true;
		$scope.isTable2 = true;
		$scope.isMianpage = true;
		var temp ={
		"dcName": $scope.dcName, 
		"userName": sessionStorage.userName 
		};
		var url = synctype == 1 ? urlService.SYNC_All_ACTIVE_TRANS : urlService.SYNC_All_RESRV_TRANS;
		$http.post(url,temp, { 
		headers: {'x-api-key': sessionStorage.apikey}
		})
			.success(function (data) {
				$("#showloader").css("display", "none");//pradeep 1/2/18
				$scope.syncNumber = synctype;
				if (data.resMessage.indexOf('Are you sure you want to proceed?') >= 0) {
					$('#syncAllConfirmation').modal("show");
					$scope.confirmMessage = data.resMessage;
			
				} 
				else if (data.resMessage) {
					if (data.resMessage.indexOf('Cannot proceed with sync') >= 0) {
						$scope.isFailed = false;
						$scope.isSuccess = true;
						$scope.resmessage = data.resMessage;
						$scope.dataSources(synctype,true);
						$scope.isTable1 = synctype == 1 ? true : false;
						$scope.isTable2 = synctype == 2 ? true : false;
						
					}
					else {
						$scope.isFailed = false;
						$scope.isSuccess = true;
						$scope.resmessage = data.resMessage;
						$scope.dataSources(synctype,true);
						$scope.isTable1 = synctype == 1 ? true : false;
						$scope.isTable2 = synctype == 2 ? true : false;
						
					}
				} 
				else if (data.errorMessage) {
					$scope.isFailed = true;
					$scope.isSuccess = false;
					$scope.resmessage = data.errorMessage;
				}
				
			})
			.error(function (data) {
			$("#showloader").css("display", "none");
			$scope.isFailed = true;
			$scope.resmessage = "System failed. Please try again or contact WAALOS Support";			
		});
	};
		//function to perform sunc opetation for all transactions
	$scope.fnSyncAllTrans = function () {
		$('#syncAllConfirmation').modal("hide");
		$("#showloader").css("display", "block");
		var temp ={
		"dcName": $scope.dcName, 
		"userName": sessionStorage.userName 
		};

		var url = $scope.syncNumber == 1 ? urlService.SYNC_All_ACTIVE_TRANS_SPCAll : urlService.SYNC_All_RESRV_TRANS_SPCAll;
		$http.post(url,temp, { 
		headers: {'x-api-key': sessionStorage.apikey}
		})
			.success(function (data) {
				$("#showloader").css("display", "none");//pradeep 2/1/18
				if (data.resMessage) {
					$scope.isFailed = false;
					$scope.isSuccess = true;
					$scope.resmessage = data.resMessage;
					$scope.dataSources($scope.syncNumber,true);
				} else if (data.errorMessage) {
					$scope.isFailed = true;
					$scope.isSuccess = false;
					$scope.resmessage = data.errorMessage;
				}
			})
			.error(function (data) {
				$("#showloader").css("display", "none");
			$scope.isFailed = true;
			$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
			});
	};
	//function to get the data at initial load and when tabs are changed
	$scope.dataSources = function (tabNumber,flag) {
		$scope.noRecords = false;
		if(typeof flag != "boolean"){
			$scope.isSuccess = false;
			$scope.isFailed = false;
		}
		$scope.isEdit = true; 
		$scope.isMianpage = true; 
		$("#showloader").css("display", "block");
		if(tabNumber == 1){
			$scope.isTab1 = true;
			$scope.isTab2 = false;
		}else if(tabNumber == 2){
			$scope.isTab1 = false;
			$scope.isTab2 = true;
		}
		var url = tabNumber == 1 ? urlService.GET_WS_INVENTORY_ACTIVE_TRANS : urlService.GET_WS_INVENTORY_RESRV_TRANS;
		
		url = url.replace('dName', $scope.dcName);
		url = url.replace('uName', sessionStorage.userName);
		//var res = $http.get(url);
  		var res = $http.get(url, {
    		headers: {'x-api-key': sessionStorage.apikey}
    		});
		res.success(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			if (data.errorMessage) {
				$scope.isFailed = true;
				$scope.resmessage = data.errorMessage;
				$scope.syncAllActive = tabNumber == 1 ? false : true;
				$scope.syncAllReverse = tabNumber == 2 ? false : true;
			} else if (data.resMessage) {
				if (data.resMessage == 'No Record(s) Found' && tabNumber == 1) {
					$scope.noRecords = true;
					$scope.isTable1 = false;
				} else if (data.resMessage == 'No Record(s) Found' && tabNumber == 2) {
					$scope.isTable2 = false;
					$scope.noRecords = true;
				}
				if(typeof flag != "boolean"){
				$scope.resmessage = data.resMessage;
				$scope.isSuccess = true;
				}

			} else {
				$scope.gridOptions.columnDefs = [];
				$scope.actualData = [];
				_.each(data, function (value, key) {
					var length = tabNumber == 1 ? 10 : 4;
					if ($scope.gridOptions.columnDefs.length != length) {
						for (var i = 0; i < Object.keys(value).length; i++) {
							//regular expression to provide spaces at camel case notation and capitalize first letter in the word
							var displayName = (Object.keys(value)[i].replace(/\s/g, "").replace(/([A-Z])/g, ' $1').trim()).split(' ');
							if(displayName.length<2){
								displayName =  displayName[0].charAt(0).toUpperCase()+ displayName[0].substr(1);
							}
							else if(displayName.length==2){
								displayName  = displayName[0].toUpperCase() +' '+displayName[1].charAt(0).toUpperCase()+ displayName[1].substr(1);
							}else{
								displayName  = displayName[0].toUpperCase() +' '+displayName[1].charAt(0).toUpperCase()+ displayName[1].substr(1)+' '+displayName[2].toUpperCase();
							}
							 
							// var displayName = Object.keys(value)[i].replace(/\w\S*/g, function (txt) {
							// 	return txt.charAt(0).toUpperCase() + txt.substr(1);
							// }).replace(/\s/g, "").replace(/([A-Z])/g, ' $1').trim();
							$scope.gridOptions.columnDefs.push({ name: Object.keys(value)[i], displayName: displayName, enableCellEdit: false });
						}
					}
					$scope.actualData.push(value);
				});

				$scope.isTable1 = true;
				$scope.isTable2 = true; 
				$scope.gridOptions.data = $scope.actualData;

				if ($scope.gridOptions.data > 10) {
					$scope.gridOptions.enableVerticalScrollbar = true;
					$scope.gridOptions.enableHorizontalScrollbar = 1;
				} else {
					$scope.gridOptions.enableVerticalScrollbar = false;
					$scope.gridOptions.enableHorizontalScrollbar = 1;
				}


			}
			$('.ui-grid-pager-control input').prop("disabled", true);
		});
		res.error(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			$scope.isFailed = true;
			$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
			$scope.syncAllActive = tabNumber == 1 ? false : true;
			$scope.syncAllReverse = tabNumber == 2 ? false : true;
		});
	};

	$scope.dataSources('1');
	$scope.zones = function () {
		$scope.zonesdata = "zones";
	};
	$scope.forcastSources = function () {

	};

	//user favourites code starts
	$scope.addToFavourate = function(isClicked){
		$("#showloader").css("display", "block");
		 if(typeof isClicked !== "boolean"){
		  commonService.postServiceResponse(urlService.GET_FAVOURITES,{"username": sessionStorage.userName})
			.then(function(response){
			  $("#showloader").css("display", "none");
				_.each(response,function(val,key){
				  if(val.funName == $scope.functionality && val.dcName == $scope.dcName){
					$scope.isClicked = true;      
				  }
				});
			},function(error){
			  $("#showloader").css("display", "none");
			  $scope.isClicked = false; 
			});
			//$scope.isClicked = ;
		 }else{
		  if(!$scope.isClicked){
			commonService.postServiceResponse(urlService.ADD_FAVOURITE,{"username": sessionStorage.userName,"dcName":$scope.dcName,"funName":$scope.functionality})
			.then(function(response){
			  $("#showloader").css("display", "none");
			  if(response.errorMessage){
				$scope.isFavouriteAdded= false; 
				$scope.isClicked = false;      
				$scope.$broadcast('showAlert',['']);
			  }else{
				$scope.isClicked = true;      
				$scope.isClicked = !isClicked;
				$scope.isFavouriteAdded= true; 
				$scope.favouriteMsg = response.resMessage;
			  $scope.$broadcast('ClickedOnFavourate',[$scope.dcName,$scope.functionality,$scope.isClicked]);
			  }
				
			},function(error){
			  $scope.isClicked = false;
			  $("#showloader").css("display", "none");
			});
			$scope.isClicked = !isClicked;
		  }else{
			$("#showloader").css("display", "none");
		  }
		 }
		
	  };

	  $scope.addToFavourate('load');
	//user favourites code ends
}]);