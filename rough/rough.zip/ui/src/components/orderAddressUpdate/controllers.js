var app = angular.module('OrderAddressUpdate');

app.controller('OrderAddressUpdateController', ['$scope', '$http', '$q', '$interval', '$timeout', 'urlService', 'uiGridConstants', 'commonService', function($scope, $http, $q, $interval, $timeout, urlService, uiGridConstants, commonService) {
    $scope.showDNNumbers = true;
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $scope.pagefunctionality = $scope.functionality;
    $scope.pagedc = $scope.dcName;
	$scope.disableSelect=true;
	$scope.disableName=true;
	$scope.disableContact=true;
	$scope.disableAddress1=true;
	$scope.disableAddress2=true;
	$scope.disableAddress3=true;
	$scope.disableCity=true;
	$scope.disableState=true;
	$scope.disablePin=true;
	$scope.disableCountry=true;
	$scope.disableUpdate=true;
	$scope.countryCode='';

    /**
  This function is used to change the disable value to false. Based on this SELECT button will enable.
  **/
    $scope.validateDisOrder = function() {
		$scope.isSuccess = false;
		$scope.isFailed = false;
        $scope.disableSelect = false;
	        var reg = /^[0-9\_ ]+$/;
            if ($scope.disOrder == "" || $scope.disOrder == undefined ) {
				$scope.disableUpdate= true;
                $scope.disableSelect = true;
					$scope.disableName=true;
					$scope.name = '';
					$scope.disableContact = true;
					$scope.contact = '';
					$scope.disableAddress1=true;
					$scope.address1 = '';
					$scope.disableAddress2=true;
					$scope.address2 = '';
					$scope.disableAddress3=true;
					$scope.address3 = '';
					$scope.disableCity=true;
					$scope.city = '';
					$scope.disableState=true;
					$scope.stateDropDown='';
					$scope.disablePin=true;
					$scope.pin = '';
					$scope.disableCountry=true;
					$scope.countryDropDown = '';
					$scope.countryCode= '';
            }
           };


	/** This function is used to get address details **/
	$scope.getAddressDetails = function() {
		$scope.isSuccess = true;
        $scope.resmessage = '';
		var url = urlService.GET_ADDRESS_DETAILS.replace('dName', $scope.pagedc);
        url = url.replace('disOrder', $scope.disOrder);
        var res = $http.get(url, { headers: { 'x-api-key': sessionStorage.apikey } });
		res.success(function (data, status, headers, config) {
				$("#showloader").css("display", "none");
				if (data.errorMessage) {
					$scope.isFailed = true;
					$scope.resmessage = data.errorMessage;
					$scope.disableName=true;
					$scope.name = '';
					$scope.disableContact = true;
					$scope.contact = '';
					$scope.disableAddress1=true;
					$scope.address1 = '';
					$scope.disableAddress2=true;
					$scope.address2 = '';
					$scope.disableAddress3=true;
					$scope.address3 = '';
					$scope.disableCity=true;
					$scope.city = '';
					$scope.disableState=true;
					$scope.stateDropDown='';
					$scope.disablePin=true;
					$scope.pin = '';
					$scope.disableCountry=true;
					$scope.countryDropDown = '';
					$scope.countryCode= '';
					$scope.disableUpdate=true;
				} else if (data.resMessage) {
					$scope.isSuccess = true;
					$scope.resmessage = data.resMessage;
				} else {
					$scope.disableName=false;
					$scope.name = data[0].name;
					$scope.disableContact = false;
					$scope.contact = data[0].contact;
					$scope.disableAddress1=false;
					$scope.address1 = data[0].address1;
					$scope.disableAddress2=false;
					$scope.address2 = data[0].address2;
					$scope.disableAddress3=false;
					$scope.address3 = data[0].address3;
					$scope.disableCity=false;
					$scope.city = data[0].city;
					$scope.disableState=false;
					$scope.stateDropDown=data[0].stateCode;
					$scope.disablePin=false;
					$scope.pin = data[0].postalCode;
					$scope.disableCountry=false;
					$scope.countryDropDown = data[0].countryCode;
					$scope.countryCode= data[0].countryCode;
					$scope.disableUpdate=false;
					getCountryDropDown();
					$("#showloader").css("display", "none");
				}
				$('.ui-grid-pager-control input').prop("disabled", true);
			});
		res.error(function (data, status, headers, config) {
				$("#showloader").css("display", "none");
				$scope.isFailed = true;
			});
	}
	
	$scope.clearMessage = function(){
		$scope.resmessage = '';
	}
	
	/** This function is used to get state drop down details **/
	 $scope.getStateDropDown = function(countryCode) {
        $scope.resmessage = '';
		var url = urlService.GET_STATE_COUNTRY.replace('dName', $scope.pagedc);
        url = url.replace('stateCountryFlag', 'S');
		url = url.replace('cntry',countryCode);
        var res = $http.get(url, { headers: { 'x-api-key': sessionStorage.apikey } });
		res.success(function (data, status, headers, config) {
				$("#showloader").css("display", "none");
				if (data.errorMessage) {
					$scope.isFailed = true;
					$scope.resmessage = data.errorMessage;
				} else if (data.resMessage) {
					$scope.isSuccess = true;
					$scope.resmessage = data.resMessage;
				} else {
					$scope.stateList = data;
					
					$("#showloader").css("display", "none");
				}
				$('.ui-grid-pager-control input').prop("disabled", true);
			});
			res.error(function (data, status, headers, config) {
				$("#showloader").css("display", "none");
				$scope.isFailed = true;
			});
	}
	
	/** This function is invoked on change of country selected from drop down**/
	$scope.onCountryChange = function(countryCode) {
        $scope.resmessage = '';
		$scope.stateDropDown='';
		var url = urlService.GET_STATE_COUNTRY.replace('dName', $scope.pagedc);
        url = url.replace('stateCountryFlag', 'S');
		url = url.replace('cntry',countryCode);
        var res = $http.get(url, { headers: { 'x-api-key': sessionStorage.apikey } });
		res.success(function (data, status, headers, config) {
				$("#showloader").css("display", "none");
				if (data.errorMessage) {
					$scope.isFailed = true;
					$scope.resmessage = data.errorMessage;
				} else if (data.resMessage) {
					$scope.isSuccess = true;
					$scope.resmessage = data.resMessage;
				} else {
					$scope.stateList = data;
					
					$("#showloader").css("display", "none");
				}
				$('.ui-grid-pager-control input').prop("disabled", true);
			});
			res.error(function (data, status, headers, config) {
				$("#showloader").css("display", "none");
				$scope.isFailed = true;
			});
	}
	
	/** This function is used to get counrty drop down details **/
	getCountryDropDown= function() {
		var url = urlService.GET_STATE_COUNTRY.replace('dName', $scope.pagedc);
        url = url.replace('stateCountryFlag', 'C');
		url = url.replace('cntry', '');
        var res = $http.get(url, { headers: { 'x-api-key': sessionStorage.apikey } });
		res.success(function (data, status, headers, config) {
				$("#showloader").css("display", "none");
				if (data.errorMessage) {
					$scope.isFailed = true;
					$scope.resmessage = data.errorMessage;
				} else if (data.resMessage) {
					$scope.isSuccess = true;
					$scope.resmessage = data.resMessage;
				} else {
					$scope.countryList = data;
					$scope.getStateDropDown($scope.countryDropDown);
					$("#showloader").css("display", "none");
				}
				$('.ui-grid-pager-control input').prop("disabled", true);
			});
	}
	
	
	/** This function is used to update address details **/
	$scope.updateAddressDetails=function(){
		 $scope.isSuccess = false;
         $scope.isFailed = false;
	   $("#showloader").css("display", "block");
	if($scope.stateDropDown==''){
			$("#showloader").css("display", "none");
		    $scope.isFailed = true;
            $scope.resmessage = "Please select State";
	   }else{
		   var payload = {
			"dcName": $scope.pagedc,
			"orderId": $scope.disOrder,
            "name": $scope.name,
            "contact": $scope.contact,
            "address1": $scope.address1,
            "address2": $scope.address2,
			"address3": $scope.address3,
			"city": $scope.city,
			"state": '',
			"stateCode": $scope.stateDropDown,
			"postalCode": $scope.pin,
			"country": '', 
			"countryCode": $scope.countryDropDown,
			"userId": sessionStorage.userName
        };
		 var res = $http.put(urlService.UPDATE_ADDRESS_DETAILS, payload, {
            headers: { 'x-api-key': sessionStorage.apikey }
        });
         res.success(function(data, status, headers, config) {
            $("#showloader").css("display", "none");
            if (data.errorMessage) {
                $scope.isFailed = true;
                $scope.resmessage = data.errorMessage;
            } else {
                $scope.isSuccess = true;
                $scope.resmessage = data.resMessage;
            }
        });
        res.error(function(data, status, headers, config) {
            $("#showloader").css("display", "none");
            $scope.isFailed = true;
            $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
        });
	   }
        
	}
    
    //user favourites code starts
    $scope.isClicked = false;
    $scope.addToFavourate = function(isClicked) {
        $("#showloader").css("display", "block");
        if (typeof isClicked !== "boolean") {
            commonService.postServiceResponse(urlService.GET_FAVOURITES, { "username": sessionStorage.userName })
                .then(function(response) {
                    $("#showloader").css("display", "none");
                    _.each(response, function(val, key) {
                        if (val.funName == $scope.functionality && val.dcName == $scope.dcName) {
                            $scope.isClicked = true;
                        }
                    });
                }, function(error) {
                    $("#showloader").css("display", "none");
                    $scope.isClicked = false;
                });
            //$scope.isClicked = ;
        } else {
            if (!$scope.isClicked) {
                commonService.postServiceResponse(urlService.ADD_FAVOURITE, { "username": sessionStorage.userName, "dcName": $scope.dcName, "funName": $scope.functionality })
                    .then(function(response) {
                        $("#showloader").css("display", "none");
                        if (response.errorMessage) {
                            $scope.isFavouriteAdded = false;
                            $scope.isClicked = false;
                            $scope.$broadcast('showAlert', ['']);
                        } else {
                            $scope.isClicked = true;
                            $scope.isClicked = !isClicked;
                            $scope.isFavouriteAdded = true;
                            $scope.favouriteMsg = response.resMessage;
                            $scope.$broadcast('ClickedOnFavourate', [$scope.dcName, $scope.functionality, $scope.isClicked]);
                        }

                    }, function(error) {
                        $scope.isClicked = false;
                        $("#showloader").css("display", "none");
                    });
                $scope.isClicked = !isClicked;
            } else {
                $("#showloader").css("display", "none");
            }
        }

    };
    $scope.addToFavourate('load');
    //user favourites code ends		

}]);