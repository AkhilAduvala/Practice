var app = angular.module('ShipViaUpdate', ['ui.bootstrap', 'ngTouch', 'ui.grid', 'ui.grid.selection', 'ui.grid.pagination', 'ui.grid.exporter', 'ui.grid.autoResize']);

app.controller('ShipViaUpdateController', ['$scope', '$http', '$q', '$interval', '$timeout', 'urlService', 'uiGridConstants', 'uiGridExporterConstants', 'uiGridExporterService', 'commonService', function ($scope, $http, $q, $interval, $timeout, urlService, uiGridConstants, uiGridExporterConstants, uiGridExporterService, commonService) {
	var pr = this;
	pr.pagedc = $scope.dcName;
	pr.pagefunctionality = $scope.functionality;
	$scope.isSuccess = false;
    $scope.isFailed = false;
	pr.isMianpage = false;
	pr.isClicked = false;
	pr.numberGridOptionssuccess = false;
	pr.numberGridOptionserror = false;
	pr.selectedRowValues = [];
	


	//ui grid options
	pr.numberGridOptions = {

		enableColumnMenus: false,
		enableSorting: true,
		enableRowSelection: true,//we can remove it later no use  of this
		enableSelectAll: true,//we can remove it later no use  of this             
		enableCellEdit: false, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
		enableCellEditOnFocus: true, // set any editable column to allow edit on focus

	};
	pr.gridOptions = angular.copy(pr.numberGridOptions);

	
	//on RegisterApi calls
	pr.numberGridOptions.onRegisterApi = function (gridApi) {
		//set gridApi on scope
		pr.gridApi = gridApi;
		gridApi.selection.on.rowSelectionChangedBatch(null, function (row) {

			pr.isSuccess = false;
			pr.isFailed = false;
			var booleanValues = [];
			_.each(row, function (value, key) {
				booleanValues.push(value.isSelected);
				pr.selectedRowValues.push({ 'number': value.entity.shipmentid, 'isSelected': value.isSelected });

			});

			if (booleanValues.indexOf(true) >= 0) {
				pr.searchDisable = false;
			} else {
				pr.selectedRowValues=[];
				pr.searchDisable = true;
			}
		});
		gridApi.selection.on.rowSelectionChanged(null, function (row) {
			var booleanValues = [];

			var number = _.find(pr.selectedRowValues, function (obj) {
				return obj.number == row.entity.shipmentid;
			});
			if (!number) {
				pr.selectedRowValues.push({ 'number': row.entity.shipmentid, 'isSelected': row.isSelected });
			} else {
				_.each(pr.selectedRowValues, function (value, key) {
					if (value.number == row.entity.shipmentid) {
						pr.selectedRowValues[key].isSelected = row.isSelected;
						pr.selectedRowValues = _.reject(pr.selectedRowValues, function (d) {
							return d.isSelected == false;
						});
					}
				});
			}
			_.each(pr.selectedRowValues, function (value, key) {
				booleanValues.push(value.isSelected);
			});
			if (booleanValues.indexOf(true) >= 0) {
				pr.searchDisable = false;
			} else {
				pr.searchDisable = true;
			}
			// pr.prewaveNmuber = '';
			pr.isSuccess = false;
			pr.isFailed = false;
		});
	};
	//searching thorugh selection and input text
	pr.getDimensionData = function (modelValue) {
		if (modelValue == 'valueChanged') {
			pr.searchDisable = pr.selectedRowValues.length ? false : true;
		} else {
			var searchedValues = [];
			_.each(pr.selectedRowValues, function (val, key) {
				searchedValues.push(val.number);
			});
			$scope.searchedValues = searchedValues;
			pr.updateShipmentId(searchedValues);

		}
	};

	
	pr.updateShipmentId = function (searchedValues) {
		 pr.isSuccess = false;
		 pr.isFailed = false;
		 $scope.isSuccess = false;
         $scope.isFailed = false;
		 	$("#showloader").css("display", "block");
		 url = urlService.UPDATE_SHIPMENT_IDS;
		var res = $http.put(url, { "dcName": $scope.dcName, "shipmentid": searchedValues ? searchedValues : $scope.searchedValues },
				{
					headers: { 'x-api-key': sessionStorage.apikey },

				});

         res.success(function(data, status, headers, config) {
            $("#showloader").css("display", "none");
            if (data.errorMessage) {
                $scope.isFailed = true;
				pr.resmessage = data.errorMessage;
            } else {
				pr.getShipmentIds();
				pr.selectedRowValues =[];
				pr.searchDisable = true;
                $scope.isSuccess = true;
				pr.resmessage = data.resMessage;
				
            }
        });
        res.error(function(data, status, headers, config) {
            $("#showloader").css("display", "none");
            $scope.isFailed = true;
            pr.resmessage = "System failed. Please try again or contact WAALOS Support";
        });
	
	}
	// function to get the number which need to be selected and pass in search 
	pr.getShipmentIds = function () {
		pr.isMianpage = false;
		
		$("#showloader").css("display", "block");
		pr.numberGridOptions.data = [];
		pr.numberGridOptions.columnDefs = [];
		var url = urlService.GET_SHIPMENT_IDS.replace('dName', $scope.dcName);
		url = url.replace('uName', sessionStorage.userName);
		var res = $http.get(url, {
			headers: { 'x-api-key': sessionStorage.apikey }
		});
		res.success(function (data, status, headers, config) {
			delete data.dcName;

			if (data.errorMessage) {

				pr.numberGridOptionssuccess = false;
				pr.numberGridOptionserror = true;
				pr.resmessage1 = data.errorMessage;
				$("#showloader").css("display", "none");
			} else if (data.resMessage) {
				pr.numberGridOptionssuccess = true;
				pr.numberGridOptionserror = false;
				pr.resmessage = data.resMessage;
				$("#showloader").css("display", "none");
			} else {
				var shipmentid = [];

				//regular expression to provide spaces at camel case notation and capitalize first letter in the word

				pr.isTable = true;

					_.each(data.shipmentid, function (val, key) {
						shipmentid.push({ "shipmentid": val });
					});
					pr.numberGridOptions.columnDefs.push({ name: 'shipmentid', displayName: "SHIPMENT ID", enableCellEdit: false });
					pr.numberGridOptions.data = shipmentid;
				
				$("#showloader").css("display", "none");
				if (pr.numberGridOptions.data > 10) {
					pr.numberGridOptions.enableVerticalScrollbar = true;
					pr.numberGridOptions.enableHorizontalScrollbar = 1;
				} else {
					pr.numberGridOptions.enableVerticalScrollbar = false;
					pr.numberGridOptions.enableHorizontalScrollbar = 1;
				}

			}

		});
		res.error(function (data, status, headers, config) {
			pr.numberGridOptionssuccess = false;
			pr.numberGridOptionserror = true;
			pr.resmessage = "System failed. Please try again or contact WAALOS Support";
			$("#showloader").css("display", "none");
			$scope.numberGridOptions.enableGridMenu = false;
		});
	};

	pr.addToFavourate = function (isClicked) {
		$("#showloader").css("display", "block");
		if (typeof isClicked !== "boolean") {
			commonService.postServiceResponse(urlService.GET_FAVOURITES, { "username": sessionStorage.userName })
				.then(function (response) {
					$("#showloader").css("display", "none");
					_.each(response, function (val, key) {
						if (val.funName == $scope.functionality && val.dcName == $scope.dcName) {
							pr.isClicked = true;
						}
					});
				}, function (error) {
					$("#showloader").css("display", "none");
				});
			//pr.isClicked = ;
		} else {
			if (!pr.isClicked) {
				commonService.postServiceResponse(urlService.ADD_FAVOURITE, { "username": sessionStorage.userName, "dcName": $scope.dcName, "funName": $scope.functionality })
					.then(function (response) {
						$("#showloader").css("display", "none");
						if (response.errorMessage) {
							pr.isClicked = isClicked;
							pr.isFavouriteAdded = false;
							$scope.$broadcast('showAlert', ['']);
						} else {
							pr.isClicked = !isClicked;
							pr.isFavouriteAdded = true;
							pr.favouriteMsg = response.resMessage;
							$scope.$broadcast('ClickedOnFavourate', [pr.dcName, $scope.functionality, pr.isClicked]);
						}

					}, function (error) {
						$("#showloader").css("display", "none");
					});
				pr.isClicked = !isClicked;
			} else {
				$("#showloader").css("display", "none");
			}
		}

	};

	pr.addToFavourate('load');
	pr.getShipmentIds();

}]);