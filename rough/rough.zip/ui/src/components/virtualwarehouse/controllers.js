/* =created for virtualWareHouse handling */
(function virtualWareHouse() {
	'use strict';
	angular
		.module('VirtualWareHouse')
		.controller('VirtualWarehouseCtrl', VirtualWarehouseCtrl);
	
	$("#showloader").css("display", "block");
	function VirtualWarehouseCtrl($scope, $http,urlService,commonService) {
		
		$scope.isSuccess = false;
		$scope.isFailed = false;
		$scope.isClicked = false;
		$scope.resmessage ="";
		$scope.pagefunctionality = $scope.functionality;
		$scope.pagedc = $scope.dcName;

		$scope.asnvalid = function () {
			$scope.isSuccess = false;
			$scope.isFailed = false;
			var reg = /^[0-9a-zA-Z\_]+$/;
			if ($scope.asn == '' || $scope.asn == null || $scope.asn == undefined || $scope.asn == 32 || !(reg.test($scope.asn))) {
				$("#change").attr("disabled", "disabled");
			} else {
				$("#change").removeAttr("disabled");
			}
		  };
		$scope.changeRecord = changeRecord;

		function changeRecord() {
			$("#showloader").css("display", "block");
			$scope.isSuccess = false;
			$scope.isFailed = false;
			$scope.resmessage = "";

			var changedData = {
				"dcName": $scope.pagedc,
				"userName":sessionStorage.userName,
				"asnNbr": $scope.asn,
				"codeId": $scope.newLogicals.codeId,
				"codeDesc": $scope.newLogicals.codeDesc

			};
			
			//var res = $http.put(urlService.UPDATE_VIRTUAL_WAREHOUSE, changedData);
  			var res = $http.put(urlService.UPDATE_VIRTUAL_WAREHOUSE, changedData, {
    			headers: {'x-api-key': sessionStorage.apikey}
			});
			res.success(function (data, status, headers, config) {
				$("#showloader").css("display", "none");
				if (data.errorMessage) {
					$scope.isFailed = true;
					$scope.resmessage = data.errorMessage;
				} else if (data.resMessage) {
					
					$scope.isSuccess = true;
					$scope.resmessage = data.resMessage;
	
				}
		
			});
			res.error(function (data, status, headers, config) {
				$("#showloader").css("display", "none");
				$scope.isFailed = true;
				$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
			});
		}

		/*var dcUserInfo = {
			"dcName": $scope.pagedc,
			"userName": sessionStorage.userName
		};
		var res = $http.post(urlService.GET_VIRTUAL_WAREHOUSE, dcUserInfo);
		*/

		//Fetching data onload for the dropdownlist
		function getNewLogicals() {
			$("#showloader").css("display", "block");
			$scope.isSuccess = false;
			$scope.isFailed = false;
     			$scope.resmessage = "";

			


   		var url = urlService.GET_VIRTUAL_WAREHOUSE.replace('dName',$scope.pagedc);
    		url = url.replace('uName',sessionStorage.userName);
    		//var res = $http.get(url);
  		var res = $http.get(url, {
    		headers: {'x-api-key': sessionStorage.apikey}
		});
			res.success(function (data, status, headers, config) {
				$("#showloader").css("display", "none");
				if (data.errorMessage) {
					$scope.isFailed = true;
					$scope.resmessage = data.errorMessage;
				} else if (data.resMessage) {
					$scope.isSuccess = true;
					$scope.resmessage = data.resMessage;
	
				}else{
					$scope.codesData = data;
					$scope.newLogicals = $scope.codesData[0];
				}
				
			});
			res.error(function (data, status, headers, config) {
				$("#showloader").css("display", "none");
				$scope.isFailed = true;
				$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
			});

		}
		getNewLogicals();

		//user favourites code starts
		$scope.addToFavourate = function(isClicked){
			$("#showloader").css("display", "block");
			 if(typeof isClicked !== "boolean"){
			  commonService.postServiceResponse(urlService.GET_FAVOURITES,{"username": sessionStorage.userName})
				.then(function(response){
				  $("#showloader").css("display", "none");
					_.each(response,function(val,key){
					  if(val.funName == $scope.functionality && val.dcName == $scope.dcName){
						$scope.isClicked = true;      
					  }
					});
				},function(error){
				  $("#showloader").css("display", "none");
				  $scope.isClicked = false; 
				});
				//$scope.isClicked = ;
			 }else{
			  if(!$scope.isClicked){
				commonService.postServiceResponse(urlService.ADD_FAVOURITE,{"username": sessionStorage.userName,"dcName":$scope.dcName,"funName":$scope.functionality})
				.then(function(response){
				  $("#showloader").css("display", "none");
				  if(response.errorMessage){
					$scope.isFavouriteAdded= false; 
					$scope.isClicked = false;      
					$scope.$broadcast('showAlert',['']);
				  }else{
					$scope.isClicked = true;      
					$scope.isClicked = !isClicked;
					$scope.isFavouriteAdded= true; 
					$scope.favouriteMsg = response.resMessage;
				  $scope.$broadcast('ClickedOnFavourate',[$scope.dcName,$scope.functionality,$scope.isClicked]);
				  }
					
				},function(error){
				  $scope.isClicked = false;
				  $("#showloader").css("display", "none");
				});
				$scope.isClicked = !isClicked;
			  }else{
				$("#showloader").css("display", "none");
			  }
			 }
			
		  };
		$scope.addToFavourate('load');
		//user favourites code ends
	}

})(window.angular);