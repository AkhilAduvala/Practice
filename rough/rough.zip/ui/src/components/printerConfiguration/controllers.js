var app = angular.module('PrinterConfiguration', ['ngAnimate', 'ui.grid', 'ui.grid.selection', 'ui.grid.edit', 'ui.grid.cellNav', 'ui.grid.validate', 'ui.grid.exporter']);
myApp.directive('fileModel', ['$parse', function ($parse) {
	return {
		restrict: 'A',
		link: function (scope, element, attrs) {
			var model = $parse(attrs.fileModel);
			var modelSetter = model.assign;

			element.bind('change', function () {
				scope.$apply(function () {
					modelSetter(scope, element[0].files[0]);
				});
			});
		}
	};
}]);

app.controller('PrinterConfigurationController', ['$scope', '$http', '$q', '$interval', 'uiGridValidateService', '$timeout', 'urlService', 'uiGridConstants', 'commonService', 'uiGridExporterService', 'uiGridExporterConstants', function ($scope, $http, $q, $interval, uiGridValidateService, $timeout, urlService, uiGridConstants, commonService, uiGridExporterService, uiGridExporterConstants) {

	var pr = this;
	$scope.pagefunctionality = $scope.functionality;
	$scope.pagedc = $scope.dcName;
	$scope.isTable = false;
	pr.isClicked = false;
	$scope.selectedInventory = [];
	$scope.validateExistingDb = false;
	$scope.disableDownload = true;
		$scope.clearFile = function () {
		$scope.isFailed = false;
		$scope.isTable = false;
		$scope.disableDownload = true;
		$scope.isSuccess = false;
		$scope.excelReadErrors = false;
		$scope.excelErrors = false;
		$scope.hideUploadDtls = true;
		//document.getElementById('list').innerHTML = '';
		$scope.success = false;
		document.getElementById('nextStep').innerHTML = '';
		$scope.errorMessagesArray = [];
		$scope.disableDownload = true;
	};
	
   $scope.gridOptions = { 
    enableSorting: true,
    enableColumnMenus: false,
	  multiSelect:false,
    enableRowSelection: true,//we can remove it later no use  of this
    enableSelectAll: true,//we can remove it latgridOptionsTwoer no use  of this             
    enableCellEdit: false, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
    enableCellEditOnFocus: true // set any editable column to allow edit on focus
 
  };

      $scope.gridOptions.onRegisterApi = function(gridApi){
    //set gridApi on scope
    $scope.gridApi = gridApi; 
	// $scope.getReplenshmentList();
	//$scope.getupdateData();
   
   };



	
/*    $scope.updateDisableFlag	= function(){
	   if($scope.validateExistingDb = true && ($scope.hostName == null || $scope.portNumber ==null || $scope.serviceName ==null || $scope.dbUserId ==null || $scope.dbPassword == null)){
		  $scope.disableUpload = true;
	   }else{
		   $scope.disableUpload = false;
	   }
   } */
	
	$scope.updatemigrate = function () {
		$scope.disableDownload = false;
	if($scope.migrateInstance == true){
		$scope.validateAppExistence = true;
		$scope.validateExistingDb = true;
	}else{
		$scope.validateAppExistence = false;
		$scope.validateExistingDb = false;
/* 		$scope.hostName = "";
		$scope.portNumber = "";
		$scope.serviceName = "";
		$scope.dbUserId = "";
		$scope.dbPassword = "";
		$scope.appHostName = "";
		$scope.appPortNumber = "";
		$scope.appUserId = "";
		$scope.appPassword = "";
		$scope.xmlLocation = "";
		$scope.migrateUserName = "";
		$scope.migratePortNumber = "";
		$scope.migrateServiceName = "";
		$scope.migrateDbUserId = "";
		$scope.migrateDbPassword = ""; */
	}

	};



$scope.getprinterData = function () {
	$scope.disableDownload = false;
	$scope.hideUploadDtls = true;
	$scope.resMessage = "";
    var str_array = ($scope.printer.trim().replace(/\n/g, ",")).replace(/,+/g, ',').replace(/(^\s*,)|( ,\s*$)/g, '');
    var lastChar = str_array[str_array.length - 1];
    if (lastChar == ",") {
        newStr = str_array.substring(0, str_array.length - 1);
    } else {
        newStr = str_array;
    }
    if ((newStr.match(/,/g) || []).length > 99) {
        $scope.isFailed = true;
        $scope.resmessage = "Maximum 100 Printers are allowed";
        return false;
    }
    newStr = newStr.split(",");
    newStr = newStr.filter(function (str) {//used to remove the empty spaces(like empty value)
        str = str.trim();
        if (str) {
            return /\S/.test(str);
        }
    });
    newStr = newStr.map(function (el) {//used to clear the spaces of each array element
        return el.trim();
    });

	
    $scope.isSuccess = false;
    $scope.isFailed = false;
    var dcName = $scope.dcName;
    var userName = sessionStorage.userName;
	var keyval = sessionStorage.apikey ;
    $("#showloader").css("display", "block");
	var dcName = $scope.dcName;
	var userName = sessionStorage.userName;
	var validateE =($scope.validateExistingDb == true)? 'Y':'N';
	var validateS= ($scope.validateAppExistence == true)? 'Y':'N';
	var mig= ($scope.migrateInstance== true)? 'Y':'N';
/*     var url = urlService.GET_PRINTER_DTLS;
    url = url.replace('valE', validateE);
    url = url.replace('valT', validateS);
    url = url.replace('mPrinters', mig);
    url = url.replace('uName', userName);
    url = url.replace('dName', dcName);
    url = url.replace('prnts', str_array); */
	
        var payload = {
			"dcName": dcName,
            "userName": userName,
            "validateExistingDb": validateE,
            "validateTargetXml": validateS,
            "migratePrinters": mig,
			"printers": newStr
        };
        var res = $http.post(urlService.GET_PRINTER_DTLS, payload, {
            headers: { 'x-api-key': sessionStorage.apikey }
        });	
    //var res = $http.get(url);
/*     var res = $http.post(url,$scope.validateExistingDb, {
        headers: {'x-api-key': sessionStorage.apikey }
    }); */
/* 						$http.post(uploadUrl, fd, {
							transformRequest: angular.identity,
							headers: { 'Content-Type': undefined, 'x-api-key': sessionStorage.apikey }
						}) */
    res.success(function (data, status, headers, config) {
        $("#showloader").css("display", "none");

        if (data.errorMessage) {
            $scope.isFailed = true;
            $scope.resmessage = data.errorMessage;

        } /* else if (data.resMessage) {
            $scope.isSuccess = true;
            $scope.resmessage = data.resMessage;
        }  */else {
/* 			if(mig == 'N'){
            $scope.gridOptions.columnDefs = [
                { name: 'printerName', displayName: 'Printer Name', enableCellEdit: false, sort: { direction: uiGridConstants.ASC, priority: 1 } },
                { name: 'presentInSource', displayName: 'Present In Source', enableCellEdit: false, cellTooltip: true, headerTooltip: true },
			
                { name: 'presentInTargetXML', displayName: 'Present In printservice.xml', enableCellEdit: false, cellTooltip: true, headerTooltip: true }
            ];
			}
			else{ */
				
            $scope.gridOptions.columnDefs = [
                { name: 'printerName', displayName: 'Printer Name', enableCellEdit: false, sort: { direction: uiGridConstants.ASC, priority: 1 } },
                { name: 'presentInSource', displayName: 'Present In Source', enableCellEdit: false, cellTooltip: true, headerTooltip: true },		
                { name: 'presentInTargetXML', displayName: 'Present In printservice.xml', enableCellEdit: false, cellTooltip: true, headerTooltip: true },
				{ name: 'status', displayName: 'Status', enableCellEdit: false, cellTooltip: true, headerTooltip: true }
            ];				
				
			


			$scope.disableDownload = false;
            $scope.isTable = true;
            $scope.gridOptions.data  = data.printerLst; 
			$scope.isSuccess = true;
			$scope.resmessage = data.resMessage;
            if ($scope.gridOptions.data > 10) {
                $scope.gridOptions.enableVerticalScrollbar = true;
                $scope.gridOptions.enableHorizontalScrollbar = 1;
            } else {
                $scope.gridOptions.enableVerticalScrollbar = false;
                $scope.gridOptions.enableHorizontalScrollbar = 1;
            }


        }
        $('.ui-grid-pager-control input').prop("disabled", true);
    });
    res.error(function (data, status, headers, config) {
        $("#showloader").css("display", "none");
        $scope.isFailed = true;
        $scope.resmessage = "System failed. Please try again or contact WAALOS Support";

    });
};
	
	

	
	
	
	$scope.updateExistingDb = function () {
	if($scope.validateExistingDb == false){
/* 		$scope.hostName = "";
		$scope.portNumber = "";
		$scope.serviceName = "";
		$scope.dbUserId = "";
		$scope.dbPassword = ""; */
	}

	};	

	$scope.updateAppExistence = function () {
	if($scope.validateAppExistence == false){
/* 		$scope.appHostName = "";
		$scope.appPortNumber = "";
		$scope.appUserId = "";
		$scope.appPassword = "";
		$scope.xmlLocation = ""; */
	}

	};		

	
	
	var fileInput = document.getElementById("uploadFile");
/* 	$scope.uploadchange = function(evt){
		
		if (evt.value.length == 0) {


		} else {

			$scope.excelErrors = false;
			$scope.isFailedload = false;
			$scope.excelReadErrors = false;
			$scope.isFailed = false;
			//document.getElementById('list').innerHTML = '';
			$scope.success = false;
			//document.getElementById('nextStep').innerHTML = '';
			$scope.errorMessagesArray = [];

			fileExtension = evt.value.substr((evt.value.lastIndexOf('.') + 1));

			if (fileExtension == "xls") {
				$scope.isFailed = true;
				$scope.resmessage = "Please save this xls file into xlsx format and try again to Choose File";
				return false;
			}


			if (evt.value.indexOf(".xlsx") < 0) {
				$scope.isFailed = true;
				$scope.resmessage = "Please choose only XLSX file";
				return false;
			}


			var dcName = $scope.dcName;
			var userName = sessionStorage.userName;
			var validateE =($scope.validateExistingDb == true)? 'Y':'N';
			var validateS= ($scope.validateAppExistence == true)? 'Y':'N';
			var mig= ($scope.migrateInstance== true)? 'Y':'N';
			var files = evt.files;
			var fileval = $("input[type='file']").val();
			var output = [];
			if (fileval == '' || fileval == undefined || fileval == null) {
				document.getElementById('list').innerHTML = '';
				document.getElementById('nextStep').innerHTML = '';
				//$scope.disable = false;
			} else {
				   //$scope.validateExistingDb= 'Y';
					//$scope.validateAppExistence = 'N';
					//$scope.updatemigrate = 'N';
				$("#showloader").css("display", "block");
				var uploadUrl = urlService.PRINTER_CONFIG_DTLS;
	uploadUrl =uploadUrl.replace('valE',validateE);
	uploadUrl = uploadUrl.replace('valT',validateS);
	uploadUrl = uploadUrl.replace('mPrinters',mig);
	uploadUrl = uploadUrl.replace('uName',userName);
	uploadUrl = uploadUrl.replace('dName',dcName);				
				
					//output.push('<li><strong>', escape(f.name), '</strong> was choosen successfully</li>');
					localStorage.setItem("choosenFile", files[0]);
					var file = files[0];
					var fd = new FormData();*/

/* 					fd.append('dcName', dcName);
					fd.append('userName', userName);
					fd.append('validateExistingDb', validateE);
					fd.append('validateTargetXml', validateS);
					fd.append('migratePrinters', mig); */					
					
/* 					fd.append('file', file);
					
						$http.post(uploadUrl, fd, {
							transformRequest: angular.identity,
							headers: { 'Content-Type': undefined,'x-api-key': sessionStorage.apikey }
						}) */
/* 		$http({
			method: 'POST',
			url: uploadUrl,
			data: { "dcName": dcName, "validateExistingDb": $scope.validateExistingDb,"validateTargetXml": $scope.validateAppExistence,"migratePrinters": $scope.updatemigrate,"userName": userName,"file": file },
			headers: {
				'Content-type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'x-api-key': sessionStorage.apikey
			},
			responseType: 'arraybuffer'

		})	 */					
						
/* .success( function(data, status, headers) {

$("#showloader").css("display", "none");

	if(data.byteLength == 55){
			$scope.isFailed = true;
			  $('#alert-box').modal('show');


			  }else if(data.byteLength == 98){
		$scope.isFailed = true;
		$scope.resmessage = "Error in Downloading Excel file";
		return;
	}else if (data.errorMessage == "Printers not in sync"){
						$scope.isSuccess = false;
						$scope.isFailed = true;
					$scope.isUpdate = true;
					$scope.resmessage = data.errorMessage;
	}
	else{
		$scope.isSuccess = true;
		$scope.resmessage = "Activity completed";
		var octetStreamMime = 'application/octet-stream';
		var success = false;
		var blob;
		// Get the headers
		headers = headers();

		// Get the filename from the x-filename header or default to "download.bin"
		var filename = headers['x-filename'] || 'PRINTER_CONFIG_RESULT.xlsx';

		// Determine the content type from the header or default to "application/octet-stream"
		var contentType = headers['content-type'] || octetStreamMime;

		try
		{
			// Try using msSaveBlob if supported
			console.log("Trying saveBlob method ...");
			 blob = new Blob([data], { type: contentType });
			if(navigator.msSaveBlob)
				navigator.msSaveBlob(blob, filename);
			else {
				// Try using other saveBlob implementations, if available
				var saveBlob = navigator.webkitSaveBlob || navigator.mozSaveBlob || navigator.saveBlob;
				if(saveBlob === undefined) throw "Not supported";
				saveBlob(blob, filename);
			}
			console.log("saveBlob succeeded");
			success = true;
		} catch(ex)
		{
			console.log("saveBlob method failed with the following exception:");
			console.log(ex);
		}

		if(!success)
		{
			// Get the blob url creator
			var urlCreator = window.URL || window.webkitURL || window.mozURL || window.msURL;
			if(urlCreator)
			{
				// Try to use a download link
				var link = document.createElement('a');
				if('download' in link)
				{
					// Try to simulate a click
					try
					{
						// Prepare a blob URL
						console.log("Trying download link method with simulated click ...");
						 blob = new Blob([data], { type: contentType });
						 url = urlCreator.createObjectURL(blob);
						link.setAttribute('href', url);

						// Set the download attribute (Supported in Chrome 14+ / Firefox 20+)
						link.setAttribute("download", filename);

						// Simulate clicking the download link
						var event = document.createEvent('MouseEvents');
						event.initMouseEvent('click', true, true, window, 1, 0, 0, 0, 0, false, false, false, false, 0, null);
						link.dispatchEvent(event);
						console.log("Download link method with simulated click succeeded");
						success = true;

					} catch(ex) {
						console.log("Download link method with simulated click failed with the following exception:");
						console.log(ex);
					}
				}

				if(!success)
				{
					// Fallback to window.location method
					try
					{
						// Prepare a blob URL
						// Use application/octet-stream when using window.location to force download
						console.log("Trying download link method with window.location ...");
						 blob = new Blob([data], { type: octetStreamMime });
						 url = urlCreator.createObjectURL(blob);
						window.location = url;
						console.log("Download link method with window.location succeeded");
						success = true;
					} catch(ex) {
						console.log("Download link method with window.location failed with the following exception:");
						console.log(ex);
					}
				}

			}
		}

		if(!success)
		{
			// Fallback to window.open method
			console.log("No methods worked for saving the arraybuffer, using last resort window.open");
			window.open(rowData.pathName, '_blank', '');
		}
		
	}
})

.error(function(data, status, config) {

	console.log("Request failed with status: " + status);
$("#showloader").css("display", "none");
	// Optionally write the error out to scope
	//$scope.errorDetails = "Request failed with status: " + status;
$scope.isFailed = true;
		$scope.resmessage = "Error in downloading Excel File";

});
						
			}
						
		}				
						
	};	  */
	
	
	
	
	$scope.uploadchange = function(evt){
		$scope.disableDownload = true;
		$scope.isTable = false;
		$scope.hideUploadDtls = false;
		$scope.resmessage = "";
		if (evt.value.length == 0) {


		} else {

			$scope.excelErrors = false;
			$scope.isFailedload = false;
			$scope.excelReadErrors = false;
			$scope.isFailed = false;
			//document.getElementById('list').innerHTML = '';
			$scope.success = false;
			document.getElementById('nextStep').innerHTML = '';
			$scope.errorMessagesArray = [];

			fileExtension = evt.value.substr((evt.value.lastIndexOf('.') + 1));

			if (fileExtension == "xls") {
				$scope.isFailed = true;
				$scope.resmessage = "Please save this xls file into xlsx format and try again to Choose File";
				return false;
			}


			if (evt.value.indexOf(".xlsx") < 0) {
				$scope.isFailed = true;
				$scope.resmessage = "Please choose only XLSX file";
				return false;
			}


			var dcName = $scope.dcName;
			var userName = sessionStorage.userName;
			var files = evt.files;
			var fileval = $("input[type='file']").val();
			var output = [];
			if (fileval == '' || fileval == undefined || fileval == null) {
				document.getElementById('list').innerHTML = '';
				document.getElementById('nextStep').innerHTML = '';
				//$scope.disable = false;
			} else {
				$("#showloader").css("display", "block");
				var uploadUrl = urlService.PRINTER_CONFIG_DTLS;
				for (var i = 0, f; f = files[i]; i++) {
					output.push('<li><strong>', escape(f.name), '</strong> was choosen successfully</li>');
					localStorage.setItem("choosenFile", files[i]);
					var file = files[i];
					var fd = new FormData();
					fd.append('dcName', dcName);
					fd.append('userName', userName);
					fd.append('file', file);
					if (files[i].size < 1024 * 1024 * 10) {
						$http.post(uploadUrl, fd, {
							transformRequest: angular.identity,
							headers: { 'Content-Type': undefined, 'x-api-key': sessionStorage.apikey }
						})

							.success(function (response) {
								
								if (response.lotId) {
									$scope.lotId = response.lotId;

								if (response.errorMessage) {

									$scope.disableDownload = true;
									$scope.excelReadErrors = true;
									$scope.excelReadError = response;
		
									$("#showloader").css("display", "none");
								}  else if (response.errorDtoLst.length == 0) {
									$scope.disableDownload = true;
									$scope.successCount = response.successCount;
									$scope.errorCount = response.errorCount;
									$scope.totalCount = response.totalCount;
									$scope.success = true;
									$("#showloader").css("display", "none");
								}else {

									if(response.errorDtoLst === 0){$scope.disableDownload = true;}else{$scope.disableDownload = false;}
									$scope.excelErrorsData = response.errorDtoLst;
									$scope.successCount = response.successCount;
									$scope.errorCount = response.errorCount;
									$scope.totalCount = response.totalCount;
									$scope.excelErrors = true;
									$("#showloader").css("display", "none");

								}
							}else{
								$scope.excelReadErrors = true;
								$scope.excelReadError = response;
								$("#showloader").css("display", "none");
							}
							})

							
							.error(function (err) {
								$("#showloader").css("display", "none");
								$scope.isFailedload = true;
								$scope.errorMessagesArray = [];
							});
					} else {
						$("#showloader").css("display", "none");
						$scope.isFailed = true;
						$scope.resmessage = "File size should not exceed 10MB";
						$scope.errorMessagesArray = [];
					}

				}
			}
		}
	};	
	
	
	$scope.uploadclick =  function(){ 
		
		var input = document.getElementById("uploadFile");

		if (input.value.length == 0) {

		} else if (input.value.length > 0) {
			input.value = null;
	        input.value = '';
			input.type = '';
			input.type = 'file';
			document.getElementById("uploadFile").value = null;
		}
	};
	
	
	
	
  $scope.downloadExcel = function() {
	$scope.isFailed = false;
	$("#showloader").css("display", "block");
	var url= urlService.DOWNLOAD_PRINTER_DTLS;
	var griddata;
	griddata = $scope.gridOptions.data;

		$http({
			method: 'POST',
			url: url,
			data: {  "printerLst":  griddata },
			headers: {
				'Content-type': 'application/json', 'x-api-key': sessionStorage.apikey
			},
			responseType: 'arraybuffer'

		})
.success( function(data, status, headers) {

$("#showloader").css("display", "none");

	if(data.byteLength == 55){
			$scope.isFailed = true;
			  $('#alert-box').modal('show');


			  }else if(data.byteLength == 98){
		$scope.isFailed = true;
		$scope.resmessage = "Error in Downloading Excel file";
		return;
	}else{
		
		var octetStreamMime = 'application/octet-stream';
		var success = false;
		var blob;
		// Get the headers
		headers = headers();

		// Get the filename from the x-filename header or default to "download.bin"
		var filename = headers['x-filename'] || 'PRINTER_VALIDATION_RESULT.xlsx';

		// Determine the content type from the header or default to "application/octet-stream"
		var contentType = headers['content-type'] || octetStreamMime;

		try
		{
			// Try using msSaveBlob if supported
			console.log("Trying saveBlob method ...");
			 blob = new Blob([data], { type: contentType });
			if(navigator.msSaveBlob)
				navigator.msSaveBlob(blob, filename);
			else {
				// Try using other saveBlob implementations, if available
				var saveBlob = navigator.webkitSaveBlob || navigator.mozSaveBlob || navigator.saveBlob;
				if(saveBlob === undefined) throw "Not supported";
				saveBlob(blob, filename);
			}
			console.log("saveBlob succeeded");
			success = true;
		} catch(ex)
		{
			console.log("saveBlob method failed with the following exception:");
			console.log(ex);
		}

		if(!success)
		{
			// Get the blob url creator
			var urlCreator = window.URL || window.webkitURL || window.mozURL || window.msURL;
			if(urlCreator)
			{
				// Try to use a download link
				var link = document.createElement('a');
				if('download' in link)
				{
					// Try to simulate a click
					try
					{
						// Prepare a blob URL
						console.log("Trying download link method with simulated click ...");
						 blob = new Blob([data], { type: contentType });
						 url = urlCreator.createObjectURL(blob);
						link.setAttribute('href', url);

						// Set the download attribute (Supported in Chrome 14+ / Firefox 20+)
						link.setAttribute("download", filename);

						// Simulate clicking the download link
						var event = document.createEvent('MouseEvents');
						event.initMouseEvent('click', true, true, window, 1, 0, 0, 0, 0, false, false, false, false, 0, null);
						link.dispatchEvent(event);
						console.log("Download link method with simulated click succeeded");
						success = true;

					} catch(ex) {
						console.log("Download link method with simulated click failed with the following exception:");
						console.log(ex);
					}
				}

				if(!success)
				{
					// Fallback to window.location method
					try
					{
						// Prepare a blob URL
						// Use application/octet-stream when using window.location to force download
						console.log("Trying download link method with window.location ...");
						 blob = new Blob([data], { type: octetStreamMime });
						 url = urlCreator.createObjectURL(blob);
						window.location = url;
						console.log("Download link method with window.location succeeded");
						success = true;
					} catch(ex) {
						console.log("Download link method with window.location failed with the following exception:");
						console.log(ex);
					}
				}

			}
		}

		if(!success)
		{
			// Fallback to window.open method
			console.log("No methods worked for saving the arraybuffer, using last resort window.open");
			window.open(rowData.pathName, '_blank', '');
		}
	}
})
.error(function(data, status, config) {

	console.log("Request failed with status: " + status);
$("#showloader").css("display", "none");
	// Optionally write the error out to scope
	//$scope.errorDetails = "Request failed with status: " + status;
$scope.isFailed = true;
		$scope.resmessage = "Error in downloading Excel File";

});
};	
	
	
	
	
	


    //user favourites code starts
    $scope.isClicked = false;
    $scope.addToFavourate = function(isClicked) {
        $("#showloader").css("display", "block");
        if (typeof isClicked !== "boolean") {
            commonService.postServiceResponse(urlService.GET_FAVOURITES, { "username": sessionStorage.userName })
                .then(function(response) {
                    $("#showloader").css("display", "none");
                    _.each(response, function(val, key) {
                        if (val.funName == $scope.functionality && val.dcName == $scope.dcName) {
                            $scope.isClicked = true;
                        }
                    });
                }, function(error) {
                    $("#showloader").css("display", "none");
                    $scope.isClicked = false;
                });
            //$scope.isClicked = ;
        } else {
            if (!$scope.isClicked) {
                commonService.postServiceResponse(urlService.ADD_FAVOURITE, { "username": sessionStorage.userName, "dcName": $scope.dcName, "funName": $scope.functionality })
                    .then(function(response) {
                        $("#showloader").css("display", "none");
                        if (response.errorMessage) {
                            $scope.isFavouriteAdded = false;
                            $scope.isClicked = false;
                            $scope.$broadcast('showAlert', ['']);
                        } else {
                            $scope.isClicked = true;
                            $scope.isClicked = !isClicked;
                            $scope.isFavouriteAdded = true;
                            $scope.favouriteMsg = response.resMessage;
                            $scope.$broadcast('ClickedOnFavourate', [$scope.dcName, $scope.functionality, $scope.isClicked]);
                        }

                    }, function(error) {
                        $scope.isClicked = false;
                        $("#showloader").css("display", "none");
                    });
                $scope.isClicked = !isClicked;
            } else {
                $("#showloader").css("display", "none");
            }
        }

    };
    $scope.addToFavourate('load');
    //user favourites code ends		
	
}]);
