var app = angular.module('DedicatedAttributeUpdate');

app.controller('DedicatedAttributeUpdateController', ['$scope', '$http', '$q', '$interval', '$timeout', 'urlService', 'uiGridConstants', 'commonService', function($scope, $http, $q, $interval, $timeout, urlService, uiGridConstants, commonService) {
    $scope.showDNNumbers = true;
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $scope.disable = true;
    $scope.pagefunctionality = $scope.functionality;
    $scope.pagedc = $scope.dcName;

    /**
  This function is used to change the disable value to false. Based on this update button will enable.
  **/
    
    $scope.validateInputFields = function() {
        $scope.resmessage = "";
		$scope.disable = false;
        var reg = /^[0-9\_ ]+$/;
		//if ($scope.dnNumbers=="" || $scope.dnNumbers==undefined || $scope.salesOdr == "" || $scope.salesOdrItem == "" || $scope.salesOdrItem == undefined || $scope.salesOdr == undefined ){
		if ($scope.dnNumbers=="" || $scope.dnNumbers==undefined ){
			$scope.disable = true;
		}else{
			$scope.disable = false;
		}
/* 		if($scope.daNumbers!=""){
			if(($scope.salesOdr == "" && $scope.salesOdrItem == "" )|| ($scope.salesOdr == undefined && $scope.salesOdrItem == undefined)){
				$scope.disable = true;
			} 
		}*/
		
    };
     

  $scope.resetData = function(){
	$scope.salesOdr = "";
	$scope.salesOdrItem = "";
	$scope.dnNumbers="";
	
  };		
	


   

    /** This function is used to update the FreightTerms **/
    $scope.updateAttribute = function() {
        $scope.isSuccess = false;
        $scope.isFailed = false;
		var str_array = ($scope.dnNumbers.trim().replace(/\n/g, ",")).replace(/,+/g, ',').replace(/(^\s*,)|( ,\s*$)/g, '');
		var lastChar = str_array[str_array.length - 1];
		if (lastChar == ",") {
			newStr = str_array.substring(0, str_array.length - 1);
		} else {
			newStr = str_array;
		}
		if ((newStr.match(/,/g) || []).length > 999) {
			$scope.isFailed = true;
			$scope.resmessage = "Maximum 1000 DN Numbers are allowed";
			return false;
		}
		if($scope.salesOdr.length !=  10 && $scope.salesOdr.length >  0)
		{
			$scope.isFailed = true;
			$scope.resmessage = "Sales Order must be of length 10";
			return false;			
		}
		if($scope.salesOdrItem.length != 6 && $scope.salesOdrItem.length > 0)
		{
			$scope.isFailed = true;
			$scope.resmessage = "Sales Order Item must be of length 6";
			return false;			
		}		
		newStr = newStr.split(",");
		newStr = newStr.filter(function (str) {//used to remove the empty spaces(like empty value)
			str = str.trim();
			if (str) {
				return /\S/.test(str);
			}
		});
		newStr = newStr.map(function (el) {//used to clear the spaces of each array element
			return el.trim();
		});		
		
        $("#showloader").css("display", "block");
        var payload = {
            "salesOrder": $scope.salesOdr,
            "salesOrderItem": $scope.salesOdrItem,
			"lpns": newStr,
            "dcName": $scope.pagedc,
            "userName": sessionStorage.userName
        };
        var res = $http.post(urlService.UPDATE_ATTRIBUTE, payload, {
            headers: { 'x-api-key': sessionStorage.apikey }
        });
        res.success(function(data, status, headers, config) {
            $("#showloader").css("display", "none");
            if (data.errorMessage) {
                $scope.isFailed = true;
                $scope.resmessage = data.errorMessage;
            } else {
                $scope.isSuccess = true;
                $scope.resmessage = data.resMessage;
            }
        });
        res.error(function(data, status, headers, config) {
            $("#showloader").css("display", "none");
            $scope.isFailed = true;
            $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
        });
    };



    //user favourites code starts
    $scope.isClicked = false;
    $scope.addToFavourate = function(isClicked) {
        $("#showloader").css("display", "block");
        if (typeof isClicked !== "boolean") {
            commonService.postServiceResponse(urlService.GET_FAVOURITES, { "username": sessionStorage.userName })
                .then(function(response) {
                    $("#showloader").css("display", "none");
                    _.each(response, function(val, key) {
                        if (val.funName == $scope.functionality && val.dcName == $scope.dcName) {
                            $scope.isClicked = true;
                        }
                    });
                }, function(error) {
                    $("#showloader").css("display", "none");
                    $scope.isClicked = false;
                });
            //$scope.isClicked = ;
        } else {
            if (!$scope.isClicked) {
                commonService.postServiceResponse(urlService.ADD_FAVOURITE, { "username": sessionStorage.userName, "dcName": $scope.dcName, "funName": $scope.functionality })
                    .then(function(response) {
                        $("#showloader").css("display", "none");
                        if (response.errorMessage) {
                            $scope.isFavouriteAdded = false;
                            $scope.isClicked = false;
                            $scope.$broadcast('showAlert', ['']);
                        } else {
                            $scope.isClicked = true;
                            $scope.isClicked = !isClicked;
                            $scope.isFavouriteAdded = true;
                            $scope.favouriteMsg = response.resMessage;
                            $scope.$broadcast('ClickedOnFavourate', [$scope.dcName, $scope.functionality, $scope.isClicked]);
                        }

                    }, function(error) {
                        $scope.isClicked = false;
                        $("#showloader").css("display", "none");
                    });
                $scope.isClicked = !isClicked;
            } else {
                $("#showloader").css("display", "none");
            }
        }

    };
    $scope.addToFavourate('load');
    //user favourites code ends		




}]);