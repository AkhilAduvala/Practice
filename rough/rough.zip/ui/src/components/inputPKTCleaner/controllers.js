
var app = angular.module('InputPKTCleaner', ['ui.grid', 'ui.grid.selection', 'ui.grid.pagination']);
app.controller('InputPktCleanerController', ['$scope', '$http', '$q', '$interval', '$rootScope', 'uiGridValidateService', '$timeout','urlService','uiGridConstants','commonService', function ($scope, $http, $q, $interval, $rootScope, uiGridValidateService, $timeout,urlService,uiGridConstants,commonService) {

	$scope.isTable = false;
   	$scope.disable = true;
  	$scope.isDelete = true;
  	$scope.isSuccess = false;
  	$scope.isFailed = false;
	  $scope.isClicked = false;
	$scope.pagefunctionality = $scope.functionality;
	$scope.pagedc = $scope.dcName;
	$("#showloader").css("display", "block");

	$scope.pickTicketvalid = function () {
		//var reg = /^[0-9a-zA-Z\_,\s]+$/;
		if ($scope.pickTicket == '' || $scope.pickTicket == null || $scope.pickTicket == undefined || $scope.pickTicket == 32) {
			//!(reg.test($scope.pickTicket))
		  $scope.disable = true;
		} else {
		  $scope.disable = false;
		}
	  };

	$scope.gridOptions = {
		paginationPageSizes: [15, 25, 50, 100],
		paginationPageSize: 15,
		useExternalPagination: true,
		enableSorting: true,
		enableColumnMenus: false,
		enableHorizontalScrollbar: false
	
	};

		$scope.gridOptions.columnDefs = [
			{ name: 'pickCntrlNum', displayName: 'PickTicket', enableCellEdit: false, sort: { direction: uiGridConstants.ASC, priority: 1 },  cellTooltip: true, headerTooltip: true, width: 120 },
			{ name: 'hdr', displayName: 'PickTicket Header', cellTooltip: true, headerTooltip: true, width: 170, enableCellEdit: false },
			{ name: 'dtl', displayName: 'PickTicket Details', cellTooltip: true, headerTooltip: true,  width: 170, enableCellEdit: false },
     		{ name: 'instr', displayName: 'PickTicket Instruction', cellTooltip: true, headerTooltip: true, width: 180, enableCellEdit: false },
			{
				name: 'errorMsg', displayName: 'Error Messages', enableCellEdit: false, cellTooltip: true, headerTooltip: true,
				cellTemplate: '<div class="ui-grid-cell-contents" id="errorMsg" title="{{COL_FIELD}}"><a class="errorMsg" href="javascript:void(0)">{{COL_FIELD}}<a></div>'
			}
		];

	$scope.gridOptions.onRegisterApi = function (gridApi) {

	$scope.gridApi = gridApi;

	$scope.gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
		$scope.pageNo =  newPage;
		$scope.pageSize = pageSize;
		$scope.getPktData();
	 });

	 gridApi.selection.on.rowSelectionChangedBatch($scope, function (rows) {
		$scope.isSuccess = false;
		$scope.isFailed = false;
		if ($scope.gridApi.selection.getSelectedRows().length == 0) {
			$scope.isDelete = true;
		} else {
			$scope.isDelete = false;
		}
	});

	gridApi.selection.on.rowSelectionChanged($scope, function (row) {
		$scope.isSuccess = false;
		$scope.isFailed = false;
		if ($scope.gridApi.selection.getSelectedRows().length > 0) {
			$scope.isDelete = false;
		} else {
			$scope.isDelete = true;
		}
	});
};

	$scope.deleteSelected = function () {
		$scope.resmessage = "";
		$scope.isSuccess = false;
		$scope.isFailed = false;
		

			$("#myModal").modal('hide');
			$("#showloader").css("display", "block");
		var deletedRows = [];
		angular.forEach($scope.gridApi.selection.getSelectedRows(), function (data, index) {
			var temp = {
				"dcName" : $scope.pagedc,
				"userName" : sessionStorage.userName,
				"pickCntrlNum" : data.pickCntrlNum

			};
			
			deletedRows.push(temp);
		});		
		//var res = $http.post(urlService.DELETE_PICK_CLEANUP_TCKTS, deletedRows);
		var res = $http.post(urlService.DELETE_PICK_CLEANUP_TCKTS, deletedRows, {
    		headers: {'x-api-key': sessionStorage.apikey}
		});

		res.success(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			$scope.isDelete = true;
			if (data.errorMessage) {
				$scope.isFailed = true;
				$scope.resmessage = data.errorMessage;
			  } 
			   else {
				$scope.getPktData();
				$scope.isSuccess = true;
				$scope.resmessage = data.resMessage;
			  }
			
		});
		res.error(function (data, status, headers, config) {
			$("#showloader").css("display", "none");
			$scope.isFailed = true;
			$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
			
			
		});

	};

	$scope.deleteRecord = function () {
		$scope.resmessage = "";
		$scope.isSuccess = false;
		$scope.isFailed = false;
		$scope.isFailedload = false;
		$scope.isRecordFound = false;
		$("#myModal").modal('show');

		};
	


    $scope.getPktData = function (){
	 $scope.resmessage = "";
	 $scope.isSuccess = false;
	 $scope.isFailed = false;

	$scope.pageNo = $scope.pageNo ? $scope.pageNo : 1;
    $scope.pageSize = $scope.pageSize ? $scope.pageSize: $scope.gridOptions.paginationPageSize;
	$("#showloader").css("display", "block");
	/*var inputData = {
		"dcName": $scope.pagedc,
		"userName" : sessionStorage.userName,
		"pageNumber": $scope.pageNo,
		"pageSize": $scope.pageSize
	};

	var res = $http.post(urlService.GET_PICK_CLEANUP_TCKTS, inputData);*/

    var url = urlService.GET_PICK_CLEANUP_TCKTS_ALL.replace('dName',$scope.pagedc);
    url = url.replace('uName',sessionStorage.userName);
    url = url.replace('pNumber',$scope.pageNo);
    url = url.replace('pSize',$scope.pageSize);
   
 
    //var res = $http.get(url);
  var res = $http.get(url, {
    headers: {'x-api-key': sessionStorage.apikey}
});
	res.success(function (data, status, headers, config) {
		$("#showloader").css("display", "none");
		if (data.errorMessage) {
			$scope.isTable = false;
			$scope.isFailed = true;
			$scope.resmessage = data.errorMessage;
		  }
		  else if(data.resMessage){
			$scope.isTable = false;
			$scope.isSuccess = true;
			$scope.resmessage = data.resMessage;
		  }
		  else if(data.length === 0){
			$scope.isTable = false;
			$scope.isFailed = true;
			$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
		  }
		 else {

			$scope.isTable = true;
			$('.ui-grid-pager-panel').css("display","block");
			$scope.gridOptions.totalItems  = data.totalNoOfRecords;  
			$scope.gridOptions.data = data.pageItems;
			
			if ($scope.gridOptions.data > 10) {
				$scope.gridOptions.enableVerticalScrollbar = true;
			} else {
				$scope.gridOptions.enableVerticalScrollbar = false;
				$scope.gridOptions.enableHorizontalScrollbar = 0;

			}
		
		}
	});

	res.error(function (data, status, headers, config) {
		$("#showloader").css("display", "none");
		$scope.isTable = false;
        $scope.isFailed = true;
        $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
	});
	setTimeout(function(){  $('.ui-grid-pager-control-input').attr( "disabled", true );  }, 2000);
	
 };

 $scope.getPktData();



 $scope.getPktDatarecords = function (){
	$scope.resmessage = "";
	$scope.isSuccess = false;
	$scope.isFailed = false;
	var newStr;
	var str_array = ($scope.pickTicket.trim().replace(/\n/g, ",")).replace(/,+/g, ',').replace(/(^\s*,)|( ,\s*$)/g, '');
	var lastChar = str_array[str_array.length - 1];
    if (lastChar == ",") {
			 newStr = str_array.substring(0, str_array.length - 1);
		} else {
			newStr = str_array;
    }

    if ((newStr.match(/,/g) || []).length > 9) {
			$scope.isFailed = true;
			$scope.resmessage = "Maximum 10 Carton numbers are allowed";
			return false;
		}

	$("#showloader").css("display", "block");
	/*var inputData = {
		"dcName": $scope.pagedc,
		"userName" : sessionStorage.userName,
		"pickCntrlNum":newStr

	};
	var res = $http.post(urlService.GET_PICK_CLEANUP_TCKTS, inputData);*/


    var url = urlService.GET_PICK_CLEANUP_TCKTS.replace('dName',$scope.pagedc);
    url = url.replace('uName',sessionStorage.userName);
    url = url.replace('pcNum',newStr);
 
    //var res = $http.get(url);
	var res = $http.get(url, {
    	headers: {'x-api-key': sessionStorage.apikey}
	});
	
	
	res.success(function (data, status, headers, config) {
		$("#showloader").css("display", "none");
		if (data.errorMessage) {
			$scope.isTable = false;
			$scope.isFailed = true;
			$scope.resmessage = data.errorMessage;
		  }
		  else if(data.resMessage){
			$scope.isTable = false;
			$scope.isSuccess = true;
			$scope.resmessage = data.resMessage;
		  }
		  else if(data.length === 0){
			$scope.isTable = false;
			$scope.isFailed = true;
			$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
		  }
		 else {

			$scope.isTable = true;
		
			$('.ui-grid-pager-panel').css("display","none");
	  		$scope.gridOptions.data = data;
			
			if ($scope.gridOptions.data > 10) {
				$scope.gridOptions.enableVerticalScrollbar = true;
			} else {
				$scope.gridOptions.enableVerticalScrollbar = false;
				$scope.gridOptions.enableHorizontalScrollbar = 0;

			}
			$('.ui-grid-pager-control input').prop( "disabled", true );

		}
	});
	res.error(function (data, status, headers, config) {
		$("#showloader").css("display", "none");
		$scope.isTable = false;
        $scope.isFailed = true;
        $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
	});
	$scope.disableinput();
 };

 $scope.disableinput = function(){
	setTimeout(function(){  $('.ui-grid-pager-control-input').attr( "disabled", true );  }, 2000);
  
  };

  //user favourites code starts
  $scope.addToFavourate = function(isClicked){
    $("#showloader").css("display", "block");
     if(typeof isClicked !== "boolean"){
      commonService.postServiceResponse(urlService.GET_FAVOURITES,{"username": sessionStorage.userName})
        .then(function(response){
          $("#showloader").css("display", "none");
            _.each(response,function(val,key){
              if(val.funName == $scope.functionality && val.dcName == $scope.dcName){
                $scope.isClicked = true;      
              }
            });
        },function(error){
          $("#showloader").css("display", "none");
          $scope.isClicked = false; 
        });
        //$scope.isClicked = ;
     }else{
      if(!$scope.isClicked){
        commonService.postServiceResponse(urlService.ADD_FAVOURITE,{"username": sessionStorage.userName,"dcName":$scope.dcName,"funName":$scope.functionality})
        .then(function(response){
          $("#showloader").css("display", "none");
          if(response.errorMessage){
            $scope.isFavouriteAdded= false; 
            $scope.isClicked = false;      
            $scope.$broadcast('showAlert',['']);
          }else{
            $scope.isClicked = true;      
            $scope.isClicked = !isClicked;
            $scope.isFavouriteAdded= true; 
            $scope.favouriteMsg = response.resMessage;
          $scope.$broadcast('ClickedOnFavourate',[$scope.dcName,$scope.functionality,$scope.isClicked]);
          }
            
        },function(error){
          $scope.isClicked = false;
          $("#showloader").css("display", "none");
        });
        $scope.isClicked = !isClicked;
      }else{
        $("#showloader").css("display", "none");
      }
     }
    
  };
  $scope.addToFavourate('load');
//user favourites code ends
}]);

