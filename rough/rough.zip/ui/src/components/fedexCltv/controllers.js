var app = angular.module('FedexCLTV', ['ui.bootstrap', 'ngTouch', 'ui.grid', 'ui.grid.selection', 'ui.grid.pagination', 'ui.grid.exporter', 'ui.grid.autoResize']);

app.controller('FedexCLTVController', ['$scope', '$http', '$q', '$interval', '$timeout', 'urlService', 'uiGridConstants', 'uiGridExporterConstants', 'uiGridExporterService', 'commonService', function ($scope, $http, $q, $interval, $timeout, urlService, uiGridConstants, uiGridExporterConstants, uiGridExporterService, commonService) {
	var pr = this;
	pr.pagedc = $scope.dcName;
	pr.pagefunctionality = $scope.functionality;
	$scope.isSuccess = false;
    $scope.isFailed = false;
	pr.isMianpage = false;
	pr.isClicked = false;
	pr.numberGridOptionssuccess = false;
	pr.numberGridOptionserror = false;
	pr.selectedRowValues = [] ;
	$scope.disable1 = true;
	pr.popup=[];
	$scope.isTable = false;
	
	 $scope.validateorderNbr = function(taskval) {
        $scope.disable1 = false;

        $scope.resmessage = "";
	
        var reg = /^[0-9\_ ]+$/;


            if ($scope.trailerNbr == "" || $scope.trailerNbr == undefined ) {
               $scope.disable1 = true;
            }
   
    };
	
	
	$scope.fedexConfirmation = function () {
		$("#saveModel").modal();
		
	}
	$scope.gridOptions = {
		paginationPageSizes: [10, 25, 50, 100],
		paginationPageSize: 10,
		useExternalPagination: true,
		enableColumnMenus: false,
		enableSorting: true,
		enableRowSelection: true,//we can remove it later no use  of this
		enableSelectAll: true,//we can remove it later no use  of this             
		enableCellEdit: false, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
		//enableCellEditOnFocus: true, // set any editable column to allow edit on focus
		enableColumnResizing: true,
		enableHorizontalScrollbar: true
	};

	//on RegisterApi calls
	$scope.gridOptions.onRegisterApi = function (gridApi) {
		//set gridApi on scope
		pr.gridApi = gridApi;
		gridApi.selection.on.rowSelectionChangedBatch(null, function (row) {

			pr.isSuccess = false;
			pr.isFailed = false;
			var booleanValues = [];
			_.each(row, function (value, key) {
				booleanValues.push(value.isSelected);
				pr.selectedRowValues.push({ 'number': value.entity.manifestid, 'isSelected': value.isSelected });
				pr.popup.push({ 'number': value.entity.manifestid});
			});

			if (booleanValues.indexOf(true) >= 0) {
				pr.searchDisable = false;
			} else {
				pr.selectedRowValues=[];
				pr.searchDisable = true;
			}
		});
		gridApi.selection.on.rowSelectionChanged(null, function (row) {
			var booleanValues = [];

			var number = _.find(pr.selectedRowValues, function (obj) {
				return obj.number == row.entity.manifestid;
			});
			if (!number) {
				pr.selectedRowValues.push({ 'number': row.entity.manifestid, 'isSelected': row.isSelected });
				pr.popup.push(row.entity.manifestid);
			} else {
				_.each(pr.selectedRowValues, function (value, key) {
					if (value.number == row.entity.manifestid) {
						
						var index = pr.popup.indexOf(row.entity.manifestid);
						if (index > -1) {
						  pr.popup.splice(index, 1);
						}
						pr.selectedRowValues[key].isSelected = row.isSelected;
						pr.selectedRowValues = _.reject(pr.selectedRowValues, function (d) {
							return d.isSelected == false;
						});
					}
				});
			}
			_.each(pr.selectedRowValues, function (value, key) {
				booleanValues.push(value.isSelected);
			});
			if (booleanValues.indexOf(true) >= 0) {
				pr.searchDisable = false;
			} else {
				pr.searchDisable = true;
			}
			// pr.prewaveNmuber = '';
			pr.isSuccess = false;
			pr.isFailed = false;
		});
	};
	//searching thorugh selection and input text
	pr.getDimensionData = function (modelValue) {
		if (modelValue == 'valueChanged') {
			pr.searchDisable = pr.selectedRowValues.length ? false : true;
		} else {
			var searchedValues = [];
			_.each(pr.selectedRowValues, function (val, key) {
				searchedValues.push(val.number);
			});
			$scope.searchedValues = searchedValues;
			pr.fedexJob(searchedValues);

		}
	};

pr.fedexJob = function (searchedValues) {
		 pr.isSuccess = false;
		 pr.isFailed = false;
		 $scope.isSuccess = false;
         $scope.isFailed = false;
		 $scope.resmessage = "";
		 	$("#showloader").css("display", "block");
		 url = urlService.INVOKE_FEDEX;
		var res = $http.post(url, { "dcName": $scope.dcName, "manifestNumber": searchedValues ? searchedValues : $scope.searchedValues ,"trailerNumber":$scope.trailerNbr},
				{
					headers: { 'x-api-key': sessionStorage.apikey },

				});

         res.success(function(data, status, headers, config) {
            $("#showloader").css("display", "none");
            if (data.errorMessage) {
                $scope.isFailed = true;
				$scope.resmessage = data.errorMessage;
				//$scope.resetData();
            } else {
				pr.selectedRowValues =[];
				pr.searchDisable = true;
                $scope.isSuccess = true;
				$scope.resmessage = data.resMessage;
				//$scope.resetData();
				//pr.getShipmentIds();
            }
        });
        res.error(function(data, status, headers, config) {
            $("#showloader").css("display", "none");
            $scope.isFailed = true;
            $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
        });
	
	}

	$scope.getManifestData = function (chk) {
		$scope.isSuccess = false;
		$scope.isFailed = false;
		$scope.isTable = false;
		$scope.resmessage = "";
		$scope.pageNo = $scope.pageNo ? $scope.pageNo : 1;
		$scope.pageSize = $scope.pageSize ? $scope.pageSize : $scope.gridOptions.paginationPageSize;
		$scope.check = arguments[0];


		$("#showloader").css("display", "block");
		var url = urlService.GET_MANIFEST_DETAILS;
		url = url.replace('dName', $scope.dcName);
		url = url.replace('uName', sessionStorage.userName);
		url = url.replace('pNumber', $scope.pageNo);
		url = url.replace('pSize', $scope.pageSize);
		var headers = { headers: { 'x-api-key': sessionStorage.apikey } };
		commonService.getServiceResponse(url, headers)
			.then(
			function (d) {
				if (d.pageItems) {
					if (d.pageItems.length > 0) {
						$("#showloader").css("display", "none");
						$scope.isTable = true;
						$scope.isUpdate = true;
						$scope.gridOptions.data = d.pageItems;
						$scope.gridOptions.totalItems = d.totalNoOfRecords;

						$scope.gridOptions.columnDefs = [
							{ name: 'manifestid', displayName: 'MANIFEST ID', enableCellEdit: false,sort: { direction: uiGridConstants.ASC, priority: 1 } }
							
						];
					}

					if ($scope.gridOptions.data > 10) {
						$scope.gridOptions.enableVerticalScrollbar = true;

					} else {
						$scope.gridOptions.enableVerticalScrollbar = false;
						$scope.gridOptions.enableHorizontalScrollbar = 1;
					}
				}else if (d.resMessage) {
					$scope.isSuccess = true;
					$scope.isUpdate = true;
					$scope.resmessage = d.resMessage;
					$("#showloader").css("display", "none");
					
				} else {
					$scope.isFailed = true;
					$scope.isUpdate = true;
					if($scope.check == 1 && d.errorMessage.indexOf("No data found") >= 0){
					$scope.isSuccess = true;
					$scope.isFailed = false;
					$scope.resmessage="FedexCLTV cancelled successfully";
					} else{
					$scope.resmessage = d.errorMessage;
					}
					$("#showloader").css("display", "none");
				}
			},
			function (errResponse) {

				$scope.isFailed = true;
				$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
				$("#showloader").css("display", "none");
			}
			);
	};
	
	$scope.getManifestData();
	
	$scope.resetData = function(){
		$scope.disable1 = "";
		$scope.getManifestData();
		pr.selectedRowValues=[];
		$scope.disable1 = true;
		$scope.trailerNbr="";
		pr.popup=[];
		
	};	
	

	pr.addToFavourate = function (isClicked) {
		$("#showloader").css("display", "block");
		if (typeof isClicked !== "boolean") {
			commonService.postServiceResponse(urlService.GET_FAVOURITES, { "username": sessionStorage.userName })
				.then(function (response) {
					$("#showloader").css("display", "none");
					_.each(response, function (val, key) {
						if (val.funName == $scope.functionality && val.dcName == $scope.dcName) {
							pr.isClicked = true;
						}
					});
				}, function (error) {
					$("#showloader").css("display", "none");
				});
			//pr.isClicked = ;
		} else {
			if (!pr.isClicked) {
				commonService.postServiceResponse(urlService.ADD_FAVOURITE, { "username": sessionStorage.userName, "dcName": $scope.dcName, "funName": $scope.functionality })
					.then(function (response) {
						$("#showloader").css("display", "none");
						if (response.errorMessage) {
							pr.isClicked = isClicked;
							pr.isFavouriteAdded = false;
							$scope.$broadcast('showAlert', ['']);
						} else {
							pr.isClicked = !isClicked;
							pr.isFavouriteAdded = true;
							pr.favouriteMsg = response.resMessage;
							$scope.$broadcast('ClickedOnFavourate', [pr.dcName, $scope.functionality, pr.isClicked]);
						}

					}, function (error) {
						$("#showloader").css("display", "none");
					});
				pr.isClicked = !isClicked;
			} else {
				$("#showloader").css("display", "none");
			}
		}

	};

	pr.addToFavourate('load');
	

}]);