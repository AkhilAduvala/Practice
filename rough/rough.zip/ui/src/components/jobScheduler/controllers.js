angular.module('jobScheduler', ['ui.grid', 'ui.grid.selection', 'ui.bootstrap', 'ui.grid.autoResize'])
.controller('jobSchedulerController', ['commonService','urlService','$http','$scope', function (commonService,urlService,$http,$scope) {
	 
		$scope.editedRowData = '';
$scope.isTable = false;
$scope.isClicked = false;
		$scope.pagefunctionality = 'Job Scheduler';
		$('[data-toggle="tooltip"]').tooltip();

		$scope.gridOptions = {
	paginationPageSizes: [15, 25, 50, 100],
	paginationPageSize: 15,
				enableColumnMenus: false,
				enableHorizontalScrollbar: false,
				//multiSelect: false,
				//enableRowSelection: true,//we can remove it later no use  of this
				//enableSelectAll: true,//we can remove it later no use  of this             
				 // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
				// set any editable column to allow edit on focus
				columnDefs: [
						{ name: 'jobdesc', displayName: 'Job Description', cellEditableCondition: false, width: 200 },
						{ name: 'jobhostname', displayName: 'Job Host', width: 100 },
						{ name: 'jobstatus', displayName: 'Flag', width: 100 },
						{ name: 'jobcommand', displayName: 'Job Command',
			cellTemplate: '<div class="ui-grid-cell-contents" ng-click="grid.appScope.invokeJob(grid, row)" style="cursor : pointer;"  title="{{COL_FIELD}}"><a>{{COL_FIELD}}</a></div>'}
				]
		}; 

$scope.gridOptions.onRegisterApi = function(gridApi){
	//set gridApi on scope
	$scope.gridApi = gridApi; 		 
};
$scope.invokeJob = function(grid,row) {

	$scope.resmessage = "";
$scope.rowData = row;

$("#trigger-confirm").text( "Are you sure you want to execute the job '"+row.entity.jobdesc +"'?");
$("#triggerModel").modal();
};

$scope.getJob = function(row){
$scope.getJobDetails(row);
};

$scope.getJobDetails = function (row) {
	$("#showloader").css("display", "block");
	$scope.isSuccess = false;
	$scope.isFailed = false;
	
	var url = urlService.INVOKE_JOB_SCHEDULER.replace('hname',row.entity.jobhostname);
	 url = url.replace('jscript',row.entity.jobcommand);
	// var res = $http.get(url);
	var res = $http.get(url, {
	 headers: {'x-api-key': sessionStorage.apikey}
	 });

	res.success(function (data, status, headers, config) {
		$("#showloader").css("display", "none");

		if (data.errorMessage) {
			$scope.isFailed = true;
			$scope.resmessage = data.errorMessage;

		}else {
				$scope.isSuccess = true;
				$scope.resmessage = data.resMessage;
			}
	});

	res.error(function (data, status, headers, config) {
		$("#showloader").css("display", "none");
		$scope.isFailed  = true;
		$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
	});
	setTimeout(function () { $('.ui-grid-pager-control-input').attr("disabled", true); }, 2000);
};


$scope.getJobschedularData = function () {
	$("#showloader").css("display", "block");
	$scope.isSuccess = false;
	$scope.isFailed = false;
	
	$scope.pageNo = $scope.pageNo ? $scope.pageNo : 1;
	$scope.pageSize = $scope.pageSize ? $scope.pageSize : $scope.gridOptions.paginationPageSize;

	var url = urlService.GET_JOB_SCHEDULER_DATA.replace('dName',$scope.dcName);
	 url = url.replace('uName',sessionStorage.userName);
	 url = url.replace('pNumber',$scope.pageNo);
	 url = url.replace('pSize',$scope.pageSize);
	// var res = $http.get(url);
	var res = $http.get(url, {
	 headers: {'x-api-key': sessionStorage.apikey}
	 });

	res.success(function (data, status, headers, config) {
		$("#showloader").css("display", "none");
		if (data.errorMessage) {
			$scope.isFailed = true;
			$scope.resmessage = data.errorMessage;

		} else {
			if (data.pageItems) {
				$scope.isTable = true;
				$scope.isData = false;
				$scope.gridOptions.totalItems = data.totalNoOfRecords;
				$scope.gridOptions.data = data.pageItems;
				if ($scope.gridOptions.data > 10) {
					$scope.gridOptions.enableVerticalScrollbar = true;
				} else {
					$scope.gridOptions.enableVerticalScrollbar = false;
					$scope.gridOptions.enableHorizontalScrollbar = 0;
				}
			} else {
				$scope.isFailed = true;
				$scope.resmessage = data.resMessage;
			}

		}
	});

	res.error(function (data, status, headers, config) {
		$("#showloader").css("display", "none");
		$scope.isFailed  = true;
		$scope.resmessage = "System failed. Please try again or contact WAALOS Support";


	});
	setTimeout(function () { $('.ui-grid-pager-control-input').attr("disabled", true); }, 2000);
};
$scope.getJobschedularData();    

//user favourites code starts
$scope.addToFavourate = function(isClicked){
	$("#showloader").css("display", "block");
	 if(typeof isClicked !== "boolean"){
		commonService.postServiceResponse(urlService.GET_FAVOURITES,{"username": sessionStorage.userName})
		.then(function(response){
			$("#showloader").css("display", "none");
			_.each(response,function(val,key){
				if(val.funName == $scope.functionality && val.dcName == $scope.dcName){
				$scope.isClicked = true;      
				}
			});
		},function(error){
			$("#showloader").css("display", "none");
			$scope.isClicked = false; 
		});
		//$scope.isClicked = ;
	 }else{
		if(!$scope.isClicked){
		commonService.postServiceResponse(urlService.ADD_FAVOURITE,{"username": sessionStorage.userName,"dcName":$scope.dcName,"funName":$scope.functionality})
		.then(function(response){
			$("#showloader").css("display", "none");
			if(response.errorMessage){
			$scope.isFavouriteAdded= false; 
			$scope.isClicked = false;      
			$scope.$broadcast('showAlert',['']);
			}else{
			$scope.isClicked = true;      
			$scope.isClicked = !isClicked;
			$scope.isFavouriteAdded= true; 
			$scope.favouriteMsg = response.resMessage;
			$scope.$broadcast('ClickedOnFavourate',[$scope.dcName,$scope.functionality,$scope.isClicked]);
			}
			
		},function(error){
			$scope.isClicked = false;
			$("#showloader").css("display", "none");
		});
		$scope.isClicked = !isClicked;
		}else{
		$("#showloader").css("display", "none");
		}
	 }
	
	};
	$scope.addToFavourate('load');
	//user favourites code ends
}]);