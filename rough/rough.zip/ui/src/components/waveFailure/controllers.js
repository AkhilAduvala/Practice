var app = angular.module('WaveFailure', ['ngTouch', 'ui.grid.autoResize', 'ui.grid', 'ui.grid.selection', 'ui.grid.resizeColumns', 'ui.grid.pagination']);

app.controller('WaveFailureController', ['$scope', '$http', '$q', '$interval', '$timeout', 'urlService', 'uiGridConstants', 'commonService', function ($scope, $http, $q, $interval, $timeout, urlService, uiGridConstants, commonService) {
	$scope.isTable = false;
	$scope.disable = true;
	$scope.isUpdate = true;
	$scope.isSuccess = false;
	$scope.isClicked = false;
	$scope.isFailed = false;
	$scope.pagefunctionality = $scope.functionality;
	$scope.pagedc = $scope.dcName;
	$("#showloader").css("display", "none");

	$scope.waveNumberValid = function () {
		//var reg = /^[0-9\_,\s]+$/;
		$scope.isSuccess = false;
		$scope.isFailed = false;
		if ($scope.waveNumber == '' || $scope.waveNumber == null || $scope.waveNumber == undefined || $scope.waveNumber == 32) {
			// || !(reg.test($scope.pickCartNbr))   
			$scope.disable = true;
		} else {
			$scope.disable = false;
		}
	};

	$scope.gridOptions = {
		paginationPageSizes: [1000],
		paginationPageSize: 1000,
		useExternalPagination: true,
		enableColumnMenus: false,
		enableSorting: true,
		enableRowSelection: true,//we can remove it later no use  of this
		enableSelectAll: true,//we can remove it later no use  of this             
		enableCellEdit: false, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
		//enableCellEditOnFocus: true, // set any editable column to allow edit on focus
		enableColumnResizing: true,
		enableHorizontalScrollbar: true
	};

	$scope.gridOptions.onRegisterApi = function (gridApi) {
		$scope.gridApi = gridApi;

		gridApi.selection.on.rowSelectionChangedBatch($scope, function (rows) {
			$scope.isSuccess = false;
			$scope.isFailed = false;
			if ($scope.gridApi.selection.getSelectedRows().length == 0) {
				$scope.isUpdate = true;
			} else {
				$scope.isUpdate = false;
			}
		});

		gridApi.selection.on.rowSelectionChanged($scope, function (row) {
			$scope.isSuccess = false;
			$scope.isFailed = false;
			if ($scope.gridApi.selection.getSelectedRows().length > 0) {
				$scope.isUpdate = false;
			} else {
				$scope.isUpdate = true;
			}
		});

		$scope.gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
			$scope.pageNo = newPage;
			$scope.pageSize = pageSize;
			$scope.getWaveNumberData();
		});
	};


	$scope.getWaveNumberData = function () {
		$scope.isSuccess = false;
		$scope.isFailed = false;
		$scope.isTable = false;
		$scope.resmessage = "";
		$scope.pageNo = $scope.pageNo ? $scope.pageNo : 1;
		$scope.pageSize = $scope.pageSize ? $scope.pageSize : $scope.gridOptions.paginationPageSize;

		var str_array = ($scope.waveNumber.trim().replace(/\n/g, ",")).replace(/,+/g, ',').replace(/(^\s*,)|( ,\s*$)/g, '');
		var lastChar = str_array[str_array.length - 1];
		if (lastChar == ",") {
			newStr = str_array.substring(0, str_array.length - 1);
		} else {
			newStr = str_array;
		}
		if ((newStr.match(/,/g) || []).length > 99) {
			$scope.isFailed = true;
			$scope.resmessage = "Maximum 100 DN Numbers are allowed";
			return false;
		}
		newStr = newStr.split(",");
		newStr = newStr.filter(function (str) {//used to remove the empty spaces(like empty value)
			str = str.trim();
			if (str) {
				return /\S/.test(str);
			}
		});
		newStr = newStr.map(function (el) {//used to clear the spaces of each array element
			return el.trim();
		});
		var payload = {
			"wavenbrs": newStr
		};

		$("#showloader").css("display", "block");
		var url = urlService.GET_WAVE_FAILURE_DETAILS;
		url = url.replace('dName', $scope.pagedc);
		url = url.replace('uName', sessionStorage.userName);
		url = url.replace('pNumber', $scope.pageNo);
		url = url.replace('pSize', $scope.pageSize);
		url = url.replace('wavenum', str_array);
		var headers = { headers: { 'x-api-key': sessionStorage.apikey } };
		commonService.getServiceResponse(url, headers)
			.then(
			function (d) {
				if (d.pageItems) {
					if (d.pageItems.length > 0) {
						$("#showloader").css("display", "none");
						$scope.isTable = true;
						$scope.isUpdate = true;
						$scope.gridOptions.data = d.pageItems;
						$scope.gridOptions.totalItems = d.totalNoOfRecords;

						$scope.gridOptions.columnDefs = [
							{ name: 'shipName', displayName: 'Ship Name', enableCellEdit: false, sort: { direction: uiGridConstants.ASC, priority: 1 }, cellTooltip: true, headerTooltip: true, width: 130 },
							{ name: 'pkt_ctrl_nbr', displayName: 'Pkt Ctrl Nbr', visible: false, enableCellEdit: false, cellTooltip: true, headerTooltip: true, width: 130 },
							{ name: 'shipAddr1', displayName: 'Ship Addr1', enableCellEdit: false, cellTooltip: true, headerTooltip: true, width: 130 },
							{ name: 'shipAddr2', displayName: 'Ship Addr2', enableCellEdit: false, cellTooltip: true, headerTooltip: true, visibility: false, width: 130 },
							{ name: 'shipAddr3', displayName: 'Ship Addr3', enableCellEdit: false, cellTooltip: true, headerTooltip: true, width: 170 },
							{ name: 'shipCity', displayName: 'Ship City', enableCellEdit: false, cellTooltip: true, headerTooltip: true, width: 140 },
							{ name: 'shipZip', displayName: 'Ship Zip', enableCellEdit: false, cellTooltip: true, headerTooltip: true, width: 128 },
							{ name: 'custNbr', displayName: 'Cust Nbr', enableCellEdit: false, width: 130, cellTooltip: true, headerTooltip: true, },
							{ name: 'soldName', displayName: 'Sold Name', enableCellEdit: false, width: 130, cellTooltip: true, headerTooltip: true, },
							{ name: 'soldAddr1', displayName: 'Sold Addr1', enableCellEdit: false, width: 120, cellTooltip: true, headerTooltip: true, },
							{ name: 'soldAddr2', displayName: 'Sold Addr2', enableCellEdit: false, visible: true, cellTooltip: true, width: 120, headerTooltip: true, },
							{ name: 'soldAddr3', displayName: 'Sold Addr3', enableCellEdit: false, width: 130, cellTooltip: true, headerTooltip: true, },
							{ name: 'soldCity', displayName: 'Sold City', enableCellEdit: false, width: 120, cellTooltip: true, headerTooltip: true, },
							{ name: 'soldZip', displayName: 'Sold Zip', enableCellEdit: false, width: 120, cellTooltip: true, headerTooltip: true, },
							{ name: 'splDesc', displayName: 'Spl Desc', enableCellEdit: false, visible: true, width: 120, cellTooltip: true, headerTooltip: true, },
							{ name: 'pkt_seq_nbr', displayName: 'Pkt seq Nbr', visible: false, enableCellEdit: false, cellTooltip: true, headerTooltip: true, width: 130 },
							{ name: 'spl_instr_nbr', displayName: 'Pkt instr Nbr', visible: false, enableCellEdit: false, cellTooltip: true, headerTooltip: true, width: 130 },
							{ name: 'ref_FIELD_2', displayName: 'Ref Field ', enableCellEdit: false, visible: true, width: 120, cellTooltip: true, headerTooltip: true, }
						];
					}

					if ($scope.gridOptions.data > 10) {
						$scope.gridOptions.enableVerticalScrollbar = true;

					} else {
						$scope.gridOptions.enableVerticalScrollbar = false;
						$scope.gridOptions.enableHorizontalScrollbar = 1;
					}
				} else if (d.resMessage) {
					$scope.isSuccess = true;
					$scope.isUpdate = true;
					$scope.resmessage = d.resMessage;
					$("#showloader").css("display", "none");
				} else {
					$scope.isFailed = true;
					$scope.isUpdate = true;
					$scope.resmessage = d.errorMessage;
					$("#showloader").css("display", "none");
				}
			},
			function (errResponse) {

				$scope.isFailed = true;
				$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
				$("#showloader").css("display", "none");
			}
			);
	};


	$scope.updateWaveDetails = function () {
		$scope.errorMessage = "";
		$scope.resmessage = "";
		$scope.isSuccess = false;
		$scope.isFailed = false;
		$scope.isUpdate = false;
		$("#showloader").css("display", "block");
		var url = urlService.UPDATE_Wave_FAILURE;
		var headers = { headers: { 'x-api-key': sessionStorage.apikey } };
		var postRecords = [];
		angular.forEach($scope.gridApi.selection.getSelectedRows(), function (data, index) {
			var records = {

				"custNbr": data.custNbr,
				"dcName": $scope.pagedc,
				"dsp_spNbr": data.dsp_spNbr,
				"pageNumber": data.pageNumber,
				"pageSize": data.pageSize,
				"pkt_ctrl_nbr": data.pkt_ctrl_nbr,
				"pkt_seq_nbr": data.pkt_seq_nbr,
				"spl_instr_nbr": data.spl_instr_nbr,
				"ref_FIELD_2": data.ref_FIELD_2,
				"shipAddr1": data.shipAddr1,
				"shipAddr2": data.shipAddr2,
				"shipAddr3": data.shipAddr3,
				"shipCity": data.shipCity,
				"shipName": data.shipName,
				"shipZip": data.shipZip,
				"soldAddr1": data.soldAddr1,
				"soldAddr2": data.soldAddr2,
				"soldAddr3": data.soldAddr3,
				"soldCity": data.soldCity,
				"soldName": data.soldName,
				"soldZip": data.soldZip,
				"spNbrs": data.spNbrs,
				"splDesc": data.splDesc,
				"userName": sessionStorage.userName
			};
			postRecords.push(records);
		});
		commonService.putServiceResponse(url, postRecords, headers)
			.then(
			function (d) {
				$("#showloader").css("display", "none");
				if (d.errorMessage) {

					$scope.isFailed = true;
					$scope.resmessage = d.errorMessage;
				} else if (d.resMessage) {

					$scope.getWaveNumberData();
					$scope.isSuccess = true;
					$scope.resmessage = d.resMessage;

				}
			},
			function (errResponse) {

				$scope.isFailed = true;
				$scope.resmessage = "System failed. Please try again or contact WAALOS Support";
				$("#showloader").css("display", "none");
			}
			);
	};


	//user favourites code starts
	$scope.addToFavourate = function (isClicked) {
		$("#showloader").css("display", "block");
		if (typeof isClicked !== "boolean") {
			commonService.postServiceResponse(urlService.GET_FAVOURITES, { "username": sessionStorage.userName })
				.then(function (response) {
					$("#showloader").css("display", "none");
					_.each(response, function (val, key) {
						if (val.funName == $scope.functionality && val.dcName == $scope.dcName) {
							$scope.isClicked = true;
						}
					});
				}, function (error) {
					$("#showloader").css("display", "none");
					$scope.isClicked = false;
				});
			//$scope.isClicked = ;
		} else {
			if (!$scope.isClicked) {
				commonService.postServiceResponse(urlService.ADD_FAVOURITE, { "username": sessionStorage.userName, "dcName": $scope.dcName, "funName": $scope.functionality })
					.then(function (response) {
						$("#showloader").css("display", "none");
						if (response.errorMessage) {
							$scope.isFavouriteAdded = false;
							$scope.isClicked = false;
							$scope.$broadcast('showAlert', ['']);
						} else {
							$scope.isClicked = true;
							$scope.isClicked = !isClicked;
							$scope.isFavouriteAdded = true;
							$scope.favouriteMsg = response.resMessage;
							$scope.$broadcast('ClickedOnFavourate', [$scope.dcName, $scope.functionality, $scope.isClicked]);
						}

					}, function (error) {
						$scope.isClicked = false;
						$("#showloader").css("display", "none");
					});
				$scope.isClicked = !isClicked;
			} else {
				$("#showloader").css("display", "none");
			}
		}

	};
	$scope.addToFavourate('load');
	//user favourites code ends
}]);
