var app = angular.module('KNAPPWMSInventorySync', ['ui.bootstrap', 'ngTouch', 'ui.grid', 'ui.grid.selection', 'ui.grid.pagination', 'ui.grid.exporter', 'ui.grid.autoResize']);

app.controller('KnappWmsInvSyncController', ['$scope', '$http', '$q', '$interval','$timeout','urlService', 'uiGridConstants','commonService', function ($scope, $http, $q, $interval,$timeout,urlService,uiGridConstants,commonService) {
 //$scope.isTable = true;
 $scope.isupdate = true;
 $scope.isSuccess = false;
 $scope.isFailed = false;
 $scope.isClicked = false;
 $scope.isCustom = true;
 $scope.keyVal = "";
 $scope.disable = true;
 $scope.connectionFlag = false;
 var pr = this;
 $scope.schedActive = "Y";
 $scope.custom = "custom";
 $scope.pagefunctionality = $scope.functionality;
 $scope.pagedc = $scope.dcName;
 $scope.schedType = ['TURNOFF','DAILY','WEEKLY','ADHOC'];
 $scope.startTime = ['00:00','00:30','01:00','01:30','02:00','02:30','03:00','03:30','04:00','04:30','05:00','05:30','06:00','06:30','07:00','07:30','08:00','08:30','09:00','09:30','10:00','10:30','11:00','11:30','12:00','12:30','13:00','13:30','14:00','14:30','15:00','15:30','16:00','16:30','17:00','17:30','18:00','18:30','19:00','19:30','20:00','20:30','21:00','21:30','22:00','22:30','23:00','23:30'];
 $("#showloader").css("display", "none");
 
   $scope.gridOptions = { 
    enableSorting: true,
    enableColumnMenus: false,
	  multiSelect:false,
    enableRowSelection: true,//we can remove it later no use  of this
    enableSelectAll: true,//we can remove it latgridOptionsTwoer no use  of this             
    enableCellEdit: false, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
    enableCellEditOnFocus: true // set any editable column to allow edit on focus
 
  };
  
     $scope.gridOptionsTwo = { 
    enableSorting: true,
    enableColumnMenus: false,
	  multiSelect:false,
    enableRowSelection: true,//we can remove it later no use  of this
    enableSelectAll: true,//we can remove it latgridOptionsTwoer no use  of this             
    enableCellEdit: false, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
    enableCellEditOnFocus: true // set any editable column to allow edit on focus
 
  };
  
/*      $scope.init = function () {
		 
		 if($scope.type == 'Start Date' || $scope.time =='Start Time')
		 {
			 $scope.disable = true;
		 }else{
			 $scope.disable = false;
		 }
	 } */
  
    $scope.gridOptions.onRegisterApi = function(gridApi){
    //set gridApi on scope
    $scope.gridApi = gridApi; 
	// $scope.getReplenshmentList();
	//$scope.getupdateData();
   
   };
   
       $scope.gridOptionsTwo.onRegisterApi = function(gridApi){
    //set gridApi on scope
    $scope.gridApi = gridApi; 
	// $scope.getReplenshmentList();
	//$scope.getupdateData();
   
   };
   
   
/*        $scope.navigateDown = function () {
        document.body.scrollTop = 500;
        document.documentElement.scrollTop = 500;
    };
    $scope.navigateTop = function () {
        document.body.scrollTop = 0;
        document.documentElement.scrollTop = 0;
    };	 */
   
   $scope.getupdateData = function () {
    $scope.isSuccess = false;
    $scope.isFailed = false;
    $("#showloader").css("display", "block");

    var url = urlService.INV_SYNC_JOB_STATS.replace('dName',$scope.pagedc);
    url = url.replace('uName',sessionStorage.userName);

    //var res = $http.get(url);
var res = $http.get(url, {
    headers: {'x-api-key': sessionStorage.apikey}
});
    res.success(function (data, status, headers, config) {
      $("#showloader").css("display", "none");
        if(data.jobRunning == "N" && data.jobActiveCnt =='0'){
          $scope.isupdate = false; 
			$scope.isCustom =true;
        }else if(data.jobRunning == "N" && data.jobActiveCnt !='0')
		{
		$scope.isupdate = true;
			$scope.isCustom =false;
		}
		else{
          $scope.isupdate = true;
		  $scope.isCustom =true;
        }
      if (data.errorMessage) {
        $scope.isFailed = true;
        $scope.resmessage = data.errorMessage;

      } else if (data.resMessage) {
					//$scope.isTable = true;
					$scope.isSuccess = true;
          $scope.resmessage = data.resMessage;
          //$scope.isupdate = true;
					
      }else {
		   $scope.gridOptions.columnDefs = [
/* 			{  name: 'masterId', displayName: 'Unique ID',  enableCellEdit: false, width: 100  ,cellClass: bgColor , sort: { direction: uiGridConstants.ASC, priority: 1 },  cellTooltip: true, headerTooltip: true,},
			//{ name: 'batchId', displayName: 'Batch ID',  enableCellEdit: false,cellTooltip: true, headerTooltip: true, width: 100 },
			{ name: 'jobrunId',displayName:'Task ID', enableCellEdit: false,cellTooltip: true, headerTooltip: true,width: 120,cellClass: bgColor },
 */			{ name: 'taskName', displayName: 'Activity Name',enableCellEdit: false,cellTooltip: true, headerTooltip: true, width: 330,cellClass: bgColor  },
			{ name: 'taskStatus', displayName: 'Status' ,enableCellEdit: false,cellTooltip: true, headerTooltip: true, width: 150 ,cellClass: bgColor},
			{ name: 'userName', displayName: 'User ID',enableCellEdit: false,cellTooltip: true, headerTooltip: true, width: 110,cellClass: bgColor },
			//{ name: 'region', displayName: 'DC',enableCellEdit: false,cellTooltip: true, headerTooltip: true,width: 60 ,cellClass: bgColor },
			{ name: 'comments', displayName: 'Comments' ,enableCellEdit: false,cellTooltip: true, headerTooltip: true ,width: 280 ,cellClass: bgColor },
			//{ name: 'createdDateTime', displayName: 'Task Created Time' ,enableCellEdit: false,cellTooltip: true, headerTooltip: true ,width: 140,cellClass: bgColor },
			{ name: 'startDateTime', displayName: 'Start Time' ,enableCellEdit: false,cellTooltip: true, headerTooltip: true ,width: 140 ,cellClass: bgColor },
			{ name: 'completedDateTime', displayName: 'End Time' ,enableCellEdit: false,cellTooltip: true, headerTooltip: true ,width: 140  ,cellClass: bgColor},
			//{  name: 'masterId', displayName: 'Run ID',  enableCellEdit: false, width: 90  ,cellClass: bgColor , sort: { direction: uiGridConstants.ASC, priority: 1 },  cellTooltip: true, headerTooltip: true,},
			//{ name: 'batchId', displayName: 'Batch ID',  enableCellEdit: false,cellTooltip: true, headerTooltip: true, width: 100 },
			//{ name: 'jobrunId',displayName:'Task ID', enableCellEdit: false,cellTooltip: true, headerTooltip: true,width: 120,cellClass: bgColor },

			//{ name: 'runJob', displayName: 'Action', width: 80, cellTemplate: '<div class="ui-grid-cell-contents" data-ng-disabled="isCustom" ng-click="grid.appScope.warningMessage()" data-ng-hide="checkFlag"><a >Re-Trigger</a></div>' }
		
   	  ];
	  
		   $scope.gridOptionsTwo.columnDefs = [
			{ name: 'masterRunId',displayName:'Unique ID', enableCellEdit: false,width: 120 , sort: { direction: uiGridConstants.ASC, priority: 1 },  cellTooltip: true, headerTooltip: true,},
			{ name: 'batchId', displayName: 'Batch ID',  enableCellEdit: false,cellTooltip: true, headerTooltip: true ,width: 100 },
			{ name: 'syncStartTime', displayName: 'Sync Start Time',enableCellEdit: false,cellTooltip: true, headerTooltip: true ,width: 150},
			{ name: 'syncEndTime', displayName: 'Sync End Time' ,enableCellEdit: false,cellTooltip: true, headerTooltip: true ,width: 150},
			{ name: 'isManual', displayName: 'Automated',enableCellEdit: false,cellTooltip: true, headerTooltip: true,width: 150},
			{ name: 'wmOriginalRecCnt', displayName: 'WM Original Count',enableCellEdit: false,cellTooltip: true, headerTooltip: true ,width: 150 },
			{ name: 'knappOriginalRecCnt', displayName: 'KNAPP Original Count' ,enableCellEdit: false,cellTooltip: true, headerTooltip: true,width: 150 },
			{ name: 'wmFinalRecCnt', displayName: 'WM Final Count' ,enableCellEdit: false,cellTooltip: true, headerTooltip: true,width: 150 },
			{ name: 'knappFinalRecCnt', displayName: 'KNAPP Final Count' ,enableCellEdit: false,cellTooltip: true, headerTooltip: true ,width: 150 },
			{ name: 'pixPositiveGenerated', displayName: 'Positive Pix' ,enableCellEdit: false,cellTooltip: true, headerTooltip: true ,width: 150},
			{ name: 'pixNegativeGenerated', displayName: 'Negative Pix' ,enableCellEdit: false,cellTooltip: true, headerTooltip: true ,width: 150},
			{ name: 'totalPix', displayName: 'Total Pix' ,enableCellEdit: false,cellTooltip: true, headerTooltip: true ,width: 150},
			{ name: 'wmNoAdj', displayName: 'WM No Adj' ,enableCellEdit: false,cellTooltip: true, headerTooltip: true,width: 150},
			{ name: 'wmSyncMinus', displayName: 'WM Sync Minus' ,enableCellEdit: false,cellTooltip: true, headerTooltip: true,width: 150 },
			{ name: 'wmSyncPlus', displayName: 'WM Sync Plus' ,enableCellEdit: false,cellTooltip: true, headerTooltip: true,width: 150 },
			{ name: 'knappNoAdj', displayName: 'KNAPP No Adj' ,enableCellEdit: false,cellTooltip: true, headerTooltip: true,width: 150},
			{ name: 'knappSyncMinus', displayName: 'KNAPP Sync Minus' ,enableCellEdit: false,cellTooltip: true, headerTooltip: true,width: 150},
			{ name: 'knappSyncPlus', displayName: 'KNAPP Sync Plus' ,enableCellEdit: false,cellTooltip: true, headerTooltip: true,width: 150},
			{ name: 'skuVariance', displayName: 'SKU Variance' ,enableCellEdit: false,cellTooltip: true, headerTooltip: true,width: 150}
			
			
		
   	  ];	  

        pr.isTable = true;
        //$scope.isupdate = false;
		$scope.schedulerActive = data.invSyncSchedulerStatsDto.schedulerActive; 
		$scope.schedulerType = data.invSyncSchedulerStatsDto.schedulerType; 
		$scope.scheduledBy = data.invSyncSchedulerStatsDto.scheduledBy; 
		$scope.nextRun = data.invSyncSchedulerStatsDto.nextRunDateTime; 
		$scope.gridOptions.data  = data.invSyncJobStatsDto;  
		//$scope.gridOptionsTwo.data  = data.invSyncBatchStatsDto; 
		$scope.batchGridOne=data.invSyncBatchStatsDto.batchgridOne;
		$scope.batchGridTwo=data.invSyncBatchStatsDto.batchgridTwo;
		$scope.batchGridThree=data.invSyncBatchStatsDto.batchgridThree;
		$scope.batchGridFour=data.invSyncBatchStatsDto.batchgridFour;
		pr.batchgridOnekeys = convertJsontoArray(data.invSyncBatchStatsDto.batchgridOne).keys;
		pr.batchgridOne = convertJsontoArray(data.invSyncBatchStatsDto.batchgridOne).values;
		pr.batchgridTwoDatakeys = convertJsontoArray(data.batchgridTwo).keys;
		pr.batchgridTwoDataValues = convertJsontoArray(data.batchgridTwo).values;
		pr.batchgridThreeDataKeys = convertJsontoArray(data.batchgridThree).keys;
		pr.batchgridThreeDataValues = convertJsontoArray(data.batchgridThree).values;	
		pr.batchgridFourDataKeys = convertJsontoArray(data.batchgridFour).keys;
		pr.batchgridFourDataValues = convertJsontoArray(data.batchgridFour).values;			
		
       //$scope.gridOptions.data = data.pageItems;
		
        if ($scope.gridOptions.data > 10) {
          $scope.gridOptions.enableVerticalScrollbar = true;
		  $scope.gridOptions.enableHorizontalScrollbar = 1;
        } else {
          $scope.gridOptions.enableVerticalScrollbar = false;
          $scope.gridOptions.enableHorizontalScrollbar = 1;
        }
        
	
      }
      $('.ui-grid-pager-control input').prop( "disabled", true );
    });
    res.error(function (data, status, headers, config) {
      $("#showloader").css("display", "none");
      $scope.isFailed = true;
      $scope.resmessage = "System failed. Please try again or contact WAALOS Support";

    });
  };

  $scope.getupdateData();
/*   
  $scope.checkFlag= function (taskStat) {
	  if(taskStat =='FAILED')
	  {
		  return true;
	  }
	  else{
		  return false;
	  }
  } */
  
    $scope.warningMessage = function () {
	$scope.isSuccess = false;
    $scope.isFailed = false;
		$("#addModel").modal('show');
		
	}
  $scope.open1 = function () {
    $scope.popup1.opened = true;
  };	
  
  $scope.setDate = function (year, month, day) {
    $scope.dt = new Date(year, month, day);
  };

  $scope.formats = ['dd-MMMM-yyyy', 'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate'];
  $scope.format = $scope.formats[0];
  $scope.altInputFormats = ['M!/d!/yyyy'];  
  
  
  $scope.dateOptions = {
    formatYear: 'yy',
    //maxDate : new Date(new Date().getTime()-(4*24*60*60*1000)),//new Date(),
    startingDay: 1
  };
  $scope.popup1 = {
    opened: false
  };  
  $scope.dt ="";	
  $scope.changedate = function(){

    $scope.isSuccess = false;
    $scope.isFailed = false;

    if( $scope.dt != "" && $scope.dt != undefined){
      /* $scope.disable = false; */
    }else{
      $scope.disable = true;
      $scope.isFailed = true; 
      $scope.resmessage = "Please enter current or past date only, in format [DD-Month-YYYY]";
    }
if($scope.dt){
var date = new Date();
var currentdate = date.getFullYear() + '-' + ('0' + (date.getMonth() + 1)).slice(-2) + '-' + ('0' + date.getDate()).slice(-2);
var actual = $scope.dt.getFullYear() + '-' + ('0' + ($scope.dt.getMonth() + 1)).slice(-2) + '-' + ('0' + $scope.dt.getDate()).slice(-2);
if(actual < currentdate){ $scope.disable = true; $scope.isFailed = true; 
        $scope.resmessage = "Please enter current or Future date only, in format [DD-Month-YYYY]"; }		
		
}
  };	
  
  $scope.changetime = function(){
	$scope.isSuccess = false;
    $scope.isFailed = false;  
	  
	var today = new Date();
	var currentdate = today.getFullYear() + '-' + ('0' + (today.getMonth() + 1)).slice(-2) + '-' + ('0' + today.getDate()).slice(-2);
	var actual = $scope.dt.getFullYear() + '-' + ('0' + ($scope.dt.getMonth() + 1)).slice(-2) + '-' + ('0' + $scope.dt.getDate()).slice(-2);	
	var hours = today.getHours();
	var minutes = today.getMinutes();
	var inputhours = $scope.time.split(":")[0];
	var inputminutes = $scope.time.split(":")[1];
	if(actual <= currentdate){
	if(inputhours <= hours)
	{
		if(inputminutes <= minutes){
			$scope.disable = true; $scope.isFailed = true; 
			$scope.resmessage = "Please enter current or Future time only";
		}
	}
	}
  };
  
  $scope.changeDisableFlag = function(){ 
/*   if($scope.type == 'SCHEDULER TYPE' || $scope.time =='Start Time' || $scope.type == undefined || $scope.time == undefined || $scope.dt == undefined || $scope.dt == 'Start Date'){
	  $scope.disable = true;
}if($scope.type == 'TURNOFF') {
	$scope.disable = false;
}
 else{
	$scope.disable = false;
} */
if($scope.type != 'SCHEDULER TYPE' && $scope.time !='Start Time' && $scope.time != undefined && $scope.dt != null && $scope.dt != 'Start Date' ){
	$scope.disable = false;
}else if($scope.type =='TURNOFF')
{
	$scope.disable = false;
}
else{
	$scope.disable = true;
}
};


    /** This function is used to save the Inventory Sync Scheduler Details **/
    $scope.saveInvSyncDetails = function() {
        $scope.isSuccess = false;
        $scope.isFailed = false;

	if($scope.type == 'TURNOFF')
	{
		$scope.schedActive = "N";
		$scope.actual = "";
		$scope.time = "";
		$scope.nextDate = "NA";
		$scope.dt = "";
	}else{
		$scope.schedActive = "Y";
		$scope.nextDate = $scope.dt.getFullYear() + '-' + ('0' + ($scope.dt.getMonth() + 1)).slice(-2) + '-' + ('0' + $scope.dt.getDate()).slice(-2)+ " " + $scope.time;
		$scope.dt = $scope.dt.getFullYear() + '-' + ('0' + ($scope.dt.getMonth() + 1)).slice(-2) + '-' + ('0' + $scope.dt.getDate()).slice(-2);
	}
		
        $("#showloader").css("display", "block");
        var payload = {
			"schedulerActive": $scope.schedActive,
            "schedulerType": $scope.type,
            "scheduledRunTime": $scope.time,
            "dcName": $scope.pagedc,
            "scheduledBy": sessionStorage.userName,
            "scheduledRunDate":$scope.dt ,
			"nextRunDateTime": $scope.nextDate
        };
        var res = $http.put(urlService.SAVE_INV_SYNC_DTLS, payload, {
            headers: { 'x-api-key': sessionStorage.apikey }
        });
        res.success(function(data, status, headers, config) {
            $("#showloader").css("display", "none");
            if (data.errorMessage) {
                $scope.isFailed = true;
                $scope.resmessage = data.errorMessage;
            } else {
                $scope.isSuccess = true;
                $scope.resmessage = data.resMessage;
				$scope.getupdateData();
            }
        });
        res.error(function(data, status, headers, config) {
            $("#showloader").css("display", "none");
            $scope.isFailed = true;
            $scope.resmessage = "System failed. Please try again or contact WAALOS Support";
        });
    };
	
    $scope.startMessage = function () {
	$scope.isSuccess = false;
    $scope.isFailed = false;
		$("#beginModel").modal('show');
		
	}	
  
   $scope.runJob = function (keyVal) {
	$scope.exeType=keyVal;

	$("#showloader").css("display", "block");
    $scope.resmessage = "";
    $scope.isSuccess = false;
    $scope.isFailed = false;
   // var region =  "DTC";
	
 
	
	var records = {
        "userName":sessionStorage.userName,
        "dcName": $scope.pagedc,
		"region":  "DTC",
		"key" : keyVal
	}
        
    

var res = $http.put(urlService.INV_SYNC_RUN_JOB, records, {
    headers: {'x-api-key': sessionStorage.apikey}
});
    res.success(function (data, status, headers, config) {

      $("#showloader").css("display", "none");
/* 	  if($scope.exeType == "custom")
	  {
	  $("#addModel").modal('show');
	  }else{
		  $("#addModel").modal('hide');
	  } */
	  $("#successModel").modal('show');
      if (data.errorMessage) {
        $scope.isFailed = true;
        $scope.resmessage = data.errorMessage;
      } else {
	    //$scope.isupdate = true;
		//$timeout(getupdateData, 3000)
		$scope.getupdateData();
	    $scope.isSuccess = true;
	    $scope.resmessage = data.resMessage;
		//$("#successModel").modal('show');
 		 }
    });
	
    res.error(function (data, status, headers, config) {
      $("#showloader").css("display", "none");
      $scope.isFailed = true;
      $scope.resmessage = data.replace(/(<([^>]+)>)/ig,"");
    });
  };   

 function bgColor(grid, row, col, rowRenderIndex, colRenderIndex) {
/*     if (row.entity.taskStatus === 'NOT STARTED') {
      return 'redbgnd';
    } */
    if (row.entity.taskStatus === 'COMPLETED') {
      return 'greenbgnd';
    }
	if(row.entity.taskStatus === 'MNL COMPLETED'){
		return 'bluebgnd';
	}	
	if(row.entity.taskStatus === 'FAILED'){
		return 'redbgnd';
	}	
	if(row.entity.taskStatus === 'IN PROGRESS'){
		return 'yellowbgnd';
	}

  }  
    $scope.init = function () {
        // check if there is query in url
        // and fire search in case its value is not empty

		 if($scope.type == 'Start Date' || $scope.time =='Start Time' || $scope.type == undefined || $scope.time == undefined )
		 {
			 $scope.disable = true;
		 }else{
			 $scope.disable = false;
		 }		
		
/*         if (row.entity.taskStatus= "FAILED") {
            $scope.checkFlag = true;
        }
        else {
             $scope.checkFlag = false;
        } */
    };  
	
   //user favourites code start
   $scope.addToFavourate = function(isClicked){
    $("#showloader").css("display", "block");
     if(typeof isClicked !== "boolean"){
      commonService.postServiceResponse(urlService.GET_FAVOURITES,{"username": sessionStorage.userName})
        .then(function(response){
          $("#showloader").css("display", "none");
            _.each(response,function(val,key){
              if(val.funName == $scope.functionality && val.dcName == $scope.dcName){
                $scope.isClicked = true;      
              }
            });
        },function(error){
          $("#showloader").css("display", "none");
          $scope.isClicked = false; 
        });
        
     }else{
      if(!$scope.isClicked){
        commonService.postServiceResponse(urlService.ADD_FAVOURITE,{"username": sessionStorage.userName,"dcName":$scope.dcName,"funName":$scope.functionality})
        .then(function(response){
          $("#showloader").css("display", "none");
          if(response.errorMessage){
            $scope.isFavouriteAdded= false; 
            $scope.isClicked = false;      
            $scope.$broadcast('showAlert',['']);
          }else{
            $scope.isClicked = true;      
            $scope.isClicked = !isClicked;
            $scope.isFavouriteAdded= true; 
            $scope.favouriteMsg = response.resMessage;
          $scope.$broadcast('ClickedOnFavourate',[$scope.dcName,$scope.functionality,$scope.isClicked]);
          }
            
        },function(error){
          $scope.isClicked = false;
          $("#showloader").css("display", "none");
        });
        $scope.isClicked = !isClicked;
      }else{
        $("#showloader").css("display", "none");
      }
     }
    
  };

	
	//function to seperate the keys and values from json as Object.values is not supproted in IE
	function convertJsontoArray(values) {
		var keyValues = {
			'keys': [],
			'values': []
		};
		if (values.length) {
			_.each(values, function (val, key) {
				_.each(val, function (val, key) {
					keyValues.keys.push(key);
					keyValues.values.push(val);
				});
			});
		} else {
			_.each(values, function (val, key) {
				keyValues.keys.push(key);
				keyValues.values.push(val);
			});
		}

		return keyValues;
	}  
  
  
  }]);
   
   