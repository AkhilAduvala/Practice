var app = angular.module('TroubleMarking');

app.controller('TroubleMarkingController', ['$scope', '$http', '$q', '$interval', '$timeout','urlService','uiGridConstants','commonService', function ($scope, $http, $q, $interval, $timeout,urlService,uiGridConstants,commonService) {
  $scope.isSuccess = false;
  $scope.isFailed = false;
  $scope.isEmpty = false;
  $scope.dataList = [];
  $scope.disable = true;
  $scope.cartonNumbersError = false;
  $scope.pagefunctionality = $scope.functionality;
  $scope.pagedc = $scope.dcName;
  $scope.response = "";

$("#Carton-Numbers").focus();
  $("#showloader").css("display", "none");


/**
	This function is used to call, when user press Enter button from the keyboard
**/
  $('#Carton-Numbers').keyup(function (e){
    if($scope.cartonNumbers &&  e.keyCode == 13){
	$scope.disable = false;
		console.log($scope.cartonNumbers);
        $scope.troubleMarking();
    }
  });
  
  
  /**
	This function is used to clear the input feild, when user press clear button from the UI
**/
  $scope.clearInput = function(){
      var getValue= document.getElementById("Carton-Numbers");
        if (getValue.value !="") {
            getValue.value = "";
			//$scope.form.$invalid = true;
        }
 }
  /**
	This function is used to estimate by sending the required data to backend
**/
  $scope.troubleMarking = function(){
	if($scope.form.$valid){
	$scope.isSuccess = false;
	$scope.isFailed = false;
	$("#showloader").css("display", "block");
  //var cartonNmbrs = $scope.cartonNumbers.split(/[ ,\n]/g);
	console.log($scope.cartonNumbers);
	var payload = {
		"cartonNumbers":$scope.cartonNumbers,
		"dcName":$scope.pagedc,
		"userName":sessionStorage.userName
	};
	console.log(payload);
	var res = $http.post(urlService.TROUBLE_MARKING,payload, {
		headers: {'x-api-key': sessionStorage.apikey} 
	});
	res.success(function (data, status, headers, config) {
	  $("#showloader").css("display", "none");
      $scope.response = data;
	    $scope.isSuccess = true;
	});
	res.error(function (data, status, headers, config) {
	  $("#showloader").css("display", "none");
		$scope.isFailed = true;
		$scope.response = "System failed. Please try again or contact WAALOS Support";
	});
	 }else{
		$scope.form.cartonNumbers.$setTouched(true);
	}
  };
//user favourites code start
$scope.isClicked = false;

$scope.addToFavourate = function(isClicked){
    $("#showloader").css("display", "block");
     if(typeof isClicked !== "boolean"){
      commonService.postServiceResponse(urlService.GET_FAVOURITES,{"username": sessionStorage.userName})
        .then(function(response){
          $("#showloader").css("display", "none");
            _.each(response,function(val,key){
              if(val.funName == $scope.functionality && val.dcName == $scope.dcName){
                $scope.isClicked = true;      
              }
            });
        },function(error){
          $("#showloader").css("display", "none");
          $scope.isClicked = false; 
        });
        //$scope.isClicked = ;
     }else{
      if(!$scope.isClicked){
        commonService.postServiceResponse(urlService.ADD_FAVOURITE,{"username": sessionStorage.userName,"dcName":$scope.dcName,"funName":$scope.functionality})
        .then(function(response){
          $("#showloader").css("display", "none");
          if(response.errorMessage){
            $scope.isFavouriteAdded= false; 
            $scope.isClicked = false;      
            $scope.$broadcast('showAlert',['']);
          }else{
            $scope.isClicked = true;      
            $scope.isClicked = !isClicked;
            $scope.isFavouriteAdded= true; 
            $scope.favouriteMsg = response.resMessage;
          $scope.$broadcast('ClickedOnFavourate',[$scope.dcName,$scope.functionality,$scope.isClicked]);
          }
            
        },function(error){
          $scope.isClicked = false;
          $("#showloader").css("display", "none");
        });
        $scope.isClicked = !isClicked;
      }else{
        $("#showloader").css("display", "none");
      }
     }
    
  };
  $scope.addToFavourate('load');
  //user favourites code ends

}]);