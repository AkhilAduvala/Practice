
'use strict';

// declare modules
angular.module('Authentication', []);
angular.module('Home', []);
angular.module('Common', []);
angular.module('DateChange', []);
angular.module('UserManage', ['ui.grid.pagination','ngAnimate', 'ui.grid', 'ui.grid.selection', 'ui.bootstrap','ui.grid.autoResize' ]);
angular.module('Cubiscan', []);
angular.module('HolidayExclusionCtrl', ['ngTouch', 'ngAnimate', 'ngSanitize', 'ui.bootstrap', 'ui.grid.validate', 'ui.grid.autoResize', 'ui.grid', 'ui.grid.edit', 'ui.grid.cellNav', 'ui.grid.selection', 'ui.grid.pagination', 'ui.grid.validate']);
angular.module('UserGroupManage', ['ngTouch', 'ui.grid', 'ui.grid.expandable', 'ui.grid.selection', 'ui.grid.pinning']);
angular.module('DimensionChanger', ['ngTouch', 'ui.grid', 'ui.grid.edit', 'ui.grid.cellNav', 'ui.grid.selection', 'ui.grid.pagination']);
angular.module('IPDisplay', ['ngAnimate', 'ui.grid', 'ui.grid.moveColumns', 'ui.grid.selection', 'ui.grid.cellNav', 'ui.grid.pagination', 'ui.grid.resizeColumns', 'ui.bootstrap', 'ui.grid.edit']);
angular.module('InputPKTCleaner', ['ui.grid', 'ui.grid.selection', 'ui.grid.edit', 'ui.grid.rowEdit', 'ui.grid.cellNav', 'ui.grid.pagination']);
angular.module('UnlockCart', ['ngTouch', 'ui.grid.validate', 'ui.grid.autoResize', 'ui.grid', 'ui.grid.edit', 'ui.grid.cellNav', 'ui.grid.selection', 'ui.grid.pagination', 'ui.grid.validate']);
angular.module('VirtualWareHouse',[]); 
angular.module('ManifestCarton', ['ngTouch', 'ui.grid', 'ui.grid.edit', 'ui.grid.cellNav','ui.grid.selection','ui.grid.pagination']);
angular.module('ImmediateNeedLoader', []);
angular.module('MassLoadNumberGenerator', []);
angular.module('PKTProfileLoader', []);
angular.module('PKTPDFArchive', ['ui.grid.autoResize', 'ui.grid']);
angular.module('BOLPackslip', ['ui.grid.autoResize', 'ui.grid']);
angular.module('DangerKill', ['ngTouch', 'ui.grid', 'ui.grid.edit', 'ui.grid.cellNav','ui.grid.selection','ui.grid.pagination','ui.grid.validate']);
angular.module('RetailReturnsLoader', ['ngTouch', 'ui.grid', 'ui.grid.edit', 'ui.grid.selection', 'ui.grid.pagination']);
angular.module('ManualSlotting',[]);
angular.module('massUpdateLoader',[]);
angular.module('customerLoader',[]);
angular.module('cubiscanConfigurator',[]);
angular.module('jobScheduler',[]);
angular.module('ManualSlotting',[]);
angular.module('LM-WMUserAddition', ['ngTouch', 'ui.grid', 'ui.grid.edit', 'ui.grid.cellNav','ui.grid.selection','ui.grid.pagination','ui.grid.validate']);
angular.module('WcswmInventorysync', ['ui.bootstrap','ngTouch', 'ui.grid', 'ui.grid.selection','ui.grid.pagination']);
angular.module('SlottingReports',['ui.bootstrap','ngTouch','ui.grid','ui.grid.selection','ui.grid.pagination']);
angular.module('OutboundPrepLoader',['ngTouch','ui.grid','ui.grid.edit','ui.grid.selection','ui.grid.pagination']);
angular.module('WmUserAddition', [ 'ui.grid.pagination','ngAnimate', 'ui.grid', 'ui.grid.selection', 'ui.bootstrap','ui.grid.autoResize' ]);
angular.module('AteSlotting', []);
angular.module('prewaveReport', ['ui.bootstrap', 'ngTouch', 'ui.grid', 'ui.grid.selection', 'ui.grid.pagination', 'ui.grid.exporter','ui.grid.autoResize']);
angular.module('AteTJSlotting', ['ui.bootstrap', 'ngTouch', 'ui.grid','ui.grid.edit','ui.grid.cellNav', 'ui.grid.selection','ui.grid.exporter']);
angular.module('Bgradelabeltool', ['ui.grid.autoResize', 'ngAnimate', 'ui.grid','ui.grid.pagination']);
angular.module('WaveBuddy', []);
angular.module('STOLabelCreator', []);
angular.module('FootLockerLabelReprint', []);
angular.module('LoadControl', [ 'ui.grid.pagination','ngAnimate', 'ui.grid', 'ui.grid.selection', 'ui.bootstrap','ui.grid.autoResize' ]);
angular.module('BGrade', []);
angular.module('UpdateCRD',[]);
angular.module('UserProfile', []);
angular.module('PickCartReprint', []);
angular.module('SupressEDI', ['ngTouch', 'ui.grid.validate', 'ui.grid.autoResize', 'ui.grid', 'ui.grid.edit', 'ui.grid.cellNav', 'ui.grid.selection', 'ui.grid.pagination', 'ui.grid.validate']);
angular.module('ArticleDimension', ['ngAnimate', 'ui.grid', 'ui.grid.selection',  'ui.grid.pagination', 'ui.grid.edit']);
angular.module('LocationCleanupBuddy', ['ui.bootstrap']);
angular.module('LocationUpdate', ['ngAnimate', 'ui.grid', 'ui.grid.selection',  'ui.grid.pagination','ui.grid.autoResize','ui.grid.exporter']);
angular.module('ReprintLPN', []);
angular.module('PrintToteLPN', []);
angular.module('SKUProfiling', []);
angular.module('PickByDate',['ui.bootstrap', 'ui.grid.expandable','ngTouch', 'ui.grid', 'ui.grid.selection', 'ui.grid.edit', 'ui.grid.autoResize', 'ui.grid.validate', 'ui.grid.exporter']);
angular.module('CommercialInvoice', ['ngTouch', 'ui.grid.autoResize', 'ui.grid', 'ui.grid.selection','ui.grid.resizeColumns','ui.grid.pagination']);
angular.module('WaveFailure', ['ngTouch', 'ui.grid.autoResize', 'ui.grid', 'ui.grid.selection','ui.grid.resizeColumns','ui.grid.pagination']);
angular.module('SortationWave', ['ngAnimate','ui.bootstrap', 'ui.multiselect','ui.grid', 'ui.grid.selection', 'ui.grid.pagination', 'ui.grid.autoResize', 'ui.grid.exporter']);
angular.module('LocationCleanup', ['ui.bootstrap']);
angular.module('InfoDcScript', ['ui.grid', 'ui.grid.selection', 'ui.grid.pagination']);
angular.module('DimUpdate', ['ngTouch', 'ui.grid', 'ui.grid.edit', 'ui.grid.cellNav','ui.grid.selection','ui.grid.pagination','ui.grid.validate']);
angular.module('SkuMarking', ['ui.bootstrap', 'ngTouch', 'ui.grid', 'ui.grid.pagination', 'daterangepicker','ui.grid.exporter']);
angular.module('BudgetCapacity', ['ngTouch', 'ui.grid', 'ui.grid.edit', 'ui.grid.cellNav', 'ui.grid.selection', 'ui.grid.validate', 'ui.grid.exporter']);
angular.module('DemandForecast',[]);
angular.module('PickTicketUpload', []);
angular.module('AppointmentFileUpload', []);
angular.module('AteSEASlotting', ['ui.bootstrap', 'ngTouch', 'ui.grid','ui.grid.edit','ui.grid.cellNav', 'ui.grid.selection','ui.grid.pagination']);
angular.module('ClearConsolidationLocations', ['ngAnimate', 'ui.grid', 'ui.grid.selection',  'ui.grid.pagination', 'ui.grid.edit']);
angular.module('ReplenishmentList', ['ngTouch', 'ui.grid', 'ui.grid.edit', 'ui.grid.cellNav','ui.grid.selection','ui.grid.pagination','ui.grid.validate']);
angular.module('CustomerSkuUpload', []);
angular.module('TrackingUpdate', []);
angular.module('EcomUpload', []);
angular.module('LoadPlanUpload', []);
angular.module('AutomatedSlotting', ['ui.bootstrap', 'ngTouch', 'ui.grid','ui.grid.edit','ui.grid.cellNav', 'ui.grid.selection']);
angular.module('InvoiceLoader', []);
angular.module('FreightTerms', []);
angular.module('TForce', []);
angular.module('WayBillSolution', []);
angular.module('ConsolidationLocationUpdate', []);
angular.module('HotPickBatch', []);
angular.module('PickTicketShipmentLoader', []);
angular.module('VasPickLocationAssignment', []);
angular.module('KNAPPWMSInventorySync', []);
angular.module('EcomCarrierRouteUpdate', []);
angular.module('PrioritizeReplen', []);
angular.module('ResubmitMessage', []);
angular.module('ASNLoader', []);
angular.module('DedicatedAttributeUpdate', []);
angular.module('SortBatchLoader', []);
angular.module('CancelSortBatch', ['ngAnimate', 'ui.grid', 'ui.grid.selection',  'ui.grid.pagination', 'ui.grid.edit']);
angular.module('OrderAddressUpdate', []);
angular.module('RoutingBuddy', []);
angular.module('PrinterConfiguration',[]);
angular.module('DeSlotItems',[]);
angular.module('ShipViaUpdate',['ui.bootstrap', 'ngTouch', 'ui.grid', 'ui.grid.selection', 'ui.grid.pagination', 'ui.grid.exporter','ui.grid.autoResize']);
angular.module('FedexCLTV',['ui.bootstrap', 'ngTouch', 'ui.grid', 'ui.grid.selection', 'ui.grid.pagination', 'ui.grid.exporter','ui.grid.autoResize']);
angular.module('UpdateThirdPartyBillingAddress',[]);
angular.module('KhtTool',[]); 
angular.module('EFCPalletLabel',[]);
angular.module('SequenceNumberUpdate',[]);
angular.module('PalletCountEstimator',[]);
angular.module('SortationRuleUpload', []);
angular.module('RemoveDedicatedKeyword', []);
angular.module('OrderBulkUpdateLoader',[]);
angular.module('LockUnlockShipmentLoader',[]);
angular.module('PriceTicketLoader', []);
angular.module('OrderProfileLoader', []);
angular.module('SorterBatchLoader', []);
angular.module('ItemBulkUpdateLoader',[]);
angular.module('CsvAutomation',[]);
angular.module('CTCWaveUpdate', []);
angular.module('SorterCleanUp',[]);
angular.module('TroubleMarking',[]);
angular.module('ASNDeliveryDateLoader',[]);
var waalos = angular.module('waalos', [
    'Authentication',
    'InfoDcScript',
    'DimUpdate',
    'ArticleDimension',
    'SortationWave',
    'LocationCleanupBuddy',
    'LocationCleanup',
    'CommercialInvoice',
    'WaveFailure',
    'PickByDate',
    'ReprintLPN',
    'PrintToteLPN',
    'LocationUpdate',
    'AteSlotting',
    'AteTJSlotting',
    'prewaveReport',
    'Home',
    'UserManage',
    'UserGroupManage',
    'DimensionChanger',
    'Common',
    'HolidayExclusion',
    'DateChange',
    'ngRoute',
    'ngCookies',
    'Cubiscan',
    'IPDisplay',
    'InputPKTCleaner',
    'UnlockCart',
    'VirtualWareHouse',
    'ManifestCarton',
    'ImmediateNeedLoader',
    'MassLoadNumberGenerator',
    'PKTProfileLoader',
    'PKTPDFArchive', 
    'BOLPackslip',
    'DangerKill',
    'RetailReturnsLoader',
    'ManualSlotting',
    'WcswmInventorysync', 
    'massUpdateLoader',
    'customerLoader',
    'cubiscanConfigurator',
    'jobScheduler',
    'LM-WMUserAddition',
    'ManualSlotting',
    'SlottingReports',
    'OutboundPrepLoader',
    'WmUserAddition',
    'Bgradelabeltool',
    'WaveBuddy',
    'STOLabelCreator',
    'FootLockerLabelReprint',
    'LoadControl',
    'BGrade',
    'UpdateCRD',
    'UserProfile',
    'PickCartReprint',
	'ReplenishmentList',
    'SupressEDI',
    'SKUProfiling',
    'SkuMarking',
	'BudgetCapacity',
	'DemandForecast',
	'PickTicketUpload',
    'ngRoute',
	'AppointmentFileUpload',
    'AteSEASlotting',
	'CustomerSkuUpload',
    'TrackingUpdate',
	'ClearConsolidationLocations',
    'EcomUpload',
    'LoadPlanUpload',
    'AutomatedSlotting',
	'InvoiceLoader',
	'FreightTerms',
	'TForce',
	'WayBillSolution',
	'ConsolidationLocationUpdate',
	'HotPickBatch',
	'PickTicketShipmentLoader',
	'VasPickLocationAssignment',
	'KNAPPWMSInventorySync',
	'EcomCarrierRouteUpdate',
	'PrioritizeReplen',
	'ResubmitMessage',
	'ASNLoader',
	'DedicatedAttributeUpdate',
	'SortBatchLoader',
	'CancelSortBatch',
	'OrderAddressUpdate',
	'RoutingBuddy',
	'PrinterConfiguration',
	'DeSlotItems',
	'ShipViaUpdate',
	'FedexCLTV',
	'UpdateThirdPartyBillingAddress',
	'KhtTool',
	'EFCPalletLabel',
	'SequenceNumberUpdate',
	'PalletCountEstimator',
	'SortationRuleUpload',
	'RemoveDedicatedKeyword',
	'OrderBulkUpdateLoader',
	'LockUnlockShipmentLoader',
	'PriceTicketLoader',
	'OrderProfileLoader',
	'SorterBatchLoader',
	'ItemBulkUpdateLoader',
	'CsvAutomation',
	'CTCWaveUpdate',
	'SorterCleanUp',
	'TroubleMarking',
	'ASNDeliveryDateLoader',
])

waalos.config(['$httpProvider', function($httpProvider) {
      //initialize get if not there
    if (!$httpProvider.defaults.headers.get) {
        $httpProvider.defaults.headers.get = {};    
    }    

    // Answer edited to include suggestions from comments
    // because previous version of code introduced browser-related errors

    //disable IE ajax request caching
    $httpProvider.defaults.headers.get['If-Modified-Since'] = 'Mon, 26 Jul 1997 05:00:00 GMT';
    // extra
    $httpProvider.defaults.headers.get['Cache-Control'] = 'no-cache';
    $httpProvider.defaults.headers.get['Pragma'] = 'no-cache';
	
	
}]);

waalos.config(['$routeProvider', '$locationProvider', function ($routeProvider, $locationProvider) {
 
        $routeProvider
            .when('/login', {

                templateUrl: 'components/authentication/views/login.html',
                controller: 'LoginController'
            })

            .when('/home', {

                templateUrl: 'components/home/views/home.html',
                controller: 'HomeController',
            })

            .when('/usermanagement', {

                templateUrl: 'components/userManagement/views/userManagement.html',
                controller: 'UserManageCtrl',
                controllerAs: 'vm'
            })

            .when('/usergroupmanagement', {

                templateUrl: 'components/userGroupManagement/views/userGroupManagement.html',
                controller: 'UserGroupManageController'
            })
	   .when('/userprofile', {
           
	       templateUrl: 'components/userprofile/views/userProfile.html',
               controller: 'UserProfileController'
            })

	  .when('/infodcScript', {
                templateUrl: 'components/infodcscript/views/infodcScript.html',
                controller: 'InfoDcScriptController'
             })
            .when('/home/:dc/DateChangeLoader', {

                templateUrl: 'components/dateChangeLoader/views/dateChangeLoader.html',
                controller: 'DateChangeController'
            })

            .when('/home/:dc/DimensionChanger', {

                templateUrl: 'components/dimensionChanger/views/dimensionChanger.html',
                controller: 'DimensionChangerCtrl'
            })

            .when('/home/:dc/IPGoalsChanger', {
                controller: 'IPDisplayMainCtrl',
                templateUrl: 'components/ipDisplay/views/ipDisplay.html'
            })
            .when('/home/:dc/InputPickTicketCleanup', {

                templateUrl: 'components/inputPKTCleaner/views/inputPKTCleaner.html',
                controller: 'InputPktCleanerController'
            })
            .when('/home/:dc/CubiscanLoader', {

                templateUrl: 'components/cubiscanLoader/views/cubiscanLoader.html',
                controller: 'CubiscanController'
            })
            .when('/home/:dc/HolidayExclusion', {

                templateUrl: 'components/holidayExclusion/views/holidayExclusion.html',
                controller: 'HolidayExclusionCtrl'
            })
			.when('/home/:dc/ReplenishmentList', {
                controller: 'replenishmentListController',
                templateUrl: 'components/replenishmentList/views/replenishmentList.html'
            })
            .when('/home/:dc/PickCartUnlock', {

                templateUrl: 'components/unlockCart/views/unlockCart.html',
                controller: 'UnlockCartCtrl'
            })
            .when('/home/:dc/VirtualWarehouse', {
                
                templateUrl: 'components/virtualwarehouse/views/virtualwarehouse.html',
                controller: 'VirtualWarehouseCtrl'
            }) 
            .when('/home/:dc/ManifestCartonRemove', {
                controller: 'ManifestCartController',
                templateUrl: 'components/manifestCarton/views/manifestCarton.html'
            })
            .when('/home/:dc/ImmediateNeedsLoader', {
                controller: 'ImmediateNeedLoaderController',
                templateUrl: 'components/immediateNeedLoader/views/immediateNeedLoader.html'
            })
            .when('/home/:dc/MassLoadGenerator', {
                controller: 'MassLoadNumberGeneratorController',
                templateUrl: 'components/massLoadNumberGenerator/views/massLoadNumberGenerator.html'
            })
            .when('/home/:dc/PickTicketProfileLoader', {
                controller: 'PKTProfileLoaderController',
                templateUrl: 'components/pktProfileLoader/views/pktProfileLoader.html'
            })
            .when('/home/:dc/PickTicketPDFArchive', {
                controller: 'PKTPDFArchiveController',
                templateUrl: 'components/pktPDFArchive/views/pktPDFArchive.html'
            })
             .when('/home/:dc/BOLPackslip', {
                controller: 'BOLPackslipController',
                templateUrl: 'components/bolPackslip/views/bolPackslip.html'
            })
            .when('/home/:dc/DangerKill', {
                controller: 'DangerKillController',
                templateUrl: 'components/dangerKill/views/dangerKill.html'
            })
            .when('/home/:dc/RetailReturnsLoader', {
                controller: 'retailReturnsLoaderController',
                templateUrl: 'components/retailReturnsLoader/views/retailReturnsLoader.html'
            })
            .when('/home/:dc/AutomatedSlotting-SZ', {
                controller: 'AteSlottingCtrl',
                templateUrl: 'components/ateSlotting/views/ateSlotting.html'
            })
 	     .when('/home/:dc/PreWaveReport', {
                templateUrl: 'components/prewaveReport/views/prewaveReport.html',
                controller: 'prewaveReportCtrl',
                controllerAs: 'pr'
            })
            .when('/home/:dc/AutomatedSlotting-TJ', {
                controller: 'AteTJSlottingCtrl',
                templateUrl: 'components/ateTJSlotting/views/ateTJSlotting.html'
            })
            .when('/home/:dc/ManualSlotting', {
                controller: 'ManualSlottingController',
                templateUrl: 'components/manualSlotting/views/manualSlotting.html'
            })
            .when('/home/:dc/WCS-WMInventorySync', {
                controller: 'WcswmInventorysyncCtrl',
                templateUrl: 'components/wcswmInventorysync/views/wcswmInventorysync.html'
            })
            .when('/home/:dc/MassUpdateLoader', {
                controller: 'massUpdateLoaderController',
                templateUrl: 'components/massUpdateLoader/views/massUpdateLoader.html',
                controllerAs: 'mul'
            })
            .when('/home/:dc/CustomerLoader', {
                templateUrl: 'components/customerLoader/views/customerLoader.html',
                controller: 'customerLoaderController'
            })
            .when('/home/:dc/CubiscanConfigurator', {
                templateUrl: 'components/cubiscanConfigurator/views/cubiscanConfigurator.html',
                controller: 'cubiscanConfiguratorController',
                controllerAs: 'cc'
            })
            .when('/home/:dc/JobScheduler', {
                templateUrl: 'components/jobScheduler/views/jobScheduler.html',
                controller: 'jobSchedulerController',
                controllerAs: 'js'
            })
            .when('/home/:dc/LM-WMUserAddition', {
                controller: 'LM-WMUserAdditionController',
                templateUrl: 'components/lmwmUserAddition/views/lmwmUserAddition.html'
            })
	     .when('/home/:dc/SlottingReports', {
                templateUrl:'components/slottingReports/views/slottingReports.html',
                controller:'slottingReportsController',
                controllerAs:'sr'
            }) 
		.when('/home/:dc/ManualSlotting', {
                controller: 'ManualSlottingController',
                templateUrl: 'components/manualSlotting/views/manualSlotting.html'
            })
             .when('/home/:dc/OutboundPrepLoader', {
                controller:'OutboundPrepLoaderCtrl',
                templateUrl:'components/outboundPrepLoader/views/outboundPrepLoader.html'
            })
 		.when('/home/:dc/WMUserAddition', {
                controller: 'WmUserAdditionCtrl',
                templateUrl: 'components/wmUserAddition/views/wmUserAddition.html',
                controllerAs: 'vm'
            })
            .when('/home/:dc/WaveBuddy', {
		controller: 'WaveBuddyController',
		templateUrl: 'components/waveBuddy/views/waveBuddy.html'
	    })

		.when('/home/:dc/STOLabelCreator', {
			controller: 'STOLabelCreatorController',
			templateUrl: 'components/stoLabelCreator/views/stoLabelCreator.html'
		})
		.when('/home/:dc/FootlockerLabelReprint', {
			controller: 'FootLockerController',
			templateUrl: 'components/footLockerLabelReprint/views/footLockerLabelReprint.html'
		})

		.when('/home/:dc/PickCart-Reprint', {
			controller: 'PickCartReprintController',
			templateUrl: 'components/pickCartReprint/views/pickCartReprint.html'
		})
		.when('/home/:dc/Suppress-EDI', {
			controller: 'SupressEDIController',
			templateUrl: 'components/supressEDI/views/supressEDI.html'
		})

	      .when('/home/:dc/B-GradeLabelTool', {
                controller: 'BgradelabeltoolCtrl',
                templateUrl: 'components/bgradelabeltool/views/B-GradeLabelTool.html',
                
            })
	   
		.when('/home/:dc/LoadControl', {
                controller: 'LoadControlCtrl',
                templateUrl: 'components/loadControl/views/loadControl.html',
                
            })
 		.when('/bgrade', {
                controller: 'BGradeController',
                templateUrl: 'components/bgrade/views/bGrade.html'
            })
		.when('/home/:dc/UpdateCRD', {
                controller: 'UpdateCRDController',
                templateUrl: 'components/updateCrd/views/updateCrd.html'
            })
               .when('/home/:dc/ArticleDimension', {
                controller: 'ArticleDimensionCtrl',
                templateUrl: 'components/articleDimension/views/articledimension.html',
                
            })
		
               .when('/home/:dc/LocationCleanupBuddy', {
                controller: 'LocationCleanupBuddyCtrl',
                templateUrl: 'components/locationCleanupBuddy/views/locationcleanup.html',
                
            })
	
	      .when('/home/:dc/LocationUpdate', {
                controller: 'LocationUpdateController',
                templateUrl: 'components/locationUpdate/views/locationUpdate.html'
            })
		.when('/home/:dc/Reprint-LPN', {
			controller: 'ReprintLPNController',
			templateUrl: 'components/rePrintLPN/views/rePrintLPN.html'
		})
		.when('/home/:dc/Print-Tote-LPN', {
			controller: 'PrintToteLPNController',
			templateUrl: 'components/printToteLPN/views/printToteLPN.html'
		})
		.when('/home/:dc/SKUProfiling', {
			controller: 'SKUProfilingController',
			templateUrl: 'components/skuProfiling/views/skuProfiling.html'
		})
              .when('/home/:dc/PickByDate', {
                controller: 'PickByDateController',
                templateUrl: 'components/pickByDate/views/pickByDate.html'
            })
           .when('/home/:dc/IPCommercialInvoice', {
                controller: 'CommercialInvoiceController',
                templateUrl: 'components/iPCommercialInvoice/views/commercialInvoice.html'
            })

            .when('/home/:dc/WaveFailure', {
                controller: 'WaveFailureController',
                templateUrl: 'components/waveFailure/views/waveFailure.html'
            })
 	   .when('/home/:dc/SortationWave', {
                controller: 'SortationWaveController',
                templateUrl: 'components/sortationWave/views/sortationwave.html'
            })
           .when('/home/:dc/LocationCleanup', {
                controller: 'LocationCleanupCtrl',
                templateUrl: 'components/locationCleanup/views/locationcleanup.html',
                
            })
           .when('/home/:dc/DimUpdate', {
                controller: 'DimUpdateController',
                templateUrl: 'components/dimUpdate/views/dimUpdate.html'
            })
           .when('/home/:dc/SKUMarking', {
                controller: 'SkuMarkingController',
                templateUrl: 'components/skuMarking/views/skuMarking.html'
            })
			.when('/home/:dc/DemandForecast', {
				controller: 'DemandForecastController',
				templateUrl: 'components/demandForecast/views/demandForecast.html'
			})
			.when('/home/:dc/BudgetCapacity', {
				controller: 'BudgetCapacityController',
				templateUrl: 'components/budgetCapacity/views/budgetCapacity.html'
			})
            .when('/home/:dc/AutomatedSlotting', {
                controller: 'SeaSlottingCtrl',
                templateUrl: 'components/ateSEASlotting/views/ateSeaSlotting.html'
            })
			.when('/home/:dc/AppointmentFileUpload', {
                templateUrl: 'components/appointmentFileUpload/views/appointmentFileUpload.html',
                controller: 'ApptFileUploadController'
            })
            .when('/home/:dc/TrackingUpdate', {

                templateUrl: 'components/trackingUpdate/views/trackingUpdate.html',
                controller: 'TrackingUpdateController'
            })
			.when('/home/:dc/ClearConsolidationLocations', {
				controller: 'ClearConsolidationLocationsCtrl',
                templateUrl: 'components/clearConsolidationLocations/views/clearConsolidationLocations.html'
			})
			.when('/home/:dc/PickTicketUpload', {
			controller: 'PickTicketUploadController',
			templateUrl: 'components/pickTicketUpload/views/pickTicketUpload.html'
		})	
           .when('/home/:dc/CustomerSKUUpload', {
                templateUrl: 'components/customerSkuUpload/views/customerSkuUpload.html',
                controller: 'CustomerSkuUploadController'
            })
            .when('/home/:dc/ECOMUpload', {
                templateUrl: 'components/ecomUpload/views/ecomUpload.html',
                controller: 'EcomUploadController'
            })
            .when('/home/:dc/LoadPlanUpload', {
                templateUrl: 'components/loadPlanUpload/views/loadPlanUpload.html',
                controller: 'LoadPlanUploadController'
            })
            .when('/home/:dc/AutomatedSlotting-New', {
                controller: 'AutomatedSlottingCtrl',
                templateUrl: 'components/ateSlottingNew/views/ateSlottingSz.html'
            })
			.when('/home/:dc/TForce', {
				controller: 'TForceCtrl',
                templateUrl: 'components/tForce/views/tForce.html'
			})
			.when('/home/:dc/InvoiceLoader', {
				controller: 'InvoiceLoaderdController',
				templateUrl: 'components/invoiceLoader/views/invoiceLoader.html'
			})
			.when('/home/:dc/FreightTerms', {
				controller: 'FreightTermsController',
				templateUrl: 'components/freightTerms/views/freightTerms.html'
			})


		.when('/home/:dc/WayBillSolution', {
                templateUrl: 'components/wayBillSolution/views/wayBillSolution.html',
                controller: 'WayBillSolutionController'
         })
		 .when('/home/:dc/HotPickBatch', {
				controller: 'HotPickBatchController',
				templateUrl: 'components/hotPickBatch/views/hotPickBatch.html'
			})	
		.when('/home/:dc/PickTicketShipmentLoader', {
				controller: 'PickTicketShipmentController',
				templateUrl: 'components/pickTicketShipmentLoader/views/pickTicketShipmentLoader.html'
			})
		.when('/home/:dc/ConsolidationLocationUpdate', {
				controller: 'ConsolidationLocationUpdateController',
				templateUrl: 'components/consolidationLocationUpdate/views/consolidationLocationUpdate.html'
			})
		.when('/home/:dc/VasPickLocationAssignment', {
				controller: 'VasPickLocationAssignmentController',
				templateUrl: 'components/vasPickLocationAssignment/views/vasPickLocationAssignment.html'
			})	
			.when('/home/:dc/KNAPP-WMSInventorySync', {
				controller: 'KnappWmsInvSyncController',
				templateUrl: 'components/knappWmsInvSync/views/knappWmsInvSync.html'
			})	
			.when('/home/:dc/EcomCarrierRouteUpdate', {
				controller: 'EcomCarrierRouteUpdateController',
				templateUrl: 'components/ecomCarrierRouteUpdate/views/ecomCarrierRouteUpdate.html'
			})
			.when('/home/:dc/PrioritizeReplen', {
				controller: 'PrioritizeReplenController',
				templateUrl: 'components/prioritizeReplen/views/prioritizeReplen.html'
			})	
			.when('/home/:dc/ResubmitMessage', {
				controller: 'ResubmitMessageController',
				templateUrl: 'components/resubmitMessage/views/resubmitMessage.html'
			})			
			.when('/home/:dc/ASNLoader', {
				controller: 'AsnLoaderController',
				templateUrl: 'components/asnLoader/views/asnLoader.html'
			})	
			.when('/home/:dc/DedicatedAttributeUpdate', {
				controller: 'DedicatedAttributeUpdateController',
				templateUrl: 'components/dedicatedAttributeUpdate/views/dedicatedAttributeUpdate.html'
			})	
			.when('/home/:dc/SortBatchLoader', {
				controller: 'SortBatchLoaderController',
				templateUrl: 'components/sortBatchLoader/views/sortBatchLoader.html'
			})	
			.when('/home/:dc/CancelSortBatch', {
				controller: 'CancelSortBatchCtrl',
				templateUrl: 'components/cancelSortBatch/views/cancelSortBatch.html'
			})	
			.when('/home/:dc/OrderAddressUpdate', {
				controller: 'OrderAddressUpdateController',
				templateUrl: 'components/orderAddressUpdate/views/orderAddressUpdate.html'
			})	
			.when('/home/:dc/RoutingBuddy', {
				controller: 'RoutingBuddyController',
				templateUrl: 'components/routingBuddy/views/routingBuddy.html'
			})		
			.when('/home/:dc/PrinterConfiguration', {
				controller: 'PrinterConfigurationController',
				templateUrl: 'components/printerConfiguration/views/printerConfiguration.html'
			})	
			.when('/home/:dc/De-SlotItems', {
				controller: 'DeSlotItemsController',
				templateUrl: 'components/deSlotItems/views/deSlotItems.html'
			})	
			.when('/home/:dc/ShipViaUpdate', {
				controller: 'ShipViaUpdateController',
				templateUrl: 'components/shipViaUpdate/views/shipViaUpdate.html',
				controllerAs: 'pr'
				
			})
			.when('/home/:dc/FEDEXCLTV', {
				controller: 'FedexCLTVController',
				templateUrl: 'components/fedexCltv/views/fedexCltv.html',
				controllerAs: 'pr'
				
			})	
			.when('/home/:dc/UpdateThirdPartyBillingAddress', {
				controller: 'UpdateThirdPartyBillingAddressController',
				templateUrl: 'components/updateThirdPartyBillingAddress/views/updateThirdPartyBillingAddress.html'
			})	
			.when('/home/:dc/KHTTool', {
				controller: 'KhtToolController',
				templateUrl: 'components/khtTool/views/khtTool.html'
			})		
			.when('/home/:dc/EFC-PalletLabel', {
				controller: 'EFCPalletLabelController',
				templateUrl: 'components/efcPalletLabel/views/efcPalletLabel.html',
				controllerAs: 'pr'
			
			})
			.when('/home/:dc/SequenceNumberUpdate', {
				controller: 'SequenceNumberUpdateController',
				templateUrl: 'components/sequenceNumberUpdate/views/sequenceNumberUpdate.html',
				controllerAs: 'pr'
			})
			.when('/home/:dc/PalletCountEstimator', {
				controller: 'PalletCountEstimatorController',
				templateUrl: 'components/palletCountEstimator/views/palletCountEstimator.html',
				controllerAs: 'pr'
			})
			.when('/home/:dc/SortationRuleUpload', {
				controller: 'SortationRuleUploadController',
				templateUrl: 'components/sortationRuleUpload/views/sortationRuleUpload.html'
			})
			.when('/home/:dc/RemoveDEDICATEDKeyword', {
				controller: 'RemoveDedicatedKeywordController',
				templateUrl: 'components/removeDedicatedKeyword/views/removeDedicatedKeyword.html'
			})
			.when('/home/:dc/OrderBulkUpdateLoader', {
				controller: 'OrderBulkUpdateLoaderController',
                templateUrl: 'components/orderBulkUpdateLoader/views/orderBulkUpdateLoader.html'
			})
			.when('/home/:dc/Lock-UnlockShipmentLoader', {
				controller: 'LockUnlockShipmentLoaderController',
                templateUrl: 'components/lockUnlockShipmentLoader/views/lockUnlockShipmentLoader.html'
			})
			.when('/home/:dc/PriceTicketLoader', {
				controller: 'PriceTicketLoaderController',
				templateUrl: 'components/priceTicketLoader/views/priceTicketLoader.html'
			})
			.when('/home/:dc/OrderProfileLoader', {
				controller: 'OrderProfileLoaderController',
                templateUrl: 'components/orderProfileLoader/views/orderProfileLoader.html'
			})
			.when('/home/:dc/SorterBatchLoader', {
				controller: 'SorterBatchLoaderController',
				templateUrl: 'components/sorterBatchLoader/views/sorterBatchLoader.html'
			})
			.when('/home/:dc/ItemBulkUpdateLoader', {
				controller: 'ItemBulkUpdateLoaderController',
                templateUrl: 'components/itemBulkUpdateLoader/views/itemBulkUpdateLoader.html'
			})
			.when('/home/:dc/CSVAutomation',{
				controller: 'CsvAutomationController',
				templateUrl: 'components/csvAutomation/views/CsvAutomation.html'	
			})
			.when('/home/:dc/CTCWaveUpdate',{
				controller: 'CTCWaveUpdateController',
				templateUrl: 'components/ctcWaveUpdate/views/ctcWaveUpdate.html'
			})
			.when('/home/:dc/SorterCleanUP',{
				controller: 'SorterCleanUpController',
				templateUrl: 'components/sorterCleanup/views/sorterCleanup.html'				
			})
			.when('/home/:dc/TroubleMarking', {
				controller: 'TroubleMarkingController',
				templateUrl: 'components/troubleMarking/views/troubleMarking.html',
				controllerAs: 'pr'
			})
			.when('/home/:dc/ASNDeliveryDateLoader', {
				controller: 'AsndeldateController',
				templateUrl: 'components/asndeldateload/views/asndelfile.html',
				controllerAs: 'pr'
			})
            .otherwise({ redirectTo: '/login' });
    }])

    waalos.run(['$rootScope', '$location', '$cookieStore', '$http',
        function ($rootScope, $location, $cookieStore, $http) {


            // keep user logged in after page refresh
            $rootScope.globals = $cookieStore.get('globals') || {};
            if ($rootScope.globals.currentUser) {
                $http.defaults.headers.common['Authorization'] = 'Basic ' + $rootScope.globals.currentUser.authdata; // jshint ignore:line
                $("#showloader").css("display", "none");
                 $location.path('/home');
            }
 
        $rootScope.$on('$locationChangeSuccess', function() {
                if ($location.path() !== '/login' && !$rootScope.globals.currentUser) {
                    $location.path('/login');
                }else{
                    $rootScope.actualLocation=$location.path();
                    var dc_fun_name = $rootScope.actualLocation.split('/');
                    $rootScope.$broadcast('DrpValues',[dc_fun_name[2],dc_fun_name[3]]);
                    $location.path($rootScope.actualLocation);
                }
                
            }); 
			

        }]);

