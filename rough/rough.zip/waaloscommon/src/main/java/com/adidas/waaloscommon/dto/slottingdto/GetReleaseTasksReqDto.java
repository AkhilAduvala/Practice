/*
 * Copyright (C) 2017 adidas AG.
 */
package com.adidas.waaloscommon.dto.slottingdto;

import lombok.Data;

/**
 * The persistent class for Ate Sz Slotting Data sources.
 * 
 */
@Data
public class GetReleaseTasksReqDto {
	private String grpType;
	private String wrkZone;
	private String wrkType;
	private String aisles;
}
