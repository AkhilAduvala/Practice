package com.adidas.waaloscommon.dto.prewavereportdto;

import lombok.Data;

@Data
public class WavePlanEstCubingDto {
	 private String pickTicket;
	 private int numOfPkts;
	 private String estCartons;
	 private String estRepacks;
	 private String estVol;
	 private String estWt;
	 private String estShipVia;
	 private String appApparel;
	 private String ftwApparelPreSort;
	 private String blkPAtoWAPallets;
	 private String ftwFootwear;
}

