package com.adidas.waaloscommon.dto.reportsdto;

import lombok.Data;

@Data
public class NoOfLocationsUsedAfterSlotDto {
	private String locationId;
	private int noOfLocationsUsedAfterSlot;
	private String wrkGrp;
}
