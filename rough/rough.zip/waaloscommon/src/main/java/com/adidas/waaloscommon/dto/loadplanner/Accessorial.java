package com.adidas.waaloscommon.dto.loadplanner;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Accessorial
{
    private String Is_Approved;

    private String Accessorial_Code;

    private String Accessorial_Cost;

    private String Payee;

    private String Accessorial_Datasource_Value;

    public String getIs_Approved ()
    {
        return Is_Approved;
    }

    @XmlElement(name = "Is_Approved", required = true, nillable = true)
    public void setIs_Approved (String Is_Approved)
    {
        this.Is_Approved = Is_Approved;
    }

    public String getAccessorial_Code ()
    {
        return Accessorial_Code;
    }
    
    @XmlElement(name = "Accessorial_Code", required = true, nillable = true)
    public void setAccessorial_Code (String Accessorial_Code)
    {
        this.Accessorial_Code = Accessorial_Code;
    }

    public String getAccessorial_Cost ()
    {
        return Accessorial_Cost;
    }

    @XmlElement(name = "Accessorial_Cost", required = true, nillable = true)
    public void setAccessorial_Cost (String Accessorial_Cost)
    {
        this.Accessorial_Cost = Accessorial_Cost;
    }

    public String getPayee ()
    {
        return Payee;
    }

    @XmlElement(name = "Payee", required = true, nillable = true)
    public void setPayee (String Payee)
    {
        this.Payee = Payee;
    }

    public String getAccessorial_Datasource_Value ()
    {
        return Accessorial_Datasource_Value;
    }

    @XmlElement(name = "Accessorial_Datasource_Value", required = true, nillable = true)
    public void setAccessorial_Datasource_Value (String Accessorial_Datasource_Value)
    {
        this.Accessorial_Datasource_Value = Accessorial_Datasource_Value;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Is_Approved = "+Is_Approved+", Accessorial_Code = "+Accessorial_Code+", Accessorial_Cost = "+Accessorial_Cost+", Payee = "+Payee+", Accessorial_Datasource_Value = "+Accessorial_Datasource_Value+"]";
    }
}