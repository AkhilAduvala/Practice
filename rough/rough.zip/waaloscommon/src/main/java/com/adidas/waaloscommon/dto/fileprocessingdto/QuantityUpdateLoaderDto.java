package com.adidas.waaloscommon.dto.fileprocessingdto;

import lombok.Data;

@Data
public class QuantityUpdateLoaderDto {
	private Integer rowNum;
	private String displayLocation;
	private String pickLocationSequenceNumber;
	private String itemName;
	private String itemDescription;
	private String maximumInventoryQty;
	private String maximumInventoryILPNs;
	private String std;
	private String errorType;
	private String errorMessage;	

	
	
}
