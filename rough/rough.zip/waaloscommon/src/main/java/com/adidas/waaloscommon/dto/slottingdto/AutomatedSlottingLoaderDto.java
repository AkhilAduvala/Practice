package com.adidas.waaloscommon.dto.slottingdto;

import lombok.Data;

@Data
public class AutomatedSlottingLoaderDto {
	private Integer rowNum;
	private String articleNumber;
	private String sizeDesc;
	private Integer qty;
	private Integer stdCaseQty;
	private String errorType;
	private String errorMessage;
	public Integer getRowNum() {
		return rowNum;
	}
	public void setRowNum(Integer rowNum) {
		this.rowNum = rowNum;
	}
	public String getArticleNumber() {
		return articleNumber;
	}
	public void setArticleNumber(String articleNumber) {
		this.articleNumber = articleNumber;
	}
	public String getSizeDesc() {
		return sizeDesc;
	}
	public void setSizeDesc(String sizeDesc) {
		this.sizeDesc = sizeDesc;
	}
	public Integer getQty() {
		return qty;
	}
	public void setQty(Integer qty) {
		this.qty = qty;
	}
	public Integer getStdCaseQty() {
		return stdCaseQty;
	}
	public void setStdCaseQty(Integer stdCaseQty) {
		this.stdCaseQty = stdCaseQty;
	}
	public String getErrorType() {
		return errorType;
	}
	public void setErrorType(String errorType) {
		this.errorType = errorType;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	
	
	
	
}
