package com.adidas.waaloscommon.dto.loadplanner;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Critical_Change_Attributes
{
    private String[] Changed_Attribute;

    public String[] getChanged_Attribute ()
    {
        return Changed_Attribute;
    }

    @XmlElement(name = "Changed_Attribute", required = true, nillable = true)
    public void setChanged_Attribute (String[] Changed_Attribute)
    {
        this.Changed_Attribute = Changed_Attribute;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Changed_Attribute = "+Changed_Attribute+"]";
    }
}
