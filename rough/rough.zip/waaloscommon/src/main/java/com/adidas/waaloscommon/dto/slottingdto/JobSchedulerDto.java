package com.adidas.waaloscommon.dto.slottingdto;

import lombok.Data;

@Data
public class JobSchedulerDto {

	private String hostName;
	private String userName;
	private String password;
}
