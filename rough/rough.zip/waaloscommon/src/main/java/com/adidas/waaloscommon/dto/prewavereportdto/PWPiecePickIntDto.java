package com.adidas.waaloscommon.dto.prewavereportdto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


import lombok.Data;

@Data
@JsonIgnoreProperties( { "piecePick" ,"channel","int2"})
public class PWPiecePickIntDto {

	private String brand;	
	private String channel;
	private int piecePick;
	private int int2;
	private int ppWhlslCount;
	private int ppRtlCount;
	private int ppWhlsVasCount;
	private int ppWhlsNonVasCount;
	private int ppEcomCount;
	private int int2WhlslCount;
	private int int2WhlsVasCount;
	private int int2WhlsNonVasCount;
	private int int2RtlCount;
	private int int2EcomCount;
	
}
