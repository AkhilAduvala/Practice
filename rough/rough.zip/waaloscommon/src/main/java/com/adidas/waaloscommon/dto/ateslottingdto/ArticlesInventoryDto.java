package com.adidas.waaloscommon.dto.ateslottingdto;

import java.util.List;

import lombok.Data;

@Data
public class ArticlesInventoryDto {

	
	private String articleNo;
	private List<LocationInventorySnapShotDto> inventoryDtoList;
	private Integer pickLocationQty;
	private String workGroup;
	
}
