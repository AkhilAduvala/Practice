/*
 * Copyright (C) 2017 adidas AG.
 */
package com.adidas.waaloscommon.dto.slottingdto;

import lombok.Data;

/**
 * The persistent class for Pkt Pdf Archive.
 * 
 */
@Data
public class PktPdfArchiveResponseDto {

	private String pktCtrlNbr;
	private String shipTo;
	private String soldTo;
	private String shipToCntry;
	private String pdfType;
	private String whse;
	private String custPoNbr;
	private String planLoadNbr;
	private String createDateTime;
	private String pathName;
	private String pathId;
}
