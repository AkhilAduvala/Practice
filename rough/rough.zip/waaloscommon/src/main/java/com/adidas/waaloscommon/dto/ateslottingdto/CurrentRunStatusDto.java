package com.adidas.waaloscommon.dto.ateslottingdto;

import lombok.Data;

@Data
public class CurrentRunStatusDto {

	long lotId;
	int statusCode;
	String statusDesc;
}
