package com.adidas.waaloscommon.dto.reportsdto;

import lombok.Data;

@Data
public class AvgSkuPerStylePostDto {
	private String locationId;
	private Double avgSkuPerStylePost;
	private String wrkGrp;
}
