package com.adidas.waaloscommon.dto.slottingdto;

import com.adidas.waaloscommon.dto.wmsdto.ErrorDto;

import lombok.Data;

@Data
public class AutomatedSlottingLoaderErrorDto {
	private ErrorDto errorDto;
	private AutomatedSlottingLoaderDto automatedSlottingLoaderDto;
	

}
