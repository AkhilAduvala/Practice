package com.adidas.waaloscommon.dto.ateslottingdto;

import java.math.BigDecimal;

import lombok.Data;

@Data
public class MoveListDto {

	private String skuId;
	private String dspSku;
	private String fromLocnId;
	private String toLocnId;
	private Integer quantity;
	private String zoneType;
	private String zoneValue;
	private String slottingType;
	private Long lotId;
	private String fromZone;
	private String division;
	private BigDecimal stdCaseQty;
	private BigDecimal totCases;
}
