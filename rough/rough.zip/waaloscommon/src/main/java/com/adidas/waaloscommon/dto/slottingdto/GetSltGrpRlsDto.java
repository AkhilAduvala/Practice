/*
 * Copyright (C) 2017 adidas AG.
 */
package com.adidas.waaloscommon.dto.slottingdto;

import lombok.Data;

/**
 * The persistent class for Ate Sz Slotting Data sources.
 * 
 */
@Data
public class GetSltGrpRlsDto {
	private String dcName;
	private String userName;
	private String grpType; 
	private String grpAttr;
	private String userId; 
	private String createDateTime; 
	private String modDateTime; 
	private String statCode; 
	private String useFixAmount; 
	private String pctFull; 
	private String needDereslot; 
	private String spillOrder; 
	private String daysTillSlot; 
	private String kitType; 
	private String kitUserType; 
	private String kitValue; 
	private String deslotToReserve; 
	private String deslotToResvValue; 
	private String deslotToZone; 
	private String prodTypes; 
	private String prodGroups; 
	private String cartonTypes; 
	private String putwyTypes; 
	private String allowKitBreak; 
	private String lockInPlace; 
	private String seasonYr; 
	private String slotType; 
	private String slotTypeRegion; 
	private String deslotZero; 
	private String prodSubGroups; 
	private String saBusSeg; 
	private String reslotLimits;
	private String fillLocations;
	private String noOfCases;
}
