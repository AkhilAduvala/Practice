package com.adidas.waaloscommon.dto.prewavereportdto;

import lombok.Data;

@Data
public class PWDimIssuesDto {
	 private String pick_wave_nbr; 
	 private String pickticket; 
	 private String dsp_sku; 
	 private String season; 
	 private String style; 
	 private String style_sfx; 
	 private String color; 
	 private String color_sfx; 
	 private String size_desc; 
	 private String oper_code; 
	 private String sku_brcd; 
	 private String unit_ht; 
	 private String unit_len; 
	 private String unit_width; 
	 private String unit_wt; 
	 private String unit_vol; 
	 private String std_case_ht; 
	 private String std_case_len; 
	 private String std_case_width; 
	 private String std_case_vol; 
	 private String std_case_wt; 
	 private String std_case_qty; 
	 private String std_plt_qty;
}

