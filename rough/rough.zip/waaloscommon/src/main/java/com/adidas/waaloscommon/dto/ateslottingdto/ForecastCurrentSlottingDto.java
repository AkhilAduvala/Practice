package com.adidas.waaloscommon.dto.ateslottingdto;

import java.util.ArrayList;
import java.util.List;

import lombok.Data;

@Data
public class ForecastCurrentSlottingDto {

	private Long lotId;
	private String userName;
	private String dcName;
	private Integer unSlottedSkuCount = 0;
	private Integer slottedSkuCount = 0;
	List<SlottedSkuInfoDto> slottedSkuInfoDto = new ArrayList<SlottedSkuInfoDto>();
	List<UnSlottedSkuInfoDto> unSlottedSkuInfoDto = new ArrayList<UnSlottedSkuInfoDto>();
	List<String> reSlottedSkuInfo = new ArrayList<String>();
	boolean slottingValid = false;
	 
}
