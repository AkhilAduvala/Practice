package com.adidas.waaloscommon.dto.prewavereportdto;

import java.util.Map;

import lombok.Data;

@Data
public class PWIntSumDto {
	private String pickCntrlNbr;
	private String int2Sum;
	private String excessSum;
	private String shipVia;
	private String codeDesc;
}

