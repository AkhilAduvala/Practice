package com.adidas.waaloscommon.dto.slottingdto;

import lombok.Data;

@Data
public class RejectQueueDto {

	private String dsp_sku;
	private String article;
	private String article_location;
	private String comments;
	private String sno;
	
}
