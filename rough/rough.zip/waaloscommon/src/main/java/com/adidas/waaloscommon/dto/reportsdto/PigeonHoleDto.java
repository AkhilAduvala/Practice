package com.adidas.waaloscommon.dto.reportsdto;

import lombok.Data;

@Data
public class PigeonHoleDto {

	private String dspSku;
	private String dspLocation;
}
