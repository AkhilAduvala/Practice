package com.adidas.waaloscommon.dto.prewavereportdto;

import java.util.List;

import lombok.Data;

@Data
public class OneWMPrewaveDataResDto {
	private String dcName;
	private List<OneWMPrewaveDto> prewaveDatalst;

}
