/*
 * Copyright (C) 2017 adidas AG.
 */
package com.adidas.waaloscommon.dto.slottingdto;

import lombok.Data;

/**
 * The persistent class for Ate Sz Slotting Data sources.
 * 
 */
@Data
public class GetSltGrpDtlsDto {
private String slotGrp;
private String totLocnd;
private String distZones;
private String hasRules;
private String priority;
private String lockInPlace;
private String pctFull;
private String daysTillSlot;
private String prodtypes;
private String prodGrps;
private String cartonTypes;
private String putwyTypes;
private String seasonYr;
private String prodSubGrps;
private String saBusSeg;
}
