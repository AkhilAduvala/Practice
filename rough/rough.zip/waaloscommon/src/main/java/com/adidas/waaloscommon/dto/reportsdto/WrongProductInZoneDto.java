package com.adidas.waaloscommon.dto.reportsdto;

import lombok.Data;

@Data
public class WrongProductInZoneDto {

	private String template;
	private String dspSku;
	private String dspLocation;
}
