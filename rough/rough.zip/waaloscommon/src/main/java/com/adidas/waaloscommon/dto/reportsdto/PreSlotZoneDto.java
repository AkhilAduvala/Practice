package com.adidas.waaloscommon.dto.reportsdto;

import lombok.Data;

@Data
public class PreSlotZoneDto {

	private String zone;
	private String workGroup;
	private int totalLocations;
	private int noOfUsedLocations;
	private int noOfEmptyLocations;
	private int utilizationBeforeSlot;
	private int noOfArticles;
	private Double avgSizeOfKits;
	private Double avgSkuPerArticle;
	private int maxForecastCaseQty;
	private int minForecastCaseQty;	
	private int reslotsOut;
	private int reslotsIn;
	private int deslotsOut;
	private int newSlots;
	private int noOfLocationsUsedAfterSlot;
	private int noOfEmptyAfterSlot;
	private int utilizationAfterSlot;	
	private Double avgSkuPerStylePost;
}
