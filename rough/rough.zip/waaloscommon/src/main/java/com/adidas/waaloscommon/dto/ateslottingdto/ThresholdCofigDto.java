package com.adidas.waaloscommon.dto.ateslottingdto;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode
public class ThresholdCofigDto extends BaseDto{
	Integer thresholdValue;

}
