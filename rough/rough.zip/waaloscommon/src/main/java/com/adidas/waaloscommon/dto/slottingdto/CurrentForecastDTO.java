package com.adidas.waaloscommon.dto.slottingdto;

import lombok.Data;

@Data
public class CurrentForecastDTO {
	private String skuIdent;
    private String articleNum;
    private String shipUnit;
    private String skuForActQty;
    private String estSkuHits;
    private String si4;
    private String si5;
    private String brandCode;
    private String division;
    private String launchDate;
    private String createDateTime;
    private String userId;
    private String modDateTime;
    private String statCode;
    private String skuId;
    private String stdCaseQty;
	

}
