package com.adidas.waaloscommon.dto.prewavereportdto;

import lombok.Data;

@Data
public class PWMapKeysDto {
	private String shipViaKey;
	private String codeDescKey;
}

