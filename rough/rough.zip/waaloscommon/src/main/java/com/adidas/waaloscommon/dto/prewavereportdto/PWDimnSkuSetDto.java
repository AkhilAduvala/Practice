package com.adidas.waaloscommon.dto.prewavereportdto;

import java.util.List;
import java.util.Set;

import lombok.Data;

@Data
public class PWDimnSkuSetDto {

	private List<PWDimIssuesDto> dimData ; 
	private Set skuSet;
	
}

