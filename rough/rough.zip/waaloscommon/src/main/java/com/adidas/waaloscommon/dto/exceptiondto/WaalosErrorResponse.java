package com.adidas.waaloscommon.dto.exceptiondto;

import lombok.Data;

@Data
public class WaalosErrorResponse {
	private int errorCode;
	private String message;
}
