package com.adidas.waaloscommon.dto.ateslottingdto;

import java.util.List;

import lombok.Data;
@Data
public class AisleDto {

	List<LocationInventorySnapShotDto> shelfLocations;
	List<LocationInventorySnapShotDto> palletLocations;
}
