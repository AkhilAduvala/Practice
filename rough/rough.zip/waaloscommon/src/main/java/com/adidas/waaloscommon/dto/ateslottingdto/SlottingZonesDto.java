/*
 * Copyright (C) 2017 adidas AG.
 */
package com.adidas.waaloscommon.dto.ateslottingdto;

import lombok.Data;

/**
 * The persistent class for Ate Sz Slotting Data sources.
 * 
 */
@Data
public class SlottingZonesDto extends BaseDto
{
			private String zone;
			private String zoneType;
			private Integer priority;

}
