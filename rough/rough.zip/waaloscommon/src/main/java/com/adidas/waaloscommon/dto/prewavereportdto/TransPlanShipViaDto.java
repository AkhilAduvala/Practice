package com.adidas.waaloscommon.dto.prewavereportdto;

import lombok.Data;

@Data
public class TransPlanShipViaDto {
	 private String shipToCntry;
	 private String estShipVia;
	 private String billShipVia;
	 private String estCartons;
	 private String estVol;
	 private String estWt;
}

