package com.adidas.waaloscommon.dto.loadplanner;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Shipment_With_Full_Orders {
	
	private String Product_Class_Code;

	private String Is_Cancelled;

	private String Is_Perishable;

	private Stop[] Stop;

	private String Bill_To_Title;

	private String Bill_To_Postal_Code;

	private String Commodity_Code;

	private String Radial_Distance_Provided;

	private String Origin_Port;

	private Loading_Method Loading_Method;

	private String Designated_Service_Level;

	private String Assigned_Service_Level;

	private String Feasible_Equipment_Code;

	private String Designated_Tractor_Code;

	private String External_System_Shipment_ID;

	private String Assigned_Mode_Code;

	private String Monetary_Value;

	private String Actual_Cost;

	private String Tender_Response_Due;

	private String BOL_Number;

	private String Distance;

	private String Trailer_Gen_Code;

	private String Distances_Provided;

	private Order[] Order;

	private String Designated_Driver_Type;

	private String Tender_Date;

	private String Route_Type_Code;

	private String Bill_To_Street_Address;

	private String Shipment_Status;

	private String Designated_Mode_Code;

	private String Bill_To_Phone;

	private String Authorization_Nbr;

	private String Wave;

	private String Spot_Charge;

	private String Purchase_Order;

	private String Status_Change_DTTM;

	private String Business_Unit;

	private String Assigned_CMID;

	private String Trailer_Number;

	private String Num_Docks;

	private String Business_Partner_Code;

	private String Hub_ID;

	private String Budgeted_Cost;

	private String TC_Shipment_ID;

	private String Bill_To_City;

	private String Designated_Equipment_Code;

	private String Broker_Carrier_Code;

	private String Reference_Number;

	private String Routing_Info;

	private String Shipper_ID;

	private Accessorial[] Accessorial;

	private String Merchandizing_Department;

	private String Protection_Level_Code;

	private String PRO_Number;

	private String Direct_Distance;

	private String Is_Hazmat;

	private String Num_Stops;

	private String Tractor_Number;

	private String Out_Of_RouteMiles;

	private String Last_Updated_Source;

	private String Assigned_CM_Shipment_ID;

	private String Broker_Reference;

	private String Destination_Port;

	private String Radial_Distance;

	private String Bill_To_State_Prov;

	private String Assigned_Carrier_Code;

	private String Bill_To_Name;

	private String Commodity_Size;

	private Critical_Change_Attributes Critical_Change_Attributes;

	private String Designated_Carrier_Code;

	private String Seal_Number;

	private String Assigned_Equipment_Code;

	private String Cons_Address_Code;

	private String Feasible_Tractor_Code;

	private String Feasible_Driver_Type;

	private String Routing_Ship_W_Control_Nbr;

	private String WMS_Status;

	private String Bill_To_Country_Code;

	private String Currency_Code;

	private String Ship_Group_ID;

	private String Last_Updated_DTTM;

	private String Last_Updated_Source_Type_Value;

	public String getProduct_Class_Code() {
		return Product_Class_Code;
	}

	@XmlElement(name = "Product_Class_Code", required = true, nillable = true)
	public void setProduct_Class_Code(String Product_Class_Code) {
		this.Product_Class_Code = Product_Class_Code;
	}

	public String getIs_Cancelled() {
		return Is_Cancelled;
	}

	@XmlElement(name = "Is_Cancelled", required = true, nillable = true)
	public void setIs_Cancelled(String Is_Cancelled) {
		this.Is_Cancelled = Is_Cancelled;
	}

	public String getIs_Perishable() {
		return Is_Perishable;
	}
	@XmlElement(name = "Is_Perishable", required = true, nillable = true)
	public void setIs_Perishable(String Is_Perishable) {
		this.Is_Perishable = Is_Perishable;
	}

	public Stop[] getStop() {
		return Stop;
	}
	@XmlElement(name = "Stop", required = true, nillable = true)
	public void setStop(Stop[] Stop) {
		this.Stop = Stop;
	}

	public String getBill_To_Title() {
		return Bill_To_Title;
	}
	@XmlElement(name = "Bill_To_Title", required = true, nillable = true)
	public void setBill_To_Title(String Bill_To_Title) {
		this.Bill_To_Title = Bill_To_Title;
	}

	public String getBill_To_Postal_Code() {
		return Bill_To_Postal_Code;
	}
	@XmlElement(name = "Bill_To_Postal_Code", required = true, nillable = true)
	public void setBill_To_Postal_Code(String Bill_To_Postal_Code) {
		this.Bill_To_Postal_Code = Bill_To_Postal_Code;
	}

	public String getCommodity_Code() {
		return Commodity_Code;
	}
	@XmlElement(name = "Commodity_Code", required = true, nillable = true)
	public void setCommodity_Code(String Commodity_Code) {
		this.Commodity_Code = Commodity_Code;
	}

	public String getRadial_Distance_Provided() {
		return Radial_Distance_Provided;
	}

	@XmlElement(name = "Radial_Distance_Provided", required = true, nillable = true)
	public void setRadial_Distance_Provided(String Radial_Distance_Provided) {
		this.Radial_Distance_Provided = Radial_Distance_Provided;
	}

	public String getOrigin_Port() {
		return Origin_Port;
	}

	@XmlElement(name = "Origin_Port", required = true, nillable = true)
	public void setOrigin_Port(String Origin_Port) {
		this.Origin_Port = Origin_Port;
	}

	public Loading_Method getLoading_Method() {
		return Loading_Method;
	}

	@XmlElement(name = "Loading_Method", required = true, nillable = true)
	public void setLoading_Method(Loading_Method Loading_Method) {
		this.Loading_Method = Loading_Method;
	}

	public String getDesignated_Service_Level() {
		return Designated_Service_Level;
	}

	@XmlElement(name = "Designated_Service_Level", required = true, nillable = true)
	public void setDesignated_Service_Level(String Designated_Service_Level) {
		this.Designated_Service_Level = Designated_Service_Level;
	}

	public String getAssigned_Service_Level() {
		return Assigned_Service_Level;
	}

	@XmlElement(name = "Assigned_Service_Level", required = true, nillable = true)
	public void setAssigned_Service_Level(String Assigned_Service_Level) {
		this.Assigned_Service_Level = Assigned_Service_Level;
	}

	public String getFeasible_Equipment_Code() {
		return Feasible_Equipment_Code;
	}

	@XmlElement(name = "Feasible_Equipment_Code", required = true, nillable = true)
	public void setFeasible_Equipment_Code(String Feasible_Equipment_Code) {
		this.Feasible_Equipment_Code = Feasible_Equipment_Code;
	}

	public String getDesignated_Tractor_Code() {
		return Designated_Tractor_Code;
	}

	@XmlElement(name = "Designated_Tractor_Code", required = true, nillable = true)
	public void setDesignated_Tractor_Code(String Designated_Tractor_Code) {
		this.Designated_Tractor_Code = Designated_Tractor_Code;
	}

	public String getExternal_System_Shipment_ID() {
		return External_System_Shipment_ID;
	}

	@XmlElement(name = "External_System_Shipment_ID", required = true, nillable = true)
	public void setExternal_System_Shipment_ID(String External_System_Shipment_ID) {
		this.External_System_Shipment_ID = External_System_Shipment_ID;
	}

	public String getAssigned_Mode_Code() {
		return Assigned_Mode_Code;
	}

	@XmlElement(name = "Assigned_Mode_Code", required = true, nillable = true)
	public void setAssigned_Mode_Code(String Assigned_Mode_Code) {
		this.Assigned_Mode_Code = Assigned_Mode_Code;
	}

	public String getMonetary_Value() {
		return Monetary_Value;
	}

	@XmlElement(name = "Monetary_Value", required = true, nillable = true)
	public void setMonetary_Value(String Monetary_Value) {
		this.Monetary_Value = Monetary_Value;
	}

	public String getActual_Cost() {
		return Actual_Cost;
	}

	@XmlElement(name = "Actual_Cost", required = true, nillable = true)
	public void setActual_Cost(String Actual_Cost) {
		this.Actual_Cost = Actual_Cost;
	}

	public String getTender_Response_Due() {
		return Tender_Response_Due;
	}

	@XmlElement(name = "Tender_Response_Due", required = true, nillable = true)
	public void setTender_Response_Due(String Tender_Response_Due) {
		this.Tender_Response_Due = Tender_Response_Due;
	}

	public String getBOL_Number() {
		return BOL_Number;
	}
	@XmlElement(name = "BOL_Number", required = true, nillable = true)
	public void setBOL_Number(String BOL_Number) {
		this.BOL_Number = BOL_Number;
	}

	public String getDistance() {
		return Distance;
	}

	@XmlElement(name = "Distance", required = true, nillable = true)
	public void setDistance(String Distance) {
		this.Distance = Distance;
	}

	public String getTrailer_Gen_Code() {
		return Trailer_Gen_Code;
	}

	@XmlElement(name = "Trailer_Gen_Code", required = true, nillable = true)
	public void setTrailer_Gen_Code(String Trailer_Gen_Code) {
		this.Trailer_Gen_Code = Trailer_Gen_Code;
	}

	public String getDistances_Provided() {
		return Distances_Provided;
	}

	@XmlElement(name = "Distances_Provided", required = true, nillable = true)
	public void setDistances_Provided(String Distances_Provided) {
		this.Distances_Provided = Distances_Provided;
	}

	public Order[] getOrder() {
		return Order;
	}

	@XmlElement(name = "Order", required = true, nillable = true)
	public void setOrder(Order[] Order) {
		this.Order = Order;
	}

	public String getDesignated_Driver_Type() {
		return Designated_Driver_Type;
	}

	@XmlElement(name = "Designated_Driver_Type", required = true, nillable = true)
	public void setDesignated_Driver_Type(String Designated_Driver_Type) {
		this.Designated_Driver_Type = Designated_Driver_Type;
	}

	public String getTender_Date() {
		return Tender_Date;
	}

	@XmlElement(name = "Tender_Date", required = true, nillable = true)
	public void setTender_Date(String Tender_Date) {
		this.Tender_Date = Tender_Date;
	}

	public String getRoute_Type_Code() {
		return Route_Type_Code;
	}

	@XmlElement(name = "Route_Type_Code", required = true, nillable = true)
	public void setRoute_Type_Code(String Route_Type_Code) {
		this.Route_Type_Code = Route_Type_Code;
	}

	public String getBill_To_Street_Address() {
		return Bill_To_Street_Address;
	}

	@XmlElement(name = "Bill_To_Street_Address", required = true, nillable = true)
	public void setBill_To_Street_Address(String Bill_To_Street_Address) {
		this.Bill_To_Street_Address = Bill_To_Street_Address;
	}

	public String getShipment_Status() {
		return Shipment_Status;
	}

	@XmlElement(name = "Shipment_Status", required = true, nillable = true)
	public void setShipment_Status(String Shipment_Status) {
		this.Shipment_Status = Shipment_Status;
	}

	public String getDesignated_Mode_Code() {
		return Designated_Mode_Code;
	}

	@XmlElement(name = "Designated_Mode_Code", required = true, nillable = true)
	public void setDesignated_Mode_Code(String Designated_Mode_Code) {
		this.Designated_Mode_Code = Designated_Mode_Code;
	}

	public String getBill_To_Phone() {
		return Bill_To_Phone;
	}

	@XmlElement(name = "Bill_To_Phone", required = true, nillable = true)
	public void setBill_To_Phone(String Bill_To_Phone) {
		this.Bill_To_Phone = Bill_To_Phone;
	}

	public String getAuthorization_Nbr() {
		return Authorization_Nbr;
	}

	@XmlElement(name = "Authorization_Nbr", required = true, nillable = true)
	public void setAuthorization_Nbr(String Authorization_Nbr) {
		this.Authorization_Nbr = Authorization_Nbr;
	}

	public String getWave() {
		return Wave;
	}

	@XmlElement(name = "Wave", required = true, nillable = true)
	public void setWave(String Wave) {
		this.Wave = Wave;
	}

	public String getSpot_Charge() {
		return Spot_Charge;
	}

	@XmlElement(name = "Spot_Charge", required = true, nillable = true)
	public void setSpot_Charge(String Spot_Charge) {
		this.Spot_Charge = Spot_Charge;
	}

	public String getPurchase_Order() {
		return Purchase_Order;
	}

	@XmlElement(name = "Purchase_Order", required = true, nillable = true)
	public void setPurchase_Order(String Purchase_Order) {
		this.Purchase_Order = Purchase_Order;
	}

	public String getStatus_Change_DTTM() {
		return Status_Change_DTTM;
	}

	@XmlElement(name = "Status_Change_DTTM", required = true, nillable = true)
	public void setStatus_Change_DTTM(String Status_Change_DTTM) {
		this.Status_Change_DTTM = Status_Change_DTTM;
	}

	public String getBusiness_Unit() {
		return Business_Unit;
	}

	@XmlElement(name = "Business_Unit", required = true, nillable = true)
	public void setBusiness_Unit(String Business_Unit) {
		this.Business_Unit = Business_Unit;
	}

	public String getAssigned_CMID() {
		return Assigned_CMID;
	}

	@XmlElement(name = "Assigned_CMID", required = true, nillable = true)
	public void setAssigned_CMID(String Assigned_CMID) {
		this.Assigned_CMID = Assigned_CMID;
	}

	public String getTrailer_Number() {
		return Trailer_Number;
	}

	@XmlElement(name = "Trailer_Number", required = true, nillable = true)
	public void setTrailer_Number(String Trailer_Number) {
		this.Trailer_Number = Trailer_Number;
	}

	public String getNum_Docks() {
		return Num_Docks;
	}

	@XmlElement(name = "Num_Docks", required = true, nillable = true)
	public void setNum_Docks(String Num_Docks) {
		this.Num_Docks = Num_Docks;
	}

	public String getBusiness_Partner_Code() {
		return Business_Partner_Code;
	}

	@XmlElement(name = "Business_Partner_Code", required = true, nillable = true)
	public void setBusiness_Partner_Code(String Business_Partner_Code) {
		this.Business_Partner_Code = Business_Partner_Code;
	}

	public String getHub_ID() {
		return Hub_ID;
	}

	@XmlElement(name = "Hub_ID", required = true, nillable = true)
	public void setHub_ID(String Hub_ID) {
		this.Hub_ID = Hub_ID;
	}

	public String getBudgeted_Cost() {
		return Budgeted_Cost;
	}

	@XmlElement(name = "Budgeted_Cost", required = true, nillable = true)
	public void setBudgeted_Cost(String Budgeted_Cost) {
		this.Budgeted_Cost = Budgeted_Cost;
	}

	public String getTC_Shipment_ID() {
		return TC_Shipment_ID;
	}
	@XmlElement(name = "TC_Shipment_ID", required = true, nillable = true)
	public void setTC_Shipment_ID(String TC_Shipment_ID) {
		this.TC_Shipment_ID = TC_Shipment_ID;
	}

	public String getBill_To_City() {
		return Bill_To_City;
	}

	@XmlElement(name = "Bill_To_City", required = true, nillable = true)
	public void setBill_To_City(String Bill_To_City) {
		this.Bill_To_City = Bill_To_City;
	}

	public String getDesignated_Equipment_Code() {
		return Designated_Equipment_Code;
	}

	@XmlElement(name = "Designated_Equipment_Code", required = true, nillable = true)
	public void setDesignated_Equipment_Code(String Designated_Equipment_Code) {
		this.Designated_Equipment_Code = Designated_Equipment_Code;
	}

	public String getBroker_Carrier_Code() {
		return Broker_Carrier_Code;
	}

	@XmlElement(name = "Broker_Carrier_Code", required = true, nillable = true)
	public void setBroker_Carrier_Code(String Broker_Carrier_Code) {
		this.Broker_Carrier_Code = Broker_Carrier_Code;
	}

	public String getReference_Number() {
		return Reference_Number;
	}

	@XmlElement(name = "Reference_Number", required = true, nillable = true)
	public void setReference_Number(String Reference_Number) {
		this.Reference_Number = Reference_Number;
	}

	public String getRouting_Info() {
		return Routing_Info;
	}

	@XmlElement(name = "Routing_Info", required = true, nillable = true)
	public void setRouting_Info(String Routing_Info) {
		this.Routing_Info = Routing_Info;
	}

	public String getShipper_ID() {
		return Shipper_ID;
	}

	@XmlElement(name = "Shipper_ID", required = true, nillable = true)
	public void setShipper_ID(String Shipper_ID) {
		this.Shipper_ID = Shipper_ID;
	}

	public Accessorial[] getAccessorial() {
		return Accessorial;
	}

	@XmlElement(name = "Accessorial", required = true, nillable = true)
	public void setAccessorial(Accessorial[] Accessorial) {
		this.Accessorial = Accessorial;
	}

	public String getMerchandizing_Department() {
		return Merchandizing_Department;
	}

	@XmlElement(name = "Merchandizing_Department", required = true, nillable = true)
	public void setMerchandizing_Department(String Merchandizing_Department) {
		this.Merchandizing_Department = Merchandizing_Department;
	}

	public String getProtection_Level_Code() {
		return Protection_Level_Code;
	}

	@XmlElement(name = "Protection_Level_Code", required = true, nillable = true)
	public void setProtection_Level_Code(String Protection_Level_Code) {
		this.Protection_Level_Code = Protection_Level_Code;
	}

	public String getPRO_Number() {
		return PRO_Number;
	}

	@XmlElement(name = "PRO_Number", required = true, nillable = true)
	public void setPRO_Number(String PRO_Number) {
		this.PRO_Number = PRO_Number;
	}

	public String getDirect_Distance() {
		return Direct_Distance;
	}

	@XmlElement(name = "Direct_Distance", required = true, nillable = true)
	public void setDirect_Distance(String Direct_Distance) {
		this.Direct_Distance = Direct_Distance;
	}

	public String getIs_Hazmat() {
		return Is_Hazmat;
	}

	@XmlElement(name = "Is_Hazmat", required = true, nillable = true)
	public void setIs_Hazmat(String Is_Hazmat) {
		this.Is_Hazmat = Is_Hazmat;
	}

	public String getNum_Stops() {
		return Num_Stops;
	}

	@XmlElement(name = "Num_Stops", required = true, nillable = true)
	public void setNum_Stops(String Num_Stops) {
		this.Num_Stops = Num_Stops;
	}

	public String getTractor_Number() {
		return Tractor_Number;
	}

	@XmlElement(name = "Tractor_Number", required = true, nillable = true)
	public void setTractor_Number(String Tractor_Number) {
		this.Tractor_Number = Tractor_Number;
	}

	public String getOut_Of_RouteMiles() {
		return Out_Of_RouteMiles;
	}

	@XmlElement(name = "Out_Of_RouteMiles", required = true, nillable = true)
	public void setOut_Of_RouteMiles(String Out_Of_RouteMiles) {
		this.Out_Of_RouteMiles = Out_Of_RouteMiles;
	}

	public String getLast_Updated_Source() {
		return Last_Updated_Source;
	}

	@XmlElement(name = "Last_Updated_Source", required = true, nillable = true)
	public void setLast_Updated_Source(String Last_Updated_Source) {
		this.Last_Updated_Source = Last_Updated_Source;
	}

	public String getAssigned_CM_Shipment_ID() {
		return Assigned_CM_Shipment_ID;
	}

	@XmlElement(name = "Assigned_CM_Shipment_ID", required = true, nillable = true)
	public void setAssigned_CM_Shipment_ID(String Assigned_CM_Shipment_ID) {
		this.Assigned_CM_Shipment_ID = Assigned_CM_Shipment_ID;
	}

	public String getBroker_Reference() {
		return Broker_Reference;
	}

	@XmlElement(name = "Broker_Reference", required = true, nillable = true)
	public void setBroker_Reference(String Broker_Reference) {
		this.Broker_Reference = Broker_Reference;
	}

	public String getDestination_Port() {
		return Destination_Port;
	}

	@XmlElement(name = "Destination_Port", required = true, nillable = true)
	public void setDestination_Port(String Destination_Port) {
		this.Destination_Port = Destination_Port;
	}

	public String getRadial_Distance() {
		return Radial_Distance;
	}

	@XmlElement(name = "Radial_Distance", required = true, nillable = true)
	public void setRadial_Distance(String Radial_Distance) {
		this.Radial_Distance = Radial_Distance;
	}

	public String getBill_To_State_Prov() {
		return Bill_To_State_Prov;
	}

	@XmlElement(name = "Bill_To_State_Prov", required = true, nillable = true)
	public void setBill_To_State_Prov(String Bill_To_State_Prov) {
		this.Bill_To_State_Prov = Bill_To_State_Prov;
	}

	public String getAssigned_Carrier_Code() {
		return Assigned_Carrier_Code;
	}

	@XmlElement(name = "Assigned_Carrier_Code", required = true, nillable = true)
	public void setAssigned_Carrier_Code(String Assigned_Carrier_Code) {
		this.Assigned_Carrier_Code = Assigned_Carrier_Code;
	}

	public String getBill_To_Name() {
		return Bill_To_Name;
	}

	@XmlElement(name = "Bill_To_Name", required = true, nillable = true)
	public void setBill_To_Name(String Bill_To_Name) {
		this.Bill_To_Name = Bill_To_Name;
	}

	public String getCommodity_Size() {
		return Commodity_Size;
	}

	@XmlElement(name = "Commodity_Size", required = true, nillable = true)
	public void setCommodity_Size(String Commodity_Size) {
		this.Commodity_Size = Commodity_Size;
	}

	public Critical_Change_Attributes getCritical_Change_Attributes() {
		return Critical_Change_Attributes;
	}

	@XmlElement(name = "Critical_Change_Attributes", required = true, nillable = true)
	public void setCritical_Change_Attributes(Critical_Change_Attributes Critical_Change_Attributes) {
		this.Critical_Change_Attributes = Critical_Change_Attributes;
	}

	public String getDesignated_Carrier_Code() {
		return Designated_Carrier_Code;
	}

	@XmlElement(name = "Designated_Carrier_Code", required = true, nillable = true)
	public void setDesignated_Carrier_Code(String Designated_Carrier_Code) {
		this.Designated_Carrier_Code = Designated_Carrier_Code;
	}

	public String getSeal_Number() {
		return Seal_Number;
	}

	@XmlElement(name = "Seal_Number", required = true, nillable = true)
	public void setSeal_Number(String Seal_Number) {
		this.Seal_Number = Seal_Number;
	}

	public String getAssigned_Equipment_Code() {
		return Assigned_Equipment_Code;
	}

	@XmlElement(name = "Assigned_Equipment_Code", required = true, nillable = true)
	public void setAssigned_Equipment_Code(String Assigned_Equipment_Code) {
		this.Assigned_Equipment_Code = Assigned_Equipment_Code;
	}

	public String getCons_Address_Code() {
		return Cons_Address_Code;
	}

	@XmlElement(name = "Cons_Address_Code", required = true, nillable = true)
	public void setCons_Address_Code(String Cons_Address_Code) {
		this.Cons_Address_Code = Cons_Address_Code;
	}

	public String getFeasible_Tractor_Code() {
		return Feasible_Tractor_Code;
	}

	@XmlElement(name = "Feasible_Tractor_Code", required = true, nillable = true)
	public void setFeasible_Tractor_Code(String Feasible_Tractor_Code) {
		this.Feasible_Tractor_Code = Feasible_Tractor_Code;
	}

	public String getFeasible_Driver_Type() {
		return Feasible_Driver_Type;
	}

	@XmlElement(name = "Feasible_Driver_Type", required = true, nillable = true)
	public void setFeasible_Driver_Type(String Feasible_Driver_Type) {
		this.Feasible_Driver_Type = Feasible_Driver_Type;
	}

	public String getRouting_Ship_W_Control_Nbr() {
		return Routing_Ship_W_Control_Nbr;
	}

	@XmlElement(name = "Routing_Ship_W_Control_Nbr", required = true, nillable = true)
	public void setRouting_Ship_W_Control_Nbr(String Routing_Ship_W_Control_Nbr) {
		this.Routing_Ship_W_Control_Nbr = Routing_Ship_W_Control_Nbr;
	}

	public String getWMS_Status() {
		return WMS_Status;
	}

	@XmlElement(name = "WMS_Status", required = true, nillable = true)
	public void setWMS_Status(String WMS_Status) {
		this.WMS_Status = WMS_Status;
	}

	public String getBill_To_Country_Code() {
		return Bill_To_Country_Code;
	}

	@XmlElement(name = "Bill_To_Country_Code", required = true, nillable = true)
	public void setBill_To_Country_Code(String Bill_To_Country_Code) {
		this.Bill_To_Country_Code = Bill_To_Country_Code;
	}

	public String getCurrency_Code() {
		return Currency_Code;
	}

	@XmlElement(name = "Currency_Code", required = true, nillable = true)
	public void setCurrency_Code(String Currency_Code) {
		this.Currency_Code = Currency_Code;
	}

	public String getShip_Group_ID() {
		return Ship_Group_ID;
	}

	@XmlElement(name = "Ship_Group_ID", required = true, nillable = true)
	public void setShip_Group_ID(String Ship_Group_ID) {
		this.Ship_Group_ID = Ship_Group_ID;
	}

	public String getLast_Updated_DTTM() {
		return Last_Updated_DTTM;
	}

	@XmlElement(name = "Last_Updated_DTTM", required = true, nillable = true)
	public void setLast_Updated_DTTM(String Last_Updated_DTTM) {
		this.Last_Updated_DTTM = Last_Updated_DTTM;
	}

	public String getLast_Updated_Source_Type_Value() {
		return Last_Updated_Source_Type_Value;
	}

	@XmlElement(name = "Last_Updated_Source_Type_Value", required = true, nillable = true)
	public void setLast_Updated_Source_Type_Value(String Last_Updated_Source_Type_Value) {
		this.Last_Updated_Source_Type_Value = Last_Updated_Source_Type_Value;
	}

	@Override
	public String toString() {
		return "ClassPojo [Product_Class_Code = " + Product_Class_Code + ", Is_Cancelled = " + Is_Cancelled
				+ ", Is_Perishable = " + Is_Perishable + ", Stop = " + Stop + ", Bill_To_Title = " + Bill_To_Title
				+ ", Bill_To_Postal_Code = " + Bill_To_Postal_Code + ", Commodity_Code = " + Commodity_Code
				+ ", Radial_Distance_Provided = " + Radial_Distance_Provided + ", Origin_Port = " + Origin_Port
				+ ", Loading_Method = " + Loading_Method + ", Designated_Service_Level = " + Designated_Service_Level
				+ ", Assigned_Service_Level = " + Assigned_Service_Level + ", Feasible_Equipment_Code = "
				+ Feasible_Equipment_Code + ", Designated_Tractor_Code = " + Designated_Tractor_Code
				+ ", External_System_Shipment_ID = " + External_System_Shipment_ID + ", Assigned_Mode_Code = "
				+ Assigned_Mode_Code + ", Monetary_Value = " + Monetary_Value + ", Actual_Cost = " + Actual_Cost
				+ ", Tender_Response_Due = " + Tender_Response_Due + ", BOL_Number = " + BOL_Number + ", Distance = "
				+ Distance + ", Trailer_Gen_Code = " + Trailer_Gen_Code + ", Distances_Provided = " + Distances_Provided
				+ ", Order = " + Order + ", Designated_Driver_Type = " + Designated_Driver_Type + ", Tender_Date = "
				+ Tender_Date + ", Route_Type_Code = " + Route_Type_Code + ", Bill_To_Street_Address = "
				+ Bill_To_Street_Address + ", Shipment_Status = " + Shipment_Status + ", Designated_Mode_Code = "
				+ Designated_Mode_Code + ", Bill_To_Phone = " + Bill_To_Phone + ", Authorization_Nbr = "
				+ Authorization_Nbr + ", Wave = " + Wave + ", Spot_Charge = " + Spot_Charge + ", Purchase_Order = "
				+ Purchase_Order + ", Status_Change_DTTM = " + Status_Change_DTTM + ", Business_Unit = " + Business_Unit
				+ ", Assigned_CMID = " + Assigned_CMID + ", Trailer_Number = " + Trailer_Number + ", Num_Docks = "
				+ Num_Docks + ", Business_Partner_Code = " + Business_Partner_Code + ", Hub_ID = " + Hub_ID
				+ ", Budgeted_Cost = " + Budgeted_Cost + ", TC_Shipment_ID = " + TC_Shipment_ID + ", Bill_To_City = "
				+ Bill_To_City + ", Designated_Equipment_Code = " + Designated_Equipment_Code
				+ ", Broker_Carrier_Code = " + Broker_Carrier_Code + ", Reference_Number = " + Reference_Number
				+ ", Routing_Info = " + Routing_Info + ", Shipper_ID = " + Shipper_ID + ", Accessorial = " + Accessorial
				+ ", Merchandizing_Department = " + Merchandizing_Department + ", Protection_Level_Code = "
				+ Protection_Level_Code + ", PRO_Number = " + PRO_Number + ", Direct_Distance = " + Direct_Distance
				+ ", Is_Hazmat = " + Is_Hazmat + ", Num_Stops = " + Num_Stops + ", Tractor_Number = " + Tractor_Number
				+ ", Out_Of_RouteMiles = " + Out_Of_RouteMiles + ", Last_Updated_Source = " + Last_Updated_Source
				+ ", Assigned_CM_Shipment_ID = " + Assigned_CM_Shipment_ID + ", Broker_Reference = " + Broker_Reference
				+ ", Destination_Port = " + Destination_Port + ", Radial_Distance = " + Radial_Distance
				+ ", Bill_To_State_Prov = " + Bill_To_State_Prov + ", Assigned_Carrier_Code = " + Assigned_Carrier_Code
				+ ", Bill_To_Name = " + Bill_To_Name + ", Commodity_Size = " + Commodity_Size
				+ ", Critical_Change_Attributes = " + Critical_Change_Attributes + ", Designated_Carrier_Code = "
				+ Designated_Carrier_Code + ", Seal_Number = " + Seal_Number + ", Assigned_Equipment_Code = "
				+ Assigned_Equipment_Code + ", Cons_Address_Code = " + Cons_Address_Code + ", Feasible_Tractor_Code = "
				+ Feasible_Tractor_Code + ", Feasible_Driver_Type = " + Feasible_Driver_Type
				+ ", Routing_Ship_W_Control_Nbr = " + Routing_Ship_W_Control_Nbr + ", WMS_Status = " + WMS_Status
				+ ", Bill_To_Country_Code = " + Bill_To_Country_Code + ", Currency_Code = " + Currency_Code
				+ ", Ship_Group_ID = " + Ship_Group_ID + ", Last_Updated_DTTM = " + Last_Updated_DTTM
				+ ", Last_Updated_Source_Type_Value = " + Last_Updated_Source_Type_Value + "]";
	}
}