package com.adidas.waaloscommon.dto.loadplanner;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Quantity
{
    private String OrderQty;

    private String ReceivedQty;

    private String ShippedQty;

    private String QtyUOM;

    public String getOrderQty ()
    {
        return OrderQty;
    }
    @XmlElement(name = "OrderQty", required = true, nillable = true)
    public void setOrderQty (String OrderQty)
    {
        this.OrderQty = OrderQty;
    }

    public String getReceivedQty ()
    {
        return ReceivedQty;
    }

    @XmlElement(name = "ReceivedQty", required = true, nillable = true)
    public void setReceivedQty (String ReceivedQty)
    {
        this.ReceivedQty = ReceivedQty;
    }

    public String getShippedQty ()
    {
        return ShippedQty;
    }

    @XmlElement(name = "ShippedQty", required = true, nillable = true)
    public void setShippedQty (String ShippedQty)
    {
        this.ShippedQty = ShippedQty;
    }

    public String getQtyUOM ()
    {
        return QtyUOM;
    }

    @XmlElement(name = "QtyUOM", required = true, nillable = true)
    public void setQtyUOM (String QtyUOM)
    {
        this.QtyUOM = QtyUOM;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [OrderQty = "+OrderQty+", ReceivedQty = "+ReceivedQty+", ShippedQty = "+ShippedQty+", QtyUOM = "+QtyUOM+"]";
    }
}