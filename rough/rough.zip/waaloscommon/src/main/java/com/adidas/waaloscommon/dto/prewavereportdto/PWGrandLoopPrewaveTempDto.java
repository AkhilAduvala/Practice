package com.adidas.waaloscommon.dto.prewavereportdto;

import lombok.Data;

@Data
public class PWGrandLoopPrewaveTempDto {
	private String pktCtrlNum;
	private String skuId;
	private String origPktQty;
	private String stdCaseQty;
	private String int2s;
	private String excessFromCase;
	private String codeDesc;
	private String pickWaveNum;
	private String cartonType;
	private String ppackQty;
	private String skuAttr1;
	private String shipVia;
	private String unitVol;
	private String unitLen;
	private String vasProcType;
	private String int2sSelected;
	private String unitHeight;
	private String unitWidth;
	private String unitWeight;
	private String stdCaseHeight;
	private String stdCaseLen;
	private String stdCaseWidth;
	private String stdCaseVol;
	private String stdCaseWeight;
}

