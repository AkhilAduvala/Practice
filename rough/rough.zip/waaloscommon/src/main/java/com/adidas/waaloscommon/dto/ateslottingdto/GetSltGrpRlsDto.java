/*
 * Copyright (C) 2017 adidas AG.
 */
package com.adidas.waaloscommon.dto.ateslottingdto;

import lombok.Data;

/**
 * The persistent class for Ate Sz Slotting Data sources.
 * 
 */
@Data
public class GetSltGrpRlsDto {
	private String dcName;
	private String userName;
	private String grpType; 
	private String grpAttr;
	private String userId; 
	private String createDateTime; 
	private String modDateTime;  
	private String daysTillSlot;  
	private String prodTypes; 
	private String reSlotToResVal;
	private String reSlotInvGrpAttr;
	private String reSlotSeasonGrpAttr;
	private String zoneType;
	private String priority;
	private String totLocns;
	private String noOfCases;
	private String hasRules;
	private String distZones;
}
