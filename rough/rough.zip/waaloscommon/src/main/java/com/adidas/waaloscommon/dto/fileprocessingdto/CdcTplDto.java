package com.adidas.waaloscommon.dto.fileprocessingdto;

import lombok.Data;

@Data
public class CdcTplDto {
	private Integer rowNum;
	private String shipmentId;
	private String shipmentTrackingNumber;
	private String shipmentNumber;
	private String CarrierString;
	private String load1stOptimizationId;
	private String carrierId;
	private String serviceId;
	private String transportMode;
	private String errorType;
	private String errorMessage;
}
