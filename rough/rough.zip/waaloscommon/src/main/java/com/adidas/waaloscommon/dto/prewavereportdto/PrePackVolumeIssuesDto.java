package com.adidas.waaloscommon.dto.prewavereportdto;

import lombok.Data;

@Data
public class PrePackVolumeIssuesDto {
	
	private String shipWaveNbr;
	private String waveNbr;
	private String tcOrderId;
	private String ppackGrpCode;
	private String assortNbr;
	private String cartonType;
	private double prePackVol;
	private double maxVol;
	
}
