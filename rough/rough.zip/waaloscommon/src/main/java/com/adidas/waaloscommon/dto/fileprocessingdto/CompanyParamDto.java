package com.adidas.waaloscommon.dto.fileprocessingdto;

import lombok.Data;

@Data
public class CompanyParamDto {
	private String dimensionUom;
	private String volumeUom;
	private String weightUom;
}
