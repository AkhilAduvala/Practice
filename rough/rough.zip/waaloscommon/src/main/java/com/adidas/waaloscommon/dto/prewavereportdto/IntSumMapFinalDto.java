package com.adidas.waaloscommon.dto.prewavereportdto;

import java.util.List;
import java.util.Map;

import lombok.Data;

@Data
public class IntSumMapFinalDto {
	private Map<String, Object> dPktInt2;
	private Map<String, Object> dShipVia;
	private Map<String, Object> dInt2Cases;
	private Map<String, Object> dVasInt2Cases;
	private Map<String, Object> dVasInt2Units;
	private Map<String, Object> dInt150Units;
	private Map<String, Object> dInt1Cases;
	private Map<String, Object> dInt2Units;
	private Map<String, Object> dInt1Units;
	private Map<String, Object> dInt50Cases;
	private Map<String, Object> dInt50Units;
	private Map<String, Object> dCartons;
	private Map<String, Object> dMissingInventory;
	private List<PWMapKeysDto> mapsDto;
	private String missingInventoryVal;
	private String missingDimsVal; 
	private String locnsNeededVal;
	
}

