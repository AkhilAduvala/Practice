package com.adidas.waaloscommon.dto.ateslottingdto;

import lombok.Data;
import java.util.ArrayList;
import java.util.List;

import com.adidas.waaloscommon.dto.wmsdto.ErrorDto;

@Data
public class ForecastResponseDto {
	
	private Long lotId;
	private String status;
	private List<ErrorDto> errorDtoLst = new ArrayList<ErrorDto>();
	private Integer successCount;
	private Integer errorCount;
	private Integer totalCount;
	private Integer validationErrorCount;

	}


