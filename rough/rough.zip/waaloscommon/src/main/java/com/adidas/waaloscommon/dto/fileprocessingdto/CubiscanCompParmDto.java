package com.adidas.waaloscommon.dto.fileprocessingdto;

import lombok.Data;

@Data
public class CubiscanCompParmDto {
	private String paramDefId;
	private String paramValue;
}
