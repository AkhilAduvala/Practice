package com.adidas.waaloscommon.dto;

import lombok.Getter;
import lombok.Setter;

@Setter @Getter
public class EmailDetailsDto {
	private String emailFrom;
	private String [] recipients;
	private String [] recipientsInCC;
	private String [] recipientsInBCC;
	private String messageHdr;
	private String message;	
	private String attachmentPath;
	private String attachmentName;
}
