package com.adidas.waaloscommon.dto.prewavereportdto;

import lombok.Data;

@Data
public class PrePackOrderSizeIssuesDto {
	
	private String waveNbr;
	private int orderId;
	private String tcOrderId;
	private String ppackGrpCode;
	private String assortNbr;
	private double nbrOfRatios;

}
