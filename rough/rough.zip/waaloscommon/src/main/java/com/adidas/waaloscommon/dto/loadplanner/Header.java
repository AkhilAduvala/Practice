package com.adidas.waaloscommon.dto.loadplanner;

import java.util.Date;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Header {
	private String Source;
	private String Action_Type;
	private Integer Sequence_Number;
	private String Batch_ID;
	private String Reference_ID;
	private String User_ID;
	private String Password;
	private String Message_Type;
	private String Company_ID;
	private String Msg_Locale;
	private String Msg_Time_Zone;
	private String Version;
	private String Internal_Reference_ID;
	private Date Internal_Date_Time_Stamp;
	private String External_Reference_ID_Type;
	private String External_Reference_ID;
	private Date External_Date_Time_Stamp;
	
	public String getSource() {
		return Source;
	}
	@XmlElement(name = "Source", required = true, nillable = true)
	public void setSource(String source) {
		Source = source;
	}
	
	public String getAction_Type() {
		return Action_Type;
	}
	@XmlElement(name = "Action_Type", required = true, nillable = true)
	public void setAction_Type(String action_Type) {
		Action_Type = action_Type;
	}
	public Integer getSequence_Number() {
		return Sequence_Number;
	}
	@XmlElement(name = "Sequence_Number", required = true, nillable = true)
	public void setSequence_Number(Integer sequence_Number) {
		Sequence_Number = sequence_Number;
	}
	public String getBatch_ID() {
		return Batch_ID;
	}
	@XmlElement(name = "Batch_ID", required = true, nillable = true)
	public void setBatch_ID(String batch_ID) {
		Batch_ID = batch_ID;
	}
	public String getReference_ID() {
		return Reference_ID;
	}
	@XmlElement(name = "Reference_ID", required = true, nillable = true)
	public void setReference_ID(String reference_ID) {
		Reference_ID = reference_ID;
	}
	public String getUser_ID() {
		return User_ID;
	}
	@XmlElement(name = "User_ID", required = true, nillable = true)
	public void setUser_ID(String user_ID) {
		User_ID = user_ID;
	}
	public String getPassword() {
		return Password;
	}
	@XmlElement(name = "Password", required = true, nillable = true)
	public void setPassword(String password) {
		Password = password;
	}
	public String getMessage_Type() {
		return Message_Type;
	}
	@XmlElement(name = "Message_Type", required = true, nillable = true)
	public void setMessage_Type(String message_Type) {
		Message_Type = message_Type;
	}
	public String getCompany_ID() {
		return Company_ID;
	}
	@XmlElement(name = "Company_ID", required = true, nillable = true)
	public void setCompany_ID(String company_ID) {
		Company_ID = company_ID;
	}
	public String getMsg_Locale() {
		return Msg_Locale;
	}
	@XmlElement(name = "Msg_Locale", required = true, nillable = true)
	public void setMsg_Locale(String msg_Locale) {
		Msg_Locale = msg_Locale;
	}
	public String getMsg_Time_Zone() {
		return Msg_Time_Zone;
	}
	@XmlElement(name = "Msg_Time_Zone", required = true, nillable = true)
	public void setMsg_Time_Zone(String msg_Time_Zone) {
		Msg_Time_Zone = msg_Time_Zone;
	}
	public String getVersion() {
		return Version;
	}
	@XmlElement(name = "Version", required = true, nillable = true)
	public void setVersion(String version) {
		Version = version;
	}
	public String getInternal_Reference_ID() {
		return Internal_Reference_ID;
	}
	@XmlElement(name = "Internal_Reference_ID", required = true, nillable = true)
	public void setInternal_Reference_ID(String internal_Reference_ID) {
		Internal_Reference_ID = internal_Reference_ID;
	}
	public Date getInternal_Date_Time_Stamp() {
		return Internal_Date_Time_Stamp;
	}
	@XmlElement(name = "Internal_Date_Time_Stamp", required = true, nillable = true)
	public void setInternal_Date_Time_Stamp(Date internal_Date_Time_Stamp) {
		Internal_Date_Time_Stamp = internal_Date_Time_Stamp;
	}
	public String getExternal_Reference_ID_Type() {
		return External_Reference_ID_Type;
	}
	@XmlElement(name = "External_Reference_ID_Type", required = true, nillable = true)
	public void setExternal_Reference_ID_Type(String external_Reference_ID_Type) {
		External_Reference_ID_Type = external_Reference_ID_Type;
	}
	public String getExternal_Reference_ID() {
		return External_Reference_ID;
	}
	@XmlElement(name = "External_Reference_ID", required = true, nillable = true)
	public void setExternal_Reference_ID(String external_Reference_ID) {
		External_Reference_ID = external_Reference_ID;
	}
	public Date getExternal_Date_Time_Stamp() {
		return External_Date_Time_Stamp;
	}
	@XmlElement(name = "External_Date_Time_Stamp", required = true, nillable = true)
	public void setExternal_Date_Time_Stamp(Date external_Date_Time_Stamp) {
		External_Date_Time_Stamp = external_Date_Time_Stamp;
	}
}
