package com.adidas.waaloscommon.dto.reportsdto;

import java.util.Date;

import lombok.Data;

@Data
public class GetDestinationsDto {

	private int cityId;
	private String srcCity;
	private String destCity;
	private Date departTime;
	private Date arrTime;
}
