package com.adidas.waaloscommon.dto.reportsdto;

import java.util.List;

import lombok.Data;
@Data
public class PreSlotZoneResponseDto {
	private List<PreSlotZoneDto> preSlotZoneDtoList;
}
