/*
 * Copyright (C) 2017 adidas AG.
 */
package com.adidas.waaloscommon.dto.slottingdto;

import java.util.List;

import lombok.Data;

/**
 * The persistent class for Ate Sz Slotting Data sources.
 * 
 */
@Data
public class GetForecastSrcDto {
private String dcName;
private String userName;
private String grpType;
private String grpName;
private String createDateTime;
private String modDateTime;
private String userId;
private String useForecastFile;
private String forFileLocn;
private String forFileType;
private String int2sRemoved;
private String useOrders;
private String ordersStatCode;
private String ordersWithXFuture;
private String ordersWithXPast;
private String orderPrewave;
private String useAsns;
private String asnStatCode;
private String asnWithXFuture;
private String asnWithXPast;
private String ordersMinStatCode;
private List<SzForecastDropdownDto> orderInfoLst;
private List<SzForecastDropdownDto> asnInfoLst;
}
