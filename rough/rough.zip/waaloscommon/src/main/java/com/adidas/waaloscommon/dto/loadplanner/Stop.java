package com.adidas.waaloscommon.dto.loadplanner;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Stop
{
    private String Possible_Departure_End;

    private String Contact_Last_Name;

    private String Address;

    private String Departure_Start;

    private String Shipment_Start_DTTM;

    private Shipment_Stop_Attribute_List[] Shipment_Stop_Attribute_List;

    private String Departure_NET_DTTM;

    private String Possible_Departure_Start;

    private String Arrival_End;

    private String Is_Reconsigned;

    private String Possible_Arrival_End;

    private String County;

    private String Name_Of_Location;

    private String Actual_Departure;

    private String Departure_End;

    private String Postal_Code;

    private String Handler_Code;

    private String Distance;

    private String Arrival_Start;

    private String State_Prov;

    private String Contact_Phone;

    private String Arrival_NLT_DTTM;

    private String Stop_Sequence;

    private String City;

    private String Is_Drop_And_Hook;

    private String Paperwork_Start_DTTM;

    private String Pick_Start_DTTM;

    private String Actual_Arrival;

    private String Wave;

    private String Contact_First_Name;

    private String Country_Code;

    private Stop_Action[] Stop_Action;

    private String Contact_Email;

    private String Departure_NLT_DTTM;

    private String Possible_Arrival_Start;

    private String Wave_Option;

    private String Facility_Alias_ID;

    private String Arrival_NET_DTTM;

    private String Bill_Of_Lading_Number;

    private String Shipment_End_DTTM;

    private String Is_Appointment_Required;

    private String Estimated_Dispatch_DTTM;

    public String getPossible_Departure_End ()
    {
        return Possible_Departure_End;
    }

    @XmlElement(name = "Possible_Departure_End", required = true, nillable = true)
    public void setPossible_Departure_End (String Possible_Departure_End)
    {
        this.Possible_Departure_End = Possible_Departure_End;
    }

    public String getContact_Last_Name ()
    {
        return Contact_Last_Name;
    }

    @XmlElement(name = "Contact_Last_Name", required = true, nillable = true)
    public void setContact_Last_Name (String Contact_Last_Name)
    {
        this.Contact_Last_Name = Contact_Last_Name;
    }

    public String getAddress ()
    {
        return Address;
    }

    @XmlElement(name = "Address", required = true, nillable = true)
    public void setAddress (String Address)
    {
        this.Address = Address;
    }

    public String getDeparture_Start ()
    {
        return Departure_Start;
    }

    @XmlElement(name = "Departure_Start", required = true, nillable = true)
    public void setDeparture_Start (String Departure_Start)
    {
        this.Departure_Start = Departure_Start;
    }

    public String getShipment_Start_DTTM ()
    {
        return Shipment_Start_DTTM;
    }

    @XmlElement(name = "Shipment_Start_DTTM", required = true, nillable = true)
    public void setShipment_Start_DTTM (String Shipment_Start_DTTM)
    {
        this.Shipment_Start_DTTM = Shipment_Start_DTTM;
    }

    public Shipment_Stop_Attribute_List[] getShipment_Stop_Attribute_List ()
    {
        return Shipment_Stop_Attribute_List;
    }

    @XmlElement(name = "Shipment_Stop_Attribute_List", required = true, nillable = true)
    public void setShipment_Stop_Attribute_List (Shipment_Stop_Attribute_List[] Shipment_Stop_Attribute_List)
    {
        this.Shipment_Stop_Attribute_List = Shipment_Stop_Attribute_List;
    }

    public String getDeparture_NET_DTTM ()
    {
        return Departure_NET_DTTM;
    }

    @XmlElement(name = "Departure_NET_DTTM", required = true, nillable = true)
    public void setDeparture_NET_DTTM (String Departure_NET_DTTM)
    {
        this.Departure_NET_DTTM = Departure_NET_DTTM;
    }

    public String getPossible_Departure_Start ()
    {
        return Possible_Departure_Start;
    }

    @XmlElement(name = "Possible_Departure_Start", required = true, nillable = true)
    public void setPossible_Departure_Start (String Possible_Departure_Start)
    {
        this.Possible_Departure_Start = Possible_Departure_Start;
    }

    public String getArrival_End ()
    {
        return Arrival_End;
    }

    @XmlElement(name = "Arrival_End", required = true, nillable = true)
    public void setArrival_End (String Arrival_End)
    {
        this.Arrival_End = Arrival_End;
    }

    public String getIs_Reconsigned ()
    {
        return Is_Reconsigned;
    }

    @XmlElement(name = "Is_Reconsigned", required = true, nillable = true)
    public void setIs_Reconsigned (String Is_Reconsigned)
    {
        this.Is_Reconsigned = Is_Reconsigned;
    }

    public String getPossible_Arrival_End ()
    {
        return Possible_Arrival_End;
    }

    @XmlElement(name = "Possible_Arrival_End", required = true, nillable = true)
    public void setPossible_Arrival_End (String Possible_Arrival_End)
    {
        this.Possible_Arrival_End = Possible_Arrival_End;
    }

    public String getCounty ()
    {
        return County;
    }

    @XmlElement(name = "County", required = true, nillable = true)
    public void setCounty (String County)
    {
        this.County = County;
    }

    public String getName_Of_Location ()
    {
        return Name_Of_Location;
    }

    @XmlElement(name = "Name_Of_Location", required = true, nillable = true)
    public void setName_Of_Location (String Name_Of_Location)
    {
        this.Name_Of_Location = Name_Of_Location;
    }

    public String getActual_Departure ()
    {
        return Actual_Departure;
    }

    @XmlElement(name = "Actual_Departure", required = true, nillable = true)
    public void setActual_Departure (String Actual_Departure)
    {
        this.Actual_Departure = Actual_Departure;
    }

    public String getDeparture_End ()
    {
        return Departure_End;
    }

    @XmlElement(name = "Departure_End", required = true, nillable = true)
    public void setDeparture_End (String Departure_End)
    {
        this.Departure_End = Departure_End;
    }

    public String getPostal_Code ()
    {
        return Postal_Code;
    }

    @XmlElement(name = "Postal_Code", required = true, nillable = true)
    public void setPostal_Code (String Postal_Code)
    {
        this.Postal_Code = Postal_Code;
    }

    public String getHandler_Code ()
    {
        return Handler_Code;
    }

    @XmlElement(name = "Handler_Code", required = true, nillable = true)
    public void setHandler_Code (String Handler_Code)
    {
        this.Handler_Code = Handler_Code;
    }

    public String getDistance ()
    {
        return Distance;
    }

    @XmlElement(name = "Distance", required = true, nillable = true)
    public void setDistance (String Distance)
    {
        this.Distance = Distance;
    }

    public String getArrival_Start ()
    {
        return Arrival_Start;
    }

    @XmlElement(name = "Arrival_Start", required = true, nillable = true)
    public void setArrival_Start (String Arrival_Start)
    {
        this.Arrival_Start = Arrival_Start;
    }

    public String getState_Prov ()
    {
        return State_Prov;
    }

    @XmlElement(name = "State_Prov", required = true, nillable = true)
    public void setState_Prov (String State_Prov)
    {
        this.State_Prov = State_Prov;
    }

    public String getContact_Phone ()
    {
        return Contact_Phone;
    }

    @XmlElement(name = "Contact_Phone", required = true, nillable = true)
    public void setContact_Phone (String Contact_Phone)
    {
        this.Contact_Phone = Contact_Phone;
    }

    public String getArrival_NLT_DTTM ()
    {
        return Arrival_NLT_DTTM;
    }

    @XmlElement(name = "Arrival_NLT_DTTM", required = true, nillable = true)
    public void setArrival_NLT_DTTM (String Arrival_NLT_DTTM)
    {
        this.Arrival_NLT_DTTM = Arrival_NLT_DTTM;
    }

    public String getStop_Sequence ()
    {
        return Stop_Sequence;
    }

    @XmlElement(name = "Stop_Sequence", required = true, nillable = true)
    public void setStop_Sequence (String Stop_Sequence)
    {
        this.Stop_Sequence = Stop_Sequence;
    }

    public String getCity ()
    {
        return City;
    }

    @XmlElement(name = "City", required = true, nillable = true)
    public void setCity (String City)
    {
        this.City = City;
    }

    public String getIs_Drop_And_Hook ()
    {
        return Is_Drop_And_Hook;
    }

    @XmlElement(name = "Is_Drop_And_Hook", required = true, nillable = true)
    public void setIs_Drop_And_Hook (String Is_Drop_And_Hook)
    {
        this.Is_Drop_And_Hook = Is_Drop_And_Hook;
    }

    public String getPaperwork_Start_DTTM ()
    {
        return Paperwork_Start_DTTM;
    }

    @XmlElement(name = "Paperwork_Start_DTTM", required = true, nillable = true)
    public void setPaperwork_Start_DTTM (String Paperwork_Start_DTTM)
    {
        this.Paperwork_Start_DTTM = Paperwork_Start_DTTM;
    }

    public String getPick_Start_DTTM ()
    {
        return Pick_Start_DTTM;
    }

    @XmlElement(name = "Pick_Start_DTTM", required = true, nillable = true)
    public void setPick_Start_DTTM (String Pick_Start_DTTM)
    {
        this.Pick_Start_DTTM = Pick_Start_DTTM;
    }

    public String getActual_Arrival ()
    {
        return Actual_Arrival;
    }

    @XmlElement(name = "Actual_Arrival", required = true, nillable = true)
    public void setActual_Arrival (String Actual_Arrival)
    {
        this.Actual_Arrival = Actual_Arrival;
    }

    public String getWave ()
    {
        return Wave;
    }

    @XmlElement(name = "Wave", required = true, nillable = true)
    public void setWave (String Wave)
    {
        this.Wave = Wave;
    }

    public String getContact_First_Name ()
    {
        return Contact_First_Name;
    }

    @XmlElement(name = "Contact_First_Name", required = true, nillable = true)
    public void setContact_First_Name (String Contact_First_Name)
    {
        this.Contact_First_Name = Contact_First_Name;
    }

    public String getCountry_Code ()
    {
        return Country_Code;
    }

    @XmlElement(name = "Country_Code", required = true, nillable = true)
    public void setCountry_Code (String Country_Code)
    {
        this.Country_Code = Country_Code;
    }

    public Stop_Action[] getStop_Action ()
    {
        return Stop_Action;
    }

    @XmlElement(name = "Stop_Action", required = true, nillable = true)
    public void setStop_Action (Stop_Action[] Stop_Action)
    {
        this.Stop_Action = Stop_Action;
    }

    public String getContact_Email ()
    {
        return Contact_Email;
    }

    @XmlElement(name = "Contact_Email", required = true, nillable = true)
    public void setContact_Email (String Contact_Email)
    {
        this.Contact_Email = Contact_Email;
    }

    public String getDeparture_NLT_DTTM ()
    {
        return Departure_NLT_DTTM;
    }

    @XmlElement(name = "Departure_NLT_DTTM", required = true, nillable = true)
    public void setDeparture_NLT_DTTM (String Departure_NLT_DTTM)
    {
        this.Departure_NLT_DTTM = Departure_NLT_DTTM;
    }

    public String getPossible_Arrival_Start ()
    {
        return Possible_Arrival_Start;
    }

    @XmlElement(name = "Possible_Arrival_Start", required = true, nillable = true)
    public void setPossible_Arrival_Start (String Possible_Arrival_Start)
    {
        this.Possible_Arrival_Start = Possible_Arrival_Start;
    }

    public String getWave_Option ()
    {
        return Wave_Option;
    }

    @XmlElement(name = "Wave_Option", required = true, nillable = true)
    public void setWave_Option (String Wave_Option)
    {
        this.Wave_Option = Wave_Option;
    }

    public String getFacility_Alias_ID ()
    {
        return Facility_Alias_ID;
    }

    @XmlElement(name = "Facility_Alias_ID", required = true, nillable = true)
    public void setFacility_Alias_ID (String Facility_Alias_ID)
    {
        this.Facility_Alias_ID = Facility_Alias_ID;
    }

    public String getArrival_NET_DTTM ()
    {
        return Arrival_NET_DTTM;
    }

    @XmlElement(name = "Arrival_NET_DTTM", required = true, nillable = true)
    public void setArrival_NET_DTTM (String Arrival_NET_DTTM)
    {
        this.Arrival_NET_DTTM = Arrival_NET_DTTM;
    }

    public String getBill_Of_Lading_Number ()
    {
        return Bill_Of_Lading_Number;
    }

    @XmlElement(name = "Bill_Of_Lading_Number", required = true, nillable = true)
    public void setBill_Of_Lading_Number (String Bill_Of_Lading_Number)
    {
        this.Bill_Of_Lading_Number = Bill_Of_Lading_Number;
    }

    public String getShipment_End_DTTM ()
    {
        return Shipment_End_DTTM;
    }

    @XmlElement(name = "Shipment_End_DTTM", required = true, nillable = true)
    public void setShipment_End_DTTM (String Shipment_End_DTTM)
    {
        this.Shipment_End_DTTM = Shipment_End_DTTM;
    }

    public String getIs_Appointment_Required ()
    {
        return Is_Appointment_Required;
    }

    @XmlElement(name = "Is_Appointment_Required", required = true, nillable = true)
    public void setIs_Appointment_Required (String Is_Appointment_Required)
    {
        this.Is_Appointment_Required = Is_Appointment_Required;
    }

    public String getEstimated_Dispatch_DTTM ()
    {
        return Estimated_Dispatch_DTTM;
    }

    @XmlElement(name = "Estimated_Dispatch_DTTM", required = true, nillable = true)
    public void setEstimated_Dispatch_DTTM (String Estimated_Dispatch_DTTM)
    {
        this.Estimated_Dispatch_DTTM = Estimated_Dispatch_DTTM;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Possible_Departure_End = "+Possible_Departure_End+", Contact_Last_Name = "+Contact_Last_Name+", Address = "+Address+", Departure_Start = "+Departure_Start+", Shipment_Start_DTTM = "+Shipment_Start_DTTM+", Shipment_Stop_Attribute_List = "+Shipment_Stop_Attribute_List+", Departure_NET_DTTM = "+Departure_NET_DTTM+", Possible_Departure_Start = "+Possible_Departure_Start+", Arrival_End = "+Arrival_End+", Is_Reconsigned = "+Is_Reconsigned+", Possible_Arrival_End = "+Possible_Arrival_End+", County = "+County+", Name_Of_Location = "+Name_Of_Location+", Actual_Departure = "+Actual_Departure+", Departure_End = "+Departure_End+", Postal_Code = "+Postal_Code+", Handler_Code = "+Handler_Code+", Distance = "+Distance+", Arrival_Start = "+Arrival_Start+", State_Prov = "+State_Prov+", Contact_Phone = "+Contact_Phone+", Arrival_NLT_DTTM = "+Arrival_NLT_DTTM+", Stop_Sequence = "+Stop_Sequence+", City = "+City+", Is_Drop_And_Hook = "+Is_Drop_And_Hook+", Paperwork_Start_DTTM = "+Paperwork_Start_DTTM+", Pick_Start_DTTM = "+Pick_Start_DTTM+", Actual_Arrival = "+Actual_Arrival+", Wave = "+Wave+", Contact_First_Name = "+Contact_First_Name+", Country_Code = "+Country_Code+", Stop_Action = "+Stop_Action+", Contact_Email = "+Contact_Email+", Departure_NLT_DTTM = "+Departure_NLT_DTTM+", Possible_Arrival_Start = "+Possible_Arrival_Start+", Wave_Option = "+Wave_Option+", Facility_Alias_ID = "+Facility_Alias_ID+", Arrival_NET_DTTM = "+Arrival_NET_DTTM+", Bill_Of_Lading_Number = "+Bill_Of_Lading_Number+", Shipment_End_DTTM = "+Shipment_End_DTTM+", Is_Appointment_Required = "+Is_Appointment_Required+", Estimated_Dispatch_DTTM = "+Estimated_Dispatch_DTTM+"]";
    }
}
