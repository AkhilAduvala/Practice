package com.adidas.waaloscommon.dto.ateslottingdto;

import lombok.Data;

@Data
public class ItemMasterDto {
      
	  private String sku;
	  private String skuId;
	  private String sizeDec;
	  private String style;
	  private String colorl;
	  private String skuBcd;
	  private String skuDesc;
	  private String dspSku;
	  private String pkgType;
	  private String prodGrp;
	  private String prodSubGrp;
	  private String prodType;
	  private String prodLine;
	  private String saleGrp;
	  private String dspQtyUom;
	  private String dbQtyUom;
	  private String cartonType;
	  private Integer unitPrice;
	  private Integer retailPrice;
	  private Integer unitHt;
	  private Integer unitLen;
	  private Integer unitWidth;
	  private Integer unitWt;
	  private Integer unitVol;
	  private Integer maxCaseQty;
	  private Integer unitsPerPickActive;
	  private Integer unitsPerPickCasePick;
	  private Integer unitsPerPickCasePickResv;
	  private String hndlAttrCasePick;
	  private String skuAttrReqd;
	
}
