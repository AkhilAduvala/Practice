package com.adidas.waaloscommon.dto.prewavereportdto;

import java.util.List;
import java.util.Map;

import lombok.Data;

@Data
public class PWEstimationTabDto {
	private List<EstimationsTotalDto> estTotalDto;
	private Map<String, String> reserveReplenDto;
	private Map<String, String> piecePickEcomDto;
	private Map<String, String> packingDto;
	private Map<String, String> vasDto;
}
