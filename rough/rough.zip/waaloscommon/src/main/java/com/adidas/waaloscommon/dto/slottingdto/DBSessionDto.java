package com.adidas.waaloscommon.dto.slottingdto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

import lombok.Data;

/**
 * DTO class for Danger Kill
 * @author Infosys
 *
 */
@Data
public class DBSessionDto {

	private String killable; 	 	
	private int sid;
	private int serialNum;
	private String machine;
	String program;
	String objectName;
	String currTime;
	String isBlocking;
	String event;
	@JsonProperty(access = Access.WRITE_ONLY)
	String dbSessionUsrNm;
	@JsonProperty(access = Access.WRITE_ONLY)
	private String dcName ;
	@JsonProperty(access = Access.WRITE_ONLY)
	private String userName;
	@JsonProperty(access = Access.WRITE_ONLY)
	private int pageNumber;
	@JsonProperty(access = Access.WRITE_ONLY)
	private int pageSize;
	
		
}