package com.adidas.waaloscommon.dto.prewavereportdto;

import java.util.List;

import lombok.Data;
@Data
public class GenericDownloadDto {
	private String jobcode;
	private String dcName;
	private List<PWGenericDto> getGenericDto;
	//private List<PWTransPlanningDto> getPWTransDto;
	private PWTransPlanningDto getPWTransDto;
}
