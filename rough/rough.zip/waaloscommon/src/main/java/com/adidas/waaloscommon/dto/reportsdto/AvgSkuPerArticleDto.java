package com.adidas.waaloscommon.dto.reportsdto;

import lombok.Data;

@Data
public class AvgSkuPerArticleDto {
	private String locationId;
	private Double avgSkuPerArticle;
	private String wrkGrp;
}
