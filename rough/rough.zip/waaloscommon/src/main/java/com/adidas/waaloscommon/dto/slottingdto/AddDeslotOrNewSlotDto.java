package com.adidas.waaloscommon.dto.slottingdto;

import lombok.Data;

@Data
public class AddDeslotOrNewSlotDto {

	private String fromZone;
	private String fromLocn;
	private String displaySKU;
	private int actualInventory;
	private String toZone;
	private String toLocn;
	private int division;
	private String zone;
	private String displayLocn;
	private String locnId;
	private String sno;
}
