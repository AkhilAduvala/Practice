package com.adidas.waaloscommon.dto.slottingdto;

import lombok.Data;

@Data
public class JobSchedulerResponseDto {
	
	private String jobdesc; 	 	
	private String jobhostname;
	private String jobstatus;
	private String jobcommand;
	
}
