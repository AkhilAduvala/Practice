package com.adidas.waaloscommon.dto.ateslottingdto;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode
public class BaseDto {
	private String dcName;
	private String userName;
    private String createdBy;
    private String updatedBy;
    private String createdDate;
    private String updatedDate;
	private Integer rowNum;
}
