package com.adidas.waaloscommon.dto.fileprocessingdto;

import java.util.Date;

import lombok.Data;

@Data
public class UpdateCrdDto {
	private Integer rowNum;
	private String pickTicket;
	private Date sched_dlvry_date;
	private String errorType;
	private String errorMessage;

}
