package com.adidas.waaloscommon.dto.ateslottingdto;

import lombok.Data;

@Data
public class WorkGrpToZoneMapDto {

	private String zone;
	private String workGrp;
}
