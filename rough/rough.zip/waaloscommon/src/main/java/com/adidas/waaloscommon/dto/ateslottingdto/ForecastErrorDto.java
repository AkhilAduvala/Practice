package com.adidas.waaloscommon.dto.ateslottingdto;

import com.adidas.waaloscommon.dto.wmsdto.ErrorDto;

import lombok.Data;

@Data
public class ForecastErrorDto {

	private ErrorDto errorDto;
	private ForecastCurrentDto forecastCurrentDto;

}
