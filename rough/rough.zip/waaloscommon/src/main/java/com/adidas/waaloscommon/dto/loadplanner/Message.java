package com.adidas.waaloscommon.dto.loadplanner;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Message {
	
    private Shipment_With_Full_Orders[] Shipment_With_Full_Orders;

	public Shipment_With_Full_Orders[] getShipment_With_Full_Orders() {
		return Shipment_With_Full_Orders;
	}
	@XmlElement(name = "Shipment_With_Full_Orders", required = true, nillable = true)
	public void setShipment_With_Full_Orders(Shipment_With_Full_Orders[] shipment_With_Full_Orders) {
		Shipment_With_Full_Orders = shipment_With_Full_Orders;
	}
    
   

}
