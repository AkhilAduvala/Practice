package com.adidas.waaloscommon.dto.slottingdto;

import lombok.Data;

@Data
public class SlottingHostInfo {

	private String hostName;
	private String userName;
	private String password;
	private String runASlotPath;
	private String releaseSlotPath;
	
}
