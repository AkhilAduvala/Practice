package com.adidas.waaloscommon.dto.ateslottingdto;

import lombok.Data;

@Data
public class InventoryDto {

	private String skuId;
	private String locnId;
	private String dspSku;
	private String zone;
	private String style;
	private Integer pickLocationQty;
	
	
}
