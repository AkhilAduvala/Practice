package com.adidas.waaloscommon.dto.prewavereportdto;

import lombok.Data;

@Data
public class PWReplenDto {
	 private String locn_brcd;
	 private String style;
	 private String size_desc;
	 private String has_n_repl;
	 private String sku_n_repl;
}

