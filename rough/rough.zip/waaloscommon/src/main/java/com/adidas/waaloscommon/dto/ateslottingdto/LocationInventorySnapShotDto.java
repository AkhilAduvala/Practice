
package com.adidas.waaloscommon.dto.ateslottingdto;

import lombok.Data;

@Data
public class LocationInventorySnapShotDto {

	private String locnId;
	private String skuId;
	private Integer pickLocnQty;
	private String crushCode;
	private String dspSku;
	private String workGrp;
	private String locnPickSeq;
	private String locnClass;
	private String locnBrcd;
	private String style;
	private String zone;
	private String aisle;
	private String bay;
	private String level;
	private String posn;
	private String slotType;
	private Integer quantity; 
	private String prodType;
	private boolean inSeasion;
}
