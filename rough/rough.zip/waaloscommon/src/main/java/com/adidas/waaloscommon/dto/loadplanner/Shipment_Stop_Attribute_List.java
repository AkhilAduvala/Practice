package com.adidas.waaloscommon.dto.loadplanner;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Shipment_Stop_Attribute_List
{
    private String type;

    public String getType ()
    {
        return type;
    }
    @XmlElement(name = "type", required = true, nillable = true)
    public void setType (String type)
    {
        this.type = type;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [type = "+type+"]";
    }
}
