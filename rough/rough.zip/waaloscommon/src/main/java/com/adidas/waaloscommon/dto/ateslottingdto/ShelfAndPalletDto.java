package com.adidas.waaloscommon.dto.ateslottingdto;

import lombok.Data;

@Data
public class ShelfAndPalletDto {

	private int count;
	private String slotType;
}
