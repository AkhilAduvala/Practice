package com.adidas.waaloscommon.dto.loadplanner;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Stop_Action
{
    private String Dock_ID;
    private String Action_Code;

	private String[] TC_Order_ID;

    public String getDock_ID ()
    {
        return Dock_ID;
    }

    @XmlElement(name = "Dock_ID", required = true, nillable = true)
    public void setDock_ID (String Dock_ID)
    {
        this.Dock_ID = Dock_ID;
    }

    public String[] getTC_Order_ID ()
    {
        return TC_Order_ID;
    }

    @XmlElement(name = "TC_Order_ID", required = true, nillable = true)
    public void setTC_Order_ID (String[] TC_Order_ID)
    {
        this.TC_Order_ID = TC_Order_ID;
    }
    

    public String getAction_Code() {
		return Action_Code;
	}

    @XmlElement(name = "action_Code", required = true, nillable = true)
	public void setAction_Code(String action_Code) {
		Action_Code = action_Code;
	}


    @Override
    public String toString()
    {
        return "ClassPojo [Dock_ID = "+Dock_ID+", TC_Order_ID = "+TC_Order_ID+"]";
    }
}