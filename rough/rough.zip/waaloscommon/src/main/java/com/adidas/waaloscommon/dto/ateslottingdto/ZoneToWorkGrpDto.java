package com.adidas.waaloscommon.dto.ateslottingdto;

import lombok.Data;

@Data
public class ZoneToWorkGrpDto {

	private String grpAttr;
	private String workGrp;
}
