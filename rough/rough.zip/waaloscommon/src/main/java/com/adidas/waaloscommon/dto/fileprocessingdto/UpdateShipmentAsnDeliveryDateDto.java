package com.adidas.waaloscommon.dto.fileprocessingdto;

import java.util.Date;

import lombok.Data;

@Data
public class UpdateShipmentAsnDeliveryDateDto {
	
	private Integer rowNum;
	private String shipment;
	private Date deliveryDate;
	private String errorType;
	private String errorMessage;

}
