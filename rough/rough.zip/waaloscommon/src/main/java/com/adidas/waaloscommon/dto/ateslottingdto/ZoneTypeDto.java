package com.adidas.waaloscommon.dto.ateslottingdto;

import lombok.Data;

@Data
public class ZoneTypeDto {
 
	private int zoneTypeId;
	private String zoneType;
}
