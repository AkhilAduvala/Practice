package com.adidas.waaloscommon.dto.loadplanner;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Size1
{
    private String PlannedSize1;

    private String Size1UOM;

    private String ReceivedSize1;

    private String ShippedSize1;

    public String getPlannedSize1 ()
    {
        return PlannedSize1;
    }
    
    @XmlElement(name = "PlannedSize1", required = true, nillable = true)
    public void setPlannedSize1 (String PlannedSize1)
    {
        this.PlannedSize1 = PlannedSize1;
    }

    public String getSize1UOM ()
    {
        return Size1UOM;
    }

    @XmlElement(name = "Size1UOM", required = true, nillable = true)
    public void setSize1UOM (String Size1UOM)
    {
        this.Size1UOM = Size1UOM;
    }

    public String getReceivedSize1 ()
    {
        return ReceivedSize1;
    }

    @XmlElement(name = "ReceivedSize1", required = true, nillable = true)
    public void setReceivedSize1 (String ReceivedSize1)
    {
        this.ReceivedSize1 = ReceivedSize1;
    }

    public String getShippedSize1 ()
    {
        return ShippedSize1;
    }

    @XmlElement(name = "ShippedSize1", required = true, nillable = true)
    public void setShippedSize1 (String ShippedSize1)
    {
        this.ShippedSize1 = ShippedSize1;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [PlannedSize1 = "+PlannedSize1+", Size1UOM = "+Size1UOM+", ReceivedSize1 = "+ReceivedSize1+", ShippedSize1 = "+ShippedSize1+"]";
    }
}