package com.adidas.waaloscommon.dto.fileprocessingdto;

import lombok.Data;

@Data
public class BatchResultsDto {
	private int sucessCnt;
	private int failureCnt;	 
}
