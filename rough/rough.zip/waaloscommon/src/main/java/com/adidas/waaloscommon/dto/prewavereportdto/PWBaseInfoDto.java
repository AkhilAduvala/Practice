package com.adidas.waaloscommon.dto.prewavereportdto;

import java.util.List;
import java.util.Map;

import lombok.Data;

@Data
public class PWBaseInfoDto {
	private Map<String, Object> basegridData;
	private List<Map<String, Object>> installSpecificData;
	private Map<String, Object> prodTypeData;
}

