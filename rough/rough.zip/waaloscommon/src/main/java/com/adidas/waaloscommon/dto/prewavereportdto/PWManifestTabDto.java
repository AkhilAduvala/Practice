package com.adidas.waaloscommon.dto.prewavereportdto;

import lombok.Data;

@Data
public class PWManifestTabDto {

	private String pickWaveNbr;
	private String pktCntrlNbr;
	private String noShipTo;
	private String shipToCity;
	private String shipToState;
	private String shipToCntry;
	private String shipVia;
	private String noTel;
	private String noShipToContact;
	private String commitDate;
	private String collectAcctNbr;
	private String shipZip;
}
