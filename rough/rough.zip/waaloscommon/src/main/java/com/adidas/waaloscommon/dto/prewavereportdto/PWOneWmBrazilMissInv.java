package com.adidas.waaloscommon.dto.prewavereportdto;

import lombok.Data;

@Data
public class PWOneWmBrazilMissInv {

	 private String pickWaveNbr; 
	 private String pktCtrlNbr; 
	 private String itemId; 
	 private String itemName; 
	 private String itemStyleSfx; 
	 private String itemSizeDesc; 
	 private String codeDesc; 
	 private String invnAvail; 
	 private String skuNeedByOrder; 
	 private String skuNeedByTotal; 
	 private String missingTotal;
	 private String flag;
	 private String noInventory;
	 private String wsiDc1;
	 private String unAllocatable; 
}

