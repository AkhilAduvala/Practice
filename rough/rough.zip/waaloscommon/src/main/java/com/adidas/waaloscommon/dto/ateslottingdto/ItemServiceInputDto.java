package com.adidas.waaloscommon.dto.ateslottingdto;



import lombok.Data;

@Data
public class ItemServiceInputDto {

	String article;
	String sku;
}
