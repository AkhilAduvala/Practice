package com.adidas.waaloscommon.dto.ateslottingdto;

import lombok.Data;

@Data
public class UnSlottedSkuInfoDto {

	
	private Long lotId;
	private String dcName;
	private String sku;
	private String articleNo;
	private String msg;
	
}
