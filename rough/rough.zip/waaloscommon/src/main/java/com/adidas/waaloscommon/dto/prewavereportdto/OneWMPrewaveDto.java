package com.adidas.waaloscommon.dto.prewavereportdto;

import lombok.Data;

@Data
public class OneWMPrewaveDto {
	
	private String prewaveNumbers;
	private String waveType;

}
