package com.adidas.waaloscommon.dto.slottingdto;

import java.util.ArrayList;
import java.util.List;

import lombok.Data;

@Data
public class AutomatedSlottingLoaderExcelDto {
	List<AutomatedSlottingLoaderErrorDto> automatedSlottingLoaderErrorLst = new ArrayList<AutomatedSlottingLoaderErrorDto>();
	List<AutomatedSlottingLoaderDto> automatedSlottingLoaderSuccessLst = new ArrayList<AutomatedSlottingLoaderDto>();
	
}
