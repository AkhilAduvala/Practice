package com.adidas.waaloscommon.dto.reportsdto;

import lombok.Data;

@Data
public class MultipleZoneStylesDto {

	private String style;
	private int prodType;
	private int totalZones;
	private int dynamic;
	private int flow1;
	private int flow2;
	private int static1;
	private int static2;
	private int pigeonHole;
}
