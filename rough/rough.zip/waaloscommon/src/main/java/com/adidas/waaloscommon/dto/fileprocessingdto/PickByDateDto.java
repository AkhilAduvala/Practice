package com.adidas.waaloscommon.dto.fileprocessingdto;

import java.util.Date;


import lombok.Data;

@Data
public class PickByDateDto {
	private Integer rowNum;
	private String pickTicket;
	private String errorType;
	private String errorMessage;
}
