package com.adidas.waaloscommon.dto.prewavereportdto;

import lombok.Data;

@Data
public class PWEstimationsTabDto {
	private String int2Cases;
	private String int1Cases;
	private String int2Units;
	private String int150Cases;
	private String int150Units;	
	private String int1Units;	
	private String vasInt2Cases;
	private String vasInt2Units;	
	private String codeInfo;
	private String brand;
	private String channel;
	
}

