package com.adidas.waaloscommon.dto.prewavereportdto;

import lombok.Data;

@Data
public class Int2Dto {
	private String brand;
	private String channel;
	private String nonVasInt2Cases;
	private String nonVasInt2Units;
	private String int2VasCases;
	private String int2VasUnits;

}
