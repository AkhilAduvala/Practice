package com.adidas.waaloscommon.dto.prewavereportdto;

import lombok.Data;

@Data
public class TransPlanModeDto {
	 private String mode;
	 private String estCartons;
	 private String estVol;
	 private String estWt;
}

