package com.adidas.waaloscommon.dto.fileprocessingdto;

import lombok.Data;

@Data
public class TrackingUpdateLoaderDto {
	private Integer rowNum;
	private String lpn;
	private String trackingNbr;
	private String errorType;
	private String errorMessage;
	
	
	
}
