/*
 * Copyright (C) 2017 adidas AG.
 */
package com.adidas.waaloscommon.dto.prewavereportdto;

import java.util.List;

import lombok.Data;

/**
 * The persistent class for Ate Sz Slotting Data sources.
 * 
 */
@Data
public class NoPermDownloadDto {
private String jobcode;
private List<PWNoPermProfileDto> getNoPermProfileDto;
}