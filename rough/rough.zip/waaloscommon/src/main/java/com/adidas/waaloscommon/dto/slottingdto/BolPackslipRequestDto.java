package com.adidas.waaloscommon.dto.slottingdto;
import lombok.Data;

@Data
public class BolPackslipRequestDto {
	private String dcName;
	private String userName;
	private String uiPktCtrlNbr;
	private int pageSize;
	private int pageNumber;
	private String searchFlag;
	private String filePath;
	private String fileName;
}
