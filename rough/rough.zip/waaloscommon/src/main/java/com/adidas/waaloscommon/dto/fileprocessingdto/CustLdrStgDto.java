package com.adidas.waaloscommon.dto.fileprocessingdto;

import lombok.Data;

@Data
public class CustLdrStgDto {
	private String customerName;
	private String soldTo;
	private String custPoNbr;
	private String style;
	private String color;
	private String lot_Id;
}
