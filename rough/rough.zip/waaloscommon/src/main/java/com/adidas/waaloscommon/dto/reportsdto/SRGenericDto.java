package com.adidas.waaloscommon.dto.reportsdto;

import lombok.Data;

@Data
public class SRGenericDto {
	//pre-slot Zone Usage
	
	private String zone;
	private String workGroup;
	private int totalLocations;
	private int noOfUsedLocations;
	private int noOfEmptyLocations;
	private int utilizationBeforeSlot;
	private int noOfArticles;
	private Double avgSizeOfKits;
	private Double avgSkuPerArticle;
	private int maxForecastCaseQty;
	private int minForecastCaseQty;	
	private int reslotsOut;
	private int reslotsIn;
	private int deslotsOut;
	private int newSlots;
	private int noOfLocationsUsedAfterSlot;
	private int noOfEmptyAfterSlot;
	private int utilizationAfterSlot;	
	private Double avgSkuPerStylePost;
	
	//Multiple Zone Styles
		
	private String style;
	private int prodType;
	private int totalZones;
	private int dynamic;
	private int flow1;
	private int flow2;
	private int static1;
	private int static2;
	private int pigeonHole;
	
	//pigeon hole
	private String dspSku;
	private String dspLocation;
	
	//Wrongproducts in zone
	
	private String template;
/*	private String dspSku;
	private String dspLocation;*/
}
