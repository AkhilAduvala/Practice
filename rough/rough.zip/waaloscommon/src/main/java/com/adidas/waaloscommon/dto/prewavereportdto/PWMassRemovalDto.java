package com.adidas.waaloscommon.dto.prewavereportdto;

import lombok.Data;

@Data
public class PWMassRemovalDto {
	private String skuId;
	private String stdCaseQty;
	private String qty;
	private String totalQty;
	private String avail;
	private String codeDesc;
}

