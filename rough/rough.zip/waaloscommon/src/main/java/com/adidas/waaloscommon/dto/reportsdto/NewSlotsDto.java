package com.adidas.waaloscommon.dto.reportsdto;

import lombok.Data;

@Data
public class NewSlotsDto {
	private String locationId;
	private int newSlots;
	private String wrkGrp;
}
