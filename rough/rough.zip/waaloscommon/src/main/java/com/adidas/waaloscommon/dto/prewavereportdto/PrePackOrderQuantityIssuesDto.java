package com.adidas.waaloscommon.dto.prewavereportdto;

import lombok.Data;

@Data
public class PrePackOrderQuantityIssuesDto {
	
	private String waveNbr;
	private int orderId;
	private String tcOrderId;
	private String ppackGrpCode;
	private String assortNbr;
	private double ppackQty;
	private double orderQty;
	private String itemName;
	private double cartons;
	private double fraction;
	
}
