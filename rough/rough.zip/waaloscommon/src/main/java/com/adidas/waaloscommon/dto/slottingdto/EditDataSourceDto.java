package com.adidas.waaloscommon.dto.slottingdto;

import lombok.Data;

@Data
public class EditDataSourceDto {
	private String forecastFile;
	private int minSKU;
	private int maxSKU;
	private int defaultLocnsBlock;
	private int zoneLock;
	private String dcName;
	private String userName;
	private int templateId;
	private int available;
	private int	skuExcluded;
	private int	skusMoveLocation;
	private int	filledlocations;
	private int locationsUtilized;
	private int locationsRemaining;
	private int locationsWentNegative;
}
