package com.adidas.waaloscommon.constants;

import java.util.HashMap;
import java.util.Map;

public class WaalosConstants {
	public static final String TDC_DC = "TDC";
	public static final String BRAZIL_DC = "Brazil";
	public static final String US_DC = "US1";
	public static final String DC2_DC = "US2";
	public static final String CANADA_DC = "Montreal";
	public static final String SUZHOU_DC = "Suzhou";
	public static final String SUZHOU2_DC = "Suzhou2";
	public static final String PANAMA_DC = "Panama";
	public static final String KOREA_DC = "Korea";
	public static final String MEXICO_DC = "Mexico";
	public static final String CDC_DC = "CDC";
  	public static final String ONE_WMS_CDC_DC = "OneWMS-CDC";
  	public static final String LST_DC = "LST";
	public static final String TIANJIN_DC = "Tianjin";
	public static final String CHILE_DC = "Chile";
	public static final String TAIWAN_DC = "Taiwan";
	public static final String HONGKONG_DC = "HongKong";
	public static final String SEF2_DC = "Scheinfeld-2";
	public static final String SEF1_DC = "Scheinfeld-1";
	public static final String BDC_DC = "BDC";
	public static final String DTC_DC = "DTC";
	public static final String INFODB = "Infodb";
	public static final String TDCLMDB = "TDCLM";
	public static final String TJLMDB = "TianjinLM";
	public static final String SZLMDB = "SuzhouLM";
  	public static final String CDCLMDB = "CDCLM";
	public static final String BDCLMDB = "BDCLM";
	public static final String KOREALMDB = "KoreaLM";
	public static final String CHILELMDB = "ChileLM";
	public static final String THAILAND_DC = "Thailand";
	public static final String SINGAPORE_DC = "Singapore";
	public static final String PHILIPPINES_DC = "Philippines";
	public static final String ONE_WMS_PANAMA_DC = "OneWMS-Panama";
	public static final String ONE_WMS_BRAZIL_DC = "OneWMS-Brazil";
	public static final String ONE_WMS_US1 = "OneWMS-US1";
	public static final String ONE_WMS_US2 = "OneWMS-US2";	
	public static final String ONE_WMS_BDC_DC = "OneWMS-BDC";	
  	public static final String ONE_WMS_KOREA = "OneWMS-Korea";
	public static final String ONE_WMS_TDC = "OneWMS-TDC";		
	public static final String ONE_WMS_CHILE = "OneWMS-Chile";
	public static final String ONE_WMS_MEXICO = "OneWMS-Mexico";
	public static final String One_WMS_SUZHOU2_DC = "OneWMS-SZ2";
	public static final String One_WMS_TAIWAN_DC = "OneWMS-Taiwan";
	public static final String THAILAND_SLOT_DC = "Thailand_Slot";
	public static final String HONGKONG_SLOT_DC = "HongKong_Slot";
	public static final String SINGAPORE_SLOT_DC = "Singapore_Slot";
	public static final String PHILIPPINES_SLOT_DC = "Philippines_Slot";
  	public static final String IMMEDIATE_NEED_LOADER_SZX = "IMLSZX";
	public static final String TAIWAN_SLOT_DC = "Taiwan_Slot";
	public static final String ONE_WMS_BDC = "OneWMS-BDC";
	public static final String SLOT = "_Slot";
	public static final String CDC_CAMPUS_SOUTH = "CDC_CAMPUS_SOUTH";
	public static final String CDC_CSV_HEADER = "CSV_HEADER";
	public static final String DIMENSION_SUCCESS_STRING = "Dimension(s) of the SKU updated successfully";
	public static final String ERROR_STRING = "System failed. Please try again or contact WAALOS Support";
	public static final String DIMENSION_CHNGR = "Carton/Article cannot be null";
	public static final String CLEANUP_SUCCESS_STRING = "The selected PickTickets deleted successfully";
	public static final String CDC_REPORTING_DB = "CDC_REPORTING_DB";
	public static final String NO_DATA_FOUND = "No Data Found";
	public static final String WAALOS_JOB_SUCESS_STATUS = "COMPLETED";
	public static final String WAALOS_JOB_FAILURE_STATUS = "FAILED";
	public static final String WAALOS_DATE_CHANGER_SUCESS_MSG = "Date Changer date processed sucessfully";
	public static final String WAALOS_DATE_CHANGER_FAILURE_MSG = "Error in processing Date Changer Details";
	public static final String MAX_ROWS_ERROR_TYPE = "Maximum rows exceeded";
	public static final String MAX_ROWS_ERROR_DESCRIPTION = "A maximum of <> rows can be uploaded via a single excel file, please consider splitting the data into multiple excel files";

	public static final String INVALID_SHIPVIA_ERROR_DESCRIPTION = "Provided Ship Via is not present in the WMS database";
	public static final String INVALID_SHIPVIA_ERROR_TYPE = "Ship Via not found";
	public static final String INVALID_DATE_FORMAT_ERROR_TYPE = "Invalid date format";
	public static final String INVALID_DATE_FORMAT_ERROR_DESCRIPTION = "Invalid date format, expected format – DD.MM.YYYY";
	public static final String EXCEL_SHEET_INVALID_ERROR_TYPE = "Maximum sheets exceeded";
	public static final String EXCEL_SHEET_INVALID_ERROR_DESCRIPTION = "The upload excel should contain only one sheet at a time";
	public static final String MANDATORY_DATA_ERROR_TYPE = "Missing mandatory values";
    public static final String INVALID_DATA_VALUE = "In forcast file, Invalid data value";
    public static final String ALPHANUMERIC_SKU_QTY_VALUE = "SKU Quantity cannot be an alphanumeric value :"; 
	public static final String MANDATORY_DATA_ERROR_DESCRIPTION = "The mandatory value is missing in the excel file";
  	public static final String DUPLICATE_DATA_ERROR_TYPE = "Duplicate Values Present";
 	public static final String SKU_ID_MISSING="Sku Id value missing";
	public static final String MISC_SHORT_ALPHA_2_MISSING="Misc Short Alpha 2 value missing";
  	public static final String DUPLICATE_SKU_ID = "Sku_Id value is Duplicate";
	public static final String CARTONID_MISSING_ERROR_DESCRIPTION = "CartonId value is missing";
	public static final String ZRET_MISSING_ERROR_DESCRIPTION = "Zret value is missing";
  	public static final String MANDATORY_DATA_INVALID = "Invalid data";
	public static final String DATE_CHANGER_BATCH_URI = "http://10.136.242.63:5330/dateChanger/launchdatechanger";
	public static final String DATE_CHANGER_BATCH_URI_USERNAME = "?userame=";
	public static final String DATE_CHANGER_BATCH_URI_DCNAME = "&dcName=";
	public static final String DATE_CHANGER_BATCH_URI_LOTID = "&lotId=";
	public static final String FAILURE = "failure";
	public static final String SUCCESS = "success";
	public static final String EXCEL_DATE_FORMAT = "dd.MM.yyyy";
	public static final String DATABASE_DATE_FORMAT = "dd-MMM-yyyy";
	public static final String PRINTZPL_DATE_FORMAT = "dd.MM.yyyy HH:mm:ss";
	public static final Integer MAX_ROWS_ALLOWED = 50001;
	public static final String EXCEL_SHEET_NEW_FORMAT = "xlsx";
	public static final String EXCEL_SHEET_OLD_FORMAT = "xls";
	public static final String HELIOS = "Helios";
	public static final String PICKTICKET_MISSING_ERROR_DESCRIPTION = "Mandatory Pickticket value is missing";
	//Tracking Update
	public static final String TRACKING_UPDATE_REGEX = "^[a-zA-Z0-9]+$";	
	public static final String TRACKING_UPDATE_DEFAULT = "999.0";
	public static final String TRACKING_UPDATE_EMPTY = "0.0";
	public static final String TRACKING_UPDATE_DATE = "^[a-zA-Z0-9 :]*$";
	public static final String TRACKING_UPDATE_UPLOAD_SUCCESS = "Tracking Update data staged successfully";
	//Ecom Upload
	public static final String ECOM_UPLOAD_SUCCESS = "Ecom Upload data staged successfully";
	public static String CDC_TPL_LOADER_NAME ="CDC_TPL";
	public static String CDC_TPL_STGLOAD_FAILURE ="Failed";
	public static final String CDC_TPL_SHIPMENT_ID_MANDATORY = "SHIPMENT_ID column is mandatory. please check and update records";
	public static final String CDC_TPL_LOAD_IST_OPTIMIZATION_ID_MANDATORY ="LOAD_IST_OPTIMIZATION_ID column is mandatory. please check and update records";
	public static final String CDC_TPL_CARRIERSTRING_MANDATORY = "CARRIER STRING column is mandatory. please check and update records";
	public static final String CDC_TPL_TRANSPORT_MODE_MANDATORY = "TRANSPORT_MODE column should  be FLTL,PAR,GROUP. please check and update records";

	public static final String ERROR_TYPE = "Missing mandatory values";
	public static final String ERROR_DESCRIPTION = "The mandatory value is missing in the staging table";
	public static final String CUBISCAN_REGEX = "[+-]?([0-9]*[.])?[0-9]+";
	public static final String CUBISCAN_DEFAULT = "999.0";
	public static final String CUBISCAN_EMPTY = "0.0";
	public static final String CUBISCAN_EMPTY_REPLACE = "0.0";
	public static final String CUBISCAN_CDC = "CDC";
	public static final String CUBISCAN_DC1 = "US1";
	public static final String CUBISCAN_DC2 = "US2";
	public static final String TRACKING_UPDATE_DC1 = "PH";
	public static final String TRACKING_UPDATE_DC2 = "SG";
	public static final String TRACKING_UPDATE_DC3 = "TH";
	public static final String SOFTGOOD_IS_Y = "Y";
	public static final String SOFTGOOD_IS_N = "N";
	public static final String SOFTGOOD_IS_EMPTY = "";
	public static final String CUBISCAN_REPLACE_VALUE1 = "0";
	public static final String CUBISCAN_REPLACE_VALUE2 = "0.01";
	public static final String INVALID_SKU_BRCD = "sku_brcd not found";
	public static final String INVALID_SKU_BRCD_DESC = "sku_brcd is not present in the WMS database, Please check and upload again";
	public static final String CUBISCAN_UPLOAD_SUCCESS = "Cubiscan data staged successfully";
 	public static final String SORTATION_RULE_UPLOAD_SUCCESS = "Sortation Rule Upload Data staged successfully";
	public static final String REMOVE_DEDICATED_KEYWORD_SUCCESS = "Remove Dedicated Keyword Data staged successfully";
 	public static final String TRACKING_UPDATE_SUCCESS = "Tracking Update data staged successfully";
	public static final String INVALID_PICK_METHOD = "Pick Method not found";
	public static final String INVALID_PICK_METHOD_DESC = "Pick Method is not present in the System Codes in WMS database, Please check and upload again";
	public static final String PKT_PROFILE_UPLOAD_SUCCESS = "Pickticket Profile Loader staged successfully";
  	public static final String DUMMY_PKT_CREATION_SUCCESS = "Dummy PKT Creation Data staged successfully";
	public static final String PKT_PROFILE_REGEX = "[0-9]+";
	public static final String PKT_EARLIEST_DLVRY_TIME_VALUE = "";

	public static final String PKT_PROFILE_ID_PRESENT_MSG = "Pick ticket profile id is already present";
	public static final String PKT_PROFILE_ID_PRESENT_MSG_DESC = "Pick ticket profile id is already present in WMS database";

	public static final String PKT_UPLOAD_REGEX = "^[a-zA-Z0-9]+$";
	public static final String INCORRECT_DATA_ERROR_TYPE = "Incorrect data";
	public static final String INCORRECT_DATA_ERROR_DESCRIPTION = "Pkt Ctrl Nbr not found in Database";
	public static final String PKT_UPLOAD_SUCCESS = "Pick Ctrl numbers uploaded successfully";
	public static final String CNSL_LOC_UPDATE_SUCCESS = "consolidation location data uploaded successfully";
	public static final String ECOM_CARRIER_UPLOAD_SUCCESS = "Ecom Carrier Data uploaded successfully";
  	public static final String PRICE_TICKET_LOADER_SUCCESS = "Price Ticket Data Staged successfully";
	
	public static final String SHPMT_NBR_EMPTY_ERR_TYPE="SHIPMENT NBR is missing";
	public static final String SHPMT_NBR_ERR_DESC="SHIPMENTL NBR is missing";
	public static final String SHPMTNBR_DATA_ERROR_TYPE = "Incorrect data";
	public static final String SHPMTNBR_DATA_ERROR_DESCRIPTION ="Shpmt Nbr not found in Database";
	public static final String INCORRECT_ILPN_ERROR_DESCRIPTION = "ILPN details not found in Database";
  	public static final String ILPN="iLPN value missing";
	public static final String LOCN_DATA_ERROR_TYPE = "Incorrect Location data";
	public static final String LOCN_DATA_ERROR_DESCRIPTION ="Incorrect location details";	
	public static final String LOCN_AVBL_DATA_ERROR_TYPE ="Primary key available";
	public static final String LOCN_AVBL_DATA_ERROR_DESCRIPTION = "Location active in table";
  	public static final String INCORRECT_ITEM_ID_DESCRIPTION = "Item Id not found in Database";
  	public static final String INCORRECT_TCORDERID_ERROR_TYPE = "Incorrect data";
	public static final String INCORRECT_TCORDERID_ERROR_DESCRIPTION = "TcOrderId not found in Database";
	public static final String INCORRECT_SHIPVIA_ERROR_TYPE = "Incorrect data";
	public static final String INCORRECT_SHIPVIA_ERROR_DESCRIPTION = "shipVia not found in Database";
	public static final String PKT_CTRL_NBR_EMPTY_ERR_TYPE="PKT CTRL NBR is missing";
	public static final String PKT_CTRL_NBR_ERR_DESC="PKT CTRL NBR is missing";
	public static final String FLAG_EMPTY_ERR_TYPE="FLAG is missing";
	public static final String FLAG_EMPTY_ERR_DESC="FLAG is missing";
  	public static final String INCORRECT_DO_STATUS_WAVE_DESCRIPTION = "Invalid Order Status, order has been waved";
  	public static final String INCORRECT_ORDER_ID_DESCRIPTION = "Order Id not found in Database";
  	public static final String INCORRECT_ORDER_ID_MATCH_DESCRIPTION = "No Item is matched any order line on the order";
  	public static final String ACTUAL_PRICE_MISSING="Actual Price value missing";
  	public static final String ORDER_ID_MISSING="Order Id value missing";
  	public static final String INCORRECT_ITEM_ERROR_DESCRIPTION = "Item details not found in Database";
  	public static final String ITEM_BAR_CODE_MISSING="Either ITEM_BAR_CODE or the combination of ITEM_STYLE_SFX and ITEM_SIZE_DESC must be specified";
	public static final String INCORRECT_DATA_ERROR_DESCRIPTION_ORB_LINE_HAUL_SHIPVIA_INVALID = "Invalid Line Haul Ship Via";
  	public static final String ITEM_PROFILE_MISSING="Item Profile is missing";
  	public static final String INCORRECT_ITEMPROFILE_ERROR_DESCRIPTION = "Item Profile is invalid or duplicate value are present.";
	public static final String ROUTING_UPLOAD_SUCCESS = "Routing Upload Data staged successfully";
	public static final String TC_ORDER_ID = "TcOrderId value is missing";
  	public static final String INCORRECT_SKUID_ERROR_TYPE = "Incorrect data";
	public static final String INCORRECT_SKUID_ERROR_DESCRIPTION = "sKUiD not found in Database";
	public static final String INCORRECT_PKT_NMBR_ERROR_TYPE = "Incorrect data";
	public static final String INCORRECT_PKT_NMBR_ERROR_DESCRIPTION = "PKT Nmbr already exists in Database";

	public static final String PKT_SHIPMENT_UPLOAD_SUCCESS = "Pick Ticket data uploaded successfully";

	public static final String ERR9999_CODE = "ERR9999";
	public static final String ERR9999_MSG = "System failed. Please try again or contact WAALOS Support";
	public static final String ERR9002_CODE = "ERR9002";
	public static final String ERR9002_MSG = "Please verify database connectivity";
	public static final String ERR9003_CODE = "ERR9003";
	public static final String ERR9003_MSG = "DC Name is Empty";
	public static final String ERR9004_CODE = "ERR9004";
	public static final String ERR9004_MSG = "User Name is Empty";
	public static final String ERR9100_CODE ="ER9100";
  	public static final String ERR9100_MSG ="Failed to start Routing Wave";
  	public static final String ERR9200_CODE ="ERR9200";
  	public static final String ERR9200_MSG = "Failed to connect Database, please contact Waalos Support Team";
  	public static final String ERR9201_CODE ="ERR9201";
  	public static final String ERR9201_MSG = "Not able to count the Records for DB,please contact Waalos Support Team ";
  	public static final String ERR9202_CODE = "ERR9202";
  	public static final String ERR9202_MSG = "Error occured while updating the record status to 101";
  	public static final String ERR9203_CODE = "ERR9203";
  	public static final String ERR9203_MSG = "count of records is not equal to the records ready to process";
  	public static final String ERR9204_CODE = "ERR9204";
  	public static final String ERR9204_MSG = "File Download Success";
  	public static final String ERR9205_CODE = "ERR9205";
  	public static final String ERR9205_MSG = "No File Available";
  	public static final String ERR9206_CODE = "ERR9206";
  	public static final String ERR9206_MSG = "Records updated successfully";
  	public static final String ERR9207_CODE = "ERR9207";
  	public static final String ERR9207_MSG = "Failed to update Records, please contact waalos team";
  	
	public static final int FETCHSIZE_15 = 15;
	public static final int FETCHSIZE_0 = 0;
	public static final int FETCHSIZE_150 = 150;
	public static final int FETCHSIZE_100 = 100;
	public static final int FETCHSIZE_500 = 500;

	public static final String GET_HOLIDAYS_QUERY = "holidaysDisplayQuery";
	public static final String ADD_HOLIDAY_QUERY = "addHolidayQuery";
	public static final String DELETE_HOLIDAY_QUERY = "deleteHolidayQuery";
	public static final String UPDATE_HOLIDAY_QUERY = "updateHolidayQuery";
	public static final String HOLIDAYS_COUNT_QUERY = "holidaysCountQuery";

	public static final Map<Integer, String> dateChangerTemplateMap = new HashMap<Integer, String>();

	public static final Integer PICKTICKET_KEY = 1;
	public static final Integer PICKBY_DATE_KEY = 2;
	public static final Integer PGI_DATE_KEY = 3;
	public static final Integer REQUIRED_DATE_KEY = 4;
	public static final Integer CDD_KEY = 5;
	public static final Integer ORDER_TYPE_KEY = 6;
	public static final Integer SHIP_VIA_KEY = 7;
	static {
		dateChangerTemplateMap.put(PICKTICKET_KEY, "Pickticket");
		dateChangerTemplateMap.put(PICKBY_DATE_KEY, "Pick by Date");
		dateChangerTemplateMap.put(PGI_DATE_KEY, "PGI Date");
		dateChangerTemplateMap.put(REQUIRED_DATE_KEY, "Required date");
		dateChangerTemplateMap.put(CDD_KEY, "CDD");
		dateChangerTemplateMap.put(ORDER_TYPE_KEY, "Order Type");
		dateChangerTemplateMap.put(SHIP_VIA_KEY, "Ship Via");
	}

	public static final String INVALID_TEMPLATE = "Invalid Excel Template";
	public static final String INVALID_TEMPLATE_DESCRIPTION = "The excel headers in not in order,Please check and upload again";

	public static final String TEMPLATE_HEADER_EMPTY = "Header Is Empty";
	public static final String TEMPLATE_HEADER_EMPTY_DESCRIPTION = "One or more excel headers is not present,Please check and upload again";

	public static final String INVALID_PKT_CTRL_NUMBER_ERROR_TYPE = "PickTicket number not found";
	public static final String INVALID_PKT_CTRL_NUMBER_ERROR_DESCRIPTION = "PickTicket is not available in WMS database";

	public static final Map<Integer, String> pktProfileTemplateMap = new HashMap<Integer, String>();

	public static final Integer PKT_PROFILE_ID_KEY = 1;
	public static final Integer SHIPVIA_KEY = 2;
	public static final Integer FTSR_NBR_KEY = 3;
	public static final Integer EARLIEST_DLVRY_TIME_KEY = 4;

	static {
		pktProfileTemplateMap.put(PKT_PROFILE_ID_KEY, "PKT_PROFILE_ID");
		pktProfileTemplateMap.put(SHIPVIA_KEY, "SHIP_VIA");
		pktProfileTemplateMap.put(FTSR_NBR_KEY, "FTSR_NBR");
		pktProfileTemplateMap.put(EARLIEST_DLVRY_TIME_KEY, "EARLIEST_DLVRY_TIME");
	}

	public static final Map<Integer, String> cubiscanLoaderTemplateMap = new HashMap<Integer, String>();
	public static final Integer MWM_SKU_BRCD_KEY = 1;
	public static final Integer STND_UNIT_LEN_KEY = 2;
	public static final Integer STND_UNIT_WTH_KEY = 3;
	public static final Integer STND_UNIT_HGT_KEY = 4;
	public static final Integer STND_UNIT_VOL_KEY = 5;
	public static final Integer STND_UNIT_WGT_KEY = 6;
	public static final Integer STND_CS_LEN_KEY = 7;
	public static final Integer STND_CS_WTH_KEY = 8;
	public static final Integer STND_CS_HGT_KEY = 9;
	public static final Integer STND_CS_WGT_KEY = 10;
	public static final Integer STND_CS_VOL_KEY = 11;
	public static final Integer STND_CS_PCK_KEY = 12;
	public static final Integer CPP_KEY = 13;
	public static final Integer SOFT_GOOD_KEY = 14;

	static {
		cubiscanLoaderTemplateMap.put(MWM_SKU_BRCD_KEY, "MWM SKU_BRCD");
		cubiscanLoaderTemplateMap.put(STND_UNIT_LEN_KEY, "Stnd Unit Len");
		cubiscanLoaderTemplateMap.put(STND_UNIT_WTH_KEY, "Stnd Unit Wth");
		cubiscanLoaderTemplateMap.put(STND_UNIT_HGT_KEY, "Stnd Unit Hgt");
		cubiscanLoaderTemplateMap.put(STND_UNIT_VOL_KEY, "Stnd Unit Vol");
		cubiscanLoaderTemplateMap.put(STND_UNIT_WGT_KEY, "Stnd Unit Wgt");
		cubiscanLoaderTemplateMap.put(STND_CS_LEN_KEY, "Stnd Cs Len");
		cubiscanLoaderTemplateMap.put(STND_CS_WTH_KEY, "Stnd Cs Wth");
		cubiscanLoaderTemplateMap.put(STND_CS_HGT_KEY, "Stnd Cs Hgt");
		cubiscanLoaderTemplateMap.put(STND_CS_WGT_KEY, "Stnd Cs Wgt");
		cubiscanLoaderTemplateMap.put(STND_CS_VOL_KEY, "Stnd Cs Vol");
		cubiscanLoaderTemplateMap.put(STND_CS_PCK_KEY, "Stnd Cs Pck");
		cubiscanLoaderTemplateMap.put(CPP_KEY, "CPP");
		cubiscanLoaderTemplateMap.put(SOFT_GOOD_KEY, "Soft Good?");
	}

	public static int BATCH_SIZE_1K = 1000;
	public static final String IMM_NEEDS_STGLOAD_FAILURE = "Failed";
	public static final String IMM_NEEDS_STGLOAD_SUCCESS = "Immediate Needs Loader data staged successfully";
	public static final String INVALID_DATA_TYPE_ERROR = "Invalid data type";

	public static final String INVALID_CARTON_ERROR_DESCRIPTION = "Invalid value into Carton_Id column, please re-check and upload again";
	public static final String INVALID_CARTON_ERROR_TYPE = "Carton Id Already Exists";
	public static final String SUCCESS_RETAIL_LOADER = "Retail Returns loader updated Successfully";

	public static final Map<Integer, String> immNeedsTemplateMap = new HashMap<Integer, String>();
	public static final Integer PO_NBR_KEY = 1;
	public static final Integer SKU_BRCD_KEY = 2;
	public static final Integer QTY_TYPE_KEY = 3;
	public static final Integer QTY_REQD_KEY = 4;
	public static final Integer CMNT_KEY = 5;
	public static final Integer STYLE_KEY = 6;
	public static final Integer SIZE_DESC_KEY = 7;
	public static final Integer IMMD_NEED_PRTY_KEY = 8;
	static {
		immNeedsTemplateMap.put(PO_NBR_KEY, "PO_NBR");
		immNeedsTemplateMap.put(SKU_BRCD_KEY, "SKU_BRCD");
		immNeedsTemplateMap.put(QTY_TYPE_KEY, "QTY_TYPE");
		immNeedsTemplateMap.put(QTY_REQD_KEY, "QTY_REQD");
		immNeedsTemplateMap.put(CMNT_KEY, "CMNT");
		immNeedsTemplateMap.put(STYLE_KEY, "STYLE");
		immNeedsTemplateMap.put(SIZE_DESC_KEY, "SIZE_DESC");
		immNeedsTemplateMap.put(IMMD_NEED_PRTY_KEY, "IMMD_NEED_PRTY");
	}

	public static final Map<Integer, String> retailTemplateMap = new HashMap<Integer, String>();
	public static final Integer CARTONID_KEY = 1;
	public static final Integer ZRET_KEY = 2;
	static {
		retailTemplateMap.put(CARTONID_KEY, "CARTON_ID");
		retailTemplateMap.put(ZRET_KEY, "ZRET");
	}
	public static final String UPDATE_COUNT_MSG = " Record(s) Updated]";
	public static final String ADD_COUNT_MSG = " Record(s) Inserted]";
	public static final String DELETE_COUNT_MSG = " Record(s) Deleted]";

	public static final String INVALID_COLUMN_VALUE_ERROR = "Invalid data";

	public static final String INVALID_FILE_TYPE = "Only xls and xlsx are allowed";
	public static final String INVALID_FILE_TYPE_ERROR_DESCRIPTION = "The uploaded file is not an excel file";

	public static final String TRACKING_UPDATE_BIND_VALUE_YES = "YES";
	public static final String TRACKING_UPDATE_BIND_VALUE_NO = "NO";
	
	public static final String CUBISCAN_BIND_VALUE_YES = "YES";
	public static final String CUBISCAN_BIND_VALUE_NO = "NO";

	public static final Map<Integer, String> manualSlottingTemplateMap = new HashMap<Integer, String>();
	public static final Integer SKU_ID = 1;
	public static final Integer DSP_SKU = 2;
	public static final Integer SKU_BRCD = 3;
	public static final Integer FROM_LOCN_ID = 4;
	public static final Integer FROM_LOCN_BRCD = 5;
	public static final Integer FROM_DSP_LOCN = 6;
	public static final Integer NEED_IN_UNITS = 7;
	public static final Integer NEED_IN_CASES = 8;
	public static final Integer CHAIN = 9;
	public static final Integer ORDER = 10;
	public static final Integer TO_LOCN_ID = 11;
	public static final Integer TO_LOCN_BRCD = 12;
	public static final Integer TO_DSP_LOCN = 13;

	static {
		manualSlottingTemplateMap.put(SKU_ID, "SKU_ID");
		manualSlottingTemplateMap.put(DSP_SKU, "DSP_SKU");
		manualSlottingTemplateMap.put(SKU_BRCD, "SKU_BRCD");
		manualSlottingTemplateMap.put(FROM_LOCN_ID, "FROM LOCN_ID");
		manualSlottingTemplateMap.put(FROM_LOCN_BRCD, "FROM LOCN_BRCD");
		manualSlottingTemplateMap.put(FROM_DSP_LOCN, "FROM DSP_LOCN");
		manualSlottingTemplateMap.put(NEED_IN_UNITS, "NEED_IN_UNITS");
		manualSlottingTemplateMap.put(NEED_IN_CASES, "NEED_IN_CASES");
		manualSlottingTemplateMap.put(CHAIN, "CHAIN");
		manualSlottingTemplateMap.put(ORDER, "ORDER");
		manualSlottingTemplateMap.put(TO_LOCN_ID, "TO LOCN_ID");
		manualSlottingTemplateMap.put(TO_LOCN_BRCD, "TO LOCN_BRCD");
		manualSlottingTemplateMap.put(TO_DSP_LOCN, "TO DSP_LOCN");
	}

	public static final String MNLSLOTTING_PAD_TYPE_SPACE = "space";
	public static final String MNLSLOTTING_PAD_TYPE_ZEROS = "zeros";
	public static final String MNLSLOTTING_UNSLOTTED = "Unslotted";
	public static final String MNLSLOTTING_TRIPLE_ZERO = "000";
	public static final String MNLSLOTTING_CVALUE = "C    0000.99";
	public static final String MNLSLOTTING_FVALUE = "F000001000002000002HLW-0000999.99";
	public static final Integer MNLSLOTTING_PAD_FIFTEEN = 15;
	public static final Integer MNLSLOTTING_PAD_SIX = 6;
	public static final Integer MNLSLOTTING_PAD_FOUR = 4;
	public static final Integer MNLSLOTTING_PAD_TWENTYFIVE = 25;
	public static final String MNLSLOTTING_MOVE_VALUE = "move";
	public static final String MNLSLOTTING_OF_VALUE = " of";
	public static final String MNLSLOTTING_FILE_PATH = "/opt/home/waalos/waalostestfile.txt";
	public static final String MNLSLOTTING_SUCCESS = "SUCCESS";
	public static final String MNLSLOTTING_FAILURE = "FAILURE";
	public static final String MNLSLOTTING_NEW_LINE = "\n";
	public static final String MNLSLOTTING_STATUS = "Manual Slotting File Copied Successfully";
	public static final String MNLSLOTTING_FILENAME_SUCC = ".succ.";
	public static final String MNLSLOTTING_FILENAME_EXTENTION = ".txt";
	public static final String MNLSLOTTING_OUTPUT_FILE = "INPT_SLOTINFO_MOVE_LIST.txt";
	public static final String MNLSLOTTING_NEEDINUTS_DEF_VALUE = "1";
	public static final String MNLSLOTTING_NEEDINCASES_DEF_VALUE = "1";
	public static final Integer MNLSLOTTING_RANDOM_LOW = 1;
	public static final Integer MNLSLOTTING_RANDOM_HIGH = 100000;
	public static final String MNLSLOTTING_STND_CASE_QTY = "";
	public static final String MNLSLOTTING_DSP_SKU = "";
	public static final String MNLSLOTTING_FAILURE_STATUS = "Manual Slotting File Copy Failed";
	public static final String MNLSLOTTING_FILE_STATUS = "No Data to copy";
	public static final String OUTBOUND_PREP_VAS_CODE_ERROR_TYPE = "Blank VAS Instruction";
	public static final String OUTBOUND_PREP_VAS_CODE_ERROR_DESCRIPTION = "VAS Instruction Cannot Be Blank";

	public static final String OUTBOUND_PREP_VAS_CODE_ALPHANUMERIC_ERROR_TYPE = "VAS code is not alphanumeric";
	public static final String OUTBOUND_PREP_VAS_CODE_ALPHANUMERIC_ERROR_DESCRIPTION = "VAS Code Must Consist of Three Alpha-Num Characters";

	public static final String OUTBOUND_PREP_VAS_CODE_PRESENT_ERROR_TYPE = "VAS Code Already Exists";
	public static final String OUTBOUND_PREP_VAS_CODE_PRESENT_ERROR_DESCRIPTION = "VAS Code Already Exists in the database";

	public static final String OUTBOUND_PREP_VAS_CODE_SOLDTO_ERROR_TYPE = " VAS Code is Currently Assigned to a Sold To";
	public static final String OUTBOUND_PREP_VAS_CODE_SOLDTO_ERROR_DESCRIPTION = "VAS Code is Currently Assigned to a Sold To.  Please Remove Assignment Before Deleting VAS Code";

	public static final String OUTBOUND_PREP_VAS_CODE_NOTPRESENT_ERROR_TYPE = "VAS Code not present";
	public static final String OUTBOUND_PREP_VAS_CODE_NOTPRESENT_ERROR_DESCRIPTION = "VAS Code Does not Exist.  Please Add";

	public static final String OUTBOUND_PREP_UPLOAD_SUCCESS = "Outbound prep data staged successfully";
	public static final String OUTBOUND_PREP_LOADER_REGEX = "^[a-zA-Z0-9]{3}+$";
	public static final String OUTBOUND_PREP_LOADER_VALIDATION_SUCCESS_CODE = "WMS9214";
	public static final String OUTBOUND_PREP_DELETE_MESSAGE = "No VAS code to delete";
	public static final Map<Integer, String> outBoundPrepMap = new HashMap<Integer, String>();
	public static final Integer SOLD_TO = 1;
	public static final Integer VAS_CODE = 2;

	static {
		outBoundPrepMap.put(SOLD_TO, "SOLD TO");
		outBoundPrepMap.put(VAS_CODE, "VAS CODE");

	}

	public static final int FETCHSIZE_50 = 50;
	// Customers specific to Customer loader <Start>
	public static final String LZ_HANN = "LZH";
	public static final String EL_CORTE_INGLES = "ECI";
	public static final String EL_CORTE_INGLES_ONEWMS = "ONEECI";
	public static final String EL_CORTE_INGLES_SPLINSTRDESC_F0RMAT=".00";
	public static final String GENERIC_LOADER = "GLD";
	public static final String GENERIC_LOADER_ONEWMS = "ONEGLD";
	public static final String MODIS_SPORTZONE_LOADER_ONEWMS = "ONEMOD";
	public static final String GENERIC_LOADER_DN = "GDN";
	public static final String MIGROS_NON_CASELOT = "MIG";
	public static final String MIGROS_CASELOT = "MIC";
	public static final String HEINEKEN = "HEI";
	public static final String PRIMO = "PRI";
	public static final String UNITED_BRANDS = "UNI";
	public static final String ATHLETICUM = "ATH";
	public static final String DECATHLON = "DEC";
	public static final String DECATHLON_ONEWMS = "ONEDEC";
	public static final String LAREDOUTE = "LRD";
	public static final String LES3SUISSES = "L3S";
	public static final String OTTO = "OTT";
	public static final String BREUNINGER = "BRE";
	public static final String SDG_SHOP_DIRECT = "SDG";
	public static final String JD_WILLIAMS = "JDW";
	public static final String JD_WILLIAMS_ONEWMS = "ONEJDW";
	public static final String LZ_BW_DITZINGEN = "LZB";
	public static final String KARSTADT = "KAR";
	public static final String AKTIESPORT = "ATK";
	public static final String JAKOO = "JAK";
	public static final String FITZ = "FIT";
	public static final String BESSON = "BES";
	public static final String MANOR = "MNR";
	public static final String INTERSPORTNORTH = "INS";
	public static final String RUNNERS_NEED = "RUN";
	public static final String ASOS = "ASO";
	public static final String ASOS_ONEWMS = "ONEASO";
	public static final String WIGGLE = "WIG";
	public static final String WIGGLE_ONEWMS = "ONEWIG";
	public static final String HOUSE_OF_FRASER = "HOF";
	public static final String FOOTLOCKER = "FTL";
	public static final String FOOTLOCKER_ONEWMS = "ONEFTL";
	public static final String HnM = "HNM";
	public static final String HnM_ONEMWS = "ONEHNM";
	public static final String INTERSPORT = "INT";
	public static final String SPRINTER = "SPR";
	public static final String SPRINTER_ONEWMS = "ONESPR";
	public static final String PERRYSPORT = "PER";
	public static final String CISALFA = "CIS";
	public static final String CISALFA_ONEWMS = "ONECIS";
	public static final String PITTARELLO = "PIT";
	public static final String PITTARELLO_ONEWMS = "ONEPIT";
	public static final String SIEMENS = "SIE";
	public static final String KARSTADT_OFFPRICE = "KOF";
	public static final String EAST_ROMANIA = "ERL";
	public static final String EAST_BULGARIA = "EBL";
	public static final String UNICODE = "UTF8";
	public static final String GOLFHOUSE = "GLF";
	public static final String GOLFHOUSE_ONEWMS = "ONEGLF";
	public static final String DORMY = "DOR";
	public static final String RUSSIAM2M = "M2M";
  	public static final String PITTAROSSO = "PTR";
  	public static final String PITTAROSSO_ONEWMS = "ONEPTR";
	
	// Customers specific to Customer loader <End>

	public static final String MNLSLOTTING_NEEDINUNIT_DEF_VALUE = "0";
	public static final String PKT_PROFILE_LOADER_PAD_LENGTH = "5";
	public static final String PKT_PROFILE_FTSR_DEFAULT = "";

	public static final String BATCH_ERR_TYPE = "PV";
	public static final String BATCH_DATA_ERR_TYPE = "DV";

	public static final String BATCH_ERR_TYPE_STR = "Processing Validation";
	public static final String BATCH_DATA_ERR_TYPE_STR = "Data Validation";
	public static final String  TRACKING_UPDATE = "Tracking Update";
	public static final String  TRACKING_UPDATE_TH = "Tracking Update Thailand";
	
	//Loader name Constants  <Start>	
	public static final String CUSTOMER_SKU_UPLOAD = "Customer SKU Upload";		
	public static final String IMMD_NEEDS_LOADER = "Immd Needs Loader";
	public static final String OUTBOUND_PREP_LOADER = "Outbound Prep Loader";
	public static final String CUBISCAN_LOADERS = "Cubiscan Loader";
	public static final String ONEWMS_TDC_CUBISCAN_LOADERS = "OneWms TDC Cubiscan Loader";
  	public static final String ONEWMS_KOREA_CUBISCAN_LOADERS = "OneWms Korea Cubiscan Loader";
	public static final String PICKTICKET_PROFILE_LOADER = "Pick Ticket Profile Loader";
	public static final String DATECHANGE_LOADER = "Date Change Loader";

	public static final String MANUAL_SLOTTING = "Manual Slotting";

	public static final String RETAIL_RETURNS_LOADER = "Retail Return Loader";

	// Loader name Constants <End>
	public static final String MARK_SKU_LOADER = "MSU";
	public static final String MARK_SKU_LOADER_TWO = "MSU2";
	public static final String MARK_SKU_LOADER_THREE = "MSU3";
	public static final String RETAIL_RETURN_LOADER = "RRL";
	public static final String IMMEDIATE_NEED_LOADER = "IML";
	public static final String DATE_CHANGER_LOADER = "DCL";
	public static final String MANUAL_SLOTTING_LOADER = "MSL";
	public static final String LOAD_PLAN_UPLOAD_LOADER = "LPU";
	public static final String CUSTOMER_SKU_UPLOADER = "CSU";
	public static final String CUBISCAN_LOADER = "CBL";
	public static final String PKT_PROFILE_LOADER = "PPL";
	public static final String CUSTOMER_LOADER = "CUL";
	public static final String OTB_PREP_LOADER = "OPL";
	public static final String DATA_SIZE_TRANSLATOR = "DST";
	public static final String BGRADE_LABEL_MASTER_DATA = "BGLM";
	public static final String STOP_STYLE_DATA = "SSD";
	public static final String DEMAND_FORECAST_LOADER = "DFT";
	public static final String PICKTICKET_UPLOAD_LOADER = "PUL";
	public static final String INVOICE_LOADER = "IVL";
 	public static final String SORTATION_RULE_UPLOAD_LOADER = "SRUL";
	public static final String REMOVE_DEDICATED_KEYWORD_LOADER = "RDKL";
	public static final String CONSOLIDATION_LOCATION_UPDATE = "CLU";
	public static final String PICKTICKET_SHIPMENT_LOADER = "PSL";
	public static final String APPOINTMENT_FILE_UPLOAD = "APU";
	public static final String ECOM_CARRIER_UPDATE = "ECU";	
	public static final String ASN_LOADER = "ALU";
	public static final String SORT_BATCH_LOADER = "SBU";
	public static final String SORT_BATCH_ASN_LOADER = "SBA";	
	public static final String PRINTER_UPLOAD_LOADER = "NPC";
	public static final String BGRADE_CUSTOM_DATA = "CSTM";	
  	public static final String PRICE_TICKET_LOADER_ONE = "PTL1";
	public static final String PRICE_TICKET_LOADER_TWO = "PTL2";
  	public static final String PRICE_TICKET_LOADER = "PTL";
  	public static final String ITEM_BULK_UPDATE_LOADER_CD = "IBUL";
  	public static final String ITEM_BULK_UPDATE_LOADER = "IBUL";
	public static final String ROUTING_UPLOAD_LOADER = "RUL";
  	public static final String DUMMY_PKT_CREATION = "DPKTC";

	public static final String INVALID_PKT_CTRL_NBR_UNSELECTED_ERROR_TYPE = "Pickticket is not unselected";
	public static final String INVALID_PKT_CTRL_NBR_UNSELECTED_ERROR_DESCRIPTION = "Status of the pickticket is not unselected";
	public static final String OUTBOUND_PREP_STGLOAD_FAILURE = "Failed";
	public static final String CUBISCAN_STGLOAD_FAILURE = "Failed";
	public static final String PKT_PROFILE_STGLOAD_FAILURE = "Failed";
	public static final String MANUAL_SLOTTING_FAILURE = "Failed";
	public static final String INVOICE_LOADER_FAILURE = "Failed";
  	public static final String SORTATION_RULE_UPLOAD_LOADER_FAILURE = "Failed";
	public static final String CONSOLIDATION_LOC_UPDATE_STGLOAD_FAILURE = "Failed";
	public static final String PKT_SHIPMENT_STGLOAD_FAILURE = "Failed";
	public static final String ECOM_CARRIER_STGLOAD_FAILURE = "Failed";
	public static final String ASN_LOADER_STGLOAD_FAILURE = "Failed";
	public static final String SORT_BATCH_LOADER_STGLOAD_FAILURE = "Failed";
	public static final String PRINTER_UPLOAD_LOADER_STGLOAD_FAILURE = "Failed";
  	public static final String PRICE_TICKET_LOADER_FAILURE = "Failed";
  	public static final String ITEM_BULK_UPDATE_FAILURE = "Failed";

	public static final String PRINT_LABEL_CD = "PLCD01";
	public static final String PRINT_LABEL_CONSTATNS_MSG = "Error in generating Labels";

	public static final String ERR9037_CODE = "ERR9037";
	public static final String ERR9037_MSG = "Error while reading excel file";

	public static final String ERR9150_CODE = "ERR9150";
	public static final String ERR9150_MSG = "Excel template is not proper,Please check the headers and upload again";
	public static final String DATE_DELIMETER_SLASH = "/";
	public static final String DATE_DELIMETER_DOT = ".";
	public static final String UPDATECRD_EXCEL_DATE_FORMAT = "dd/MM/yyyy";

	public static final String PASSWORD = "waalos";
	public static final String ALGORTHIM = "PBEWithMD5AndDES";

	public static final String WAALOS_USER = "WAALOS";

	public static final String ERR5005_CODE = "ERR5005";
	public static final String ERR5005_MSG = "Error in executing JobScheduler Script";
	public static final String HEADER = "header";
	public static final String DMDFORECAST_INVALID_DATE_FORMAT_ERROR_TYPE = "Invalid date format";
	public static final String DMDFORECAST_INVALID_DATE_FORMAT_ERROR_DESCRIPTION = "Invalid date format, expected format – MM/dd/yyyy";

	public static final String DMD_EXCEL_DATE_FORMAT = "MM/dd/yyyy";
	public static final String DMD_DATABASE_DATE_FORMAT = "yyyy-MM-dd";
	public static final String DATE_DELIMETER_DMD = "DMD";
	public static final String DEMAND_FORECAST_SUCCESS_RSLTS = "DSF";
	public static final String UI_DATE_FORMAT = "yyyy-MM-dd";
	public static final String LABOUR_MANAGEMENT = "LM";

	//Declare the Headers in Chinese Language	
	public static final String BAR_CODE_NUMER = "條碼號碼";
	public static final String ITEM_NUMBER = "貨號"; 
	public static final String NUMBER_OF_PIECES = "件數";
	public static final String VOLUME = "才積";
	public static final String RECIPIENT_SHORT_NAME = "收件人簡稱";
	public static final String RECEIPT_DATE = "收貨日期";
	public static final String RECIPIENT_PHONE = "收件人電話"; 
	public static final String SENDER_CODE = "寄件人代碼";
	public static final String DESIGNATED_DELIVERY_DATE = "指定送達日"; 
	public static final String RECEIVING_POSTAL_CODE = "收件郵遞區號"; 
	public static final String RECIPIENT_ADDRESS = "收件地址";
	public static final String PAYMENT_METHOD =	"付款方式";
	public static final String PAYER = "付款人統編";
	public static final String PAYMENT_SHOP_CODE = "付款店代碼";
	public static final String COLLECTION_PAYMENT = "代收款";
	public static final String INVOICE_NO =	"發票號碼";
	public static final String REMARK_1 = "備註1"; 
	public static final String REMARK_2 = "備註2"; 
	public static final String REMARK_3 = "備註3"; 
	public static final String REMARK_4 = "備註4"; 
	public static final String REMARK_5 = "備註5"; 
	public static final String RESIDENTIAL = "住宅";
	
	public static final String WM_NEW_PLATFORM_ACTIVE = "WM_NEW_PLATFORM_ACTIVE";
	public static final String GET_TRANSLATION_BY_TYPE_AND_KEY_QRY = "translation.getTranslationByTypeAndKey";

	// One WMS Panama - Manual Slotting chnages -- Start
	public static final Integer MNLSLOTTING_PAD_100 = 100;
	public static final String MNLSLOTTING_NINE_ZERO = "000000000";
	public static final String MNLSLOTTING_LAST_VALUE = "0001 000000000000000000   -0000999.00";
	public static final String MNLSLOTTING_FLOAT_ZERO_VALUE = "     0000.00";
	// One WMS Panama - Manual Slotting changes -- Start

	public static final String XML_FORMAT = "xml";
	public static final String ERR9005_CODE = "ERR9005_CODE";
	public static final String ERR9005_MSG = "Could not generate file";
	public static final String ERR9006_CODE = "ERR9006_CODE";
	public static final String ERR9006_MSG = "The file is not uploaded";

	// TMS Upload Constant Variables
	public static final String SENDER_NO = "97165344";
	public static final String CUSTOMER_CODE = "04753160008_ADIDAS";
	public static final String NOT_APPLICATION = "NA";
	public static final String Order_BULK_UPDATE_LOADER_OneWMS_KOREA_CD = "OBULOKOREA";
	public static final String SUPPLIER_NAME = "Adidas DC";
	public static final String CARRIER_III = "ECOM_ASN";
	public static final String VERSION = "V2";
	public static final String FILE_END_NO = "001";
	public static final String UNDERSCORE = "_";
	public static final String DOUBLE_COMMA = "\",\"";
	public static final String COMMA = ",";
	public static final String FILE_EXTENSION = ".csv";
	public static final String NEXT_LINE = "\r\n";
	public static final String FRONT_DOUBLE_QUOTED = ",\"";
	public static final String BACK_DOUBLE_QUOTED = "\"";
	public static final String HEADER_DOUBLE_QUOTED = "\"";
	public static final String CARTON_NUMBER = "纸箱号码";
	public static final String NO_OF_PIECES = "件数";
	public static final String SHIP_TO_NAME = "发货到名";
	public static final String SHIPPING_DATE = "发货日期";
	public static final String SHIP_TO_PHONE = "送到电话";
	public static final String SENDERNO = "发件人号码";
	public static final String DELIVERY_DATE = "邮寄日期";
	public static final String ZIP_CODE = "邮政编码";
	public static final String ADDRESS1 = "地址1";
	public static final String ADDRESS2 = "地址2";
	public static final String ADDRESS3 = "地址3";
	public static final String VER = "版";
	
	public static final String INVENTORYSNAPSHOT_PH = "PH_MA_INV_";
	public static final String INVENTORYSNAPSHOT_SG = "SG_MA_INV_";
	public static final String INVENTORYSNAPSHOT_TH = "TH_MA_INV_";
	
	//Load Plan Upload
	public static final String LOAD_PLAN_UPLOAD = "Load Plan Upload";
	public static final String LOAD_PLANNER_UPLOAD_SUCCESS = "Load Planner Data Processed Successfully";
	public static final String LOADPLANNER_STGLOAD_FAILURE = "Failed";
	public static final String REMOVE_DEDICATED_KEYWORD_LOADER_FAILURE = "Failed";
	public static final String LOADPLANNER_UPLOAD_SUCCESS = "LoadPlanner data staged successfully";
	public static final String LOADNUMBER_EMPTY = "LoadNumber is Empty";
	public static final String PICKTKTNUMBER_EMPTY = "PickTicketNbr is empty";
	public static final String INVALID_PICKTICKET_NUMBER= "Pick ticket number not found";
	//Customer Sku upload changes
	public static final String CUST_SKU_UPLOAD_SUCCESS = "Customer SKU Upload data staged successfully";
	public static final String INVALID_STYLE_SIZE = "style or size details not found";
	public static final String INVALID_STYLE_SIZE_DESC = "style or size details is not present in the WMS database, Please check and upload again";
	public static final String CUST_SKU_STGLOAD_FAILURE = "Failed";
	public static final String XFER_WHSE_EMPTY_ERR_TYPE="XFER_WHSE is missing";
	public static final String XFER_WHSE_EMPTY_ERR_DESC="XFER_WHSE is missing";
	public static final String INCORRECT_XFER_WHSE_DESCRIPTION="Invalid XFER_WHSE";
  	public static final String INVALID_LENGTH_XFER_WHSE_DESCRIPTION="Invalid XFER_WHSE length";
	
	public static final String INVALID_DATA_ERROR_DESCRIPTION = "No Location[s] with active consol key found for Location barcode[s] ";
	public static final String ROUTING_UPLOAD_LOADER_FAILURE = "Failed";

	public static final String CARRIER1 = "shyangyih (Carrier 1)";
	public static final String CARRIER2 = "hct (Carrier 2)";
	public static final String CARRIER3 = "ecom_ASN (Carrier 3)";
	public static final String PH_CARRIER = "PH_RECON";
	public static final String SG_CARRIER = "SG_RECON";
	public static final String TH_CARRIER = "TH_RECON";	
	public static final String SINGAPORE_ECOM_DC = "Singapore_ECOM";
	public static final String ECOM = "_ECOM";
	public static final String PHILIPPINES_ECOM_DC = "Philippines_ECOM";
	public static final String	THAILAND_ECOM_DC = "Thailand_ECOM";
	public static final String FORECAST_UPLOAD_SUCESSFULLY="Forecast file data staged successfully";
	public static final String PROC_TYPE_NR = "3";
	public static final String PICK_LOCN_NR = "NR";
	public static final String MISC_ALPHA_NR = "";
	public static final String CONVEY_FLAG_NR = "Y";
	
	public static final String TC_ORDER_ID_MISSING="TC Order Id value missing";
	public static final String CUSTOMER_NAME_MISSING="Customer Name value missing";
	public static final String NOTA_FISCAL_MISSING="Nota Fiscal value missing";
	public static final String WAYBILL_SOLUTION_FAILURE = "Failed";
	public static final String WAYBILL_SOLUTION_SUCCESS = "WayBill Solution data staged successfully";
	public static final String  WAYBILL_SOLUTION = "WayBill Solution";
	
	public static final String INCORRECT_NEWSLOT_ERROR_DESCRIPTION ="SKU already slotted";
	public static final String INCORRECT_INVSLOT_ERROR_DESCRIPTION ="To be picked or To be filled exists for the SKU";
	
	public static final String VAS_PICK_ASSIGNMENT="VAS Pick Assignment";
	public static final String VAS_PICK_ASSIGNMENT_SUCCESS="VAS Pick Assignment data processed successfully";
	
	public static final String VAS_PICK_ASSIGNMENT_FAILED="VAS Pick Assignment data failed";
	public static final String VAS_PICK_ASSIGNMENT_ERR="cannot insert NULL into";
	public static final String VAS_PICK_ASSIGNMENT_ERR_MSG ="Invalid  seq nbr for pkt hdr";
  
    public static final String  CUB_IS_DEFAULT_ACTIVE = "CUB_IS_DEFAULT_ACTIVE";
	public static final String REGION_CHINA = "China";
	
	public static final String PREVIEWWAVE_DESELECT_UPLOAD_LOADER = "OPDL";
	public static final String PREVIEWWAVE_DESELECT_STGLOAD_FAILURE = "Failed";
	public static final String ORDER_UPLOAD_SUCCESS = "Orders uploaded successfully";
	public static final String INCORRECT_ORDERS_DESCRIPTION = "Order not found in Database";
	public static final String INCORRECT_ORDERS_STATUS = "Do_status is not equal to 115 ";
	public static final String INCORRECT_ORDERS_LINE_ITEM_STATUS = "Do_dtl_status is not equal to 115 ";
	public static final String INCORRECT_ORDERS_WAVE_NBR = "Wave number for order is null";
	
	public static final Integer FEDEX_CLTV_PADDING = 117;
	public static final String FEDEX_PAD_TYPE_SPACE = "space";
	
	public static final Integer FEDEX_GROUND_SHIPMENT_NBR_PADDING = 2;
	public static final Integer FEDEX_TRACKING_NBR_PADDING =21;
  
  	public static final String Order_BULK_UPDATE_LOADER_CD = "OBUL";
  	public static final String ORB_PROFILE_STGLOAD_FAILURE = "Failed";
  	public static final String INCORRECT_DATA_ERROR_DESCRIPTION_ORB = "Order# not found in Database";
	public static final String INCORRECT_DATA_ERROR_DESCRIPTION_ORB_NO_OCCUPANCY = "Order has been waved";
	public static final String INCORRECT_DATA_ERROR_DESCRIPTION_ORB_SHIPVIA_INVALID = "Invalid Ship Via";
	public static final String INVALID_DATA_VALUE_ORB = "Invalid data value";
  	public static final String ORDERBULK_UPLOAD_LOADER = "OBUL";
  	public static final String ORBUPLOAD_STGLOAD_SUCCESS = "Order Bulk Update Loader data staged successfully";
  
  	public static final String LOCKUNLOCK_SHIPMENT_LOADER = "Lock Unlock Shipment Loader";
  	public static final String SUZHOUX_DC = "SuzhouX";
	public static final String LOCKUNLOCK_SHIPMENT_UPLOAD_SUCCESS = "Lock-Unlock Shipment Loader staged successfully";
	public static final String INVALID_SHIPMENT_ERROR_TYPE = "Shipment not found";
	public static final String INVALID_SHIPMENT_ERROR_DESCRIPTION = "Provided Shipment is not present in the WMS database";
	public static final String INVALID_SHIPMENT_LOCKING_ERROR_TYPE = "Invalid Status for Locking";
	public static final String INVALID_SHIPMENT_UNLOCKING_ERROR_TYPE = "Invalid Status for Unlocking";
  	public static final String INVALID_SHIPMENT_ERROR_MSG = "Check the WMS Status of the Shipment.";
	public static final String LOCKUNLOCK_SHIPMENT_STGLOAD_FAILURE = "Failed";
	public static final String LOCKUNLOCK_SHIPMENT_STGLOAD_SUCCESS = "Lock-Unlock Shipment Loader data staged successfully";
	public static final String LOCKUNLOCK_SHIPMENT_INVALID_DATA_TYPE_ERROR = "Invalid data type";
  	public static final String DUMMY_PKT_CREATION_FAILURE = "Failed";


	public static final String IMMD_NEEDS_LOADER_SZX = "Immd Needs Loader SZX";
  
  	public static final String LOCK_UNLOCK_LDR = "LUS";
  
  	public static final String SORTERBATCH_UPLOAD_LOADER = "SBAX";
	public static final String SORT_BATCH_ASN_LOADER_SUZHOX_ONE = "SBAX1";
	public static final String SORT_BATCH_ASN_LOADER_SUZHOX_TWO = "SBAX2";
  
  	public static final String ORDER_PROFILE_LOADER_REGEX = "^[0-9]+$";
	public static final String INCORRECT_VALUE = "Invalid value";
  	public static final String INCORRECT_SPECIAL_CHARACTER = "Value contains special character";
	public static final String WAALOS_TEMPLATE_ERROR_TYPE = "Waalos Template not found";
	public static final String WAALOS_TEMPLATE_ERROR_DESCRIPTION = "Waalos Template must be created first";
  
  	public static final String NEGATIVE_DATA_ERROR_TYPE = "Negative values present";
	public static final String NEGATIVE_DATA_ERROR_MISSING = "Negative values are present in the excel. Please check and correct the data";
  	public static final String ASN_LOADER_SZX = "ALUSZX";
	public static final String ERR9008_CODE = "ERR9008";
	public static final String ERR9008_MSG = "ASN Number not found. Please check and try again or contact WAALOS Support";
  	public static final String ERR9007_CODE = "ERR9007";
	public static final String ERR9007_MSG = "Invalid ASN Status. Please check and try again or contact WAALOS Support";
	
	public static final String SHIPMENT_ASN_DELIIVERYDATE_LOADER= "Shipment Asn Delivery Date Loader";
	public static final String SHIPMENT_DATA_MISSING_ERROR_TYPE = "Mandatory ASN or Shipment data value is missing";
	public static final String SHIPMENT_DATA_VALIDATION_ERROR_TYPE = "Shipment Validation Failed";
	public static final String UPDATE_SHIP_ASN_DD_STGLOAD_FAILURE = "Failed";
	public static final String WAALOS_UPDATE_SHIPMENT_DELIVERY_DATE_LOADER_FAILURE_MSG = "Error in processing Date Changer Details";
	public static final String ASN_DELIVARY_DATE_LOADER = "USADDL";
	
	public static final String SCI_EMAIL_LOADER_NAME= "SCI Email Loader";
	public static final String SCI_EMAIL_STGLOAD_FAILURE = "Failed";
	public static final String WAALOS_SCI_LOADER_FAILURE_MSG = "Error in processing loader Details";
	public static final String SCI_EMAIL_ERROR_TYPE = "All columns are Mandatory , please check the records uploaded";
	public static final String SCI_EMAIL_LOADER_JOBCODE = "SCIEL";	

	public static final String CUSTOMER_ON_HOLD_LOADER_JOBCODE = "COHK";
	public static final String CUSTOMER_ON_HOLD_LOADER_NAME ="Customer on Hold";
	public static final String CUSTOMER_ON_HOLD_DESCRIPTION_ERROR ="Excel file missing Descriptions"; 
	public static final String CUSTOMER_ON_HOLD_ERROR_TYPE ="Record already exists"; 
	public static final String CDC_TPL_LOADER_JOBCODE = "CDCTPL";
	
	//Trucktor
	public static final String TRUCK_TOR_SECURITY_DATA = "SEC";
	public static final String TRUCK_TOR_SECURITY_DATA_CUR = "SEC_CURR";
	public static final String TRUCK_TOR_SECURITY_DATA_BTW = "SEC_BTW";
	public static final String TRUCK_TOR_INBOUND_DATA_CUR = "INB_CURR";
	public static final String TRUCK_TOR_INBOUND_DATA_BTW = "INB_BTW";
	public static final String TRUCK_TOR_OUTBOUND_DATA_BTW = "OUTBOUNDD_BTW";
	public static final String TRUCK_TOR_OUTBOUND_DATA_NXT = "OUTBOUNDD_NXT";
	public static final String TRUCK_TOR_OUTBOUND_DATA_CUR = "OUTBOUND_CURR";
	public static final String TRUCK_TOR_INBOUND_DATA = "INB";
	public static final String TRUCK_TOR_OUTBOUND_DATA = "OUT";
	public static final String TRUCK_TOR_RETURN_EQUIP = "RET";
	public static final String TRUCK_TOR_IMPORT = "TOR";
	public static final String TRUCK_TOR_OUTBOUND_IMPORT = "TOROUT";
	public static final String TRUCK_TOR_INBOUND_IMPORT = "TORINB";
	public static final String TRUCK_TOR_RETURN_IMPORT = "TORRET";
	
	public static final String TRACKING_UPDATE_LOADERS = "TUL";
	public static final String QUANTITY_UPDATE_LOADERS = "QUL";

	public static final String AUTOMATION_SLOTTING_UPDATE_LOADERS = "AUL";
	public static final String CHOOSE_FILE_ERROR_TYPE = "DV";
	public static final String AUTOMATION_SLOTTING_SUCCESS = "AUTOMATION_SLOTTING staged successfully";
	
	public static final String ERR9036_CODE = "ERR9036";
	public static final String ERR9036_MSG = "Excel Sheet is empty";
	public static final String INSERT_INVALID_CHOOSE_FILE_RECS = "insertInvalidChooseFileRec";

	//inventory Grade 
	public static final String INVENTORY_GRADE_JOBCODE = "IGC";
}
