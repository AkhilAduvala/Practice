package com.adidas.waaloscommon.dto.reportsdto;

import lombok.Data;

@Data
public class ReslotsOutDto {
	private String locationId;
	private int reslotsOut;
	private String wrkGrp;
}
