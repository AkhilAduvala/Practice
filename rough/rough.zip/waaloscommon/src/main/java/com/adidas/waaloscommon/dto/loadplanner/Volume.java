package com.adidas.waaloscommon.dto.loadplanner;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Volume
{
    private String ReceivedVolume;

    private String ShippedVolume;

    private String PlannedVolume;

    private String VolumeUOM;

    public String getReceivedVolume ()
    {
        return ReceivedVolume;
    }

    @XmlElement(name = "ReceivedVolume", required = true, nillable = true)
    public void setReceivedVolume (String ReceivedVolume)
    {
        this.ReceivedVolume = ReceivedVolume;
    }

    public String getShippedVolume ()
    {
        return ShippedVolume;
    }

    @XmlElement(name = "ShippedVolume", required = true, nillable = true)
    public void setShippedVolume (String ShippedVolume)
    {
        this.ShippedVolume = ShippedVolume;
    }

    public String getPlannedVolume ()
    {
        return PlannedVolume;
    }

    @XmlElement(name = "PlannedVolume", required = true, nillable = true)
    public void setPlannedVolume (String PlannedVolume)
    {
        this.PlannedVolume = PlannedVolume;
    }

    public String getVolumeUOM ()
    {
        return VolumeUOM;
    }

    @XmlElement(name = "VolumeUOM", required = true, nillable = true)
    public void setVolumeUOM (String VolumeUOM)
    {
        this.VolumeUOM = VolumeUOM;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [ReceivedVolume = "+ReceivedVolume+", ShippedVolume = "+ShippedVolume+", PlannedVolume = "+PlannedVolume+", VolumeUOM = "+VolumeUOM+"]";
    }
}
