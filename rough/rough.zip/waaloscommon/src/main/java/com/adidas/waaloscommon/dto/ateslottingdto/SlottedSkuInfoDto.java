package com.adidas.waaloscommon.dto.ateslottingdto;

import lombok.Data;

@Data
public class SlottedSkuInfoDto {

	private Long lotId;
	private String sku;
	private String dspSku;
	private String fromLocnId;
	private String toLocnId;
	private Integer quantity;
	private Double averageSkuFcActivePickqty;
	private String zoneType;
	private String zone;
	private String slottingType;
	private String style;
	private String division;
	
}
