package com.adidas.waaloscommon.dto.fileprocessingdto;

import lombok.Data;

@Data
public class CustomerLoaderNbrDto {
	public String pktCtrlNbr;// tc_orderID
	public String ftsrNbr;//BILL_TO_FACILITY_NAME
	public String orderId;
}
