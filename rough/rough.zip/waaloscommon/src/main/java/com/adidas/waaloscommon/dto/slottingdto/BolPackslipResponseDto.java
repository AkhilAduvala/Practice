package com.adidas.waaloscommon.dto.slottingdto;
import lombok.Data;

@Data
public class BolPackslipResponseDto {
	private String tcOrderId;
	private String tcShipmentId;
	private String createDateTime;
	private String pathname;
}
