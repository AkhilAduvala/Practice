package com.adidas.waaloscommon.dto.loadplanner;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Loading_Method
{
    private String Is_FILO;

    private String Is_Coolest_At_Nose;

    public String getIs_FILO ()
    {
        return Is_FILO;
    }
    @XmlElement(name = "Is_FILO", required = true, nillable = true)
    public void setIs_FILO (String Is_FILO)
    {
        this.Is_FILO = Is_FILO;
    }

    public String getIs_Coolest_At_Nose ()
    {
        return Is_Coolest_At_Nose;
    }
    @XmlElement(name = "Is_Coolest_At_Nose", required = true, nillable = true)
    public void setIs_Coolest_At_Nose (String Is_Coolest_At_Nose)
    {
        this.Is_Coolest_At_Nose = Is_Coolest_At_Nose;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Is_FILO = "+Is_FILO+", Is_Coolest_At_Nose = "+Is_Coolest_At_Nose+"]";
    }
}
