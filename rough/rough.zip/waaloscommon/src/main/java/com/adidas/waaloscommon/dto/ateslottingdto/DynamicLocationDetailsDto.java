package com.adidas.waaloscommon.dto.ateslottingdto;

import lombok.Data;

@Data
public class DynamicLocationDetailsDto {

	private int totalLocns;
	private int totalSkus;
	private int palletLocns;
	private int shelfLocns;
	private int shelfSkus;
	private int pallateSkus;
	private boolean enoughDynamicLocns;
}
