/*
 * Copyright (C) 2017 adidas AG.
 */
package com.adidas.waaloscommon.dto.slottingdto;

import java.util.List;

import lombok.Data;

/**
 * The persistent class for Ate Sz Slotting Data sources.
 * 
 */
@Data
public class GetItemGrpDtlsDto {
	private List<SzForecastDropdownDto> productTypes;
	private List<SzForecastDropdownDto> productGroups;
	private List<SzForecastDropdownDto> putawayTypes;
	private List<SzForecastDropdownDto> productSubGroups;
	private List<SzForecastDropdownDto> saBusinessSegments;
	private List<SzItemGrpCartonDto> cartonTypes;
	private List<SzItemGrpSeasonDto> seasonYrs;
}
