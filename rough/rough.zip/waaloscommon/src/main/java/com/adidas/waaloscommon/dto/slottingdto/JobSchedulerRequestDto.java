package com.adidas.waaloscommon.dto.slottingdto;

import lombok.Data;

@Data
public class JobSchedulerRequestDto {

	private int pageNumber;
	private int pageSize;
	private String dcName ;
	private String userName;
	
}
