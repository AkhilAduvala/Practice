package com.adidas.waaloscommon.dto.loadplanner;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Weight
{
    private String PlannedWeight;

    private String WeightUOM;

    private String ReceivedWeight;

    private String ShippedWeight;

    public String getPlannedWeight ()
    {
        return PlannedWeight;
    }

    @XmlElement(name = "PlannedWeight", required = true, nillable = true)
    public void setPlannedWeight (String PlannedWeight)
    {
        this.PlannedWeight = PlannedWeight;
    }

    public String getWeightUOM ()
    {
        return WeightUOM;
    }

    @XmlElement(name = "WeightUOM", required = true, nillable = true)
    public void setWeightUOM (String WeightUOM)
    {
        this.WeightUOM = WeightUOM;
    }

    public String getReceivedWeight ()
    {
        return ReceivedWeight;
    }

    @XmlElement(name = "ReceivedWeight", required = true, nillable = true)
    public void setReceivedWeight (String ReceivedWeight)
    {
        this.ReceivedWeight = ReceivedWeight;
    }

    public String getShippedWeight ()
    {
        return ShippedWeight;
    }

    @XmlElement(name = "ShippedWeight", required = true, nillable = true)
    public void setShippedWeight (String ShippedWeight)
    {
        this.ShippedWeight = ShippedWeight;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [PlannedWeight = "+PlannedWeight+", WeightUOM = "+WeightUOM+", ReceivedWeight = "+ReceivedWeight+", ShippedWeight = "+ShippedWeight+"]";
    }
}