package com.adidas.waaloscommon.dto.prewavereportdto;

import lombok.Data;

@Data
public class PWNoPermProfileDto {
	 private String ship_wave_nbr; 
	 private String pkt_ctrl_nbr; 
	 private String dsp_sku; 
	 private String season; 
	 private String style; 
	 private String style_sfx; 
	 private String color; 
	 private String color_sfx; 
	 private String size_desc; 
	 private String sku_brcd; 
	 private String slot_misc_4; 
	 private String prod_type; 
	 private String prod_group; 
	 private String std_case_qty; 
	 private String carton_type; 
  	 private String itemName;
	 private String itemStyleSfx;
	 private String itemSizeDesc;
	 private String itemBrcd;
	 private String prodType;
	 private String brand;
	 private String qty;
	
}

