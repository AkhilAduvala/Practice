/*
 * Copyright (C) 2017 adidas AG.
 */
package com.adidas.waaloscommon.dto.slottingdto;

import java.util.List;

import lombok.Data;

/**
 * The persistent class for Ate Sz Slotting Data sources.
 * 
 */
@Data
public class GetAssociateZonesLstDto {
private List<GetAssociateZonesDto> getAssociateZonesDtoLst;
private List<GetAssociateZonesDto> checkedAisles;
}
