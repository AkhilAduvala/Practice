package com.adidas.waaloscommon.dto.fileprocessingdto;

import lombok.Data;

@Data
public class OutboundPrepDto {
	private int rowNum;
	private String soldTo;
	private String vasCode;
	private String userId;
	private String errorMessage;
	private String errorType;
}
