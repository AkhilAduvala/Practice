package com.adidas.waaloscommon.dto.ateslottingdto;

import lombok.Data;

@Data
public class LocnIdDspLocnWorkGrpDto {
	
	private String locnId;
	private String dspLocn;
	private String workGrp;
	
}
