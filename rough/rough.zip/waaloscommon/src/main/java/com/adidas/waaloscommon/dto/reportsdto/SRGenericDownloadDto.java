package com.adidas.waaloscommon.dto.reportsdto;

import java.util.List;


import lombok.Data;
@Data
public class SRGenericDownloadDto {
	private String jobcode;
	private List<SRGenericDto> getSRGenericDto;
}
