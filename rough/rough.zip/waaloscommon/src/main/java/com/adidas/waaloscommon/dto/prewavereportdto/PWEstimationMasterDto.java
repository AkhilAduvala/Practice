package com.adidas.waaloscommon.dto.prewavereportdto;

import lombok.Data;

@Data
public class PWEstimationMasterDto {

	private String waveNbr;
	private String totalOrders;
	private String estLpn;
	private String totalUnits;
	private Integer singleUnits;
	private Integer multiUnits;
	private Integer ecomSingleUnits;
	private Integer ecomMultiUnits;
	private String vasUntis;
	private String conveyableUnits;
	private String nonConveyableUntis;
	private Integer int50SorterUnits;
	private Integer sortInt50Units; //adding this for OneWMS-BDC logic, for all other DC(s) query hard coded as 0
	private Integer nonSortInt50Units; //adding this for OneWMS-BDC logic, for all other DC(s) query hard coded as 0
	private Integer int2Units;
	private Integer int150Units;
	private Integer int1Units;
	private Integer int1Lpn;
	private Integer int1Yield;
	private Integer vasEasy;
	private Integer vasMedium;
	private Integer vasHard;

}
