package com.adidas.waaloscommon.dto.reportsdto;

import lombok.Data;

@Data
public class DeslotsOutDto {
	private String locationId;
	private int deslotsOut;
	private String wrkGrp;
}
