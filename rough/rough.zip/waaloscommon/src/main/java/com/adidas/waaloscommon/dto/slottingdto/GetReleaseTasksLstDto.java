/*
 * Copyright (C) 2017 adidas AG.
 */
package com.adidas.waaloscommon.dto.slottingdto;

import lombok.Data;

/**
 * The persistent class for Ate Sz Slotting Data sources.
 * 
 */
@Data
public class GetReleaseTasksLstDto {
	private String fromZone;
	private String fromLocn;
	private String dispalySku;
	private String actlInventory;
	private String toZone;
	private String toLocn;
	private String batch;
	private String stepValue;
	private String nullValue;
	private String nullVal1;
	private String prodType;
	private String locnPick;
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		GetReleaseTasksLstDto other = (GetReleaseTasksLstDto) obj;
		if (actlInventory == null) {
			if (other.actlInventory != null)
				return false;
		} else if (!actlInventory.equals(other.actlInventory))
			return false;
		if (batch == null) {
			if (other.batch != null)
				return false;
		} else if (!batch.equals(other.batch))
			return false;
		if (dispalySku == null) {
			if (other.dispalySku != null)
				return false;
		} else if (!dispalySku.equals(other.dispalySku))
			return false;
		if (fromLocn == null) {
			if (other.fromLocn != null)
				return false;
		} else if (!fromLocn.equals(other.fromLocn))
			return false;
		if (fromZone == null) {
			if (other.fromZone != null)
				return false;
		} else if (!fromZone.equals(other.fromZone))
			return false;
		if (locnPick == null) {
			if (other.locnPick != null)
				return false;
		} else if (!locnPick.equals(other.locnPick))
			return false;
		if (nullVal1 == null) {
			if (other.nullVal1 != null)
				return false;
		} else if (!nullVal1.equals(other.nullVal1))
			return false;
		if (nullValue == null) {
			if (other.nullValue != null)
				return false;
		} else if (!nullValue.equals(other.nullValue))
			return false;
		if (prodType == null) {
			if (other.prodType != null)
				return false;
		} else if (!prodType.equals(other.prodType))
			return false;
		if (stepValue == null) {
			if (other.stepValue != null)
				return false;
		} else if (!stepValue.equals(other.stepValue))
			return false;
		if (toLocn == null) {
			if (other.toLocn != null)
				return false;
		} else if (!toLocn.equals(other.toLocn))
			return false;
		if (toZone == null) {
			if (other.toZone != null)
				return false;
		} else if (!toZone.equals(other.toZone))
			return false;
		return true;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((actlInventory == null) ? 0 : actlInventory.hashCode());
		result = prime * result + ((batch == null) ? 0 : batch.hashCode());
		result = prime * result + ((dispalySku == null) ? 0 : dispalySku.hashCode());
		result = prime * result + ((fromLocn == null) ? 0 : fromLocn.hashCode());
		result = prime * result + ((fromZone == null) ? 0 : fromZone.hashCode());
		result = prime * result + ((locnPick == null) ? 0 : locnPick.hashCode());
		result = prime * result + ((nullVal1 == null) ? 0 : nullVal1.hashCode());
		result = prime * result + ((nullValue == null) ? 0 : nullValue.hashCode());
		result = prime * result + ((prodType == null) ? 0 : prodType.hashCode());
		result = prime * result + ((stepValue == null) ? 0 : stepValue.hashCode());
		result = prime * result + ((toLocn == null) ? 0 : toLocn.hashCode());
		result = prime * result + ((toZone == null) ? 0 : toZone.hashCode());
		return result;
	}
}
