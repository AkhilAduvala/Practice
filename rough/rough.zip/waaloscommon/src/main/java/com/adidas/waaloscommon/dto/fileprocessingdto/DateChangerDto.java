package com.adidas.waaloscommon.dto.fileprocessingdto;

import java.util.Date;

import lombok.Data;

@Data
public class DateChangerDto {
	
	private Integer rowNum;
	private String pickTicket;
	private Date pickByDate;
	private Date pgiDate;
	private Date requiredDate;
	private Date cdd;
	private String orderType;
	private String shipVia;
	private String errorMessage; 
	private String errorType;
	

}
