package com.adidas.waaloscommon.dto.loadplanner;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Line_Item
{
    private String Product_Class_Code;

    private String TC_Master_Order_ID;

    private String RRC;

    private String Description;

    private String Original_Budgeted_Cost;

    private String Prod_Sched_Ref_Number;

    private String LengthUOM;

    private String Commodity_Code;

    private String Reference_Field2;

    private String Reference_Field3;

    private String Delivery_Ref_Number;

    private String MV_Currency_Code;

    private String Reference_Field1;

    private String SKU_Name;

    private String UN_Number;

    private String Protection_Level_Code;

    private String Package_Type;

    private String Is_Hazmat;

    private String Actual_Cost;

    private String Package_Type_Instance;

    private String Height;

    private String Epc_Tracking_Number;

    private String Width;

    private String Diameter;

    private String DiameterUOM;

    private String Standard_Pack_Quantity;

    private String MV_Size_UOM;

    private String WidthUOM;

    private String Unit_Monetary_Value;

    private String Pickup_Ref_Number;

    private String Standard_Case_Quantity;

    private Quantity Quantity;

    private String Ext_Sys_Line_Item_ID;

    private String MO_Line_Item_ID;

    private String Total_Monetary_Value;

    private Weight Weight;

    private String Parent_Line_Item_ID;

    private Size2 Size2;

    private Size1 Size1;

    private String Length;

    private Volume Volume;

    private String HeightUOM;

    private String RTS_Detail_ID;

    private String Currency_Code;

    private String RTS_ID;

    private String Line_Item_ID;

    private String Budgeted_Cost;

    public String getProduct_Class_Code ()
    {
        return Product_Class_Code;
    }

    @XmlElement(name = "Product_Class_Code", required = true, nillable = true)
    public void setProduct_Class_Code (String Product_Class_Code)
    {
        this.Product_Class_Code = Product_Class_Code;
    }

    public String getTC_Master_Order_ID ()
    {
        return TC_Master_Order_ID;
    }

    @XmlElement(name = "TC_Master_Order_ID", required = true, nillable = true)
    public void setTC_Master_Order_ID (String TC_Master_Order_ID)
    {
        this.TC_Master_Order_ID = TC_Master_Order_ID;
    }

    public String getRRC ()
    {
        return RRC;
    }

    @XmlElement(name = "RRC", required = true, nillable = true)
    public void setRRC (String RRC)
    {
        this.RRC = RRC;
    }

    public String getDescription ()
    {
        return Description;
    }

    @XmlElement(name = "Description", required = true, nillable = true)
    public void setDescription (String Description)
    {
        this.Description = Description;
    }

    public String getOriginal_Budgeted_Cost ()
    {
        return Original_Budgeted_Cost;
    }

    @XmlElement(name = "Original_Budgeted_Cost", required = true, nillable = true)
    public void setOriginal_Budgeted_Cost (String Original_Budgeted_Cost)
    {
        this.Original_Budgeted_Cost = Original_Budgeted_Cost;
    }

    public String getProd_Sched_Ref_Number ()
    {
        return Prod_Sched_Ref_Number;
    }

    @XmlElement(name = "Prod_Sched_Ref_Number", required = true, nillable = true)
    public void setProd_Sched_Ref_Number (String Prod_Sched_Ref_Number)
    {
        this.Prod_Sched_Ref_Number = Prod_Sched_Ref_Number;
    }

    public String getLengthUOM ()
    {
        return LengthUOM;
    }

    @XmlElement(name = "LengthUOM", required = true, nillable = true)
    public void setLengthUOM (String LengthUOM)
    {
        this.LengthUOM = LengthUOM;
    }

    public String getCommodity_Code ()
    {
        return Commodity_Code;
    }

    @XmlElement(name = "Commodity_Code", required = true, nillable = true)
    public void setCommodity_Code (String Commodity_Code)
    {
        this.Commodity_Code = Commodity_Code;
    }

    public String getReference_Field2 ()
    {
        return Reference_Field2;
    }

    @XmlElement(name = "Reference_Field2", required = true, nillable = true)
    public void setReference_Field2 (String Reference_Field2)
    {
        this.Reference_Field2 = Reference_Field2;
    }

    public String getReference_Field3 ()
    {
        return Reference_Field3;
    }

    @XmlElement(name = "Reference_Field3", required = true, nillable = true)
    public void setReference_Field3 (String Reference_Field3)
    {
        this.Reference_Field3 = Reference_Field3;
    }

    public String getDelivery_Ref_Number ()
    {
        return Delivery_Ref_Number;
    }

    @XmlElement(name = "Delivery_Ref_Number", required = true, nillable = true)
    public void setDelivery_Ref_Number (String Delivery_Ref_Number)
    {
        this.Delivery_Ref_Number = Delivery_Ref_Number;
    }

    public String getMV_Currency_Code ()
    {
        return MV_Currency_Code;
    }

    @XmlElement(name = "MV_Currency_Code", required = true, nillable = true)
    public void setMV_Currency_Code (String MV_Currency_Code)
    {
        this.MV_Currency_Code = MV_Currency_Code;
    }

    public String getReference_Field1 ()
    {
        return Reference_Field1;
    }

    @XmlElement(name = "Reference_Field1", required = true, nillable = true)
    public void setReference_Field1 (String Reference_Field1)
    {
        this.Reference_Field1 = Reference_Field1;
    }

    public String getSKU_Name ()
    {
        return SKU_Name;
    }

    @XmlElement(name = "SKU_Name", required = true, nillable = true)
    public void setSKU_Name (String SKU_Name)
    {
        this.SKU_Name = SKU_Name;
    }

    public String getUN_Number ()
    {
        return UN_Number;
    }

    @XmlElement(name = "UN_Number", required = true, nillable = true)
    public void setUN_Number (String UN_Number)
    {
        this.UN_Number = UN_Number;
    }

    public String getProtection_Level_Code ()
    {
        return Protection_Level_Code;
    }

    @XmlElement(name = "Protection_Level_Code", required = true, nillable = true)
    public void setProtection_Level_Code (String Protection_Level_Code)
    {
        this.Protection_Level_Code = Protection_Level_Code;
    }

    public String getPackage_Type ()
    {
        return Package_Type;
    }

    @XmlElement(name = "Package_Type", required = true, nillable = true)
    public void setPackage_Type (String Package_Type)
    {
        this.Package_Type = Package_Type;
    }

    public String getIs_Hazmat ()
    {
        return Is_Hazmat;
    }

    @XmlElement(name = "Is_Hazmat", required = true, nillable = true)
    public void setIs_Hazmat (String Is_Hazmat)
    {
        this.Is_Hazmat = Is_Hazmat;
    }

    public String getActual_Cost ()
    {
        return Actual_Cost;
    }

    @XmlElement(name = "Actual_Cost", required = true, nillable = true)
    public void setActual_Cost (String Actual_Cost)
    {
        this.Actual_Cost = Actual_Cost;
    }

    public String getPackage_Type_Instance ()
    {
        return Package_Type_Instance;
    }

    @XmlElement(name = "Package_Type_Instance", required = true, nillable = true)
    public void setPackage_Type_Instance (String Package_Type_Instance)
    {
        this.Package_Type_Instance = Package_Type_Instance;
    }

    public String getHeight ()
    {
        return Height;
    }

    @XmlElement(name = "Height", required = true, nillable = true)
    public void setHeight (String Height)
    {
        this.Height = Height;
    }

    public String getEpc_Tracking_Number ()
    {
        return Epc_Tracking_Number;
    }

    @XmlElement(name = "Epc_Tracking_Number", required = true, nillable = true)
    public void setEpc_Tracking_Number (String Epc_Tracking_Number)
    {
        this.Epc_Tracking_Number = Epc_Tracking_Number;
    }

    public String getWidth ()
    {
        return Width;
    }

    @XmlElement(name = "Width", required = true, nillable = true)
    public void setWidth (String Width)
    {
        this.Width = Width;
    }

    public String getDiameter ()
    {
        return Diameter;
    }

    @XmlElement(name = "Diameter", required = true, nillable = true)
    public void setDiameter (String Diameter)
    {
        this.Diameter = Diameter;
    }

    public String getDiameterUOM ()
    {
        return DiameterUOM;
    }

    @XmlElement(name = "DiameterUOM", required = true, nillable = true)
    public void setDiameterUOM (String DiameterUOM)
    {
        this.DiameterUOM = DiameterUOM;
    }

    public String getStandard_Pack_Quantity ()
    {
        return Standard_Pack_Quantity;
    }

    @XmlElement(name = "Standard_Pack_Quantity", required = true, nillable = true)
    public void setStandard_Pack_Quantity (String Standard_Pack_Quantity)
    {
        this.Standard_Pack_Quantity = Standard_Pack_Quantity;
    }

    public String getMV_Size_UOM ()
    {
        return MV_Size_UOM;
    }

    @XmlElement(name = "MV_Size_UOM", required = true, nillable = true)
    public void setMV_Size_UOM (String MV_Size_UOM)
    {
        this.MV_Size_UOM = MV_Size_UOM;
    }

    public String getWidthUOM ()
    {
        return WidthUOM;
    }

    @XmlElement(name = "WidthUOM", required = true, nillable = true)
    public void setWidthUOM (String WidthUOM)
    {
        this.WidthUOM = WidthUOM;
    }

    public String getUnit_Monetary_Value ()
    {
        return Unit_Monetary_Value;
    }

    @XmlElement(name = "Unit_Monetary_Value", required = true, nillable = true)
    public void setUnit_Monetary_Value (String Unit_Monetary_Value)
    {
        this.Unit_Monetary_Value = Unit_Monetary_Value;
    }

    public String getPickup_Ref_Number ()
    {
        return Pickup_Ref_Number;
    }

    @XmlElement(name = "Pickup_Ref_Number", required = true, nillable = true)
    public void setPickup_Ref_Number (String Pickup_Ref_Number)
    {
        this.Pickup_Ref_Number = Pickup_Ref_Number;
    }

    public String getStandard_Case_Quantity ()
    {
        return Standard_Case_Quantity;
    }

    @XmlElement(name = "Standard_Case_Quantity", required = true, nillable = true)
    public void setStandard_Case_Quantity (String Standard_Case_Quantity)
    {
        this.Standard_Case_Quantity = Standard_Case_Quantity;
    }

    public Quantity getQuantity ()
    {
        return Quantity;
    }

    @XmlElement(name = "Quantity", required = true, nillable = true)
    public void setQuantity (Quantity Quantity)
    {
        this.Quantity = Quantity;
    }

    public String getExt_Sys_Line_Item_ID ()
    {
        return Ext_Sys_Line_Item_ID;
    }

    @XmlElement(name = "Ext_Sys_Line_Item_ID", required = true, nillable = true)
    public void setExt_Sys_Line_Item_ID (String Ext_Sys_Line_Item_ID)
    {
        this.Ext_Sys_Line_Item_ID = Ext_Sys_Line_Item_ID;
    }

    public String getMO_Line_Item_ID ()
    {
        return MO_Line_Item_ID;
    }

    @XmlElement(name = "MO_Line_Item_ID", required = true, nillable = true)
    public void setMO_Line_Item_ID (String MO_Line_Item_ID)
    {
        this.MO_Line_Item_ID = MO_Line_Item_ID;
    }

    public String getTotal_Monetary_Value ()
    {
        return Total_Monetary_Value;
    }

    @XmlElement(name = "Total_Monetary_Value", required = true, nillable = true)
    public void setTotal_Monetary_Value (String Total_Monetary_Value)
    {
        this.Total_Monetary_Value = Total_Monetary_Value;
    }

    public Weight getWeight ()
    {
        return Weight;
    }

    @XmlElement(name = "Weight", required = true, nillable = true)
    public void setWeight (Weight Weight)
    {
        this.Weight = Weight;
    }

    public String getParent_Line_Item_ID ()
    {
        return Parent_Line_Item_ID;
    }

    @XmlElement(name = "Parent_Line_Item_ID", required = true, nillable = true)
    public void setParent_Line_Item_ID (String Parent_Line_Item_ID)
    {
        this.Parent_Line_Item_ID = Parent_Line_Item_ID;
    }

    public Size2 getSize2 ()
    {
        return Size2;
    }

    @XmlElement(name = "Size2", required = true, nillable = true)
    public void setSize2 (Size2 Size2)
    {
        this.Size2 = Size2;
    }

    public Size1 getSize1 ()
    {
        return Size1;
    }

    @XmlElement(name = "Size1", required = true, nillable = true)
    public void setSize1 (Size1 Size1)
    {
        this.Size1 = Size1;
    }

    public String getLength ()
    {
        return Length;
    }

    @XmlElement(name = "Length", required = true, nillable = true)
    public void setLength (String Length)
    {
        this.Length = Length;
    }

    public Volume getVolume ()
    {
        return Volume;
    }

    @XmlElement(name = "Volume", required = true, nillable = true)
    public void setVolume (Volume Volume)
    {
        this.Volume = Volume;
    }

    public String getHeightUOM ()
    {
        return HeightUOM;
    }

    @XmlElement(name = "HeightUOM", required = true, nillable = true)
    public void setHeightUOM (String HeightUOM)
    {
        this.HeightUOM = HeightUOM;
    }

    public String getRTS_Detail_ID ()
    {
        return RTS_Detail_ID;
    }

    @XmlElement(name = "RTS_Detail_ID", required = true, nillable = true)
    public void setRTS_Detail_ID (String RTS_Detail_ID)
    {
        this.RTS_Detail_ID = RTS_Detail_ID;
    }

    public String getCurrency_Code ()
    {
        return Currency_Code;
    }

    @XmlElement(name = "Currency_Code", required = true, nillable = true)
    public void setCurrency_Code (String Currency_Code)
    {
        this.Currency_Code = Currency_Code;
    }

    public String getRTS_ID ()
    {
        return RTS_ID;
    }

    @XmlElement(name = "RTS_ID", required = true, nillable = true)
    public void setRTS_ID (String RTS_ID)
    {
        this.RTS_ID = RTS_ID;
    }

    public String getLine_Item_ID ()
    {
        return Line_Item_ID;
    }

    @XmlElement(name = "Line_Item_ID", required = true, nillable = true)
    public void setLine_Item_ID (String Line_Item_ID)
    {
        this.Line_Item_ID = Line_Item_ID;
    }

    public String getBudgeted_Cost ()
    {
        return Budgeted_Cost;
    }

    @XmlElement(name = "Budgeted_Cost", required = true, nillable = true)
    public void setBudgeted_Cost (String Budgeted_Cost)
    {
        this.Budgeted_Cost = Budgeted_Cost;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Product_Class_Code = "+Product_Class_Code+", TC_Master_Order_ID = "+TC_Master_Order_ID+", RRC = "+RRC+", Description = "+Description+", Original_Budgeted_Cost = "+Original_Budgeted_Cost+", Prod_Sched_Ref_Number = "+Prod_Sched_Ref_Number+", LengthUOM = "+LengthUOM+", Commodity_Code = "+Commodity_Code+", Reference_Field2 = "+Reference_Field2+", Reference_Field3 = "+Reference_Field3+", Delivery_Ref_Number = "+Delivery_Ref_Number+", MV_Currency_Code = "+MV_Currency_Code+", Reference_Field1 = "+Reference_Field1+", SKU_Name = "+SKU_Name+", UN_Number = "+UN_Number+", Protection_Level_Code = "+Protection_Level_Code+", Package_Type = "+Package_Type+", Is_Hazmat = "+Is_Hazmat+", Actual_Cost = "+Actual_Cost+", Package_Type_Instance = "+Package_Type_Instance+", Height = "+Height+", Epc_Tracking_Number = "+Epc_Tracking_Number+", Width = "+Width+", Diameter = "+Diameter+", DiameterUOM = "+DiameterUOM+", Standard_Pack_Quantity = "+Standard_Pack_Quantity+", MV_Size_UOM = "+MV_Size_UOM+", WidthUOM = "+WidthUOM+", Unit_Monetary_Value = "+Unit_Monetary_Value+", Pickup_Ref_Number = "+Pickup_Ref_Number+", Standard_Case_Quantity = "+Standard_Case_Quantity+", Quantity = "+Quantity+", Ext_Sys_Line_Item_ID = "+Ext_Sys_Line_Item_ID+", MO_Line_Item_ID = "+MO_Line_Item_ID+", Total_Monetary_Value = "+Total_Monetary_Value+", Weight = "+Weight+", Parent_Line_Item_ID = "+Parent_Line_Item_ID+", Size2 = "+Size2+", Size1 = "+Size1+", Length = "+Length+", Volume = "+Volume+", HeightUOM = "+HeightUOM+", RTS_Detail_ID = "+RTS_Detail_ID+", Currency_Code = "+Currency_Code+", RTS_ID = "+RTS_ID+", Line_Item_ID = "+Line_Item_ID+", Budgeted_Cost = "+Budgeted_Cost+"]";
    }
}