package com.adidas.waaloscommon.dto.slottingdto;

import lombok.Data;

@Data
public class DownloadPdfDto {

	private String pdfFilePath;
	
}
