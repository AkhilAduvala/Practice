package com.adidas.waaloscommon.dto.ateslottingdto;



import java.util.Date;

import lombok.Data;

@Data
public class ForecastCurrentDto {

	private String skuId;
	private String sku;
	private String dspSku;
	private String articleNo;
	private int stdCaseQty;
	private Integer skuFcActivePickqty;
	private Boolean isValid = Boolean.TRUE;
	private Integer estSkuHits;
	private Integer maxPick;
	private Integer avgPick;
	private Integer brandCode;
	private String division;
	private String launchDate;
	private String dcName;
	private String userName;
	private String createdBy;
	private Date createdDate;
	private String updatedBy;
	private String updatedDate;	
	private Integer rownum;
	private Long lotId;
	private String errorType;
	private String errorMessage;	
	private String userId;	
	private String grpType;
	private Long sizeNo4;
	private Long sizeNo5;
	private int pickLocnQty;
	
}
