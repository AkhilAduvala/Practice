/*
 * Copyright (C) 2017 adidas AG.
 */
package com.adidas.waaloscommon.dto.slottingdto;

import lombok.Data;

/**
 * The persistent class for Pkt Pdf Archive.
 * 
 */
@Data
public class PktPdfArchiveRequestDto {
	private String dcName;
	private String userName;
	private String uiPktCtrlNbr;
	private int pageSize;
	private int pageNumber;
	private String searchFlag;
	private String filePath;
	private String fileName;
}
