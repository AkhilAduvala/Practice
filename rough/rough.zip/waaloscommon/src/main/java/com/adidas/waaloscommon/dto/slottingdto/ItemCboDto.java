package com.adidas.waaloscommon.dto.slottingdto;

import lombok.Data;

@Data
public class ItemCboDto {

	private String itemStyleSfx;
	private String itemSizeDesc;
	private String itemName;
	private String brand;
	private String prodType;
	
	
}
