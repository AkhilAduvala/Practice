package com.adidas.waaloscommon.dto.prewavereportdto;

import lombok.Data;

@Data
public class EstimationsTotalDto {

	private String waveNbr;
	private String totalUnits;
	private String sortable;
	private String nonSortable;
	private String estLpn;
}
