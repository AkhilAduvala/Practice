package com.adidas.waaloscommon.dto.prewavereportdto;

import java.util.List;

import lombok.Data;

@Data
public class PWGenericDto {
	// NoPermProfile,Missing Inventory
	private List<String> orders;
	private String ship_wave_nbr;
	private String pkt_ctrl_nbr;
	private String dsp_sku;
	private String season;
	private String style;
	private String style_sfx;
	private String color;
	private String color_sfx;
	private String size_desc;
	private String sku_brcd;
	private String slot_misc_4;
	private String prod_type;
	private String prod_group;
	private String std_case_qty;
	private String carton_type;
	private String pick_wave_nbr;
	private String code_desc;
	private String qty;
  
  	 private String itemBrcd;
	 private String prodType;
	// Estimations
	private String int2Cases;
	private String int1Cases;
	private String int2Units;
	private String int150Cases;
	private String int150Units;
	private String int1Units;
	private String vasInt2Cases;
	private String vasInt2Units;
	private String codeInfo;

	// Dimension issues
	// private String pick_wave_nbr;
	private String pickticket;
	// private String dsp_sku;
	// private String season;
	// String style;
	// private String style_sfx;
	// private String color;
	// private String color_sfx;
	// private String size_desc;
	private String oper_code;
	// private String sku_brcd;
	private String unit_ht;
	private String unit_len;
	private String unit_width;
	private String unit_wt;
	private String unit_vol;
	private String std_case_ht;
	private String std_case_len;
	private String std_case_width;
	private String std_case_vol;
	private String std_case_wt;
	// private String std_case_qty;
	private String std_plt_qty;

	// Manifest
	private String pickWaveNbr;
	private String pktCntrlNbr;
	private String noShipTo;
	private String shipToCity;
	private String shipToState;
	private String shipToCntry;
	private String shipVia;
	private String noTel;
	private String noShipToContact;
	private String commitDate;
	private String collectAcctNbr;
	private String shipZip;
	private String pktCtrlNbr;
	private String itemId;
	private String itemName;
	private String itemStyleSfx;
	private String itemSizeDesc;
	private String codeDesc;
	private String invnAvail;
	private String skuNeedByOrder;
	private String skuNeedByTotal;
	private String missingTotal;
	private String flag;
	private String noInventory;
	private String wsiDc1;
	private String unAllocatable;
	
	private String brand;
	private String channel;
	
	
}
