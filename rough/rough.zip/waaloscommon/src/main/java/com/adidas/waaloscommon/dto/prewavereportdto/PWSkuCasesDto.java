package com.adidas.waaloscommon.dto.prewavereportdto;

import lombok.Data;

@Data
public class PWSkuCasesDto {
	private String caseNum;
	private String skuId;
	private String skuAttr1;
	private String actlQty;
}

