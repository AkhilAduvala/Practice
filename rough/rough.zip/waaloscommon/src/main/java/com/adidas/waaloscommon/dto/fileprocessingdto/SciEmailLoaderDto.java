package com.adidas.waaloscommon.dto.fileprocessingdto;

import lombok.Data;

@Data
public class SciEmailLoaderDto {
	
	private Integer rowNum;
	private String brand;
	private String soldTo;
	private String ShipTo;
	private String mailAddress;
	private String flag;
	private String errorType;
	private String errorMessage;

}
