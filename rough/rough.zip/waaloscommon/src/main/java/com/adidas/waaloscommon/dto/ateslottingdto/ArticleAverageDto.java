package com.adidas.waaloscommon.dto.ateslottingdto;

import java.util.Date;
import java.util.List;
import java.util.OptionalDouble;

import lombok.Data;

@Data
public class ArticleAverageDto {

	
	private String articleNo;
	private List<ForecastCurrentDto> forecastCurrentDto;
	private Double averageSkuFcActivePickqty;
	private Integer skuCount;
	private String zoneType;	
	private String prodType;
	private boolean hasShelfSkus=false;
}
