package com.adidas.waaloscommon.dto.slottingdto;

import lombok.Data;

@Data
public class DataSourceDto {

	private int templateId;
	private String name;
	private String hasAssoc;
	private String hasTasks;
	private String lastCompletionTime;
	private String status;
	private String dcName;
	private String userName;
	private String workType;
	private String zone;
	private String prodType;
	private String comments;
	private String taskType;
}
