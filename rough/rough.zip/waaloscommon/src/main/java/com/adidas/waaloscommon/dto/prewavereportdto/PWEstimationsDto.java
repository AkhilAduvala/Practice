package com.adidas.waaloscommon.dto.prewavereportdto;

import java.util.Map;

import lombok.Data;

@Data
public class PWEstimationsDto {
	private Map<String, Object> dPktInt2;
	private Map<String, Object> dPickLocnDtl;
	private Map<String, Object> dCartonSize;
	private Map<String, Object> dCartons;
	private IntSumMapFinalDto mapData;
	
}

