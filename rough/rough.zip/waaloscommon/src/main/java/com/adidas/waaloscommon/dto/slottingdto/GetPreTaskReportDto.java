/*
 * Copyright (C) 2017 adidas AG.
 */
package com.adidas.waaloscommon.dto.slottingdto;

import lombok.Data;

/**
 * The persistent class for Ate Sz Slotting Data sources.
 * 
 */
@Data
public class GetPreTaskReportDto {
private String spillOrder;
private String grpAttr;
private String count;
private String profiledWithFcEmpty;
private String profiledWithoutFcEmpty;
private String justEmpty;
private String totForWInv;
private String totNotForWInv;
private String numOfStyles;
private String numOfKits;
private String avgKitSize;
private String avgStyleCount;
}
