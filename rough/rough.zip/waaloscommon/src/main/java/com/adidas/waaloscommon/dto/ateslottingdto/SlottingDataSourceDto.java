/*
 * Copyright (C) 2017 adidas AG.
 */
package com.adidas.waaloscommon.dto.ateslottingdto;

import java.io.Serializable;

import lombok.Data;

/**
 * The persistent class for Sz Slotting Data sources.
 * 
 */
@Data
public class SlottingDataSourceDto implements Serializable{

	private String grpType;
	private String grpName;
	private String hasAssoc;
	private String hasTask;
	private String lastRun;
	private String statusDescription;
	private long lotId;
	private String statusCode;
}
