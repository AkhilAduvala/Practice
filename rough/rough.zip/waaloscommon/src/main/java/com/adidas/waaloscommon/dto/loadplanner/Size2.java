package com.adidas.waaloscommon.dto.loadplanner;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Size2
{
    private String ReceivedSize2;

    private String PlannedSize2;

    private String Size2UOM;

    private String ShippedSize2;

    public String getReceivedSize2 ()
    {
        return ReceivedSize2;
    }

    @XmlElement(name = "ReceivedSize2", required = true, nillable = true)
    public void setReceivedSize2 (String ReceivedSize2)
    {
        this.ReceivedSize2 = ReceivedSize2;
    }

    public String getPlannedSize2 ()
    {
        return PlannedSize2;
    }

    @XmlElement(name = "PlannedSize2", required = true, nillable = true)
    public void setPlannedSize2 (String PlannedSize2)
    {
        this.PlannedSize2 = PlannedSize2;
    }

    public String getSize2UOM ()
    {
        return Size2UOM;
    }

    @XmlElement(name = "Size2UOM", required = true, nillable = true)
    public void setSize2UOM (String Size2UOM)
    {
        this.Size2UOM = Size2UOM;
    }

    public String getShippedSize2 ()
    {
        return ShippedSize2;
    }

    @XmlElement(name = "ShippedSize2", required = true, nillable = true)
    public void setShippedSize2 (String ShippedSize2)
    {
        this.ShippedSize2 = ShippedSize2;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [ReceivedSize2 = "+ReceivedSize2+", PlannedSize2 = "+PlannedSize2+", Size2UOM = "+Size2UOM+", ShippedSize2 = "+ShippedSize2+"]";
    }
}
