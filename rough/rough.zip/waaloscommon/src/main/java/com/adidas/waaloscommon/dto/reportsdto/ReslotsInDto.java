package com.adidas.waaloscommon.dto.reportsdto;

import lombok.Data;

@Data
public class ReslotsInDto {
	private String locationId;
	private int reslotsIn;
	private String wrkGrp;
}
