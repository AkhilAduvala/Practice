package com.adidas.waaloscommon.dto.prewavereportdto;

import java.util.List;

import lombok.Data;

@Data
public class PWWavePlanningUpdatesDto {
	private String dcName;
	private String updateType;
	private List<String> prewaveNumbers;
	private List<String> pktNumbers;
}
