package com.adidas.waaloscommon.dto.ateslottingdto;

import java.util.List;

import lombok.Data;

@Data
public class ConfigurationsDto {

	public String zone;
	public String zoneType;
	public Integer priority;
	public Integer thresholdValue;
	public String inSeasonZoneConfig;
	public String outSeasonZoneConfig;
	public List<String> workGroups;
	public Integer daysTillSlot;
	public Integer reslotToReserveValue;
	public String prodTypes;
	public int noOfCases;
}
