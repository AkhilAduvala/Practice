package com.adidas.waaloscommon.dto.ateslottingdto;

import java.math.BigDecimal;

import lombok.Data;

@Data
public class TotalDcCasesDto {

	private String articleNo;
	private BigDecimal totalDcCases;
}
