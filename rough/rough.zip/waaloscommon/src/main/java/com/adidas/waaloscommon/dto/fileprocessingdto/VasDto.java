package com.adidas.waaloscommon.dto.fileprocessingdto;

import lombok.Data;

@Data
public class VasDto {
	
	private String soldToNmbr;
	private String vasCode;
	private String userId;
	private int lotId;

}