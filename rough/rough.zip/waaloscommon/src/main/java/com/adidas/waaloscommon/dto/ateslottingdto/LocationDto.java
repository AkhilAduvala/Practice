package com.adidas.waaloscommon.dto.ateslottingdto;

import java.util.Date;

import lombok.Data;

@Data
public class LocationDto {
	
	private String locnId;
	private String whse;
	private String locnClass;
	private String locnBrcd;
	private String area;
	private String zone;
	private String aisle;
	private String bay;
	private String level;
	private String posn;
	private String dspLocn;
	private String locnPickSeq;
	private String skuDedctnType;
	private String slotType;
	private String putwyZone;
	private String pullZone;
	private String pickDetrmZone;
	private Integer length;
	private Integer width;
	private Integer height;
	private Integer xCoord;
	private Integer yCoord;
	private Integer zCoord;
	private String 	workGrp;
	private String 	workArea;
	private Date lastFroznDateTime;
	private Date lastCntDateTime;
	private String cycleCntPending;
	private String prtLabelFlag;
	private String travelAisle;
	private String travelZone;
	private String storageUom;
	private String pickUom;
	private Date createDateTime;
	private Date modDateTime;
	private String userId;
	private String slotUnusable;
	private String checkDigit;
	private String vocoIntrnlReverseBrcd;
	private String locnPutwySeq;
	private String locnDynAssgnSeq;	
}
