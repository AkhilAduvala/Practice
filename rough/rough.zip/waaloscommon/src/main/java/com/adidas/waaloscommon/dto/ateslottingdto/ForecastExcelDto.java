package com.adidas.waaloscommon.dto.ateslottingdto;

import java.util.ArrayList;
import java.util.List;

import lombok.Data;

@Data
public class ForecastExcelDto {
	List<ForecastErrorDto> insertErrorLst = new ArrayList<ForecastErrorDto>();
	List<ForecastCurrentDto> insertSuccessLst = new ArrayList<ForecastCurrentDto>();

}
