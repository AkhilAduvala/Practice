package com.adidas.waaloscommon.dto.prewavereportdto;

import java.util.List;
import java.util.Map;

import lombok.Data;

@Data
public class PWTransPlanningDto {
	private List<TransPlanModeDto> estCartonModeData;
	private List<TransPlanShipViaDto> estCartonShipviaData;
}

