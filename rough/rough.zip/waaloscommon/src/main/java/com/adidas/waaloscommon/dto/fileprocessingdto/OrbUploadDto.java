package com.adidas.waaloscommon.dto.fileprocessingdto;
import lombok.Data;
import java.util.Date;
@Data
public class OrbUploadDto {
	private String orderid;
	private Date pgiStartDate;
	private Date pgiEndDate;
	private Date rddEndDatetime;
	private String shipVia;
	private String RteTo;
	private String Rte1;
	private String Rte2;
	private Integer rowNum;
	private String orbErrorMessage;
	private String errorType;
	private String errorMessage;	
    private Date stagedDateTime;
    private String lineHaulShipVia;
    private String orderType;
    private String waveMarking;
    private String zipCode;
}
