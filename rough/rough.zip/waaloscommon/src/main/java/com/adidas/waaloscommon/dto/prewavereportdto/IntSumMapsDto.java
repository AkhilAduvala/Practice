package com.adidas.waaloscommon.dto.prewavereportdto;

import java.util.List;
import java.util.Map;

import lombok.Data;

@Data
public class IntSumMapsDto {
	private List<Map<String, Integer>> d_pkt_int2;
	private List<Map<String, Integer>> d_ship_via;
	private List<Map<String, Integer>> d_int2_cases;
	private List<Map<String, Integer>> d_vas_int2_cases;
	private List<Map<String, Integer>> d_vas_int2_units;
	private List<Map<String, Integer>> d_int150_units;
	private List<Map<String, Integer>> d_int1_cases;
	private List<Map<String, Integer>> d_int2_units;
	private List<Map<String, Integer>> d_int1_units;
	private List<Map<String, Integer>> d_int50_cases;
	private List<Map<String, Integer>> d_int50_units;
	private List<Map<String, Integer>> d_cartons;
	private List<Map<String, Integer>> d_missing_inventory;
	private int v_missing_inventory;
	private int v_missing_dims; 
	private int v_locns_needed;
}

