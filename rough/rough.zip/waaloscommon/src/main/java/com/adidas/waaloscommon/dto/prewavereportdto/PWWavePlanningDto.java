package com.adidas.waaloscommon.dto.prewavereportdto;

import java.util.List;
import java.util.Map;

import lombok.Data;

@Data
public class PWWavePlanningDto {
	private Map<String, Object> cusSuppliedLabelData;
	private Map<String, Object> specVASWorkStationData;
	private Map<String, Object> repacksCartonData;
	private Map<String, Object> fullCasesData;
	private Map<String, Object> vasOutboundPrepData;
	private Map<String, Object> looseUnitsByArea;
	private List<WavePlanEstCubingDto> estCubingData;
}

