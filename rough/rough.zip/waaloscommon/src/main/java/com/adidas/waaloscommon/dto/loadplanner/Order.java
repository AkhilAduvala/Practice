package com.adidas.waaloscommon.dto.loadplanner;

import java.util.Date;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement
public class Order
{
    private String Product_Class_Code;

    private String Is_Perishable;

    private String Compartment;

    private String Origin_Postal_Code;

    private String TC_Order_ID;
    
    private Date Pickup_Start;
    
    private Date Pickup_End;
    
    private Date Delivery_Start;
    
    private Date Delivery_End;

    private String Movement_Option;
    
    private  String Billing_Method_Code;

	private String Commodity_Code;

    private String Origin_State_Prov;

    private String Designated_Service_Level;

    private String Destination_Address;

    private String Order_Type;

    private String Designated_Tractor_Code;

    private String Origin_City;

    private String Monetary_Value;

    private String Is_Acceptance_Required;

    private String Actual_Cost;

    private String BOL_Number;

    private String Designated_Driver_Type;

    private String Loading_Sequence;

    private String Priority;

    private String Is_Direct_Allowed;

    private String Designated_Mode_Code;

    private String Planning_Destination;

    private Line_Item[] Line_Item;

    private String Wave;

    private String Purchase_Order;

    private String Destination_City;

    private String Business_Unit;

    private String Business_Partner_Code;

    private String Budgeted_Cost;

    private String Designated_Equipment_Code;

    private String Is_Customer_Pickup;

    private String Num_Splits;

    private String Parent_Order_ID;

    private String Prod_Sched_Ref_Number;

    private String Reference_Number;

    private String Is_Partially_Planned;

    private String Destination_County;

    private String Origin_Address;

    private String Destination_Dock_ID;

    private String Destination_Postal_Code;

    private String Origin_County;

    private String Shipper_ID;

    private String UN_Number;

    private String Order_Split_Seq;

    private String Protection_Level_Code;

    private String Destination_Facility_Alias_ID;

    private String Is_Hazmat;

    private String Block_Auto_Create;

    private String Origin_Country_Code;

    private String Is_On_Multiple_Shipments;

    private String Origin_Facility_Alias_ID;

    private String[] Commodity_Size;

    private String Designated_Carrier_Code;

    private String Planning_Origin;

    private String External_System_Order_ID;

    private String Block_Auto_Consolidate;

    private String Origin_Dock_ID;

    private String Wave_Option;

    private String Incoterm_Name;

    private String WMS_Status;

    private String Destination_Country_Code;

    private String Destination_State_Prov;

    public String getProduct_Class_Code ()
    {
        return Product_Class_Code;
    }

    @XmlElement(name = "Product_Class_Code", required = true, nillable = true)
    public void setProduct_Class_Code (String Product_Class_Code)
    {
        this.Product_Class_Code = Product_Class_Code;
    }

    public String getIs_Perishable ()
    {
        return Is_Perishable;
    }

    @XmlElement(name = "Is_Perishable", required = true, nillable = true)
    public void setIs_Perishable (String Is_Perishable)
    {
        this.Is_Perishable = Is_Perishable;
    }

    public String getCompartment ()
    {
        return Compartment;
    }

    @XmlElement(name = "Compartment", required = true, nillable = true)
    public void setCompartment (String Compartment)
    {
        this.Compartment = Compartment;
    }

    public String getOrigin_Postal_Code ()
    {
        return Origin_Postal_Code;
    }

    @XmlElement(name = "Origin_Postal_Code", required = true, nillable = true)
    public void setOrigin_Postal_Code (String Origin_Postal_Code)
    {
        this.Origin_Postal_Code = Origin_Postal_Code;
    }

    public String getTC_Order_ID ()
    {
        return TC_Order_ID;
    }

    @XmlElement(name = "TC_Order_ID", required = true, nillable = true)
    public void setTC_Order_ID (String TC_Order_ID)
    {
        this.TC_Order_ID = TC_Order_ID;
    }
    public Date getPickup_Start() {
		return Pickup_Start;
	}

    @XmlElement(name = "pickup_Start", required = true, nillable = true)
	public void setPickup_Start(Date pickup_Start) {
		Pickup_Start = pickup_Start;
	}

	public Date getPickup_End() {
		return Pickup_End;
	}

	@XmlElement(name = "pickup_End", required = true, nillable = true)
	public void setPickup_End(Date pickup_End) {
		Pickup_End = pickup_End;
	}

	public Date getDelivery_Start() {
		return Delivery_Start;
	}

	@XmlElement(name = "delivery_Start", required = true, nillable = true)
	public void setDelivery_Start(Date delivery_Start) {
		Delivery_Start = delivery_Start;
	}

	public Date getDelivery_End() {
		return Delivery_End;
	}

	@XmlElement(name = "delivery_End", required = true, nillable = true)
	public void setDelivery_End(Date delivery_End) {
		Delivery_End = delivery_End;
	}
	
	public String getMovement_Option() {
		return Movement_Option;
	}

	@XmlElement(name = "movement_Option", required = true, nillable = true)
	public void setMovement_Option(String movement_Option) {
		Movement_Option = movement_Option;
	}

	public String getBilling_Method_Code() {
		return Billing_Method_Code;
	}

	@XmlElement(name = "billing_Method_Code", required = true, nillable = true)
	public void setBilling_Method_Code(String billing_Method_Code) {
		Billing_Method_Code = billing_Method_Code;
	}

    public String getCommodity_Code ()
    {
        return Commodity_Code;
    }

    @XmlElement(name = "Commodity_Code", required = true, nillable = true)
    public void setCommodity_Code (String Commodity_Code)
    {
        this.Commodity_Code = Commodity_Code;
    }

    public String getOrigin_State_Prov ()
    {
        return Origin_State_Prov;
    }

    @XmlElement(name = "Origin_State_Prov", required = true, nillable = true)
    public void setOrigin_State_Prov (String Origin_State_Prov)
    {
        this.Origin_State_Prov = Origin_State_Prov;
    }

    public String getDesignated_Service_Level ()
    {
        return Designated_Service_Level;
    }

    @XmlElement(name = "Designated_Service_Level", required = true, nillable = true)
    public void setDesignated_Service_Level (String Designated_Service_Level)
    {
        this.Designated_Service_Level = Designated_Service_Level;
    }

    public String getDestination_Address ()
    {
        return Destination_Address;
    }

    @XmlElement(name = "Destination_Address", required = true, nillable = true)
    public void setDestination_Address (String Destination_Address)
    {
        this.Destination_Address = Destination_Address;
    }

    public String getOrder_Type ()
    {
        return Order_Type;
    }

    @XmlElement(name = "Order_Type", required = true, nillable = true)
    public void setOrder_Type (String Order_Type)
    {
        this.Order_Type = Order_Type;
    }

    public String getDesignated_Tractor_Code ()
    {
        return Designated_Tractor_Code;
    }

    @XmlElement(name = "Designated_Tractor_Code", required = true, nillable = true)
    public void setDesignated_Tractor_Code (String Designated_Tractor_Code)
    {
        this.Designated_Tractor_Code = Designated_Tractor_Code;
    }

    public String getOrigin_City ()
    {
        return Origin_City;
    }

    @XmlElement(name = "Origin_City", required = true, nillable = true)
    public void setOrigin_City (String Origin_City)
    {
        this.Origin_City = Origin_City;
    }

    public String getMonetary_Value ()
    {
        return Monetary_Value;
    }

    @XmlElement(name = "Monetary_Value", required = true, nillable = true)
    public void setMonetary_Value (String Monetary_Value)
    {
        this.Monetary_Value = Monetary_Value;
    }

    public String getIs_Acceptance_Required ()
    {
        return Is_Acceptance_Required;
    }

    @XmlElement(name = "Is_Acceptance_Required", required = true, nillable = true)
    public void setIs_Acceptance_Required (String Is_Acceptance_Required)
    {
        this.Is_Acceptance_Required = Is_Acceptance_Required;
    }

    public String getActual_Cost ()
    {
        return Actual_Cost;
    }

    @XmlElement(name = "Actual_Cost", required = true, nillable = true)
    public void setActual_Cost (String Actual_Cost)
    {
        this.Actual_Cost = Actual_Cost;
    }

    public String getBOL_Number ()
    {
        return BOL_Number;
    }

    @XmlElement(name = "BOL_Number", required = true, nillable = true)
    public void setBOL_Number (String BOL_Number)
    {
        this.BOL_Number = BOL_Number;
    }

    public String getDesignated_Driver_Type ()
    {
        return Designated_Driver_Type;
    }

    @XmlElement(name = "Designated_Driver_Type", required = true, nillable = true)
    public void setDesignated_Driver_Type (String Designated_Driver_Type)
    {
        this.Designated_Driver_Type = Designated_Driver_Type;
    }

    public String getLoading_Sequence ()
    {
        return Loading_Sequence;
    }

    @XmlElement(name = "Loading_Sequence", required = true, nillable = true)
    public void setLoading_Sequence (String Loading_Sequence)
    {
        this.Loading_Sequence = Loading_Sequence;
    }

    public String getPriority ()
    {
        return Priority;
    }

    @XmlElement(name = "Priority", required = true, nillable = true)
    public void setPriority (String Priority)
    {
        this.Priority = Priority;
    }

    public String getIs_Direct_Allowed ()
    {
        return Is_Direct_Allowed;
    }

    @XmlElement(name = "Is_Direct_Allowed", required = true, nillable = true)
    public void setIs_Direct_Allowed (String Is_Direct_Allowed)
    {
        this.Is_Direct_Allowed = Is_Direct_Allowed;
    }

    public String getDesignated_Mode_Code ()
    {
        return Designated_Mode_Code;
    }

    @XmlElement(name = "Designated_Mode_Code", required = true, nillable = true)
    public void setDesignated_Mode_Code (String Designated_Mode_Code)
    {
        this.Designated_Mode_Code = Designated_Mode_Code;
    }

    public String getPlanning_Destination ()
    {
        return Planning_Destination;
    }

    @XmlElement(name = "Planning_Destination", required = true, nillable = true)
    public void setPlanning_Destination (String Planning_Destination)
    {
        this.Planning_Destination = Planning_Destination;
    }

    public Line_Item[] getLine_Item ()
    {
        return Line_Item;
    }

    @XmlElement(name = "Line_Item", required = true, nillable = true)
    public void setLine_Item (Line_Item[] Line_Item)
    {
        this.Line_Item = Line_Item;
    }

    public String getWave ()
    {
        return Wave;
    }

    @XmlElement(name = "Wave", required = true, nillable = true)
    public void setWave (String Wave)
    {
        this.Wave = Wave;
    }

    public String getPurchase_Order ()
    {
        return Purchase_Order;
    }

    @XmlElement(name = "Purchase_Order", required = true, nillable = true)
    public void setPurchase_Order (String Purchase_Order)
    {
        this.Purchase_Order = Purchase_Order;
    }

    public String getDestination_City ()
    {
        return Destination_City;
    }

    @XmlElement(name = "Destination_City", required = true, nillable = true)
    public void setDestination_City (String Destination_City)
    {
        this.Destination_City = Destination_City;
    }

    public String getBusiness_Unit ()
    {
        return Business_Unit;
    }

    @XmlElement(name = "Business_Unit", required = true, nillable = true)
    public void setBusiness_Unit (String Business_Unit)
    {
        this.Business_Unit = Business_Unit;
    }

    public String getBusiness_Partner_Code ()
    {
        return Business_Partner_Code;
    }

    @XmlElement(name = "Business_Partner_Code", required = true, nillable = true)
    public void setBusiness_Partner_Code (String Business_Partner_Code)
    {
        this.Business_Partner_Code = Business_Partner_Code;
    }

    public String getBudgeted_Cost ()
    {
        return Budgeted_Cost;
    }

    @XmlElement(name = "Budgeted_Cost", required = true, nillable = true)
    public void setBudgeted_Cost (String Budgeted_Cost)
    {
        this.Budgeted_Cost = Budgeted_Cost;
    }

    public String getDesignated_Equipment_Code ()
    {
        return Designated_Equipment_Code;
    }

    @XmlElement(name = "Designated_Equipment_Code", required = true, nillable = true)
    public void setDesignated_Equipment_Code (String Designated_Equipment_Code)
    {
        this.Designated_Equipment_Code = Designated_Equipment_Code;
    }

    public String getIs_Customer_Pickup ()
    {
        return Is_Customer_Pickup;
    }

    @XmlElement(name = "Is_Customer_Pickup", required = true, nillable = true)
    public void setIs_Customer_Pickup (String Is_Customer_Pickup)
    {
        this.Is_Customer_Pickup = Is_Customer_Pickup;
    }

    public String getNum_Splits ()
    {
        return Num_Splits;
    }

    @XmlElement(name = "Num_Splits", required = true, nillable = true)
    public void setNum_Splits (String Num_Splits)
    {
        this.Num_Splits = Num_Splits;
    }

    public String getParent_Order_ID ()
    {
        return Parent_Order_ID;
    }

    @XmlElement(name = "Parent_Order_ID", required = true, nillable = true)
    public void setParent_Order_ID (String Parent_Order_ID)
    {
        this.Parent_Order_ID = Parent_Order_ID;
    }

    public String getProd_Sched_Ref_Number ()
    {
        return Prod_Sched_Ref_Number;
    }

    @XmlElement(name = "Prod_Sched_Ref_Number", required = true, nillable = true)
    public void setProd_Sched_Ref_Number (String Prod_Sched_Ref_Number)
    {
        this.Prod_Sched_Ref_Number = Prod_Sched_Ref_Number;
    }

    public String getReference_Number ()
    {
        return Reference_Number;
    }

    @XmlElement(name = "Reference_Number", required = true, nillable = true)
    public void setReference_Number (String Reference_Number)
    {
        this.Reference_Number = Reference_Number;
    }

    public String getIs_Partially_Planned ()
    {
        return Is_Partially_Planned;
    }

    @XmlElement(name = "Is_Partially_Planned", required = true, nillable = true)
    public void setIs_Partially_Planned (String Is_Partially_Planned)
    {
        this.Is_Partially_Planned = Is_Partially_Planned;
    }

    public String getDestination_County ()
    {
        return Destination_County;
    }

    @XmlElement(name = "Destination_County", required = true, nillable = true)
    public void setDestination_County (String Destination_County)
    {
        this.Destination_County = Destination_County;
    }

    public String getOrigin_Address ()
    {
        return Origin_Address;
    }

    @XmlElement(name = "Origin_Address", required = true, nillable = true)
    public void setOrigin_Address (String Origin_Address)
    {
        this.Origin_Address = Origin_Address;
    }

    public String getDestination_Dock_ID ()
    {
        return Destination_Dock_ID;
    }

    @XmlElement(name = "Destination_Dock_ID", required = true, nillable = true)
    public void setDestination_Dock_ID (String Destination_Dock_ID)
    {
        this.Destination_Dock_ID = Destination_Dock_ID;
    }

    public String getDestination_Postal_Code ()
    {
        return Destination_Postal_Code;
    }

    @XmlElement(name = "Destination_Postal_Code", required = true, nillable = true)
    public void setDestination_Postal_Code (String Destination_Postal_Code)
    {
        this.Destination_Postal_Code = Destination_Postal_Code;
    }

    public String getOrigin_County ()
    {
        return Origin_County;
    }

    @XmlElement(name = "Origin_County", required = true, nillable = true)
    public void setOrigin_County (String Origin_County)
    {
        this.Origin_County = Origin_County;
    }

    public String getShipper_ID ()
    {
        return Shipper_ID;
    }

    @XmlElement(name = "Shipper_ID", required = true, nillable = true)
    public void setShipper_ID (String Shipper_ID)
    {
        this.Shipper_ID = Shipper_ID;
    }

    public String getUN_Number ()
    {
        return UN_Number;
    }

    @XmlElement(name = "UN_Number", required = true, nillable = true)
    public void setUN_Number (String UN_Number)
    {
        this.UN_Number = UN_Number;
    }

    public String getOrder_Split_Seq ()
    {
        return Order_Split_Seq;
    }

    @XmlElement(name = "Order_Split_Seq", required = true, nillable = true)
    public void setOrder_Split_Seq (String Order_Split_Seq)
    {
        this.Order_Split_Seq = Order_Split_Seq;
    }

    public String getProtection_Level_Code ()
    {
        return Protection_Level_Code;
    }

    @XmlElement(name = "Protection_Level_Code", required = true, nillable = true)
    public void setProtection_Level_Code (String Protection_Level_Code)
    {
        this.Protection_Level_Code = Protection_Level_Code;
    }

    public String getDestination_Facility_Alias_ID ()
    {
        return Destination_Facility_Alias_ID;
    }

    @XmlElement(name = "Destination_Facility_Alias_ID", required = true, nillable = true)
    public void setDestination_Facility_Alias_ID (String Destination_Facility_Alias_ID)
    {
        this.Destination_Facility_Alias_ID = Destination_Facility_Alias_ID;
    }

    public String getIs_Hazmat ()
    {
        return Is_Hazmat;
    }

    @XmlElement(name = "Is_Hazmat", required = true, nillable = true)
    public void setIs_Hazmat (String Is_Hazmat)
    {
        this.Is_Hazmat = Is_Hazmat;
    }

    public String getBlock_Auto_Create ()
    {
        return Block_Auto_Create;
    }

    @XmlElement(name = "Block_Auto_Create", required = true, nillable = true)
    public void setBlock_Auto_Create (String Block_Auto_Create)
    {
        this.Block_Auto_Create = Block_Auto_Create;
    }

    public String getOrigin_Country_Code ()
    {
        return Origin_Country_Code;
    }

    @XmlElement(name = "Origin_Country_Code", required = true, nillable = true)
    public void setOrigin_Country_Code (String Origin_Country_Code)
    {
        this.Origin_Country_Code = Origin_Country_Code;
    }

    public String getIs_On_Multiple_Shipments ()
    {
        return Is_On_Multiple_Shipments;
    }

    @XmlElement(name = "Is_On_Multiple_Shipments", required = true, nillable = true)
    public void setIs_On_Multiple_Shipments (String Is_On_Multiple_Shipments)
    {
        this.Is_On_Multiple_Shipments = Is_On_Multiple_Shipments;
    }

    public String getOrigin_Facility_Alias_ID ()
    {
        return Origin_Facility_Alias_ID;
    }

    @XmlElement(name = "Origin_Facility_Alias_ID", required = true, nillable = true)
    public void setOrigin_Facility_Alias_ID (String Origin_Facility_Alias_ID)
    {
        this.Origin_Facility_Alias_ID = Origin_Facility_Alias_ID;
    }

    public String[] getCommodity_Size ()
    {
        return Commodity_Size;
    }

    @XmlElement(name = "Commodity_Size", required = true, nillable = true)
    public void setCommodity_Size (String[] Commodity_Size)
    {
        this.Commodity_Size = Commodity_Size;
    }

    public String getDesignated_Carrier_Code ()
    {
        return Designated_Carrier_Code;
    }

    @XmlElement(name = "Designated_Carrier_Code", required = true, nillable = true)
    public void setDesignated_Carrier_Code (String Designated_Carrier_Code)
    {
        this.Designated_Carrier_Code = Designated_Carrier_Code;
    }

    public String getPlanning_Origin ()
    {
        return Planning_Origin;
    }

    @XmlElement(name = "Planning_Origin", required = true, nillable = true)
    public void setPlanning_Origin (String Planning_Origin)
    {
        this.Planning_Origin = Planning_Origin;
    }

    public String getExternal_System_Order_ID ()
    {
        return External_System_Order_ID;
    }

    @XmlElement(name = "External_System_Order_ID", required = true, nillable = true)
    public void setExternal_System_Order_ID (String External_System_Order_ID)
    {
        this.External_System_Order_ID = External_System_Order_ID;
    }

    public String getBlock_Auto_Consolidate ()
    {
        return Block_Auto_Consolidate;
    }

    @XmlElement(name = "Block_Auto_Consolidate", required = true, nillable = true)
    public void setBlock_Auto_Consolidate (String Block_Auto_Consolidate)
    {
        this.Block_Auto_Consolidate = Block_Auto_Consolidate;
    }

    public String getOrigin_Dock_ID ()
    {
        return Origin_Dock_ID;
    }

    @XmlElement(name = "Origin_Dock_ID", required = true, nillable = true)
    public void setOrigin_Dock_ID (String Origin_Dock_ID)
    {
        this.Origin_Dock_ID = Origin_Dock_ID;
    }

    public String getWave_Option ()
    {
        return Wave_Option;
    }

    @XmlElement(name = "Wave_Option", required = true, nillable = true)
    public void setWave_Option (String Wave_Option)
    {
        this.Wave_Option = Wave_Option;
    }

    public String getIncoterm_Name ()
    {
        return Incoterm_Name;
    }

    @XmlElement(name = "Incoterm_Name", required = true, nillable = true)
    public void setIncoterm_Name (String Incoterm_Name)
    {
        this.Incoterm_Name = Incoterm_Name;
    }

    public String getWMS_Status ()
    {
        return WMS_Status;
    }

    @XmlElement(name = "WMS_Status", required = true, nillable = true)
    public void setWMS_Status (String WMS_Status)
    {
        this.WMS_Status = WMS_Status;
    }

    public String getDestination_Country_Code ()
    {
        return Destination_Country_Code;
    }

    @XmlElement(name = "Destination_Country_Code", required = true, nillable = true)
    public void setDestination_Country_Code (String Destination_Country_Code)
    {
        this.Destination_Country_Code = Destination_Country_Code;
    }

    public String getDestination_State_Prov ()
    {
        return Destination_State_Prov;
    }

    @XmlElement(name = "Destination_State_Prov", required = true, nillable = true)
    public void setDestination_State_Prov (String Destination_State_Prov)
    {
        this.Destination_State_Prov = Destination_State_Prov;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Product_Class_Code = "+Product_Class_Code+", Is_Perishable = "+Is_Perishable+", Compartment = "+Compartment+", Origin_Postal_Code = "+Origin_Postal_Code+", TC_Order_ID = "+TC_Order_ID+", Commodity_Code = "+Commodity_Code+", Origin_State_Prov = "+Origin_State_Prov+", Designated_Service_Level = "+Designated_Service_Level+", Destination_Address = "+Destination_Address+", Order_Type = "+Order_Type+", Designated_Tractor_Code = "+Designated_Tractor_Code+", Origin_City = "+Origin_City+", Monetary_Value = "+Monetary_Value+", Is_Acceptance_Required = "+Is_Acceptance_Required+", Actual_Cost = "+Actual_Cost+", BOL_Number = "+BOL_Number+", Designated_Driver_Type = "+Designated_Driver_Type+", Loading_Sequence = "+Loading_Sequence+", Priority = "+Priority+", Is_Direct_Allowed = "+Is_Direct_Allowed+", Designated_Mode_Code = "+Designated_Mode_Code+", Planning_Destination = "+Planning_Destination+", Line_Item = "+Line_Item+", Wave = "+Wave+", Purchase_Order = "+Purchase_Order+", Destination_City = "+Destination_City+", Business_Unit = "+Business_Unit+", Business_Partner_Code = "+Business_Partner_Code+", Budgeted_Cost = "+Budgeted_Cost+", Designated_Equipment_Code = "+Designated_Equipment_Code+", Is_Customer_Pickup = "+Is_Customer_Pickup+", Num_Splits = "+Num_Splits+", Parent_Order_ID = "+Parent_Order_ID+", Prod_Sched_Ref_Number = "+Prod_Sched_Ref_Number+", Reference_Number = "+Reference_Number+", Is_Partially_Planned = "+Is_Partially_Planned+", Destination_County = "+Destination_County+", Origin_Address = "+Origin_Address+", Destination_Dock_ID = "+Destination_Dock_ID+", Destination_Postal_Code = "+Destination_Postal_Code+", Origin_County = "+Origin_County+", Shipper_ID = "+Shipper_ID+", UN_Number = "+UN_Number+", Order_Split_Seq = "+Order_Split_Seq+", Protection_Level_Code = "+Protection_Level_Code+", Destination_Facility_Alias_ID = "+Destination_Facility_Alias_ID+", Is_Hazmat = "+Is_Hazmat+", Block_Auto_Create = "+Block_Auto_Create+", Origin_Country_Code = "+Origin_Country_Code+", Is_On_Multiple_Shipments = "+Is_On_Multiple_Shipments+", Origin_Facility_Alias_ID = "+Origin_Facility_Alias_ID+", Commodity_Size = "+Commodity_Size+", Designated_Carrier_Code = "+Designated_Carrier_Code+", Planning_Origin = "+Planning_Origin+", External_System_Order_ID = "+External_System_Order_ID+", Block_Auto_Consolidate = "+Block_Auto_Consolidate+", Origin_Dock_ID = "+Origin_Dock_ID+", Wave_Option = "+Wave_Option+", Incoterm_Name = "+Incoterm_Name+", WMS_Status = "+WMS_Status+", Destination_Country_Code = "+Destination_Country_Code+", Destination_State_Prov = "+Destination_State_Prov+"]";
    }
}
	
