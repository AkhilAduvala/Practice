package com.adidas.waaloscommon.dto.prewavereportdto;

import lombok.Data;

@Data
public class PWMissingInvDto {

	private String pick_wave_nbr; 
	 private String pkt_ctrl_nbr; 
	 private String dsp_sku; 
	 private String season; 
	 private String style; 
	 private String style_sfx; 
	 private String color; 
	 private String color_sfx; 
	 private String size_desc; 
	 private String code_desc; 
	 private String qty;
}

