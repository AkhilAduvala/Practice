package com.adidas.waaloscommon.dto.reportsdto;

import lombok.Data;

@Data
public class AvgSizeOfKitsDto {
	
	private String locationId;
	private Double avgSizeOfKits;
	private String wrkGrp;
}
