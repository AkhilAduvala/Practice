package com.adidas.waaloscommon.dto.ateslottingdto;

import java.util.List;

import lombok.Data;

@Data
public class SlottingConfigDto extends BaseDto{

	Integer thresholdValue;
	List<SlottingZonesDto> slottingZonesDtoList;
}
