package com.adidas.waaloscommon.dto.loadplanner;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement
public class tXML {
	private Message Message;
	private Header Header;
	
	public Message getMessage() {
		return Message;
	}
	@XmlElement(name = "Message", required = true, nillable = true)
	public void setMessage(Message message) {
		Message = message;
	}
	public Header getHeader() {
		return Header;
	}
	@XmlElement(name = "Header", required = true, nillable = true)
	public void setHeader(Header header) {
		Header = header;
	}
	

}
