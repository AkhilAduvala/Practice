package com.adidas.waaloscommon.dto.fileprocessingdto;

import com.google.gson.annotations.Expose;

import lombok.Data;

@Data
public class CustomerLoaderDto {
	@Expose
	private String rowNum;
	@Expose
	private String ean;
	@Expose (serialize = false, deserialize = false)
	private String splInstrCode;
	@Expose (serialize = false, deserialize = false)
	private String splInstrDesc;
	@Expose (serialize = false, deserialize = false)
	private String soldTo;
	@Expose
	private String custPoNbr;
	@Expose
	private String pktCtrlNbr;
	@Expose
	private String style;
	@Expose (serialize = false, deserialize = false)
	private String color;
	@Expose (serialize = false, deserialize = false)
	private String custName;
	@Expose (serialize = false, deserialize = false)
	private String userId;
	@Expose (serialize = false, deserialize = false)
	private String shipTo;
	@Expose (serialize = false, deserialize = false)
	private long lotId;
	@Expose
	private String errorType;
	@Expose
	private String errorMessage;
	@Expose
	private String size;
}
